/**
 * 1758渠道
 */
class H5_1758_Sdk {
	/**渠道编号 */
	public sdkIndex = "303";
	/**sdk地址 */
	public sdkUrl: string = "//res.1758.com/sdk/js/1758sdk.js";
	/**gid */
	public gid: string;
	/** appKey*/
	public appKey: string;
	/**hlmy_gw 1758平台自定义参数*/
	public hlmy_gw: string;
	/**用户信息 */
	public playerInfo: any;
	/**用户凭证 */
	public userToken: string;
	/**hlmysdk 1758平台自定义参数*/
	public hlmysdk: any;

	/**关注状态 /0为未关注，1为已关注*/
	public follow: number;

	//单例
	private static instance: H5_1758_Sdk;
	public static getInstance(): H5_1758_Sdk {
		if (this.instance == null) {
			this.instance = new H5_1758_Sdk();
		}
		return this.instance;
	}


	public constructor() {
		this.hlmy_gw = egret.getOption("hlmy_gw");
		this.userToken = egret.getOption("userToken");
		this.appKey = egret.getOption("appKey");
		GameLog.log("1758hlmy_gw" + this.hlmy_gw);
		GameLog.log("1758userToken" + this.userToken);
		GameLog.log("1758appKey" + this.appKey);
	}


	/**加载4177的sdk*/
	public loadSdk(callback) {
		loadSingleScript(this.sdkUrl, function () {
			GameLog.log("H5_1758_Sdk >> 加载H5_1758_Sdk完成");


			//获取用户信息
			var hlmysdk = window["HLMY_SDK"];
			// var authData = {
			// 	appKey: H5_1758_Sdk.getInstance().appKey,
			// 	hlmy_gw: H5_1758_Sdk.getInstance().hlmy_gw,
			// 	userToken: H5_1758_Sdk.getInstance().userToken,
			// 	callback: function (data) {
			// 		GameLog.log(data);
			// 		H5_1758_Sdk.getInstance().playerInfo = data;
			// 	}
			// }
			// hlmysdk.auth(authData);

			let playerInfo = H5_1758_Sdk.getInstance().playerInfo;
			GameLog.log(playerInfo);

			H5_1758_Sdk.getInstance().gid = playerInfo.userdata.uid;

			//sdk初始化	
			H5_1758_Sdk.getInstance().hlmysdk = hlmysdk;
			H5_1758_Sdk.getInstance().hlmysdk.init({
				"gid": H5_1758_Sdk.getInstance().gid,
				"appKey": H5_1758_Sdk.getInstance().appKey,
				"hlmy_gw": H5_1758_Sdk.getInstance().hlmy_gw
			});

			callback();
		});
	}
}