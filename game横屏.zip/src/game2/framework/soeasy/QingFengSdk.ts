declare let xgGame:any;    //清风sdk实例

/**
 * 清风渠道SDK  (单例类)
 * @author chenkai 2018/3/21
 */
class QingFengSdk {
    /**渠道编号 */
    public sdkIndex = "10448";
	/**sdk地址 */
    public sdkUrl: string = "http://h5.520cai.com/Public/static/xigusdk/xgh5sdk.js";
	/**游戏编号 */
    public game_appid:string;   
	/**清风 登录模块名   */
    public sdkloginmodel:string;  
	/**是否显示过公告 */
	public isNoticed:boolean = false;

	public constructor(){
		//从链接上获取透传参数
		this.game_appid = egret.getOption("game_appid");
		this.sdkloginmodel = egret.getOption("sdkloginmodel");
	}

	/**加载清风的sdk */
	public loadSdk(callback){
		loadSingleScript(this.sdkUrl, function () {
			GameLog.log("QingFengSdk >> 加载清风游戏sdk完成");
			callback();
		});
	}

	/**调用清风渠道游戏公告 */
    public noticeSdk(){
		if(this.isNoticed){
			return;
		}

		if(SoEasySdk.isCurChannel(SoEasySdk.channelList.qingFeng) == false){
			return;
		}

		this.isNoticed = true;

        xgGame.noticeSdk({game_appid:this.game_appid,sdkloginmodel:this.sdkloginmodel},function(data){
          GameLog.log("QingFengSdk >> 清风游戏公告:", data);
        });
    }

	//单例
	private static instance:QingFengSdk;
	public static getInstance():QingFengSdk{
		if(this.instance == null){
			this.instance = new QingFengSdk();
		}
		return this.instance;
	}
	
	
}


var loadSingleScript = function (src, callback) {
    var s = document.createElement('script');
    s.async = false;
    s.src = src;
    s.addEventListener('load', function () {
        s.parentNode.removeChild(s);
        // s.removeEventListener('load', arguments.callee, false);
        callback();
    }, false);
    document.body.appendChild(s);
};