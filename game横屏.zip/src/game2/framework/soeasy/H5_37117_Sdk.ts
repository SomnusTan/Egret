declare class Game37117 {
	constructor(obj: any);
	public Ready();
};
/**37117渠道 */
class H5_37117_Sdk {

	/**渠道编号 */
	public sdkIndex = "10303";
	/**游戏编号 */
	public game_appid: string;
	/**sdk地址 */
	public sdkUrl: string = "http://m.37117c.com/Scripts/GameLib.v1.js";
	/**游戏密码*/
	public game_appkey: string;
	/**37117用户 token */
	public game_token: string;
	/**游戏id */
	public game_id: number = 130;

	public Debug: boolean = true;

	//单例
	private static instance: H5_37117_Sdk;
	public static getInstance(): H5_37117_Sdk {
		if (this.instance == null) {
			this.instance = new H5_37117_Sdk();
		}
		return this.instance;
	}

	constructor() {
		//从链接上获取透传参数
		this.game_token = egret.getOption("Token");
		
		GameLog.log("this.game_token    " + this.game_token);
		GameLog.log("this.game_uid      " + this.game_id);
		GameLog.log("this.Debug         " + this.Debug);
	}

	/**加载37117的sdk */
	public loadSdk(callback) {
		loadSingleScript(this.sdkUrl, function () {
			GameLog.log("H5_37117_Sdk >> 加载H5_37117_Sdk完成");
			var g37SDk = new Game37117({
				"GameID": H5_37117_Sdk.getInstance().game_id,
				"Token": H5_37117_Sdk.getInstance().game_token,
				"Debug": H5_37117_Sdk.getInstance().Debug
			});
			g37SDk.Ready();
			callback();
		});
	}
}

var loadSingleScript = function (src, callback) {
	var s = document.createElement('script');
	s.async = false;
	s.src = src;
	s.addEventListener('load', function () {
		s.parentNode.removeChild(s);
		callback();
	}, false);
	document.body.appendChild(s);
};