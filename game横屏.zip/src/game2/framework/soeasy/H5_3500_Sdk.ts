/**3500渠道 */
class H5_3500_Sdk {

	/**渠道编号 */
	public sdkIndex = "10217";
	/**游戏编号 */
	public game_appid: string;
	/**sdk地址 */
	public sdkUrl: string = "http://www.3500.com/statics/js/lib.v1.js";
	/**游戏密码*/
	public game_appkey: string;
	/**3500用户 token */
	public game_token: string;
	/**游戏uid */
	public game_uid: string;
	/** */
	public game35: any;


	//单例
	private static instance: H5_3500_Sdk;
	public static getInstance(): H5_3500_Sdk {
		if (this.instance == null) {
			this.instance = new H5_3500_Sdk();
		}
		return this.instance;
	}

	public constructor() {
		//从链接上获取透传参数
		this.game_token = egret.getOption("token");
		this.game_uid = egret.getOption("uid");

	}


	/**加载3500的sdk */
	public loadSdk(callback) {
		loadSingleScript(this.sdkUrl, function () {
			GameLog.log("H5_3500_Sdk >> 加载H5_3500_Sdk完成");
			GameLog.log("this.game_token" + this.game_token);
			GameLog.log("this.game_uid" + this.game_uid);

			let clz = egret.getDefinitionByName("Game35");

			H5_3500_Sdk.getInstance().game35 = new clz({
				uid: H5_3500_Sdk.getInstance().game_uid,
				token: H5_3500_Sdk.getInstance().game_token
			});

			callback(); 
		});
	}
}

var loadSingleScript = function (src, callback) {
	var s = document.createElement('script');
	s.async = false;
	s.src = src;
	s.addEventListener('load', function () {
		s.parentNode.removeChild(s);
		// s.removeEventListener('load', arguments.callee, false);
		callback();
	}, false);
	document.body.appendChild(s);
};