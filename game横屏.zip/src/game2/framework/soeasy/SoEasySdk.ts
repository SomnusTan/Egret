/**
 * @author lucywang
 * @date 2018/01/29
 */
class SoEasySdk implements Platform {

    private _soEasySrc: string = "https://cn.soeasysdk.com/soeasysr/zm_engine_v2.js";   //soeasy sdk下载地址
    private order_id: string;  //订单号
    private t;                 //轮询计时ID

    //需要隐藏公告、qq号的SoEasy渠道。由服务端传来屏蔽渠道数据。
    public static hideChannelList = ["10382", "10217", "10425", "379", "10528"];

    //渠道列表
    public static channelList = {
        "h5_9g": "10382",      //9G  
        "qingFeng": "10448",   //清风
        "h5_3500": "10217",    //3500
        "baidu": "10425",       //百度
        "lehaihai": "379",      //乐嗨嗨
        "h5_15cmgame": "10528", //15厘米游戏
        "h5_37117": "37117",      //37117渠道
        "h5_4177": "10215",       //4177渠道
        "h5_1758": "303"        //1758渠道
    }

    /**检查当前渠道是否是指定的渠道 */
    public static isCurChannel(sdkindex) {
        var userinfo = ZmSdk.getInstance().getUserInfo();
        if (sdkindex == userinfo.common.sdkindx) {
            return true;
        }
        return false;
    }

    //分享数据
    public static shareData = {
        "title": "心动女生",
        "content": "恋爱养成游戏，一段怦然心动的恋爱旅程等待着你。",
        "imgurl": "http://xdns-h5.oss-cn-beijing.aliyuncs.com/soeasy/1.0.10/share.png"
    };

    //游戏服务器登录地址
    public _loginUrl: string = "/user/login/soeasy/";

    //游戏服务器下单地址
    public _payOrderUrl: string = "/shop/gift/buy/";

    async getUserInfo() {

    }

    public getLoginUrl() {
        return ProtocolHttpUrlGame2.url + this._loginUrl;
    }

    async init() {
        GameLog.log("SoEasySdk >> start init");
        loadSingleScript(this._soEasySrc, function () {
            GameLog.log("SoEasySdk >> init complete");
        });
    }

    async login() {
        GameLog.log("SoEasySdk >> login start");
    }

    async payOrder(gid) {
        let param = JSON.stringify({ gid: gid, Authorization: App.data.game2Center.DataCenter.skey, 'channel': 'soeasy' });
        Http.post(ProtocolHttpUrlGame2.url + this._payOrderUrl, param, this.payOrderHandler, this);
    };

    /**
	 * 下订单回调
	 */
    private payOrderHandler(e) {
        var request = e.currentTarget;
        let result = JSON.parse(request.response);
        GameLog.log("SoEasySdk >> payOrderHandler:", result);
        let data = result.data;
        if (result.code == 200) {
            //唤起支付
            platform.pay(result.data);
        } else {
            Notice.showBottomCenterMessage(result.info);
        }
    }

    async pay(data) {
        let payinfojson = {
            feeid: data.feeid,
            fee: data.fee,
            feename: data.feename,
            extradata: data.extradata,
            // serverid: "1",
            check: data.check,
        }
        //保存订单号，以做轮询
        this.order_id = data.extradata;
        GameLog.log("SoEasySdk >> pay:", payinfojson);
        ZmSdk.getInstance().pay(payinfojson, function (data) {
            //注：没有回调...不走这里...需要轮询
            GameLog.log("SoEasySdk >> easysdk payback:", data.retcode);
            if (data.retcode === "0") {
                //购买成功处理
            } else if (data.retcode === "1") {
                //购买失败处理
            } else if (data.retcode === "2") {
                //初购取消
            } else if (data.retcode === "3") {
                // 跳转到了支付界面或渠道不支持
            }
        });
        //因为没有支付回调，这里轮询
        this.getBuy();
    }

    //获得购买的状态
    private getBuy() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.payBack, this));
    }

    private payBack(data: any): void {
        if (data.code == 200) {
            Notice.showBottomCenterMessage("支付成功");
            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
            App.data.game2Center.LoadingLock.unlock();
        } else {
            this.t = 0;
            this._needSendBuy = true;
            App.timer.clearTimer(this, this.onTimer);
            App.timer.doTimeLoop(this, 3000, this.onTimer);
        }
    }
    private _needSendBuy: boolean;//请求是否支付成功

    private onTimer(): void {
        this.t += 3;
        if (this.t >= 600) {
            GameLog.log("-------------10分钟内支付失败");
            App.timer.clearTimer(this, this.onTimer);
            return;
        }
        if (this._needSendBuy) {
            this._needSendBuy = false;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.onPaySuccess, this, true));
        }
    }

    private onPaySuccess(data: any): void {
        if (data.code == 200) {
            Notice.showBottomCenterMessage("支付成功");
            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
            App.timer.clearTimer(this, this.onTimer);
            App.data.game2Center.LoadingLock.unlock();
        } else {
            GameLog.log("-------------未支付，继续检测----------");
            this._needSendBuy = true;
        }
    }

    //屏蔽频道
    public static shieldChannel() {
        //用户信息
        var userinfo = ZmSdk.getInstance().getUserInfo();

        let len = SoEasySdk.hideChannelList.length;
        for (let i = 0; i < len; i++) {
            if (SoEasySdk.hideChannelList[i] == userinfo.common.sdkindx) {
                return true;
            }
        }
        return false;
    }

    //soeasy上报游戏角色
    public static reportRoleInfoH5() {
        let reportRoleInfo = {
            "datatype": "2",
            "serverid": "1",
            "servername": "1",
            "roleid": App.data.game2Center.DataCenter.UserInfo.id,
            "rolename": App.data.game2Center.DataCenter.UserInfo.nickName,
            "rolelevel": "1",
            "fightvalue": "1"
        }
        if (ZmSdk.getInstance().isSupportMethod("reportRoleStatus")) {
            ZmSdk.getInstance().reportRoleStatus(reportRoleInfo);
        }
    }
}
declare let ZmSdk: any;

if (!window.zmInitSucc) {
    window.zmInitSucc = function () {
        GameLog.log("SoEasySdk >>cp start work");
        //TODO 必须在这里或者该方法调用之后进行 sdk 调用
        ZmSdk.getInstance().init(zmInitBack);
    }
}

var dispatcherReqUpgradeStatus = function () { App.dispatcher.dispatchEvent(G2_GameSceneEvent.REQ_UPGRADE_STATUS); }
/** type:0登录游戏盒子，1:登录心动一 */
var onSoeasyLogin = function (type: number, callBack: FunctionVO) {
    var userinfo = ZmSdk.getInstance().getUserInfo();
    var pramsObj: any = { uid: userinfo.userdata.uid, t: userinfo.userdata.t, sign: userinfo.userdata.sign, common: userinfo.common };
    let param = JSON.stringify(pramsObj);
    GameLog.log("SoEasySdk >> send", param);
    if (type == 0) {
        ProtocolCommon.instance().sendLoginSoeasy(pramsObj, callBack);
    } else {
        Http.post(platform.getLoginUrl(), param, callBack.fun, this);
    }
}

//初始化成功之后调用其他 sdk 能力 如 获取用户信息、支付、角色上报、设置分/
//享信息、分享等…
//掌盟 SoEasy SDK 开发者帮助文档
var zmInitBack = function (data) {
    if (data.retcode === "0") {
        GameLog.log("SoEasySdk >> SoEasy初始化成功");
        var userinfo = ZmSdk.getInstance().getUserInfo();
        GameLog.log("SoEasySdk >> 用户信息:", userinfo);

        //初始化分享
        if (ZmSdk.getInstance().isSupportMethod("setShareInfo")) {
            ZmSdk.getInstance().setShareInfo(SoEasySdk.shareData, (ret) => {
                GameLog.log("分享结果:", ret);
            });
        }
    } else if (data.retcode === "1") {
        //初始化失败处理
    }
}

declare let zmInitSucc: Function;
declare interface Window {
    zmInitSucc: Function;
}

var loadSingleScript = function (src, callback) {
    var s = document.createElement('script');
    s.async = false;
    s.src = src;
    s.addEventListener('load', function () {
        s.parentNode.removeChild(s);
        // s.removeEventListener('load', arguments.callee, false);
        callback();
    }, false);
    document.body.appendChild(s);
};