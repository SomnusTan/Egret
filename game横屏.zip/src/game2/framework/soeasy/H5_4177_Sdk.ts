declare class aiaiusdk { };

/**4177渠道 */
class H5_4177_Sdk {

	/**渠道编号 */
	public sdkIndex = "10215";
	/**sdk地址 */
	public sdkUrl: string = "http://passport.4177.com/game/h5sdk";
	/**open_id */
	public open_id: string;
	/**channel*/
	public channel: string;
	/**app_id */
	public app_id: string;

	/**aiaiusdk 4177渠道sdk的类 */
	public aiaiusdk: any;




	//单例
	private static instance: H5_4177_Sdk;
	public static getInstance(): H5_4177_Sdk {
		if (this.instance == null) {
			this.instance = new H5_4177_Sdk();
		}
		return this.instance;
	}

	public constructor() {
		//从链接上获取透传参数
		this.open_id = egret.getOption("open_id");
		this.channel = egret.getOption("channel");
		this.app_id = "10625";
		GameLog.log("open_id" + this.open_id);
		GameLog.log("channel" + this.channel);
	}


	/**加载4177的sdk*/
	public loadSdk(callback) {
		loadSingleScript(this.sdkUrl, function () {
			GameLog.log("H5_4177_Sdk >> 加载H5_4177_Sdk完成");
			// let clz = egret.getDefinitionByName("aiaiusdk");
			let clz = new aiaiusdk();
			H5_4177_Sdk.getInstance().aiaiusdk = aiaiusdk;
			var initdata = {
				"app_id": H5_4177_Sdk.getInstance().app_id,
				"open_id": H5_4177_Sdk.getInstance().open_id,
				"channel": H5_4177_Sdk.getInstance().channel
			};
			GameLog.log(initdata);
			GameLog.log(H5_4177_Sdk.getInstance().aiaiusdk);
			H5_4177_Sdk.getInstance().aiaiusdk.init(initdata);
			callback();
		});
	}
}

var loadSingleScript = function (src, callback) {
	var s = document.createElement('script');
	s.async = false;
	s.src = src;
	s.addEventListener('load', function () {
		s.parentNode.removeChild(s);
		// s.removeEventListener('load', arguments.callee, false);
		callback();
	}, false);
	document.body.appendChild(s);
};