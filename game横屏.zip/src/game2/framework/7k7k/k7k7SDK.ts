/*
<!--========================= 7k7k SDK =============================-->
	<script >
		function GetQueryString(name){
				var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
				var r = window.location.search.substr(1).match(reg);
				if(r!=null)return  unescape(r[2]); return null;
		}

		let account = GetQueryString("userid");
		let k7_vaildCode = GetQueryString("vaildCode");

		let userid = GetQueryString("userid");
		let username = GetQueryString("username");
		let isAdult = GetQueryString("isAdult");
		let avatar = GetQueryString("avatar");
		let sex = GetQueryString("sex");
		let vaildCode = GetQueryString("vaildCode");
		let time = GetQueryString("time");
		let sign = GetQueryString("sign");

		var channel = "";

		if(userid && username  && vaildCode && sign && time){
			var auth_7k7k = {userid,username,isAdult,avatar,sex,vaildCode,time,sign};
			channel = "7k7k";
		}

		var sdkInit = {
			account,
			"appkey": "733262ed3b9ae839657918a7f0caf886 ",
			k7_vaildCode
		}

		//游戏分享成功回调
		function wxShareRes() {	
			//游戏在方法内实现自身逻辑，如：提示用户分享成功，并发放奖励
			GameLog.log("share success");
			window["GC"].reqShareGain();
    	}

	</script>

	<script src="http://h5.7k7k.com/assets/v0.1.0/k7sdk.js" ></script>

	<!--=========================  End 7k7k SDK =============================-->
	*/