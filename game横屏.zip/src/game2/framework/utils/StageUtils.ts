/**
 * 舞台类
 * @author chenkai
 * @date 2016/10/11
 */
class StageUtils extends SingleClass {
	/**舞台 */
	public stage: egret.Stage;

	/**
	 * 获取舞台宽度
	 */
	public get stageWidth() {
		return Config.SCREEN_WIDTH;
	}

	/**
	 * 获取舞台高度
	 */
	public get stageHeight() {
		return Config.SCREEN_HEIGHT;
	}

	//横屏游戏部分无法合适适配的机型，使用showAll
	//全面屏    2:1   2160:1080 
	//主流机型  16:9  1920x1080 
	//ipad      4:3   2048x1536  
	//iphonexX        2436x1125
	//注：华为虚拟键盘、 h5微信或浏览器有黑边会占一定比例
	//根据手机截图测试，电量栏72像素  微信黑边142像素  华为虚拟键盘108像素 72+142+108=322
	public fitScreen() {
		let rate = egret.Capabilities.boundingClientWidth / egret.Capabilities.boundingClientHeight;
		if (rate > 2436 / 1125 || rate < 4 / 3) {
			App.stage.scaleMode = egret.StageScaleMode.SHOW_ALL;
		} else if (rate >= 2) {
			App.stage.scaleMode = egret.StageScaleMode.FIXED_HEIGHT;
		}
		if (H5_Vivo_SDK.getInstance().vivoData && H5_Vivo_SDK.getInstance().getEarInfo() && H5_Vivo_SDK.getInstance().getEarInfo().result) {
			//vivo情况的的刘海屏 比例过2 高度适配
			if ((parseInt(H5_Vivo_SDK.getInstance().getEarInfo().width) / (parseInt(H5_Vivo_SDK.getInstance().getEarInfo().height)) > 2)) {
				App.stage.scaleMode = egret.StageScaleMode.FIXED_HEIGHT;
			}
		}
	}

	//设置背景适配iphonex
	public fitBgIPhoneX(bg: egret.DisplayObject) {
		if (DeviceUtil.isIPhoneX) {
			let rate = bg.height / bg.width;
			bg.width = this.stageWidth;
			bg.height = bg.width * rate;
		}
	}

	/**
	 * 一个物体充满在舞台上
	 */
	public fullSomeToStage(some: egret.DisplayObject, w: number = 1280, h: number = 720): void {
		if (this.stageHeight <= 720 && !DeviceUtil.isIPhoneX) {
			return;
		}
		var stageW: number = this.stageWidth;
		var stageH: number = this.stageHeight;
		// if (H5_Vivo_SDK.getInstance().vivoData && H5_Vivo_SDK.getInstance().getEarInfo() && H5_Vivo_SDK.getInstance().getEarInfo().result) {
		// 	stageW = parseInt(H5_Vivo_SDK.getInstance().getEarInfo().width);
		// 	stageH = parseInt(H5_Vivo_SDK.getInstance().getEarInfo().height);
		// }
		let fw: number = stageW / w;
		let fh: number = stageH / h;
		if (fw > fh) {
			some.scaleX = some.scaleY = fw;
		} else {
			some.scaleX = some.scaleY = fh;
		}
	}
}