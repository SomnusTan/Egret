/**
 * 资源管理类
 * @author chenkai
 * @date 2016/9/8
 * 
 */
class ResUtils {
    /**待加载资源组 */
    private groupList: Array<any>;
    /**待加载配置列表*/
    private configList: Array<any>;
    /**配置加载完成回调*/
    private onConfigComplete: Function;
    /**配置加载完成回调执行对象*/
    private onConfigCompleteTarget: any;

    public constructor() {
        this.initResVersion();
        this.groupList = new Array<any>();
        this.configList = new Array<any>();

        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceLoadProgress, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
    }

	/**
     * Res加载使用版本号的形式
	 * version在index.php页面设置
     */
    private initResVersion(): void {
        // if (GlobalConfig.version_obj) {
        //     RES.web.Html5VersionController.prototype.getVirtualUrl = function (url) {
        //         let version = GlobalConfig.version_obj.res_version;
        //         if (url.indexOf("?") == -1) {
        //             url += "?ver=" + version;
        //         } else {
        //             url += "&ver=" + version;
        //         }
        //         return url;
        //     }
        // }
    }

	/**
     * 加载资源组 (有回调)
     * @group 资源组名称(支持字符串和数组)
	 * @thisObject 资源加载监听函数所属对象
     * @onComplete 资源加载完成执行函数
     * @onProgress 资源加载进度监听函数
     */
    public loadGroup(group: any, onProgress: Function = null, onComplete: Function = null, thisObject: any = null, priority: number = 1): void {
        let groupName: string = this.combGroupName(group);
        this.groupList[groupName] = [onComplete, onProgress, thisObject];
        RES.loadGroup(groupName, priority);
        GameLog.log("加载组资源-》" + groupName);
    }

    /**
     * 资源组加载完成
     */
    private onResourceLoadComplete(event: RES.ResourceEvent): void {
        var groupName: string = event.groupName;
        GameLog.log("加载资源组完成:", groupName);
        if (this.groupList[groupName]) {
            var loadComplete: Function = this.groupList[groupName][0];
            var loadCompleteTarget: any = this.groupList[groupName][2];
            if (loadComplete != null && loadCompleteTarget != null) {
                loadComplete.call(loadCompleteTarget);
            }
            this.deleteCallBack(groupName);
        }
    }

    /**
     * 资源组加载进度
     */
    private onResourceLoadProgress(event: RES.ResourceEvent): void {
        var groupName: string = event.groupName;
        if (this.groupList[groupName]) {
            var loadProgress: Function = this.groupList[groupName][1];
            var loadProgressTarget: any = this.groupList[groupName][2];
            if (loadProgress != null && loadProgressTarget != null) {
                loadProgress.call(loadProgressTarget, event);
            }
        }
    }

    /**
     * 资源组加载失败
     * @param event
     */
    private onResourceLoadError(event: RES.ResourceEvent): void {
        GameLog.logError(event.groupName + "资源组加载失败");
        // this.onResourceLoadComplete(event);
    }

    /**
    * 资源组是否已加载
    */
    public isGroupLoaded(groupName: string) {
        return RES.isGroupLoaded(groupName);
    }

	/**
	 * 停止加载资源组的回调函数
	 * @groupName 资源组名
	 */
    public deleteCallBack(groupName) {
        // GameLog.log("取消加载资源组回调:" + groupName);

        //删除列表中回调
        this.groupList[groupName] = null;
        delete this.groupList[groupName];
    }

    /**删除所有资源组回调*/
    public deleteAllCallBack() {
        for (var key in this.groupList) {
            this.deleteCallBack(key);
        }
    }

    /**
     * 销毁某个组的资源
     */
    public destroyOneGrp(grpName: string): void {
        RES.destroyRes(grpName);
    }

	/**
	 * 拼接资源组名
	 * @group 资源数组
	 * @return 资源组名
	 */
    private combGroupName(group): string {
        var groupName = "";
        if (typeof (group) == "string") {
            groupName = group;
        } else {
            var len = group.length;
            if (len > 1) {
                for (var i = 0; i < len; i++) {
                    groupName += "->" + group[i];
                }
                RES.createGroup(groupName, group);
            }
            else {
                groupName = group;
            }
        }
        return groupName;
    }
}