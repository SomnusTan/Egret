class Game2PayUtil {

    public static pay(id: number, name: string, price: number, count: number, callBack: FunctionVO): void {
        var data: any = {};
        data.gid = id;
        if (window.hasOwnProperty("channel"))
            data.channel = window["channel"];
        if (Config.U8Login) {
            data.channel = "u8";
        }
        else if (DeviceUtil.IsIos && Config.isGZSnow) {

        }
        else if (DeviceUtil.IsIos) {

        }
        //新ios下单，增加渠道标识
        // if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
        // 	data["channel"] = IOSConfig.channel;
        // }
        else if (DeviceUtil.IsWeb) {
            //360渠道
            if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
                data["channel"] = "360";
            } else {
                data["channel"] = "web_alipay";
            }
        }
        data.method = EnumPayType.BUY_TYPE_COIN;
        data.setting = DeviceUtil.currentSetting;
        data.callBack = callBack;
        data.price = price;
        Alert.show2(StringUtil.substitute(EnumAlertContent.BUY_GAME2_GIFT, price * count, name, count > 1 ? " X " + count : ""), "确 定|取 消",
            new FunctionVO(Game2PayUtil.onSurePay, Game2PayUtil, data), "提示", true);
    }

    private static onSurePay(backData: any, data: any): void {
        var callBack: FunctionVO = data.callBack;
        var price: number = data.price;
        delete data.callBack;
        delete data.price;
        if (backData.type == Alert.OK) {
            if (App.global.userInfo.xdCoin >= price) 
                ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, data, new FunctionVO(this.onPayBack, this, callBack));
            else
				PanelOpenManager.openPanel(EnumPanelID.G2_SHOP_COIN_PANEL, { type: 1, minCoin: price, successClose: true });
        }
    }

    private static onPayBack(response: any, callBack: FunctionVO): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.global.userInfo.xdCoin = response.data;
            if (callBack) {
                callBack.exec();
            }
        }
        else {
            if (response.code == 234 || response.code == 224) {
                PanelOpenManager.openPanel(EnumPanelID.G2_SHOP_COIN_PANEL, { type: 1 });
            }
            Notice.showBottomCenterMessage(response.info);
        }
    }
}