/**
 * 声音管理类
 * @author chenkai
 * @date 2016/6/30
 */
class SoundManager extends SingleClass {
    private soundList = {};                    //声音列表
    private bgmChannel: egret.SoundChannel;     //背景音声道
    private effectChannel: egret.SoundChannel    //音效声道

    private _allowPlayEffect: boolean = true;   //是否允许播放音效
    private _allowPlayBGM: boolean = true;      //是否允许播放背景音乐
    private _effectVolume: number = 1;          //音效音量
    private _bgmVolume: number = 0.4;             //背景音量

    /**心动女友 */
    public static bgm: string = "Lovehome";            //背景音乐
    public static button: string = "return";       //按钮
    public static click: string = "g2_click"; //点击
    public static time_click: string = "time_click";//计时
    public static success: string = "success";//成功
    public static select: string = "select";//选择
    public static new_msg: string = "new_msg";//新消息
    public static calling: string = "calling";//拨打电话
    public static common_use: string = "common_use";//确认点击
    public static close: string = "close2";//关闭音效

    public static working: string = "working";//工作中
    public static work_done: string = "work_done";//工作完成
    public static love_done: string = "love_done";//恋爱完成
    public static dialogue_pop: string = "dialogue_pop";//弹出框音效
    public static wrong_answer: string = "wrong_answer";//好感度减少
    public static sent_msg: string = "sent_msg";//发送微信
    public static levelup: string = "levelup";//升级音效
    public static page_switch: string = "page_switch";//商城页面切换音效
    public static number_add: string = "number_add";//道具加音效
    public static number_reduce: string = "number_reduce";//道具减音效

    public static library: string = "library";//图书馆音效
    public static canteen: string = "canteen";//吃饭音效
    public static shopping: string = "shopping";//唱歌音效
    public static park: string = "park";//公园音效
    public static gym: string = "gym";//健身音效
    public static cat: string = "cat";//逗猫音效
    public static carnie: string = "carnie";//游乐园音效


    private _startTime: number;
    private _loops: number;
    private bgm: egret.Sound;
    private _startTimeE: number;
    private _loopsE: number;
    private effect: egret.Sound;
    /**背景音乐播放中 */
    private _isPlaying: boolean;

    public constructor() {
        super();
    }


	/**
	 * 播放音效
	 * @param soundName 声音名
	 * @param startTime 播放起始位置
	 * @param loops 循环次数
	 */
    public playEffect(soundName: string, startTime: number = 0, loops: number = 1) {
        if (this.allowPlayEffect == false) {
            return;
        }
        this._startTimeE = startTime;
        this._loopsE = loops;
        //从声音列表中获取,声音列表中不存在，则从加载资源中获取
        var sound: egret.Sound = this.soundList[soundName];
        if (sound == null) {
            sound = RES.getRes(soundName);
            if (sound != null) {
                this.soundList[soundName] = sound
            } else {
                //TODO 从resource/assets中加载，则使用一个加载一个，而不需要全部加载
                // if (this.effect == null)
                //     this.effect = new egret.Sound();
                // this.effect.type = egret.Sound.EFFECT;
                // this.effect.addEventListener(egret.Event.COMPLETE, this.onLoadEffectComplete, this);
                // var sn: string = soundName.substr(0, soundName.length - 4);
                // var path: string = ResPathUtil.getSoundPath1(sn);
                // this.effect.load(path);
                // this.soundList[soundName] = this.effect;
            }
        }
        if (sound) {
            sound.type = egret.Sound.EFFECT;
            return sound.play(startTime, loops)
        }
        return null;
    }

    // private onLoadEffectComplete(e: egret.Event): void {
    //     GameLog.log('音效加载完成', e.data);
    //     if (this.effect) {
    //         this.effect.removeEventListener(egret.Event.COMPLETE, this.onLoadEffectComplete, this);
    //         this.effectChannel = this.effect.play(this._startTimeE, this._loopsE);
    //     }
    // }

    /**
     * 停止音效
     */
    public stopEffect(chanel: egret.SoundChannel) {
        if (chanel) {
            chanel.stop();
            chanel = null;
        } else {
            if (this.effectChannel) {
                this.effectChannel.stop();
                this.effectChannel = null;
            }
        }
    }


	/**
	 * 播放背景音乐
	 * @param bgmName 背景音名
	 * @param startTime 播放起始位置
	 * @param loops 循环次数
	 */
    public playBGM(bgmName: string, startTime: number = 0, loops: number = Number.MAX_VALUE) {
        if (this.allowPlayBGM == false || this.bgmChannel != null) {
            return;
        }
        this._startTime = startTime;
        this._loops = loops;
        this.stopBGM();
        var bgm: egret.Sound = this.soundList[bgmName + "_mp3"];
        if (bgm == null) {
            bgm = RES.getRes(bgmName + "_mp3");
            bgm && (this.soundList[bgmName + "_mp3"] = bgm);
            // this.bgm = bgm;
        }
        if (bgm) {
            bgm.type = egret.Sound.MUSIC;
            this.bgmChannel = bgm.play(startTime, loops);
            this.bgmChannel.volume = this._bgmVolume;
            this._isPlaying = true;
        } else {
            this.bgm = new egret.Sound();
            this.bgm.type = egret.Sound.MUSIC;
            this.bgm.addEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
            var path: string = ResPathUtil.getBgmPath(bgmName);
            this.bgm.load(path);
            this._isPlaying = true;
        }
    }

    /**
     * 加载完成
     */
    private onLoadComplete(e: egret.Event): void {
        e.currentTarget.removeEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
        if (this.bgm && this._isPlaying) {
            this.bgmChannel = this.bgm.play(this._startTime, this._loops);
            this.bgmChannel.volume = this._bgmVolume;
        }
    }

    /**停止背景音乐*/
    public stopBGM() {
        if (this.bgmChannel) {
            this.bgmChannel.stop();
            this.bgmChannel = null;
        }
        this._isPlaying = false;
    }

    /**获取是否允许播放音效*/
    public get allowPlayEffect() {
        return this._allowPlayEffect;
    }

    /**设置是否允许播放音效*/
    public set allowPlayEffect(bAllow: boolean) {
        if (bAllow)
            App.global.storage.setItem(EnumStorageType.G2_ALLOW_EFFECT, "");
        else
            App.global.storage.setItem(EnumStorageType.G2_ALLOW_EFFECT, "1");
        this._allowPlayEffect = bAllow;
    }

    /**获取是否允许播放背景音*/
    public get allowPlayBGM() {
        return App.global.storage.getItem(EnumStorageType.G2_ALLOW_MUSIC) != "1";;
    }

    /**设置是否允许播放背景音*/
    public set allowPlayBGM(bAllow: boolean) {
        if (bAllow)
            App.global.storage.setItem(EnumStorageType.G2_ALLOW_MUSIC, "");
        else
            App.global.storage.setItem(EnumStorageType.G2_ALLOW_MUSIC, "1");

        this._allowPlayBGM = bAllow;
        if (this._allowPlayBGM == false) {
            this.stopBGM();
        } else {
            this.playBGM(SoundManager.bgm);
        }
    }

    /**获取音效音量*/
    public get effectVolume() {
        return this._effectVolume;
    }

    /**设置音效音量*/
    public set effectVolume(value: number) {
        this._effectVolume = value;
    }

    /**获取BGM音量*/
    public get bgmVolume() {
        return this._bgmVolume;
    }

    /**设置BGM音量*/
    public set bgmVolume(value: number) {
        this._bgmVolume = value;
        if (this.bgmChannel) {
            this.bgmChannel.volume = this._bgmVolume;
        }
    }

    /**窗口失去焦点时 关闭背景音乐 */
    public windowFocusHandler() {
        if (DeviceUtil.IsWeb) {
            App.stage.addEventListener(egret.Event.ACTIVATE, () => {
                if (App.data.game2Center.DataCenter.isVideoPlaying == false) {
                    App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
                }
            }, this);

            App.stage.addEventListener(egret.Event.DEACTIVATE, () => {
                App.data.game2Center.SoundManager.stopBGM();
            }, this)
        }
    }


}
