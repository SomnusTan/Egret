/**
 * 视图代理
 * 负责Http、Socket通讯、以及视图模块之间的通讯
 * @author chenkai
 * @since 2017/11/1
 */
class Mediator {
	protected _dispatcher: DispatcherRegister;

	protected _hasRegister: boolean = false;

	public constructor() {
		this._dispatcher = new DispatcherRegister();
	}

	/**注册时调用 */
	public onRegister() {
		this._hasRegister = true;
	}

	/**注销时调用 */
	public onRemove() {
		this._hasRegister = false;
		if (this._dispatcher) {
			this._dispatcher.removeAllListeners();
		}
	}

	public dispose(): void {
		if (this._dispatcher) {
			this._dispatcher.removeAllListeners();
			this._dispatcher = null;
		}
	}

	/**
	 * 是否注册了
	 */
	public get hasRegister(): boolean {
		return this._hasRegister;
	}

	/**派发事件 */
	public sendEvent(type: string, data: any = null) {
		App.dispatcher.dispatchEvent(type, data);
	}

	/**监听事件 */
	public addEvent(type: string, listener: Function, thisObject: any) {
		this._dispatcher.addEventListener(type, listener, thisObject);
	}

	/**移除事件 */
	public removeEvent(type: string, listener: Function, thisObject: any) {
		this._dispatcher.removeEventListener(type, listener, thisObject);
	}
}