declare class VivoGame {
	constructor(obj: any);
}

/**
 * vivo 渠道
 */
class H5_Vivo_SDK {
	private static instance: H5_Vivo_SDK;
	public static getInstance() {
		if (this.instance == null) {
			this.instance = new H5_Vivo_SDK();
		}
		return this.instance;
	}

	//登录后获得的用户信息
	public gameInfo: { username: string, openid: string, opentoken: string };
	//vivo数据
	public vivoData: any;
	public appid: string = "e7efe8904625515afd226b727a5a5039";
	public appkey: string = "ae87bb76942e9523e505dce7f754e27a";
	public order_id: any;

	constructor() {
		//GameLog.log("H5_Vivo_SDK-->" + window["auth_type"]);
		if (window["auth_type"] == "auth_vivo") {
			this.vivoData = window["auth_type"];
		}
	}

	//登录
	public Vivo_login(func: Function, obj: any) {
		console.info("Vivo_login");
		if (!window["isSupportH5Game"]) {
			Notice.showBottomCenterMessage("授权失败!");
			GameLog.log("isSupportH5Game 失败");
			return;
		}
		VivoGame.call("login", function (accountInfo) {
			console.info(accountInfo);
			H5_Vivo_SDK.getInstance().gameInfo = JSON.parse(accountInfo);
			func.call(obj);
		});
	}

	/**
	 * 刘海屏
	 */
	public getEarInfo(): { result: string, width: string, height: string } {
		if (window["getEarInfo"]) {
			return { result: window["getEarInfo"].result, width: window["getEarInfo"].width, height: window["getEarInfo"].height };
		}
		return null;
	}

	//支付
	//params = {
	//     productName:"真正男子汉_2",
	//     productDes:"真正男子汉",
	//     productPrice:"1",
	//     vivoSignature:data.accessKey,
	//     appId:"4de4c7e0c5f0d62f7a189976d5d68825",
	//     transNo:data.orderNumber,
	//     uid:uid
	// }
	// // js支付
	// VivoGame.call("pay", params, function(data) {
	//     alert(data)
	// });
	public Vivo_pay(payinfo: {
		productName: string, productDes: string,
		productPrice: string, vivoSignature: string, appId: string, transNo: string, uid: string
	}, func: Function, obj: any) {
		GameLog.log("支付通过vivo payinfo->" + JSON.stringify(payinfo));
		GameLog.log("支付通过vivo payinfo->" + payinfo);
		VivoGame.call("pay", payinfo,
			function (data) {
				GameLog.log("支付返回vivo -》" + data + "-->errorCode=" + JSON.parse(data).errorCode);
				switch (JSON.parse(data).errorCode) {
					case "0":
						Notice.showBottomCenterMessage("支付成功");
						func.call(obj);
						break
					case "-1":
						Notice.showBottomCenterMessage("支付取消");
						break
					case "-2":
						Notice.showBottomCenterMessage("其他错误");
						break
					case "-3":
						Notice.showBottomCenterMessage("参数错误");
						break
					case "-4":
						Notice.showBottomCenterMessage("支付结果请求超时");
						break
					case "-5":
						Notice.showBottomCenterMessage("非足额支付（充值成功，未完成支付）");
						break
					case "-6":
						Notice.showBottomCenterMessage("初始化失败");
						break
				}
			});
	}

	//支付状态
	public Vivo_payState() {
		
		let param = {};
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.u8_login, param, new FunctionVO(this.Vivo_payBack, this));
	}

	//支付结果返回
	public Vivo_payBack(data) {

	}

	public Vivo_change() {
		VivoGame.call("requestOrientation", { orientation: "0" }, function () {
			GameLog.log("横屏切换");
		});
	}


}