/**mqq .js sdk */
declare var mqq: any;

/**关闭logo */
declare function closeLogo();

/**
 * 关于玩吧接口的一些功能以及数据的对接工具
 * 
 */
class WanBaSDK {
    private static instance_: WanBaSDK;
    public static getIntance(): WanBaSDK {
        if (!WanBaSDK.instance_) {
            WanBaSDK.instance_ = new WanBaSDK();
        }
        return WanBaSDK.instance_;
    }

    /**
     * 玩吧对接的数据
     */
    public wanBaData: WanBaData;
    /**
     * 礼物
     */
    public gift: number;

    constructor() {
        this.init();
    }

    /**
     * 初始化
     */
    private init(): void {
        try {
            this.wanBaData = window["auth_wanBa"];//需要在index中声明赋值这个属性-->	window["auth_wanBa"] = window.OPEN_DATA;
            let win: any = window;
            win.getOpenKey(function (d) {
                GameLog.log("异步获取openkey-->" + JSON.stringify(d));
                WanBaSDK.getIntance().wanBaData.openkey = d.data.openkey;// JSON.stringify(d);
            });
            GameLog.log("获取到玩吧数据，WanBaSDK-->" + this.wanBaData);

            //获取url的参数
            let getPar: Function = function (par) {
                //获取当前URL
                var local_url = document.location.href;
                //获取要取得的get参数位置
                var get = local_url.indexOf(par + "=");
                if (get == -1) {
                    return false;
                }
                //截取字符串
                var get_par = local_url.slice(par.length + get + 1);
                //判断截取后的字符串是否还有其他get参数
                var nextPar = get_par.indexOf("&");
                if (nextPar != -1) {
                    get_par = get_par.slice(0, nextPar);
                }
                return get_par;
            }
            this.gift = getPar("GIFT");
        } catch (e) {

        }

    }

    /**
     * 显示分享菜单
     */
    public showShareMenu(): void {
        try {

            if (this.wanBaData.platform == 1) {

            } else {
                let type = 0;
                if (this.wanBaData.qua.app == "SQ") {
                } else if (this.wanBaData.qua.app == "QZ") {
                } else if (this.wanBaData.qua.app == "WX") {
                } else if (this.wanBaData.qua.app == "QQLive") {
                }
                //再次注册分享信息 IOS
                mqq.ui.shareMessage({
                    title: '心动女生',
                    desc: '大家一起来玩吧',
                    share_type: type,
                    share_url: this.wanBaData.jumpurl,
                    image_url: this.wanBaData.appicon,
                    back: true
                }, function (result) {
                    GameLog.log("注册分享信息回调  ios->" + result);
                });
            }
            //再次注册分享信息 android
            mqq.ui.shareArkMessage({
                title: '心动女生',
                desc: '大家一起来玩吧',
                share_url: this.wanBaData.jumpurl,
                image_url: this.wanBaData.appicon,
                back: true
            }, function (result) {
                //result.
                GameLog.log("注册分享信息回调  android->" + result);
            });

            //弹起面板
            mqq.ui.showShareMenu();
        } catch (e) {
            GameLog.log(e);
        }

    }

    /**
     * 收藏发送到桌面
     */
    public collectSendToDesktop(call_back_c: Function): void {
        try {
            GameLog.log("收藏发送到桌面-->");
            mqq.ui.addShortcut({
                action: "web",
                title: "心动女生",
                icon: WanBaSDK.getIntance().wanBaData.appicon,
                url: WanBaSDK.getIntance().wanBaData.jumpurl,
                callback: call_back_c
            });
        } catch (e) {
            GameLog.log(e);
        }

    }
}



/**
 * 玩吧的数据
 */
class WanBaData {
    /**
     *  平台，2-IOS，1-安卓
     */
    public platform: number;
    /**
     * 用户平台来源，用于OpenAPI接口。透传即可，关于pf的详细用法，可以参见：如何使用pf值。 
     */
    public pf: string;
    /**
     * 第三方appid
     */
    public appid: string;
    /**
     * 第三方openid
     */
    public openid: string;
    /**
     * 第三方登录态openkey，调用window.getOpenKey()后自动更新
     */
    public openkey: string;
    /**
     * 渠道标识，用于统计，透传即可
     */
    public via: string;
    /**
     * 当前页面对应的原始地址
     */
    public appurl: string;
    /**
     * 图标，100x100
     */
    public appicon: string;
    /**
     * 用于设置分享地址
     */
    public shareurl: string;
    /**
     * 用于设置快捷方式
     */
    public jumpurl: string;
    /**
     * qua解析后的对象
     */
    public qua: {
        /** 原始qua字符串*/
        meybeQua: string,
        /**  
         * 操作系统。AND-安卓，IPH-IOS
         */
        os: string,
        /**
         * 手机QQ、手机QQ空间或微信：SQ-手Q，QZ-手空，WX-微信，QQLive-腾讯视频
         */
        app: string,
        /**
         * 版本号，前三位
         */
        version: string,
        /**
         * 版本号，第四位
         */
        subVersion: string,
        /**
         * 渠道号
         */
        appType
    }
}