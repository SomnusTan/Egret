/**
 * 游戏中心JSBridge 
 */
declare class clientApi {
    /**
     * h5GameLogin是调用游戏中心H5游戏登陆功能
     */
    public static h5GameLogin(obj: { appId: string, appKey: string }, Func: Function);
    /**
     * h5GamePay是调用游戏中心H5游戏支付功能
     */
    public static h5GamePay(obj: any, Func: Function);
}

/**授权的小米参数 */
declare var milletConfig: { result: number, uid: number, session: string };
/**登陆 */
declare function login(callF, obj);
/**支付 */
declare function paySome(cpOrderId, cpUserInfo, productCode, count, callF);
/**
 * 关于小米接口的一些功能以及数据的对接工具
 * 
 */
class MilletSDK {
    private static instance_: MilletSDK;
    public static getInstance(): MilletSDK {
        if (!MilletSDK.instance_) {
            MilletSDK.instance_ = new MilletSDK();
        } else {
            if (!MilletSDK.instance_.milletData) {
                try {
                    //获取参数
                    MilletSDK.instance_.milletData = milletConfig;
                } catch (e) {

                }
            }
        }
        return MilletSDK.instance_;
    }
    //小米渠道是否启用
    ////设置为小米数据 millet.js
    // window["auth_millet"] = true;
    public millet: boolean = false;
    /**小米数据 */
    public milletData: { result: number, uid: number, session: string };

    public order_id: any;

    constructor() {
        this.init();
    }

    /**
     * 初始化
     */
    private init(): void {
        try {
            if (window["auth_type"] == "auth_millet") {
                GameLog.log("auth_millet  初始化---");
                this.millet = window["auth_type"];
            }
        } catch (e) {

        }

    }

    /**
     * 登录 
     */
    public login(callF: Function, obj: any): void {
        login(callF, obj);
    }

    /**
     * 支付
     */
    public pay(cpOrderId: number, cpUserInfo: string, productCode: string, count: number, func: Function, obj: any, type: number = 1): void {
        let funcCall: Function = function (isOver) {
            if (isOver) {
                func.call(obj);
            } else {
                Notice.showBottomCenterMessage("支付失败");
            }
        }
        paySome(cpOrderId, cpUserInfo, productCode, count, funcCall);
    }

    /**
     * h5GamePay是调用游戏中心H5游戏支付功能。该方法同时支持按计费代码计费和按金额计费。
        按金额计费时，调用方式为clientApi.h5GamePay({cpOrderId:'20151117',cpUserInfo:'2015_h5game',amount:1},function(e)，cpOrderId为订单id，cpUserInfo为订单透传信息，amount为金额，大于0的整数，单位为人民币元。
     */
    public h5GamePay(amount: number, cpOrderId: string, cpUserInfo: string, type: number = 1): void {
        if (type == 1) {

        } else {

        }
    }

}


