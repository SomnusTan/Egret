declare let H5_GAME_360: any;
/*
*360渠道 
*/
class H5_360_Sdk {

	/**游戏编号 */
	public game_appid: string;
	/**sdk地址 */
	public sdkUrl: string = "http://h5.wan.360.cn/h5-cp-sdk-loader.js";
	/**游戏密码*/
	public game_appkey: string;
	/**用户 token */
	public server_id: string;
	/**游戏qid */
	public game_qid: string;
	/** */
	public game35: any;
	/**h5Game */
	public h5Game: any;
	/** */
	public CONST: any;
	/**360渠道信息 */
	public config360: any;
	/**360渠道支付参数 */
	public pay360Param: any;

	public order_id: number;
	//单例
	private static instance: H5_360_Sdk;
	public static getInstance(): H5_360_Sdk {
		if (this.instance == null) {
			this.instance = new H5_360_Sdk();
		}
		return this.instance;
	}

	constructor() {
		this.config360 = window["360_sdk_config"];
	}

	
	// public getUserInfo(callback) {
	// 	loadSingleScript(this.sdkUrl, function () {
	// 		//let clz = egret.getDefinitionByName("H5_GAME_360");
	// 		var h5Game = new H5_GAME_360();
	// 		var CONST = H5_GAME_360.CONST;
	// 		h5Game.emit(CONST.EVENT.USER.INFO, {
	// 			qid: H5_360_Sdk.getInstance().game_qid //此时的qid，后端登录接口会传给CP
	// 		}, function (user) {  // 回调函数，user是一个json对象
	// 			GameLog.log(user);  // 结构为{“qid”: “qid 回传”， “nickname”：“用户昵称”, “img_url”: “用户头像地址url，48*48”}
	// 		});
	// 	});
	// }

	public paySdk() {
		if (this.h5Game) {
            GameLog.log("h5Game 有值");
		} else {
			GameLog.log("h5Game 无值");
			this.h5Game = new H5_GAME_360();
		}
		var CONST = H5_GAME_360.CONST;
		let params = this.pay360Param;
		GameLog.log(params);
		this.h5Game.emit(CONST.EVENT.BUY.START, params);
	}

}

var loadSingleScript = function (src, callback) {
	var s = document.createElement('script');
	s.async = false;
	s.src = src;
	s.addEventListener('load', function () {
		s.parentNode.removeChild(s);
		// s.removeEventListener('load', arguments.callee, false);
		callback();
	}, false);
	document.body.appendChild(s);
};