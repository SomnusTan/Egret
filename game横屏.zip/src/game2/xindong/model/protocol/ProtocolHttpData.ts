/**
 * http请求返回结构
 * @author xiongjian
 * @date 2017/8/30
 */
class ProtocolHttpData {

    /**注册 */
    public static register = {
        info: "",
        code: 0,
        data: {
            skey: "",
            user: ""
        }
    }

    /**登录 */
    public static login = {
        info: "",
        code: 0,
        data: {
            skey: "",
            user: ""
        }
    };

    /**游客登录 */
    public static guest = {
        info: "",
        code: 0,
        data: {
            skey: "",
            user: ""
        }
    };

    /**登出 */
    public static logout = {
        info: "",
        code: 0,
        data: {}
    };

    /**游戏信息 */
    public static gameInfo = {
        info: "",
        code: 0,
        data: {
            tel: [],
            love: [],
            work: [],
            shop: [],
            back: [],
            video: [],
            weibo: [],
            power: {},
            config: {
                update_time: {
                },
                avilable_event: [],
                event_id: 0,
                oid: 0,
                main_event: [],
                days: 0,
                mark: {
                },
                create_time: {
                },
                video: "",
                girl_name: "",
                hearts: 0,
                id: 0
            },
            wechat: {
                0: {
                    update_time: {
                    },
                    uid: 0,
                    start_id: 0,
                    days: 0,
                    create_time: {
                    },
                    chat_id: 0,
                    dialog: [],
                    id: 0,
                    types: 0
                },
            },
            userinfo: {
                bgi:"",
                update_time: "",
                elove_id: {
                },
                echat_id: 0,
                gold: 0,
                evideo_id: {
                },
                eback_id: {
                },
                days: 0,
                power: 0,
                event_id: 1,
                create_time: {
                },
                eweibo_id: {
                },
                hearts: 0,
                id: 0,
                ework_id: {
                },
                uid: 0,
                user_name: "",
                diamond: 0,
                wc_wait: 0,
                nick_name: ""
            }
        }
    };

    /**消息实体 */
    public static messageInfo = {
        chat_id: 0,
        create_time: null,
        days: 0,
        dialog: [],
        id: 0,
        start_id: 0,
        types: 0,
        uid: 0,
        update_time: null
    };

    /**dialog消息实体 */
    public static dialog = {
        audio: "",
        pid: 0,
        reply: 0,
        role: 0,
        says: "",
        score: 0,
        sid: 0,
        status: 0,
    };

    /**tel 消息实体 */
    public static tel = {
        chat_id: 0,
        create_time: "",
        days: 0,
        dialog: [],
        id: 0,
        start_id: 0,
        types: 0,
        uid: 0,
        update_time: ""
    };

    /**wechat 消息实体 */
    public static wechat = {
        chat_id: 0,
        create_time: "",
        days: 0,
        dialog: [],
        id: 0,
        start_id: 0,
        types: 0,
        uid: 0,
        update_time: ""
    };

    /**公告 */
    public static attention =
    {
        "info": "success",
        "code": 200,
        "data": {
            "qq": "123123",
            "update_time": null,
            "title": "至亲爱的玩家",
            "content": "心动女生将于2017年12月3日进行停服,给同学们带来的不便,敬请谅解",
            "create_time": null,
            "wechat": "123123",
            "id": 1
        }
    };
    //***********************dlc模块*******************************//
    //数据
    /** dlc模块返回数据*/
    public static dlc_chaptersData: dlc_getChapters_S;
    /**当前游戏进行的章节id */
    public static gameChapterId: number;
    /**需要开始的第一个消息 */
    public static dlc_ChatStartInfo: dlc_storyNexInfo[];
    /**结算数据 */
    public static dlc_storyFinish_Info: dlc_storyFinish_S;
}

//***********************dlc模块*******************************//
//dlc模块返回数据
class dlc_getChapters_S {
    info: string;
    code: number;
    data: {
        detail: ChapterDetail[],
        chapters: ChapterInfo[],
        story: dlc_storyNexInfo[]
    }
};

/**章节信息 */
class ChapterInfo {
    status: number;
    locked: boolean;
    title: string;
    des: string;
    score: number;
    id: number
}

/**章节奖励简介 */
class ChapterDetail {
    locked: boolean;
    name: string;
    cid: number;
    pic: string;
    preview:string;
    score: number;
    id: number
}

/**章节详情返回数据接口 */
class dlc_getChaptersDetail_S {
    info: string;
    code: number;
    data: {
        story: dlc_storyNexInfo[],
        detail: {
            locked: boolean;
            name: string;
            cid: number;
            pic: string;
            preview:string;
            score: number;
            id: number
        }[];
        start_status: number
    }
};

/**对话返回数据接口 */
class dlc_storyNex_S {
    info: string;
    code: number;
    data: {
        story: dlc_storyNexInfo[]
    }
};

/**消息的单个结构 */
class dlc_storyNexInfo {
    cons: {
    };
    cid: number;
    pid: number;
    content: string;
    score: number;
    role: number;
    sid: number;
    video: string;
    next_id: number;
    audio: string;
    id: number;
    roleimg:string;
}

/**结算返回请求数据 */
class dlc_storyFinish_S {
    info: string;
    code: number;
    data: {
        score: number,
        detail: {
            locked: boolean;
            name: string;
            cid: number;
            pic: string;
            preview:string;
            score: number;
            id: number
        }[],
        chapters:ChapterInfo[],
        story: dlc_storyNexInfo[]
    }
};