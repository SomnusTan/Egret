/**
 * 数据中心
 * @author chenkai 
 * @date 2016/6/27
 */
class DataCenter {
    //单例
    public static instance: DataCenter;
    public static getInstance(): DataCenter {
        if (this.instance == null) {
            this.instance = new DataCenter();
        }
        return this.instance;
    }
    /**是否第一次进入游戏 */
    public isFirstEnterGame: boolean = false;

    /**用户信息 */
    public UserInfo: UserInfo = new UserInfo();
    /**配置 */
    public ConfigInfo: ConfigInfo = new ConfigInfo();
    /**登录奖励详情 */
    public loginRewardInfo;

    /**累计充值*/
    public total_pay;
    /**月卡 */
    public month_cards;
    /**每日红包 */
    public red_packet;

    /**电话消息 */
    public Tel;
    /**微信消息 */
    public Wechat;
    /**恋爱 */
    public Love;
    /**工作 */
    public Work = [];
    /**商城 */
    public Shop;
    /**神秘商店 */
    public smShopData: any;
    /**背包 */
    public Bags;
    /**视频 */
    public Video: {
        /**回忆 */
        mem: any,
        /**收藏视频 */
        fav: any,
        /**背景 */
        bgi: any
    };
    /**微博 */
    public Weibo;
    /**是否能领取体力 */
    public isPower = false;
    /**邮件 */
    public mail = [];
    /**引导 */
    public guide;
    /**礼包数据 */
    public keybuy;
    /**首冲双倍活动事件 */
    public act_decade;
    /**红包抽中的钻石 */
    public lottery_result = 0;
    /**分享内容 */
    public shareContent: any;

    /**http请求权鉴 */
    public skey = "";

    /**引导 */
    public dianhuaGuide = false;
    public weixinGuide = false;
    public shipinGuide = false;
    public loveGuide = false;
    public workGuide = false;
    public bagGuide: boolean = false;
    public weiboGuide: boolean = false;

    public weixinWaitTimeEnd: number = 0;
    /**微信信息列表 */
    public weixinSendMsg: any[];
    /**微信消息类型 */
    public weixinMsgType: any;

    /**登录奖励(是否有登录奖励可以领取标志位)  活动中心内按钮状态：0不显示红点 1显示红点 -1不显示 */
    public login_reward: number = 0;
    /**累计充值（是否有累计充值可以领取标志位） 活动中心内按钮状态：0不显示红点 1显示红点 -1不显示*/
    public accumulative_recharge: number = 0;
    /**首冲礼包(是否第一次充值) false没冲过值  true冲过值 */
    public first_gift: boolean = false;
    /**是否当天第一次登录 */
    public is_first_login: boolean = false;
    /**视频是否正在播放(用于播放时停止bgm) */
    public isVideoPlaying: boolean = false;
    /**版本信息 */
    public authorInfo: any;
    /**最新优惠信息 */
    public offer: any;
    /**联动活动 */
    public announcement: any;
    /**碎片数量 */
    public excess_debris: number;

    /**360渠道 */
    public h5_360: boolean = false;

    /**累计充值内容 */
    public actAwardInfo: ActAwardInfo = new ActAwardInfo();

    public constructor() {
        this.Video = { mem: "", fav: "", bgi: "" };
    }

    /**销毁 */
    public destoryMe() {
        DataCenter.instance = null;
    }

    /**跳转支付宝 */
    public setOpenWindon(a) {
        window.open("/shop/web/switch/?url=" + a, "AliPay", "height=750,innerHeight=750,width=800,innerWidth=800,top=" + (window.screen.availHeight - 780) / 2 + ",left=" + (window.screen.availWidth - 810) / 2 + ",toolbar=no,menubar=no,scrollbars=auto,resizable=yes,location=yes,status=no");
    }

    //base64加密函数
    public setSelect(str) {
        var c1, c2, c3;
        var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        var i = 0, len = str.length, string0 = '';

        while (i < len) {
            c1 = str.charCodeAt(i++) & 0xff;
            if (i == len) {
                string0 += base64EncodeChars.charAt(c1 >> 2);
                string0 += base64EncodeChars.charAt((c1 & 0x3) << 4);
                string0 += "==";
                break;
            }
            c2 = str.charCodeAt(i++);
            if (i == len) {
                string0 += base64EncodeChars.charAt(c1 >> 2);
                string0 += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
                string0 += base64EncodeChars.charAt((c2 & 0xF) << 2);
                string0 += "=";
                break;
            }
            c3 = str.charCodeAt(i++);
            string0 += base64EncodeChars.charAt(c1 >> 2);
            string0 += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
            string0 += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
            string0 += base64EncodeChars.charAt(c3 & 0x3F)
        }
        return string0;
    }

    /**读取游戏信息 */
    public readGameInfo(data) {
        let json = ProtocolHttpData.gameInfo;
        json = data;
        this.Wechat = json.data.wechat;
        this.Tel = json.data.tel;
        this.Love = this.UserInfo.parseLoveData(json.data.love);
        this.Work = this.UserInfo.parseWorkData(json.data.work);
        this.Shop = json.data.shop;
        this.Bags = json.data.back;
        // App.DataCenter.Video = json.data.video;
        this.Weibo = json.data.weibo;
        this.isPower = data.data.power.can_get_power;
        this.keybuy = data.data.keybuy;
        this.guide = data.data.guide;
        this.mail = data.data.mail;
        this.login_reward = data.data.login_reward;
        this.first_gift = data.data.first_gift;
        this.is_first_login = data.data.is_first_login;
        this.act_decade = data.data.act_decade;
        this.offer = data.data.offer;
        this.announcement = data.data.announcement;
        this.excess_debris = data.data.excess_debris;

        //用户资料
        this.UserInfo.nickName = json.data.userinfo.nick_name;
        this.UserInfo.bgi = json.data.userinfo.bgi;
        // App.global.storage.setItem(EnumStorageType.G2_USERNAME, json.data.userinfo.user_name);
        this.UserInfo.id = json.data.userinfo.uid;
        this.UserInfo.days = json.data.userinfo.days;
        this.UserInfo.diamond = json.data.userinfo.diamond;
        this.UserInfo.gold = json.data.userinfo.gold;
        this.UserInfo.hearts = json.data.userinfo.hearts;
        this.UserInfo.power = json.data.userinfo.power;
        this.UserInfo.wc_wait = json.data.userinfo.wc_wait;
        if (json.data.work && json.data.work[0]) {
            this.UserInfo.workCount = json.data.work[0].left_times;
        };
        //配置
        this.ConfigInfo.main_event = json.data.config.main_event;
        this.ConfigInfo.avilable_event = json.data.config.avilable_event;
        this.ConfigInfo.days = json.data.config.days;
        this.ConfigInfo.hearts = json.data.config.hearts;
        this.ConfigInfo.video = json.data.config.video;
        this.ConfigInfo.girl_name = json.data.config.girl_name;

        //下阶段可做的事
        if (data.data.tel.nexttel && data.data.tel.nexttel.length > 0) {
            this.UserInfo.nextTel = true;
            this.UserInfo.tel_main = false;
        } else {
            this.UserInfo.nextTel = false;
            this.UserInfo.tel_main = true;//主事件完成
        }
        if (data.data.wechat.nextwechat && data.data.wechat.nextwechat.length > 0) {
            this.UserInfo.nextWechat = true;
            this.UserInfo.wechat_main = false;
        } else {
            this.UserInfo.nextWechat = false;
            this.UserInfo.wechat_main = true//主事件完成
        }


        //累计充值处是否显示
        this.total_pay = data.data.total_pay;
        GameLog.log('累计充值：', this.total_pay);
        if (data.data.total_pay.onoff == 1) {
            //累计充值处红点是否显示
            let len = this.total_pay.rewards.length;
            let rewardsData = this.total_pay.rewards;
            for (let i = 0; i < len; i++) {
                if (rewardsData[i].status == 1) {
                    this.accumulative_recharge = 1;
                }
            }
        } else {
            this.accumulative_recharge = -1;
        }

        //月卡 
        if (data.data.month_cards) {
            this.month_cards = data.data.month_cards;
        }

        //红包
        if (data.data.red_packet) {
            this.red_packet = data.data.red_packet;
        }
        if (data.data.lottery_result) {
            this.lottery_result = data.data.lottery_result;
        }
    }

    /**提前预加载图片 */
    public preLoadImg(data, doc: egret.DisplayObjectContainer) {
        //有人说这样搞，可以提高加载图片速度
        let img = new eui.Image(data.data.wechat.head);
        img.x = -100;
        img.y = -100;
        img.alpha = 0;
        doc.addChild(img);

        let img1 = new eui.Image(data.data.tel.head);
        img1.x = -100;
        img1.y = -100;
        img1.alpha = 0;
        doc.addChild(img1);

        data.data.love.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.work.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.shop.giftpcak.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.shop.tools.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.shop.diamonds.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.shop.golds.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.shop.limitpack.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.back.map(item => {
            let img = new eui.Image(item.pic);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.video.fav.map(item => {
            let img = new eui.Image(item.preview);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
        data.data.video.mem.map(item => {
            let img = new eui.Image(item.preview);
            img.x = -100;
            img.y = -100;
            img.alpha = 0;
            doc.addChild(img);
        });
    }
}


/**登录奖励领取状态 */
enum ActTabs {
    NewAct = 0,     //可领取
    LoginReward = 1, //已领取
    CannotRev = 2   //未达到天数不可领取
}

/**登录奖励领取状态 */
enum RevRewardStatus {
    CanRev = 0,     //可领取
    AlreadyRev = 1, //已领取
    CannotRev = 2   //未达到天数不可领取
}

/**登录奖励状态 */
enum LoginRewardStatus {
    NoRedTip = 0,  //活动中心内 登录奖励不显示红点
    RedTip = 1,    //活动中心内 登录奖励显示红点
    HideBtn = -1   //活动中心内 不显示登录奖励按钮
}

/**视频类型 */
class VideoType {
    /**回忆 */
    public static mem: string = "1";
    /**珍藏 */
    public static fav: string = "2";
}

/**游客类型 */
class GuestType {
    /**游客 */
    public static YES = "1";
    /**非游客 */
    public static NO = "0";
}

/**首冲领取状态 */
enum SCGainStatus {
    NoBuy = -1,  //未购买, 未领取
    HasBuy = 0,  //已购买, 未领取
    HasGain = 1  //已购买已领取
}

/**通话状态 */
enum CallStatus {
    Free,     //未接通
    Waiting   //等待回复
}

/**商城翻页 */
enum ShopPage {
    XianGou = 0,   //限购礼包
    GouMai,        //购买礼包
    Diamond,       //钻石
    Gold,          //金币
    DaoJu          //道具
}

/**后台开关配置 */
class ClientConfig {
    public static attention: number = 0;     //公告开关
    public static video: number = 1;         //视频开关
    public static inviteCode: number = 1;    //邀请码开关
};

/**ios配置 */
class IOSConfig {
    /**渠道标识 */
    public static channel: string = "";
    /**设备码 */
    public static iosID: string = "";
}

/**全局配置 */
class GlobalConfig {

    /**版本号 */
    private static _version_obj: {
        lib_version: string,
        main_version: string,
        res_version: string
    };
    /**
     * 获取版本控制器
     */
    public static get version_obj() {
        if (GlobalConfig._version_obj) {
            return GlobalConfig._version_obj;
        }
        //需要更改
        let v_obj = {
            lib_version: "1.7.4",
            main_version: "1.9.1",
            res_version: "1.7.4"
        };
        if (window && window["manifest"]) {
            v_obj.lib_version = window["manifest"].lib_version;
            v_obj.main_version = window["manifest"].main_version;
            v_obj.res_version = window["manifest"].res_version;
        }
        if (Config.isRelease) {
        } else {
            v_obj.main_version = "测试" + v_obj.main_version;
        }
        GlobalConfig._version_obj = v_obj;
        return GlobalConfig._version_obj;
    }
}
