/**
 * 累计充值内容
 * @author chenkai
 * @since 2017/10/19
 */

class ActAwardInfo {
	public content: string =
	"\n" + "活动规则："
	+ "\n" +
	"活动期间，累计充值达到对应档位将获得额外奖励，奖励叠"
	+ "加（例如充值{0}元可领取所有累计充值奖励）"
}

