/**
 * 用户数据
 * @author xiongjian 
 * @date 2017/9/8
 */
class UserInfo {
    /**
     * 当前背景
     */
    public bgi: string;
    /**角色id */
    public id;
    /**昵称*/
    public nickName: string = "";
    /**用户天数*/
    public days: number = 0;
    /**砖石*/
    public diamond: number = 0;
    /**金币*/
    public gold: number = 0;
    /**恋爱值*/
    public hearts: number = 0;
    /**体力值*/
    public power: number = 0;
    /**微信等待时间*/
    public wc_wait: number = 0;

    /**是否有下一段电话 */
    public nextTel: boolean = false;
    /**是否有下一段微信 */
    public nextWechat: boolean = false;
    /**微信是否结束* */
    public weChatFinish: boolean = true;
    /**微博是否可评论可赞 */
    public nextWeibo: boolean = false;

    /**剩余工作次数 */
    public workCount: number = 0;
    /**电话主事件是否完成 */
    public tel_main: boolean = false;
    /**微信主事件是否完成 */
    public wechat_main: boolean = false;

    /**礼包弹出随机常数 */
    public randNum = 3;
    /**恋爱红点检测结束时间 */
    private _loveCheckTime: number = 0;
    private _workCheckTime: number = 0;

    /**
     * 解析恋爱数据
     */
    public parseLoveData(json: any): any {
        if (json) {
            let len = json.length;
            for (let i = 0; i < len; i++) {
                let wait: number = json[i].wait;                    //当前冷却还需等待时间
                if (wait != undefined && wait > 0) {
                    json[i].endTime = ServerTime.serverTime + wait;
                    if (json.is_available) {
                        if (json.endTime < this._loveCheckTime || App.timer.hasTimer(this.checkLoveRed, this) == false) {
                            this._loveCheckTime = json.endTime;
                            App.timer.doTimeOnce(this, (this._loveCheckTime - ServerTime.serverTime) * 1000, this.checkLoveRed);
                        }
                    }
                }
                else
                    json[i].endTime = 0;
            }
        }
        return json;
    }

    /**
     * 更新恋爱数据
     */
    public updateLoveData(data: any): void {
        var lid: number = data.lid;
        var json: any = data.data;
        if (json.cd != 0) {
            let loveList = App.data.game2Center.DataCenter.Love;
            for (var i: number = 0, len: number = loveList.length; i < len; i++) {
                if (loveList[i].lid == lid) {
                    loveList[i].wait = json.wait;
                    loveList[i].endTime = ServerTime.serverTime + json.wait;
                    if (loveList[i].endTime < this._loveCheckTime || App.timer.hasTimer(this.checkLoveRed, this) == false) {
                        this._loveCheckTime = loveList[i].endTime;
                        App.timer.doTimeOnce(this, (this._loveCheckTime - ServerTime.serverTime) * 1000, this.checkLoveRed);
                    }
                    return;
                }
            }
        }
    }

    private checkLoveRed(): void {
        App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);
    }

    /**
     * 解析恋爱数据
     */
    public parseWorkData(json: any): any {
        if (json) {
            let len = json.length;
            for (let i = 0; i < len; i++) {
                let wait: number = json[i].wait;                    //当前冷却还需等待时间
                if (wait != undefined && wait > 0) {
                    json[i].endTime = ServerTime.serverTime + wait;
                    if (json.is_available) {
                        if (json.endTime < this._workCheckTime || App.timer.hasTimer(this.checkWorkRed, this) == false) {
                            this._workCheckTime = json.endTime;
                            App.timer.doTimeOnce(this, (this._workCheckTime - ServerTime.serverTime) * 1000, this.checkWorkRed);
                        }
                    }
                }
                else
                    json[i].endTime = 0;
            }
        }
        return json;
    }

    /**
     * 更新工作数据
     */
    public updateWorkData(data: any): void {
        var json: any = data.data;
        let workList = App.data.game2Center.DataCenter.Work;
        workList[0].exps = json.exps;
        workList[0].wait = json.wait;
        workList[0].left_times = json.left_times;
        workList[0].endTime = ServerTime.serverTime + json.wait;
        if (workList[0].endTime < this._workCheckTime || App.timer.hasTimer(this.checkWorkRed, this) == false) {
            this._workCheckTime = workList[0].endTime;
            App.timer.doTimeOnce(this, (this._workCheckTime - ServerTime.serverTime) * 1000, this.checkWorkRed);
        }
    }

    private checkWorkRed(): void {
        App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);
    }

    /**恋爱红点提示，判断条件：体力足够+恋爱项激活+恋爱项无冷却*/
    public isCanLove() {
        let loveList = App.data.game2Center.DataCenter.Love;
        if (loveList) {
            let lovePanelIsShowing: boolean = PanelManager.isShowing(PanelRegister.G2_LovePanel);
            let len = loveList.length;
            let cur_power: number = App.data.game2Center.DataCenter.UserInfo.power;  //当前玩家体力
            for (let i = 0; i < len; i++) {
                let cons_power: number = loveList[i].cons_power;        //恋爱最小所需体力值
                let is_available: number = loveList[i].is_available;    //是否激活可用
                // let wait: number = loveList[i].wait;                    //当前冷却还需等待时间
                let endTime: number = loveList[i].endTime;                    //当前冷却还需等待时间

                //激活+体力足够
                if (is_available == 1 && (cur_power >= cons_power)) {
                    //购买无冷却道具 => 恋爱无冷却
                    if (App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy) {
                        return true;
                        //恋爱项无倒计时 => 恋爱无冷却
                        // } else if (lovePanelIsShowing && loveList[i] && App.data.game2Center.DataCenter.loveBoxList[i].timer == null) {
                    } else if (endTime <= ServerTime.serverTime) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /**工作红点提示，判断条件：工作解锁+工作次数足够+工作无冷却 */
    public isCanWork() {
        let workList = App.data.game2Center.DataCenter.Work;
        if (workList) {
            let workPanelIsShowing: boolean = PanelManager.isShowing(PanelRegister.G2_WorkPanel);
            let len = workList.length;
            for (let i = 0; i < len; i++) {
                let endTime = workList[0].endTime;
                let left_times = workList[0].left_times;
                let canUp: boolean = workList[0].exps >= workList[0].upgrade_exp;
                //工作解锁+工作次数足够
                if (workList[i].locked == false && left_times > 0) {
                    //购买无冷却道具 => 工作无冷却
                    if (App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy) {
                        return true;
                        //工作项无倒计时 => 工作无冷却
                        // } else if (workPanelIsShowing && App.data.game2Center.DataCenter.workBoxList && App.data.game2Center.DataCenter.workBoxList[0].timer == null) {   //工作只有第一项才有冷却时间
                    } else if (canUp) {   //工作可升级
                        return true;
                    } else if (endTime <= ServerTime.serverTime) {   //工作只有第一项才有冷却时间
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**背包红点提示，背包有主动使用道具增加亲密度时 */
    public isHaveActiveItem() {
        let bagList = App.data.game2Center.DataCenter.Bags;
        if (bagList) {
            let len = bagList.length;
            for (let i = 0; i < len; i++) {
                if (bagList[i].initiative) {
                    return true;
                }
            }
        }
        return false;
    }

}