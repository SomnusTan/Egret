/**
 * 语言
 * @author chenkai
 * @date 2017/11/29
 */
class LanConst {
	//======== Dialog ===========
	public static dialog0_00: string = "提示";


	//======== 活动中心 ==========
	public static act0_00: string = "领取成功，奖励已放入背包中";
	public static act1_00: string = "领取成功，奖励已放入背包中";

	//========  视频 ==========
	public static video0_00: string = "确定要解锁视频吗?";
	public static video0_01: string = "确定要解锁背景吗?";
	public static video0_02: string = "确定设置当前为背景吗?";

	//========  邮件 ==========
	public static mail0_00: string = "领取成功";

	//========  HttpSender ==========
	public static http0_00: string = "请求超时，请稍候再试";
	public static http0_01: string = "返回数据有误";
	public static http0_02: string = "网络无法连接，请检查您的网络后重试";



}