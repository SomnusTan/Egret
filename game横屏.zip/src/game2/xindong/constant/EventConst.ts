/**
 * 事件名
 * @author chenkai
 * @date 2016/9/27
 */
class EventConst {
	/**等待时间 */
	public static WaitTime: string = "EventConst.WaitTime";
	/**工作等待时间 */
	public static WorkWaitTime: string = "EventConst.WorkWaitTime";
	/**引导 */
	public static guide: string = "EventConst.GUIDE";
	/**支付成功 */
	public static payBack: string = "EventConst.PAYBACK";
	/**更新四维 */
	public static UPDATE_SIWEI: string = "EventConst.UPDATE_SIWEI";
	/**更新游戏场景红点提示 */
	public static UPDATE_RED_TIP: string = "EventConst.UPDATE_RED_TIP";
	/**更新礼包 */
	public static UPDATE_LIBAO: string = "EventConst.UPDATE_LIBAO";
	/**礼品下放 */
	public static GIFTFORUSER: string = "EventConst.GIFTFORUSER";
	/**播放web视频 */
	public static PLAY_WEB_VIDEO: string = "EventConst.PLAY_WEB_VIDEO";
	/**更新商城道具item */
	public static UPDATE_LEFT_TIMES: string = "EventConst.UPDATE_LEFT_TIMES";
	/**购买钻石成功，用于更新商城钻石道具Item 首次双倍的显示 */
	public static UPDATE_FIRST_PAY: string = "EventConst.UPDATE_FIRST_PAY";
	/**跳转到购买钻石页面 */
	public static TURN_DIAMOND_PAGE: string = "EventConst.TURN_DIAMOND_PAGE";
	/**主页面检查是否能够升级 */
	public static CHECK_UPGRADE: string = "EventConst.CHECK_UPGRADE";
	/**请求游戏数据 */
	public static REQ_GAME_INFO: string = "EventConst.REQ_GAME_INFO";
	/**请求登录奖励详情 */
	public static REQ_LOGIN_REWARD: string = "EventConst.REQ_LOGIN_REWARD";
	/**请求引导完成 */
	public static REQ_GUIDE_DONE: string = "EventConst.REQ_GUIDE_DONE";
	/**更新首充 */
	public static UPDATE_SHOU_CHONG: string = "EventConst.UPDATE_SHOU_CHONG";
	/**退出游戏 */
	public static QUIT_GAME: string = "EventConst.QUIT_GAME";
	/**U8登录 */
	public static U8LOGIN: string = "EventConst.U8LOGIN";
	/**steam登录 */
	public static STEAM_LOGIN: string = "EventConst.STEAM_LOGIN";
	/**http请求错误 */
	public static HTTP_ERROR: string = "EventConst.HTTP_ERROR";
	/**u8登录失败 */
	public static U8LoginFail: string = "EventConst.U8LoginFail";
	/**请求IOS登录 */
	public static REQ_IOS_ID_LOGIN: string = "EventConst.REQ_IOS_ID_LOGIN";
	/**请求官方登录 */
	public static REQ_OFFICIAL_LOGIN: string = "EventConst.REQ_OFFICIAL_LOGIN";
	/**请求更新背包数据 */
	public static REQ_UPDATE_BAGS: string = "EventConst.REQ_UPDATE_BAGS";
	/**恋爱cd购买提示 */
	public static BUY_LOVE_CD: string = "EventConst.BUY_LOVE_CD";
	/**购买礼包视频 */
	public static BUY_LIBAO_VIDEO_SUCCESS: string = "EventConst.BUY_LIBAO_VIDEO_SUCCESS";

	/**dlc模块修改奖励简介事件 */
	public static DLC_CHANGE_CHAPTER_DETAIL: string = "EventConst.DLC_CHANGE_CHAPTER_DETAIL";
	/**DLC显示图片信息 */
	public static SHOW_IMG_INFO_SOURCE: string = "EventConst.SHOW_IMG_INFO_SOURCE";


	/**播放视频完成 */
	public static VIDEO_PLAY_FISNISH: string = "EventConst.VIDEO_PLAY_FISNISH";

	/**月卡购买成功 */
	public static BUY_MONTH_CARDS_SUCCESS: string = "EventConst.BUY_MONTH_CARDS_SUCCESS";
	/**更新背包心数 */
	public static UPDATE_BAG_XIN: string = "EventConst.UPDATE_BAG_XIN";
	/**初始化背包 */
	public static INIT_BAG: string = "EventConst.INIT_BAG";


	/**更新活动面板界面6 */
	public static UPDATE_ACT_VIEW6: string = "EventConst.UPDATE_ACT_VIEW6";


	/**工作升职增加项目 */
	public static ADD_WORD_ITEM: string = "EventConst.ADD_WORD_ITEM";

	/**更新限购次数 */
	public static UPDATE_LIMIT_NUM: string = "EventConst.UPDATE_LIMIT_NUM";
	/**更新商城礼包的Gold */
	public static UPDATE_SHOP_GIFT_GOLD: string = "EventConst.UPDATE_SHOP_GIFT_GOLD";
	/**更新视频面板的Gold */
	public static UPDATE_SHIPIN_GOLD: string = "EventConst.UPDATE_SHIPIN_GOLD";
	/**更新商城面板的Gold */
	public static UPDATE_SHOP_GOLD: string = "EventConst.UPDATE_SHOP_GOLD";
	/**刷新最新优惠活动面板 */
	public static REFRESH_ACT7PAGE: string = "EventConst.REFRESH_ACT7PAGE";



}