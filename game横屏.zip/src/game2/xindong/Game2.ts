class Game2 extends BaseGame {

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
    }

    public show(data?: any): void {
        super.show(data);
        if (Config.isLandscape == false) {
            App.setOrientation(egret.OrientationMode.LANDSCAPE);
        }
        WebParams.ip = ProtocolHttpUrlGame2.url;
        App.sound.enabled = false;
        App.res.loadGroup([AssetConst.LoadPanel], new FunctionVO(this.onLoadResComplete, this), null);
        App.data.game2Center.DataCenter.isFirstEnterGame = true;
    }

    public hide(): void {
        super.hide();
        PanelOpenManager.removePanel(EnumPanelID.G2_SetPanel);
        PanelOpenManager.removePanel(EnumPanelID.G2_GAME_SCENE);
        App.data.game2Center.SoundManager.stopBGM();
        App.sound.enabled = true;
        WebParams.ip = ProtocolHttpUrl.ip;
        if (Config.isLandscape == false) {
            if (DeviceUtil.IsWeb && DeviceUtil.isMobile)
                App.setOrientation(egret.OrientationMode.PORTRAIT);
            else
                App.setOrientation(egret.OrientationMode.AUTO);
        }
        App.data.game2Center.DataCenter.isFirstEnterGame = false;
    }

    //加载界面资源组加载完成
    private onLoadResComplete(event: RES.ResourceEvent): void {
        this.startCreateScene();
    }

    //创建场景界面
    protected startCreateScene() {
        //启动
        App.data.game2Center.init();
        PanelOpenManager.openPanel(EnumPanelID.G2_GAME_LOAD_SCENE);
    }
}