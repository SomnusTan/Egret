/**
 * 资源加载界面
 * @author xiongjian
 * @date 2017/08/24
 */
class LoadScene extends BasePanel {

    private _view: LoadSceneUI;

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new LoadSceneUI();
        this.addChild(this._view);
    }

    public show(data?: any): void {
        super.show(data);
        this.setProgress(0);
        //this.loadAsset();

        //h5判断iosQQ浏览器，提示不能正常游戏
        if (DeviceUtil.IsWeb &&
            Config.soEasy &&
            DeviceUtil.IsIos &&
            DeviceUtil.ISQQBrower &&
            DeviceUtil.isMobile) {
            let dialog: SureDialog = new SureDialog();
            dialog.setContentSize(30);
            dialog.show();
            dialog.setContent("如观看视频后无法正常游戏请更换其它浏览器重新进入游戏。\n推荐：Safari浏览器。");
            dialog.setOk(this.loadAsset, this);
        } else {
            this.loadAsset();
        }
    }

    public hide() {
        super.hide();
        this.setProgress(0);
    }

    /**
     * 设置加载进度
     * @value 进度 0-100
     */
    public setProgress(value: number) {
        if (this._view.percentLab) {
            this._view.percentLab.text = value + "%";
        }
        if (this._view.proImg && this._view.probg) {
            this._view.proImg.width = value * this._view.probg.width / 100;
        }
    }

    /**加载资源 */
    private loadAsset() {
        //因为原项目开始时没有分配好资源组，也没有模块加载等待的设置，这里网页版就不再费力细分了，只是将除了bgm之外的的mp3静默加载。
        // App.res.loadGroup(DeviceUtil.IsWeb ? AssetConst.BASE_RES_WEB_LIST : AssetConst.BASE_RES_NATIVE_LIST, new FunctionVO(this.loadLoginComplete, this), new FunctionVO(this.loadLoginProgress, this));
        App.res.loadGroup(DeviceUtil.isWebIOS ? AssetConst.SOUND_RES_LIST : AssetConst.ONLY_IMAGE_RES_LIST, new FunctionVO(this.loadLoginComplete, this), new FunctionVO(this.loadLoginProgress, this));
    }

    /**加载大厅界面进度 */
    private loadLoginProgress(e: RES.ResourceEvent) {
        this.setProgress(Math.round(e.itemsLoaded / e.itemsTotal * 100));
    }

    /**加载大厅界面完成 */
    private loadLoginComplete() {
        //静默加载mp3
        // this.showGameAdvice();
        // App.data.game2Center.ResUtils.loadGroup(AssetConst.Music);
        this.gotoLogin();
    }

    /**显示健康游戏忠告 */
    private showGameAdvice() {
        let gameAdvice: GameAdviceUI = new GameAdviceUI();
        this.addChild(gameAdvice);
        egret.Tween.get(this).wait(200).call(() => {
            this.removeChild(gameAdvice);
            gameAdvice = null;
            this.gotoLogin();
        }, this);
    }

    /**跳转到登录界面 */
    public gotoLogin() {
        if (Config.hasEnterGame && GameManager.isPlaying && GameManager.lasetGameId == EnumGameID.GAME2) {
            PanelOpenManager.removePanel(EnumPanelID.G2_GAME_LOAD_SCENE);
            PanelOpenManager.openPanel(EnumPanelID.G2_GAME_LOGIN_SCENE, null, false);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}