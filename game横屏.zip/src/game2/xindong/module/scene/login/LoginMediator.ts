/**
 * 登录控制模块
 * @author xiongian
 * @date 2017/8/24
 */
class LoginMediator extends Mediator {
    public static NAME: string = "LoginMediator";
    /**保存账号登录时的账号 */
    private account: string;
    /**保存账号登录时的密码 */
    private password: string;

    public constructor() {
        super();
    }

    public onRegister() {
        super.onRegister();
        this.addEvent(EventConst.U8LOGIN, this.reqU8Login, this);
        this.addEvent(EventConst.REQ_IOS_ID_LOGIN, this.reqIosIDLogin, this);
        this.addEvent(EventConst.REQ_OFFICIAL_LOGIN, this.reqOfficialLogin, this);
    }

    /**请求u8登录
     * param data u8数据是string，需要转JSON
     */
    private reqU8Login(data) {
        //登录u8后打开开始按钮，防止登录失败后，不能再次点击
        // this.loginScene.startBtn.enabled = false;

        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.u8_login, JSON.parse(data), new FunctionVO(this.revAccountLogin, this));
    }

    /**请求注册 */
    public reqRegister(account, password) {
        this.account = account;
        this.password = password;

        let data = ProtocolHttp.register;
        data.passwd = password;
        data.username = account;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.register, data, new FunctionVO(this.revRegister, this));
    }

    /**注册返回 */
    private revRegister(data) {
        var json = ProtocolHttpData.register;
        json = data;
        if (json.code == 200) {
            //持久化保存用户资料
            App.global.storage.setItem(EnumStorageType.G2_ACCOUNT, json.data.user);
            // App.global.storage.setItem(EnumStorageType.G2_PASSWORD, this.password);
            // App.data.game2Center.DataCenter.skey = json.data.skey;
            App.global.storage.setItem(EnumStorageType.G2_GUEST, GuestType.NO);

            this.reqGameInfo();
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**请求官方登录 非u8 非soeay等渠道登录 */
    public reqOfficialLogin() {
        //本地缓存账号密码登录
        // if (App.global.storage.getItem(EnumStorageType.G2_GUEST) == GuestType.NO) {
        //     let account: string = App.global.storage.getItem(EnumStorageType.G2_ACCOUNT);
        //     // let password: string = App.global.storage.getItem(EnumStorageType.G2_PASSWORD);
        //     this.reqAccountLogin(account, "");
        // } else {
        //游客登录
        // this.reqGuestLogin();
        // }
        this.reqGameInfo();
    }

    /**请求账号登录 */
    public reqAccountLogin(account: string, password: string) {
        this.account = account;
        this.password = password;

        var data = ProtocolHttp.login;
        data.username = account;
        data.passwd = this.password;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.login, data, new FunctionVO(this.revAccountLogin, this));
    }

    /**7k7k登录 */
    public req7k7kLogin() {
        GameLog.log("LoginMediator >> 7k7k登录");
        let auth_7k7k = window["auth_7k7k"];
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.k7k7_login, auth_7k7k, new FunctionVO(this.revAccountLogin, this));
        return false;
    }

    /**账号登录返回 */
    private revAccountLogin(data) {
        var json = ProtocolHttpData.login;
        json = data;
        if (json.code == 200) {
            App.global.storage.setItem(EnumStorageType.G2_ACCOUNT, json.data.user);
            // App.global.storage.setItem(EnumStorageType.G2_PASSWORD, this.password);
            App.data.game2Center.DataCenter.skey = json.data.skey;
            App.data.game2Center.DataCenter.UserInfo.nickName = json.data.user;
            App.global.storage.setItem(EnumStorageType.G2_GUEST, GuestType.NO);

            this.reqGameInfo();
        } else if (json.code == 801) {
            //账号或密码错误，则清理账号
            Notice.showBottomCenterMessage(data.info);
            App.global.storage.setItem(EnumStorageType.G2_ACCOUNT, "");
            // App.global.storage.setItem(EnumStorageType.G2_PASSWORD, "");
            App.global.storage.setItem(EnumStorageType.G2_GUEST, GuestType.YES);
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**请求ios游客登录 */
    public reqIosIDLogin() {
        var data = ProtocolHttp.guest;
        data.username = IOSConfig.iosID;   //设备码
        data.channel = IOSConfig.channel;  //渠道标识
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guest, data, new FunctionVO(this.revGuestLogin, this));
    }

    /**请求游客登录 */
    public reqGuestLogin() {
        GameLog.log("LoginMediator >> 游客登录");
        var data = ProtocolHttp.guest;
        var account: string = App.data.gameHallCenter.getHeroniesData(EnumGameID.GAME2).account;
        if (account) {
            App.global.storage.setItem(EnumStorageType.G2_ACCOUNT, account);
        }
        // else {
        //     account = App.global.storage.getItem(EnumStorageType.G2_ACCOUNT);
        // }
        data.username = account;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guest, data, new FunctionVO(this.revGuestLogin, this));
    }

    /**游客登录返回 */
    private revGuestLogin(data) {
        var json = ProtocolHttpData.guest;
        json = data;
        if (json.code == 200) {
            App.data.game2Center.DataCenter.skey = json.data.skey;
            App.data.game2Center.DataCenter.UserInfo.nickName = json.data.user;
            App.global.storage.setItem(EnumStorageType.G2_ACCOUNT, json.data.user);
            App.global.storage.setItem(EnumStorageType.G2_GUEST, GuestType.YES);
            var account: string = App.data.gameHallCenter.getHeroniesData(EnumGameID.GAME2).account;
            if (!account) {
                account = App.global.storage.getItem(EnumStorageType.G2_ACCOUNT);
                ProtocolGame2.instance().sendGame2NameBind(account, new FunctionVO(this.saveGame2NameBack, this));
            }
            else {
                this.reqGameInfo();
            }
        } else if (json.code == 401 || json.code == 801) {
            //账号或密码错误，则将账号清零
            // App.data.game2Center.LocalStorageUtil.account = "";
            Notice.showBottomCenterMessage(data.info);
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    private saveGame2NameBack(response: any): void {
        if (ResponseUtil.checkResponseData(response))//已经登录
        {
            GameLog.log('绑定心动1用户名成功');
        }
        this.reqGameInfo();
    }

    /**请求游戏信息 */
    public reqGameInfo() {
        if (PanelManager.isShowing(PanelRegister.G2_GAME_LOGIN_SCENE)) {
            let param = {};
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.gameinfo, param, new FunctionVO(this.revGameInfo, this));
        }
    }

    /**返回游戏信息*/
    private revGameInfo(data) {
        if (data.code == 200) {
            // App.data.game2Center.DataCenter.preLoadImg(data, this.loginScene);
            App.data.game2Center.DataCenter.readGameInfo(data);
            PanelOpenManager.removePanel(EnumPanelID.G2_GAME_LOGIN_SCENE);
            this.reqGuide();

            //上报角色信息
            App.nativeBridge.submitGameData(data.data.userinfo);

            //H5上报角色信息
            //soeasy上报游戏角色
            if (Config.soEasy) {
                SoEasySdk.reportRoleInfoH5();
                // GameLog.log("soeasy上报游戏角色成功");
            }
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**请求引导 */
    private reqGuide() {
        let guide = App.data.game2Center.DataCenter.guide;
        let type = guide.emph_zone;
        //判断昵称、视频。如果都没有则进入游戏界面
        if (guide.fill_nick_name) {
            PanelOpenManager.openPanel(EnumPanelID.G2_InputNamePanel);
        } else if (guide.video) {
            let param = { ossvid: guide.video };
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoUrl, param, new FunctionVO(this.revVideoPlay, this));
        } else {
            PanelOpenManager.removePanel(EnumPanelID.G2_InputNamePanel);
            PanelOpenManager.removePanel(EnumPanelID.G2_GAME_LOGIN_SCENE);

            //跳转到游戏界面
            PanelOpenManager.openPanel(EnumPanelID.G2_GAME_SCENE);
        }
    }

    /**接收视频播放结果 */
    public revVideoPlay(data) {
        if (data.code == 200) {
            //web mobile
            if (DeviceUtil.IsWeb && DeviceUtil.isMobile) {
                //移动web补充一个视频播放提示，否则无法自动播放
                let dialog: PlayVideoDialog = new PlayVideoDialog();
                dialog.setContent("我是一个普通的大学生，做梦也没想到校花竟然成为了我的女朋友，但是现实中的误会却让我们一次次伤害对方……");
                dialog.setOk(() => {
                    this.delayGuideBack();
                    App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this), EnumVideoType.XIN_DONG1);
                }, this);
                dialog.show();
            } else {
                this.delayGuideBack();
                App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this), EnumVideoType.XIN_DONG1);
            }
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    private onPlayVideoComplete(): void {
        Video.instance().dispose();
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
    }

    /**延迟请求引导 */
    private delayGuideBack() {
        //延迟请求引导，在播放视频后2s再请求引导，跳转界面，这样不闪。
        App.timer.doTimeOnce(this, 1000, this.guideBack);
    }

    /**引导视频结束 */
    private guideBack() {
        if (App.data.game2Center.DataCenter.guide.video) {
            this.reqGuideDone();
        }
    }

    /**完成引导 */
    public reqGuideDone() {
        let param = {};
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, param, new FunctionVO(this.revGuideDone, this));
    }

    /**引导完成返回 */
    private revGuideDone(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.dianhuaGuide = false;
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;

            this.reqGuide();
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

}
