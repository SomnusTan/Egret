/**
 * 输入昵称面板
 * @author xiongjian
 * @date 2017/10/12
 */
class InputNamePanel extends BasePanel {

    private _view: InputNameViewUI;

    public constructor(ctrl: LoginMediator) {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        this._view = new InputNameViewUI();
        this.addChild(this._view);
        // App.data.game2Center.StageUtils.fitBgIPhoneX(this.bgImg);
    }

    /**添加到场景中*/
    public show(data?: any): void {
        super.show(data);
        GameLog.log("InputNamePanel >> 进入昵称界面");
        CommomBtn.btnClick(this._view.startBtn, this.startBtnTouch, this);
        CommomBtn.btnClick(this._view.shaiziBtn, this.shaiziBtnTouch, this);
        App.timer.doFrameLoop(this, 3, this.addTextListener);
        this.shaiziBtnTouch();
    }
    private addTextListener(): void {
        if (this._view.zhanghaoEdit.textDisplay) {
            InputTextUtil.addNativeInputTextListener(this._view.zhanghaoEdit);
            if (this._view.zhanghaoEdit["textTemp"])
                this._view.zhanghaoEdit["textTemp"].textColor = 0x333333;
            App.timer.clearTimer(this, this.addTextListener);
        }
    }

    /**从场景中移除*/
    public hide(): void {
        super.hide();
        InputTextUtil.removeNativeInputTextListener(this._view.zhanghaoEdit);
        CommomBtn.removeClick(this._view.startBtn, this.startBtnTouch, this);
        CommomBtn.removeClick(this._view.shaiziBtn, this.shaiziBtnTouch, this);
        App.timer.clearTimer(this, this.addTextListener);
    }

    /**确定按钮点击 */
    private startBtnTouch() {
        if (this._view.zhanghaoEdit.text != "") {
            let param = { nick_name: "" }
            param.nick_name = this._view.zhanghaoEdit.text;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.nameBind, param, new FunctionVO(this.bindNameBack, this));
        } else {
            Notice.showBottomCenterMessage("请输入昵称");
        }

    }

    /**筛子点击 */
    private shaiziBtnTouch() {
        let param = {}
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.randomName, param, new FunctionVO(this.randomNameBack, this));
    }

    /**绑定名字 */
    private bindNameBack(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.UserInfo.nickName = data.data.name;
            // App.LocalStorageUtil.nickName = data.data.name;

            App.data.game2Center.mediatorCenter.loginMediator.reqGuideDone();
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**随机生成名字 */
    private randomNameBack(data) {
        if (data.code == 200) {
            this._view.zhanghaoEdit.text = data.data.name;
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}
