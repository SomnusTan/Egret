/**
 * 健康游戏忠告
 * @author chenkai
 * @since 2017/10/12
 */
class GameAdviceUI extends eui.Component{

	public constructor() {
		super();
		this.skinName = "GameAdviceUISkin";
		this.percentWidth = 100;
		this.percentHeight = 100;
	}
}