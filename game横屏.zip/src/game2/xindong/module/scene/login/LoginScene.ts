/**
 * 登录界面
 * @author xiongjian
 * @date 2017/08/24
 */
class LoginScene extends BasePanel {
    private _view: LoginSceneUI;

    public constructor() {
        super();
    }

    protected init() {
        this._view = new LoginSceneUI();
        this.addChild(this._view);
        this._view.titleLabel.text = "";
        this._view.componeyLabel.text = "";
        this._view.statusLabel.text = "";

        // App.data.game2Center.StageUtils.fitBgIPhoneX(this.bgImg);
        // App.ResUtils.destroyOneGrp(AssetConst.LoadPanel);
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        //初始化界面
        // this.account = App.data.game2Center.LocalStorageUtil.username;
        // this.nameLabel.text = App.data.game2Center.LocalStorageUtil.username;
        this._view.startBtn.alpha = 0;

        //倍特渠道需要屏掉logo 安卓

        //ios游戏名为《恋爱修炼册》，所以隐藏心动女生的logo
        // if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
        //     this.logo.visible = false;
        // }

        //加载soeasy SDK
        if (Config.soEasy) {
            onSoeasyLogin(1, new FunctionVO(this.soEasyLoginBack, this));
        } else {
            //请求开关配置
            this.reqUpgradeStatus();
        }
        this._dispatcher.addEventListener(EventConst.U8LoginFail, this.revU8LoginFail, this);
        this._dispatcher.addEventListener(G2_GameSceneEvent.REQ_UPGRADE_STATUS, this.reqUpgradeStatus, this);
    }

    private soEasyLoginBack(e: any): void {
        var request = e.currentTarget;
        let data = JSON.parse(request.response);
        GameLog.log("_onLoginHandler : ", data);
        if (data.code == "200") { //保存账号和key
            var userinfo = ZmSdk.getInstance().getUserInfo();
            // App.data.game2Center.DataCenter.skey = data.data.skey;
            GameLog.log("用户的sdkindx" + userinfo.common.sdkindx);

            if (userinfo.common.sdkindx == QingFengSdk.getInstance().sdkIndex) { //清风渠道额外加载sdk
                QingFengSdk.getInstance().loadSdk(dispatcherReqUpgradeStatus);
            }
            else if (userinfo.common.sdkindx == H5_3500_Sdk.getInstance().sdkIndex) { //h5_3500
                H5_3500_Sdk.getInstance().loadSdk(dispatcherReqUpgradeStatus);
            }
            // else if (userinfo.common.sdkindx == H5_37117_Sdk.getInstance().sdkIndex) { //h5_37117
            //     H5_37117_Sdk.getInstance().loadSdk(dispatcherReqUpgradeStatus);
            // }
            else if (userinfo.common.sdkindx == H5_4177_Sdk.getInstance().sdkIndex) { //h5_4177
                H5_4177_Sdk.getInstance().loadSdk(dispatcherReqUpgradeStatus);
            }
            else {//继续login的逻辑
                dispatcherReqUpgradeStatus();
            }
        }
    }

    public hide() {
        super.hide();
        egret.Tween.removeTweens(this._view.startBtn);

        CommomBtn.removeClick(this._view.startBtn, this.gotoGame, this);
        this._view.startBtn.enabled = true;
    }

    //请求后台开关配置
    private reqUpgradeStatus() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.upgradeStatus, {}, new FunctionVO(this.revUpgradeStatus, this));
    }

    //接收后台开关配置
    private revUpgradeStatus(data) {
        if (data.code == 200) {
            ClientConfig.video = data.data.video;
            ClientConfig.inviteCode = data.data.inviteCode;
            ClientConfig.attention = data.data.attention;

            //苹果审核，关闭公告和兑换码
            if (Config.IsApplyIOS) {
                ClientConfig.inviteCode = 0;
                ClientConfig.attention = 0;
            }

            //读取版号信息
            this.reqAuthorInfo();
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    //请求版本信息
    private reqAuthorInfo() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.authorInfo, {}, new FunctionVO(this.revAuthorInfo, this));
    }

    //接收版本信息
    private revAuthorInfo(data) {
        if (data.code == 200) {

            //显示版本信息
            App.data.game2Center.DataCenter.authorInfo = data.data;
            if (App.data.game2Center.DataCenter.authorInfo) {
                this._view.titleLabel.text = App.data.game2Center.DataCenter.authorInfo.title;
                this._view.componeyLabel.text = App.data.game2Center.DataCenter.authorInfo.company;
                this._view.statusLabel.text = App.data.game2Center.DataCenter.authorInfo.status;
            }

            //请求soeasy渠道屏蔽列表
            if (Config.soEasy) {
                this.reqFilterList();
            } else {
                //请求公告，或直接显示登录
                this.tryReqNotice();
            }
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    //请求soeasy渠道屏蔽列表
    private reqFilterList() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.fitlerList, {}, new FunctionVO(this.revFilterList, this));
    }

    //接收soeasy渠道屏蔽列表
    private revFilterList(data) {
        GameLog.log("LoginScene >> soeasy渠道屏蔽列表:", data);
        if (data.code == 200) {
            SoEasySdk.hideChannelList = data.data;

            this.tryReqNotice();
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    //检查是否需要请求公告
    private tryReqNotice() {
        if (ClientConfig.attention == 1) {
            this.reqNotice();
        } else {
            this.moveBtn();
        }
    }

    //登录取消或失败，启用开始按钮
    private revU8LoginFail(data) {
        this._view.startBtn.enabled = true;
    }

    /**请求公告 */
    private reqNotice() {
        let param = { Authorization: App.data.game2Center.DataCenter.skey };

        if (DeviceUtil.IsAndroid) {
            param["channel"] = "android";
        } else if (DeviceUtil.IsIos) {
            param["channel"] = "ios";
        }

        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.attention, param, new FunctionVO(this.revNotice, this));  //区分公告发给哪个渠道
    }

    /**接收公告 */
    private revNotice(data) {
        let json = ProtocolHttpData.attention;
        json = data;

        if (data.data.share) {
            App.data.game2Center.DataCenter.shareContent = data.data.share;
            GameLog.log(App.data.game2Center.DataCenter.shareContent);
        }

        // let panel = PanelOpenManager.openPanel(EnumPanelID.G2_NoticeDialogPanel, json);
        //弹框放置在最底层
        // App.data.game2Center.LayerManager.panelLayer.addChildAt(panel, 0);
        PanelOpenManager.openPanel(EnumPanelID.G2_NoticeDialogPanel, json);
        this.moveBtn();
    }

    /**按钮动画 */
    private moveBtn() {
        let yPos: number = this._view.startBtn.y;
        egret.Tween.get(this._view.startBtn).set({ y: yPos + 50, alpha: 0.4 })
            .to({ y: yPos - 30, alpha: 1 }, 500)
            .to({ y: yPos }, 300)
            .call(() => {
                egret.Tween.removeTweens(this._view.startBtn);
                CommomBtn.btnClick(this._view.startBtn, this.gotoGame, this, 1);
            }, this);
    }


    /**登录 如果已经注册过，就账号密码登录 */
    private gotoGame() {
        App.data.game2Center.mediatorCenter.loginMediator;
        //小米平台
        if (MilletSDK.getInstance().millet) {
            GameLog.log("小米平台-->" + MilletSDK.getInstance().milletData);
            MilletSDK.getInstance().login(this.loginMillt, this);
            return;
        }

        //360平台
        if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.qid != false) {
            GameLog.log("360渠道");
            // App.global.userInfo.skey = H5_360_Sdk.getInstance().config360.skey;
            // App.data.game2Center.DataCenter.skey = H5_360_Sdk.getInstance().config360.avg_token;
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
            return;
        }

        //玩吧数据
        if (WanBaSDK.getIntance().wanBaData) {
            let objWanBa: any = WanBaSDK.getIntance().wanBaData;
            GameLog.log("玩吧平台数据->" + JSON.stringify(objWanBa));
            this.loginWanBa(objWanBa.openid, objWanBa.openkey, WanBaSDK.getIntance().wanBaData.platform);
            return;
        }

        //vivo登录
        if (H5_Vivo_SDK.getInstance().vivoData) {
            GameLog.log("vivo渠道");
            H5_Vivo_SDK.getInstance().Vivo_login(this.vivoLogin, this);
            return;
        }

        //u8登录
        if (Config.U8Login) {
            //防止调用u8时，手机打开较慢，频繁点击开始
            this._view.startBtn.enabled = false;
            // App.nativeBridge.sendU8Login("");
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
            GameLog.log("------------U8Login-------------")
            return;
        }

        //soeasy平台
        if (Config.soEasy) {
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
            GameLog.log("------------soEasy-------------")
            return;
        }

        //7k7k渠道登陆
        let auth_7k7k = window["auth_7k7k"];
        if (auth_7k7k) {
            App.data.game2Center.mediatorCenter.loginMediator.req7k7kLogin();
            GameLog.log("------------auth_7k7k-------------")
            return;
        }

        //ios设备码登录
        if (DeviceUtil.IsIos && DeviceUtil.IsNative) {
            // App.nativeBridge.sendGetIosID();
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
            return;
        }

        //请求官方登录 非u8 非soeasy等渠道
        App.data.game2Center.mediatorCenter.loginMediator.reqOfficialLogin();
    }

    /**
     * vivo登陆
     */
    private vivoLogin(): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loginVivo, { authtoken: H5_Vivo_SDK.getInstance().gameInfo.opentoken }, new FunctionVO(this.revVivoLogin, this));
    }

    private revVivoLogin(data): void {
        if (data.code == 200) {
            //持久化保存用户资料
            App.data.game2Center.DataCenter.skey = data.data.skey;
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
            Notice.showBottomCenterMessage("登陆成功");
            return;
        }
        Notice.showBottomCenterMessage("登陆失败");
    }

    /**360登陆 */
    private h5_360(data) {
        if (data.code == 200) {
            H5_360_Sdk.getInstance().game_qid = data.data.qid;
            GameLog.log("H5_360     " + data.data.qid);
            // App.data.game2Center.DataCenter.skey = data.data.skey;
            App.data.game2Center.DataCenter.UserInfo.nickName = data.data.user;
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
        }
    }

    /**
     * 玩吧登陆
     */
    private loginWanBa(openid: string, openkey: string, platform: number): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loginWanBa, { openid: openid, openkey: openkey, platform: platform }, new FunctionVO(this.revWanBaLogin, this));
    }

    private revWanBaLogin(data): void {
        if (data.code == 200) {
            //持久化保存用户资料
            App.data.game2Center.DataCenter.skey = data.data.skey;
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
        }
    }

    /**
     * 小米登陆
     */
    private loginMillt(): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loginXiaoMi, { uid: MilletSDK.getInstance().milletData.uid, session: MilletSDK.getInstance().milletData.session },
            new FunctionVO(this.revMilltLogin, this));
    }

    private revMilltLogin(data): void {
        if (data.code == 200) {
            //持久化保存用户资料
            App.data.game2Center.DataCenter.skey = data.data.skey;
            App.data.game2Center.mediatorCenter.loginMediator.reqGameInfo();
            return;
        }
        Notice.showBottomCenterMessage(data.info + "");
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}