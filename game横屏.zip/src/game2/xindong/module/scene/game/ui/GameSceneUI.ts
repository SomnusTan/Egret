class GameSceneUI extends BaseUI {
	/**钻石UI */
	public coinUI: CoinUI;
	/**钻石UI */
	public diamondUI: DiamondUI;
	/**金币UI */
	public goldUI: GoldUI;
	/**体力UI */
	public powerUI: PowerUI;
	public btnGroup: eui.Group;  //按钮Group
	public btnBG: eui.Image;     //按钮背景
	public upGroup: eui.Group;//上部分group
	public leftGroup: eui.Group;//左边部分
	public downGroup: eui.Group;//下边部分
	public gameBG: eui.Image;    //背景图
	public mohuBG: eui.Image;    //模糊背景
	public heartPlugin: HeartsPlugins;
	public setBtn: SetBtn;          //设置
	public dateLabel: eui.BitmapLabel;    //天数lebel
	public qiandaoBtn: eui.Button;
	public fuliBtn: eui.Button;
	/**引导 */
	public yindaoGroup: eui.Group;
	public yindaodianhuaGroup: eui.Group;
	public yindaolianaiGroup: eui.Group;
	public yindaoGongzuoGroup: eui.Group;
	public yindaoShipinGroup: eui.Group;
	public yindaoweixinGroup: eui.Group;
	public yd_dianhuaImg: eui.Image;
	public dianhuaHand: eui.Image;
	public yd_lianaiImg: eui.Image;
	public lianaiHand: eui.Image;
	public yd_gongzuoImg: eui.Image;
	public gongzuoHand: eui.Image;
	public yd_shipinImg: eui.Image;
	public shipinHand: eui.Image;
	public yd_weixinImg: eui.Image;
	public weixinHand: eui.Image;
	/**升级引导 */
	public yindaoLevelUp: eui.Group;
	public backCircle: eui.Image;
	public backHand: eui.Image;
	/**背包引导 */
	public yindaoBag: eui.Group;
	public bagCircle: eui.Image;
	public bagHand: eui.Image;
	/**微博引导 */
	public yindaoWei: eui.Group;
	public weiCircle: eui.Image;
	public weiHand: eui.Image;
	/**任务提示 */
	public taskTipUI: TaskTipUI;
	public shipinBtn: eui.Button;
	public leftBtnGrp: eui.Group;//左侧按钮组
	public shareBtn: ShareBtn;      //分享按钮
	public actBtn: ActBtn;          //活动中心
	public shouChongBtn: ShouChongBtn; //首冲礼包
	public qrCodeBtn: QRCodeBtn; //关注按钮
	public sendToDeBtn: SendToDeBtn;//发送到桌面
	public redPacketBtn: RedPacketBtn;//每日红包
	/**dlc模块入口 */
	public dlcBtn: SecretShopBtn;
	/**神秘商店入口 */
	public msBtn: eui.Image;

	public constructor() {
		super("GameSceneSkin");
	}
}
