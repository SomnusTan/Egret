class CoinUI extends BaseUI {
    public coinLabel: eui.BitmapLabel;

    public constructor() {
        super("CoinUISkin");
    }
    /**
     * 心动币更新
     */
    public setCoin(value: number) {
        this.coinLabel.text = value.toString();
    }
}