/**
 * 游戏控制模块
 * @author xiongian
 * @date 2017/8/24
 */
class GameMediator extends Mediator {
    public static NAME: string = "GameMediator";
    /**显示游戏界面 */
    public static SHOW_GAME_SCENE: string = "SHOW_GAME_SCENE";


    public constructor() {
        super();
    }

    public get gameScene(): any {
        return PanelManager.getPanel(PanelRegister.G2_GAME_SCENE);
    }

    public onRegister() {
        super.onRegister();
        this.addEvent(EventConst.GIFTFORUSER, this.reqGiftForUser, this);
        this.addEvent(EventConst.PLAY_WEB_VIDEO, this.playWebVideo, this);
        this.addEvent(EventConst.REQ_LOGIN_REWARD, this.reqLoginReward, this);
        // this.addEvent(EventConst.UPDATE_SIWEI, this.onUpdateSiWei, this);
        // this.addEvent(EventConst.CHECK_UPGRADE, this.onCheckUpgrade, this);
        // this.addEvent(EventConst.REQ_GAME_INFO, this.reqGameInfo, this);
        this.addEvent(EventConst.QUIT_GAME, this.onQuitGame, this);
        this.addEvent(EventConst.REQ_UPDATE_BAGS, this.reqUpdateBags, this);
    }

    /**播放web视频 */
    private playWebVideo(url: string, callBack: FunctionVO, type: number = EnumVideoType.XIN_DONG1_VIDEO) {
        App.data.game2Center.SoundManager.stopBGM();
        Video.instance().init(url, false, false, callBack, Video.TOP, null, Config.isLandscape ? false : true);
        //显示视频播放控件
        PanelOpenManager.openPanel(EnumPanelID.VIDEO_BUTTON, { type: type });
    }

    // /**更新四维 */
    // private onUpdateSiWei() {
    //     this.gameScene.setConfig();
    // }

    // /**检查是否能够升级 */
    // private onCheckUpgrade() {
    //     if (this.gameScene.isUpgrade()) {
    //         this.gameScene.upGrade();
    //     }
    // }

    /**获取恋爱列表 */
    public reqLoves() {

        let json = {}
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loves, json, new FunctionVO(this.revLoves, this));
    }

    /**恋爱列表返回 */
    private revLoves(data) {
        if (data.code == 200) {
            let json = data.data;
            App.data.game2Center.DataCenter.Love = json;
            PanelOpenManager.openPanel(EnumPanelID.G2_LovePanel, json);
        }
    }

    // /**发送请求背包列表 */
    // public reqBags() {
    //     let json = {}
    //     ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.bags, json, new FunctionVO(this.revBags, this));
    // }

    // /**背包返回 */
    // private revBags(data) {
    //     if (data.code == 200) {
    //         App.data.game2Center.DataCenter.Bags = data.data;
    //         PanelOpenManager.openPanel(EnumPanelID.G2_BagsPanel);
    //     } else {
    //         Notice.showBottomCenterMessage("" + data.info);
    //     }
    // }

    /**请求更新背包数据(只更新，不打开背包面板。因为购买道具后，没更新背包数据，导致无法判断背包红点显示) */
    public reqUpdateBags() {
        let json = {}
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.bags, json, new FunctionVO(this.revUpdateBags, this));
    }

    /**接收更新背包数据 */
    private revUpdateBags(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.Bags = data.data;
            App.dispatcher.dispatchEvent(EventConst.INIT_BAG);
            App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }


    /**ios支付完成 */
    private reqGiftForUser(data) {
        let json = JSON.parse(data);
        if (json.code == 200) {

            let param = { order_id: json.data.order_id, receipt: json.data.receipt }
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftForUser, param, new FunctionVO(this.revGiftForUser, this), false, false);

        } else {
            Notice.showBottomCenterMessage("" + json.info);
        }
    }

    /**礼品下方返回 */
    private revGiftForUser(data) {
        if (data.code == 200) {
            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
            Notice.showBottomCenterMessage("购买成功");
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }


    //分享成功，请求奖励
    public reqShareGain() {

        let param = {};
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.shareGain, param, new FunctionVO(this.revShareGain, this));
    }

    //接收分享奖励
    private revShareGain(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            App.data.game2Center.DataCenter.UserInfo.power = data.data.power;
            App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
            this.gameScene && this.gameScene.setConfig();

            let shareGainDialog: ShareGainDialog = new ShareGainDialog();
            shareGainDialog.setGain();
            shareGainDialog.show();
        } else {
            let shareGainDialog: ShareGainDialog = new ShareGainDialog();
            shareGainDialog.setNoGain();
            shareGainDialog.show();
        }

    }

    /**请求登录奖励详情 page页数*/
    public reqLoginReward(page: number = 0) {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loginReward, {}, new FunctionVO((data) => {
            if (data.code == 200) {
                App.data.game2Center.DataCenter.loginRewardInfo = data;
                // let panel = PanelOpenManager.openPanel(PanelRegister.G2_ActPanel, page);
                // //弹框放置在最底层
                // App.data.game2Center.LayerManager.panelLayer.addChildAt(panel, 0);
                PanelOpenManager.openPanel(EnumPanelID.G2_ActPanel, page);

            } else {
                Notice.showBottomCenterMessage(data.info);
            }
        }, this));
    }

    /**请求游戏信息 */
    public reqGameInfo() {
        if (PanelManager.isShowing(PanelRegister.G2_GAME_SCENE)) {
            let param = {};
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.gameinfo, param, new FunctionVO(this.revGameInfo, this));
        }
    }

    /**返回游戏信息*/
    private revGameInfo(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.readGameInfo(data);
            App.dispatcher.dispatchEvent(EventConst.payBack);         //发送时间更新商城数据
            App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);  //更新红点提示
            App.dispatcher.dispatchEvent(EventConst.UPDATE_LIBAO);    //购买礼包返回刷新数据
            App.dispatcher.dispatchEvent(EventConst.UPDATE_FIRST_PAY);//更新商城购买钻石首次购买提示
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);    //刷新四维 

            //月卡功能开启
            App.dispatcher.dispatchEvent(EventConst.BUY_MONTH_CARDS_SUCCESS);//刷新月卡           
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**退出游戏 (由于之前界面和数据都没有做销毁处理，所以会内存泄露。鉴于用户不会频繁切换账号，就不处理了。)*/
    private onQuitGame() {
        //清理所有事件
        // App.dispatcher.removeAllEventListener();
        //停止所有资源加载
        // App.res.deleteAllCallBack();
        //停止背景音乐
        App.data.game2Center.SoundManager.stopBGM();
        //删除所有按钮监听
        CommomBtn.removeAll();
        //销毁DataCenter数据
        App.data.game2Center.DataCenter.destoryMe();

        //停止语音播放，无法停止
        App.data.game2Center.TalkManager.stopSound();

        //登出游戏功能，发送原生的登出
        // App.nativeBridge.sendLogOut();
    }

}