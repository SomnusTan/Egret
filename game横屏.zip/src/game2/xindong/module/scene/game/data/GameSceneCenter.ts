class GameSceneCenter {
	private gameOverDialog: GameOverDialog;

	public constructor() {
	}

    /**
     * 检测礼包
     * 在玩吧的渠道中
     */
	public checkGitFun(): void {
		if (WanBaSDK.getIntance().wanBaData && WanBaSDK.getIntance().gift) {
			//有玩吧数据 并且有礼包数据
			ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userInviteGain,
				{ Authorization: App.data.game2Center.DataCenter.skey, code: WanBaSDK.getIntance().gift }, new FunctionVO(this.revGit, this));
		}
	}

    /**
     * 玩吧礼包领取的返回
     */
	private revGit(data: any): void {
		GameLog.log("礼包领取-->" + data);
		if (data.code == 200) {
			//弹出公告框
			let noticeDialog: NoticeDialog = new NoticeDialog();
			let str: string = "恭喜你获得:";
			let gifts: any[] = data.data.gifts;
			for (let i = 0, len = gifts.length; i < len; i++) {
				str += gifts[i].cname + "X" + gifts[i].num;
				if (i < len - 1) {
					str += " ";
				}
			}
			noticeDialog.setContent(str);
			noticeDialog.setTitle("礼包");
			noticeDialog.setNoticeTitle("收到玩吧礼包:");
			noticeDialog.setWx(null, null);
			noticeDialog.setOk(() => {
			}, this);
			noticeDialog.show();
		}
	}

	/**发送升级 */
	public sendUpGrade(): void {
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.upgrade, {}, new FunctionVO(this.upgradeBack, this));
	}

	/**检测是否可升级 */
	public checkUpGrade() {
		GameLog.log("GameScene >> 询问是否可以升级");
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.prepare, {}, new FunctionVO(this.prepareBack, this));
	}

	/**能否升级返回 */
	private prepareBack(data) {
		if (data.code == 200) {
			if (App.data.game2Center.DataCenter.UserInfo.days == 1) {
				// 第一次升级引导
				App.dispatcher.dispatchEvent(G2_GameSceneEvent.LevelUpGuide);
				App.data.game2Center.LoadingLock.unLockScreen();
				return;
			}
			GameLog.log("GameScene >> 请求升级");
			this.sendUpGrade();
		} else if (data.code == 911) {
			//已经满级，游戏结束
			if (this.gameOverDialog == null) {
				this.gameOverDialog = new GameOverDialog();
				this.gameOverDialog.show();
			}
			App.data.game2Center.LoadingLock.unLockScreen();
		} else {
			App.data.game2Center.LoadingLock.unLockScreen();
			Notice.showBottomCenterMessage("" + data.info);
		}
	}

	/**升级返回 */
	private upgradeBack(data) {
		if (data.code == 200) {
			App.data.game2Center.DataCenter.readGameInfo(data);
			this.playUpgradeAnim();
			//更新红点提示
			App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);
		} else {
			App.data.game2Center.LoadingLock.unLockScreen();
			Notice.showBottomCenterMessage("" + data.info);
		}
	}

	//播放升级动画
	private playUpgradeAnim() {
		GameLog.log("GameScene >> 播放升级动画")

		var anim: UpgradeAnim = new UpgradeAnim();
		App.layer.effectLayer.addChild(anim);
		var sw: number = App.layer.rotation == 0 ? App.data.game2Center.StageUtils.stageWidth : App.data.game2Center.StageUtils.stageHeight;
		var sh: number = App.layer.rotation == 0 ? App.data.game2Center.StageUtils.stageHeight : App.data.game2Center.StageUtils.stageWidth;
		anim.x = (sw - 590) / 2;
		anim.y = (sh - 534) / 2;
		anim.play();
		anim.once(egret.Event.COMPLETE, this.onUpgradeAnimComplete, this);

		App.sound.playSoundSwitchClient1(SoundManager.levelup);
	}

	//动画播放完成，请求播放视频
	private onUpgradeAnimComplete(e: egret.Event) {
		var anim: UpgradeAnim = e.target;
		anim.destoryMe();

		let param = { ossvid: App.data.game2Center.DataCenter.ConfigInfo.video };
		this.sendPlayVideo2(param);
	}

	//升级完成后，激活界面
	private upgradeActiveView() {
		//延迟执行，防止动画、视频、引导显示过于集中
		App.timer.doTimeOnce(this, 1000, this.delaySetGameConfig);
	}

	private delaySetGameConfig(): void {
		App.data.game2Center.LoadingLock.unLockScreen();
		App.data.game2Center.LoadingLock.unlock();
		App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETGAMECONFIG);
	}


	/**升级视频播放 */
	public sendPlayVideo(param: any) {
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoUrl, param, new FunctionVO(this.videoUrlBack, this));
	}

	/**升级视频播放 */
	public sendPlayVideo2(param: any) {
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoUrl, param, new FunctionVO(this.videoUrlBack, this));
	}

	/**请求视频Url */
	public videoUrlBack(data) {
		if (data.code == 200) {
			//web版本需要点击播放
			if (DeviceUtil.IsWeb) {
				let dialog: PlayVideoDialog = new PlayVideoDialog();
				dialog.setContent("快去看看小野在干什么");
				dialog.setOk(() => {
					this.upgradeActiveView();
					App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this), EnumVideoType.XIN_DONG1);
				}, this);
				dialog.show(false);
				//非web版本，直接播放视频
			} else {
				this.upgradeActiveView();
				App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this), EnumVideoType.XIN_DONG1);
			}
		} else {
			App.data.game2Center.LoadingLock.unLockScreen();
			Notice.showBottomCenterMessage("" + data.info);
		}
	}

	private onPlayVideoComplete(): void {
		Video.instance().dispose();
		App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
	}

}