/**
 * 游戏界面
 * @author xiongjian
 * @date 2017/08/24
 */
class GameScene extends BasePanel {
    private _view: GameSceneUI;

    /**控制模块*/
    private ctrl: GameMediator;

    private isOut: boolean = true;
    private finishIn: boolean = false;
    private finishOut: boolean = true;

    private dianhuaHandY: number;
    private lianaiHandY: number;
    private gongzuoHandY: number;
    private shipinHandY: number;
    private weixinHandY: number;
    private backY: number;
    private bagY: number;
    private weiY: number;
    //底部按钮
    private dianhuaBtn: DianhuaBtn;
    private weixinBtn: WeixinBtn;
    private weiboBtn: WeiboBtn;
    private lianaiBtn: LianaiBtn;
    private gongzuoBtn: GongzuoBtn;
    private beibaoBtn: BeibaoBtn;
    // private shipinBtn: ShipinBtn;
    private shangchengBtn: ShangchengBtn;

    private btnList = []  //按钮配置

    public dispose(): void {
        this.dianhuaBtn && this.dianhuaBtn.dispose();
        this.weixinBtn && this.weixinBtn.dispose();
        this.weiboBtn && this.weiboBtn.dispose();
        this.lianaiBtn && this.lianaiBtn.dispose();
        this.gongzuoBtn && this.gongzuoBtn.dispose();
        this.beibaoBtn && this.beibaoBtn.dispose();
        this.shangchengBtn && this.shangchengBtn.dispose();
        if (this.ctrl) {
            this.ctrl.onRemove();
            this.ctrl = null;
        }
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new GameSceneUI();
        this.addChild(this._view);
        this.ctrl = App.data.game2Center.mediatorCenter.gameMediator;

        //记录引导手初始位置
        this.dianhuaHandY = this._view.dianhuaHand.y;
        this.lianaiHandY = this._view.lianaiHand.y;
        this.gongzuoHandY = this._view.gongzuoHand.y;
        this.shipinHandY = this._view.shipinHand.y;
        this.weixinHandY = this._view.weixinHand.y;
        this.backY = this._view.backHand.y;
        this.bagY = this._view.bagHand.y;
        this.weiY = this._view.weiHand.y;

        // 适配IPhoneX
        // App.StageUtils.fitBgIPhoneX(this.gameBG);
        // App.data.game2Center.StageUtils.fitBgIPhoneX(this._view.mohuBG);
        this.fitCurrencyIPhoneX();
    }

    /**
     * 修改背景
     */
    public changeGameBg(str: string): void {
        this._view.gameBG.source = str + "_jpg";
        this._view.mohuBG.source = this._view.gameBG.source;
        // this._view.mohuBG.texture = this._view.gameBG.texture;
        this._view.mohuBG.touchEnabled = false;
        // this._view.mohuBG.width = 1280;
        // this._view.mohuBG.height = 720;
        this._view.mohuBG.scaleX = 1.3;
        this._view.mohuBG.scaleY = 1.3;
        // this._view.mohuBG.filters = [FilterUtil.blur_filter];

        // App.data.game2Center.StageUtils.fullSomeToStage(this._view.gameBG);
    }

    /**IPHONE调整货币位置 */
    private fitCurrencyIPhoneX() {
        if (DeviceUtil.isIPhoneX) {
            this._view.diamondUI.x += 30;
            this._view.goldUI.x += 30;
            this._view.powerUI.x += 30;
            this._view.coinUI.x += 30;
            // this._view.leftBtnGrp.left += 25;
            // GameLog.log('DeviceUtil.isIPhoneX = ', DeviceUtil.isIPhoneX);
        }
    }

    public show(data?: any): void {
        super.show(data);
        // GameLog.log("GameScene >> 进入游戏界面");

        this.setActiveBtn();
        this.setBottomBtn(this.btnList);
        this.enterAnimation();
        this.setConfig();

        //引导
        this.setGuide();

        //分享功能
        this.checkShareFun();

        //检测礼包功能限玩吧的渠道中
        App.data.game2Center.gameSceneCenter.checkGitFun();
        // this.revGit({});
        //soeasy 清风游戏公告。 第一次进入游戏，并且不播放开场视频时...
        if (Config.soEasy && App.data.game2Center.DataCenter.isVideoPlaying == false) {
            QingFengSdk.getInstance().noticeSdk();
        }

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showDlcInfoPanel, this, this._view.dlcBtn);
        DlcUtils.addSomeOneBtnTouchScale(this._view.msBtn);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onMsBtn, this, this._view.msBtn);

        // egret.Tween.get(this).wait(5000).call(() => {
        //     this.changeGameBg("game_bg_1");
        // });

        // App.ResUtils.destroyOneGrp(AssetConst.Login);
        this.changeGameBg(App.data.game2Center.DataCenter.UserInfo.bgi + "_bg");

        //暂时隐藏 额外剧情dlc
        this._view.dlcBtn.visible = true;
        this._view.leftBtnGrp.layout = null;
        //从新布局
        for (let i = 0; i < this._view.leftBtnGrp.numChildren; i++) {
            let ch: egret.DisplayObject = this._view.leftBtnGrp.getChildAt(i);
            if (ch.visible == false) {
                ch.parent.removeChild(ch);
                i--;
            } else {
                DlcUtils.addSomeOneBtnTouchScale(ch);
                ch.x = (i % 3) * (108 + 7) + ch.anchorOffsetX;
                ch.y = (Math.floor(i / 3)) * (108 + 18) + ch.anchorOffsetY;
            }
        }

        this.enterAnimation();
        // GameLog.log("GameScene >> 进入游戏界面1");
        if (Video.instance().src) {
            App.data.game2Center.SoundManager.stopBGM();
        } else {
            App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);

        }
        // GameLog.log("GameScene >> 进入游戏界面2");
        CommomBtn.btnClick(this._view.setBtn, this.setBtnTouch, this);

        // this.lianaiBtn && this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.lianaiBtnTouch, this, this.lianaiBtn);
        // this.gongzuoBtn && this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.gongzuoBtnTouch, this, this.gongzuoBtn);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.shipinBtnTouch, this, this._view.shipinBtn);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.fuliBtnTouch, this, this._view.fuliBtn);

        this._dispatcher.addEventListener(G2_GameSceneEvent.SHOW_SCENE_ANIMATION, this.enterAnimation, this);
        this._dispatcher.addEventListener(G2_GameSceneEvent.HIDE_SCENE_ANIMATION, this.outAnimation, this);
        this._dispatcher.addEventListener(G2_GameSceneEvent.CHANGE_BG, this.changeGameBg, this);
        this._dispatcher.addEventListener(EventType.UPDATE_COIN, this.setCoinText, this);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_dianhuaImgTouch, this, this._view.yd_dianhuaImg);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_lianaiImgTouch, this, this._view.yd_lianaiImg);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_gongzuoImgTouch, this, this._view.yd_gongzuoImg);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_shipinImgTouch, this, this._view.yd_shipinImg);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_weixinImgTouch, this, this._view.yd_weixinImg);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_levelUpImgTouch, this, this._view.backCircle);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_bagImgTouch, this, this._view.bagCircle);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_weiboImgTouch, this, this._view.weiCircle);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.coinGroupTouch, this, this._view.coinUI);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.goldGroupTouch, this, this._view.goldUI);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.diamondGroupTouch, this, this._view.diamondUI);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.powerGroupTouch, this, this._view.powerUI);

        CommomBtn.btnClick(this._view.actBtn, this.onActTouch, this, 1);
        CommomBtn.btnClick(this._view.redPacketBtn, this.onRedPacketTouch, this, 1);

        this._dispatcher.addEventListener(EventConst.guide, this.guideBack, this);
        this._dispatcher.addEventListener(EventConst.UPDATE_RED_TIP, this.onUpdateRedTip, this);
        // this._dispatcher.addEventListener(EventConst.VIDEO_PLAY_FISNISH, this.onVideoFinish, this);

        this._dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.setConfig, this);//
        this._dispatcher.addEventListener(EventConst.CHECK_UPGRADE, this.onCheckUpgrade, this);//
        this._dispatcher.addEventListener(EventConst.REQ_GAME_INFO, this.reqGameInfo, this);//
        this._dispatcher.addEventListener(G2_GameSceneEvent.LevelUpGuide, this.setLevelUpGuide, this);
        this._dispatcher.addEventListener(G2_GameSceneEvent.SETGAMECONFIG, this.setGameConfig, this);

        //IOS屏蔽红包
        // if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
        //     if (App.data.game2Center.DataCenter.red_packet) {
        //         App.data.game2Center.DataCenter.red_packet.onoff = 0;
        //     }
        // }

        //红包
        if (App.data.game2Center.DataCenter.red_packet && App.data.game2Center.DataCenter.red_packet.onoff == 1) {
            this._view.redPacketBtn.visible = true;
        } else {
            this._view.redPacketBtn.visible = false;
        }

        this.onUpdateRedTip();

        ProtocolGame2.instance().send_extra_chapters_fragment_exchange(new FunctionVO(this.onExtraBack, this));
    }

    private onExtraBack(data: any): void {
        if (data.code == "200") {
            if (data.info) {
                var d: any = JSON.parse(data.info);
                if (d.sun_number) {
                    var getItem: GetItemNotice = new GetItemNotice();
                    getItem.setData("已开启心动之旅，将获得的心动碎片 x" + d.sun_number + " 兑换为", d.add_diamond, 1);
                    getItem.show();
                }
            }
        } else {
            if (App.data.game2Center.DataCenter.excess_debris) {
                var getItem: GetItemNotice = new GetItemNotice();
                getItem.setData("获得了", App.data.game2Center.DataCenter.excess_debris, 0);
                getItem.show();
            }
        }
    }

    public hide(): void {
        super.hide();
        App.data.game2Center.SoundManager.stopBGM();
        CommomBtn.removeClick(this._view.setBtn, this.setBtnTouch, this);
        CommomBtn.removeClick(this._view.actBtn, this.onActTouch, this);
        CommomBtn.removeClick(this._view.redPacketBtn, this.onRedPacketTouch, this);
    }

    private onMsBtn(e: egret.TouchEvent): void {
        PanelOpenManager.openPanel(EnumPanelID.G2_MysteriousShop);
    }

    /**配置底部按钮 */
    private setBottomBtn(list) {
        this._view.btnGroup.removeChildren();
        var allBtn = [];
        list.sort();//排下序
        for (let i = 0; i < list.length; i++) {
            switch (list[i]) {
                case 0:
                    break;
                case 1:
                    if (!this.dianhuaBtn)
                        this.dianhuaBtn = new DianhuaBtn();
                    allBtn.push(this.dianhuaBtn);
                    break;
                case 2:
                    if (!this.weixinBtn)
                        this.weixinBtn = new WeixinBtn();
                    allBtn.push(this.weixinBtn);
                    break;
                case 3:
                    if (!this.lianaiBtn)
                        this.lianaiBtn = new LianaiBtn();
                    allBtn.push(this.lianaiBtn);
                    break;
                case 4:
                    if (!this.gongzuoBtn)
                        this.gongzuoBtn = new GongzuoBtn();
                    allBtn.push(this.gongzuoBtn);
                    break;
                case 5:
                    if (!this.weiboBtn)
                        this.weiboBtn = new WeiboBtn();
                    allBtn.push(this.weiboBtn);
                    break;
                case 6:
                    if (!this.beibaoBtn)
                        this.beibaoBtn = new BeibaoBtn();
                    allBtn.push(this.beibaoBtn);
                    break;
                case 7:
                    if (!this.shangchengBtn)
                        this.shangchengBtn = new ShangchengBtn();
                    allBtn.push(this.shangchengBtn);
                    break;
                case 8:
                    if (ClientConfig.video == 1) {
                        this._view.shipinBtn.visible = true;
                    } else {
                        this._view.shipinBtn.visible = false;
                    }
                    break;
            }
        }

        for (let i = 0, len = allBtn.length; i < len; i++) {
            allBtn[i].x = 802 - (len - i - 1) * 123;
            allBtn[i].y = 67;
            this._view.btnGroup.addChild(allBtn[i]);
        }
        this._view.btnBG.width = allBtn.length * 115 + 75;
    }

    public showDlcInfoPanel(): void {
        this.outAnimation(EnumPanelID.G2_DlcMainDoc);
        // PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainDoc);
    }

    /**入场动画 */
    private enterAnimation() {
        // this._view.btnGroup.touchChildren = true;
        this._view.touchChildren = false;

        // //更新数据
        this.setConfig();
        this.setActive();

        //是否能升级
        // GameLog.log("isUpgrade", this.isUpgrade());
        if (this.isUpgrade()) {
            App.data.game2Center.LoadingLock.lockScreen();
            this.upGrade();
        }

        // 背包引导
        if (App.data.game2Center.DataCenter.bagGuide) {
            this.setBagGuide();
        }

        // 微博引导
        this.setWeiBoGuide();
        if (PanelManager.isShowing(PanelRegister.G2_WeixinPanel)) {
            return;
        }

        //上面部分
        egret.Tween.get(this._view.upGroup).set({ x: 1280, y: 12 })
            .to({ x: 681, y: 12 }, 250)
            .to({ x: 661, y: 12 }, 200)
            .to({ x: 681, y: 12 }, 150)
            .call(() => {
                egret.Tween.removeTweens(this._view.upGroup);
                this._view.touchChildren = true;
            });

        //左边部分
        egret.Tween.get(this._view.leftGroup).set({ x: -800, y: 0 })
            // .to({ x: -26, y: -17 }, 250)
            // .to({ x: -6, y: -17 }, 200)
            .to({ x: 0, y: 0 }, 250)
            .call(() => {
                egret.Tween.removeTweens(this._view.leftGroup);
            });
        //下边部分
        egret.Tween.get(this._view.downGroup).set({ x: 1280, y: 517 })
            // .to({ x: 370, y: 517 }, 150)
            // .to({ x: 350, y: 517 }, 200)
            .to({ x: 360, y: 517 }, 250)
            .call(() => {
                egret.Tween.removeTweens(this._view.downGroup);
            });
        // this._view.mohuBG.filters = null;
        /**背景模糊 */
        egret.Tween.get(this._view.mohuBG).set({ alpha: 1 })
            .to({ alpha: 0 }, 500)
            .call(() => {
                egret.Tween.removeTweens(this._view.mohuBG);
            });

        // egret.Tween.get(FilterUtil.blur_filter, {
        //     onChange: () => {
        //         this._view.gameBG.filters = [FilterUtil.blur_filter];
        //         this._view.gameBG.scaleX = this._view.gameBG.scaleY = 1 + 0.2 * FilterUtil.blur_filter.blurX / 8;
        //     }, onChangeObj: this
        // }).set({ blurX: 8, blurY: 8 })
        //     .to({ blurX: 0, blurY: 0 }, 300)
        //     .call(() => {
        //         egret.Tween.removeTweens(FilterUtil.blur_filter);
        //         this._view.gameBG.filters = null;
        //         this._view.gameBG.scaleX = this._view.gameBG.scaleY = 1;
        //     }, this);
    }
    /**
     * 出场动画
     * @param data 如果传numebr,则是打开面板ID,如果传FunctionVO则执行VO
     */
    private outAnimation(data: any) {
        // this._view.btnGroup.touchChildren = false;
        this._view.touchChildren = false;
        //下面部分
        egret.Tween.get(this._view.upGroup).set({ x: 681, y: 12 })
            .to({ x: 661, y: 12 }, 150)
            .to({ x: 681, y: 12 }, 200)
            .to({ x: 1280, y: 12 }, 250)
            .call(() => {
                egret.Tween.removeTweens(this._view.upGroup);
                if (TypeUtil.isNumber(data) && data != 0) {
                    PanelOpenManager.openPanel(data);
                }
                else if (data instanceof FunctionVO) {
                    (data as FunctionVO).exec();
                }
            });

        //左边部分
        egret.Tween.get(this._view.leftGroup).set({ x: 0, y: 0 })
            .to({ x: -800, y: 0 }, 250)
            .call(() => {
                egret.Tween.removeTweens(this._view.leftGroup);
            });
        //下边部分
        egret.Tween.get(this._view.downGroup).set({ x: 360, y: 517 })
            .to({ x: 1280, y: 517 }, 250)
            .call(() => {
                egret.Tween.removeTweens(this._view.downGroup);
            });

        /**背景模糊 */
        egret.Tween.get(this._view.mohuBG).set({ alpha: 0 })
            .to({ alpha: 1 }, 500)
            .call(() => {
                egret.Tween.removeTweens(this._view.mohuBG);
                // this._view.mohuBG.filters = [FilterUtil.blur_filter];
            });

        // this._view.gameBG.filters = [FilterUtil.blur_filter];
        // this._view.gameBG.scaleX = this._view.gameBG.scaleY = 1 + 0.2 * FilterUtil.blur_filter.blurX / 8;
        // this._view.gameBG.alpha = 0.1;
        // egret.Tween.get(this._view.gameBG).to({ alpha: 1 }, 300);

        // egret.Tween.get(FilterUtil.blur_filter, {
        //     onChange: () => {
        //         this._view.gameBG.filters = [FilterUtil.blur_filter];
        //         this._view.gameBG.scaleX = this._view.gameBG.scaleY = 1 + 0.2 * FilterUtil.blur_filter.blurX / 8;
        //     }, onChangeObj: this
        // }).set({ blurX: 0, blurY: 0 })
        //     .to({ blurX: 8, blurY: 8 }, 300)
        //     .call(() => {
        //         egret.Tween.removeTweens(FilterUtil.blur_filter);
        //     }, this);
    }

    /**视频按钮点击 */
    private shipinBtnTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userCollections, {}, new FunctionVO(this.revVideoList, this));
    }

    //接收视频列表
    private revVideoList(data) {
        if (data.code == 200) {
            //保存视频数据
            App.data.game2Center.DataCenter.Video.mem = data.data.mem;//回忆
            App.data.game2Center.DataCenter.Video.fav = data.data.fav;//收藏
            App.data.game2Center.DataCenter.Video.bgi = data.data.bgi;//背景
            this.outAnimation(EnumPanelID.G2_ShipinPanel);
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**电话引导点击 */
    private yd_dianhuaImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaodianhuaGroup.visible = false;
        App.data.game2Center.DataCenter.dianhuaGuide = true;//电话二级引导
        egret.Tween.removeTweens(this._view.dianhuaHand);

        App.sound.playSoundSwitchClient1(SoundManager.button);
        this.outAnimation(EnumPanelID.G2_DianhuaPanel);
    }
    /**引发微信点击 */
    private yd_weixinImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaoweixinGroup.visible = false;
        App.data.game2Center.DataCenter.weixinGuide = true;//电话二级引导
        egret.Tween.removeTweens(this._view.weixinHand);

        App.sound.playSoundSwitchClient1(SoundManager.button);
        this.outAnimation(EnumPanelID.G2_WeixinPanel);
    }

    /**设置升级引导 */
    private setLevelUpGuide() {
        this._view.yindaoGroup.visible = true;
        this._view.yindaoLevelUp.visible = true;
        egret.Tween.get(this._view.backHand, { loop: true })
            .set({ y: this.backY })
            .to({ y: this.backY + 40 }, 600)
            .to({ y: this.backY }, 800)
            .wait(100);
    }

    /**升级点击 */
    private yd_levelUpImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaoLevelUp.visible = false;
        egret.Tween.removeTweens(this._view.backHand);
        App.data.game2Center.gameSceneCenter.sendUpGrade();
    }

    /**设置背包引导 */
    private setBagGuide() {
        this._view.yindaoGroup.visible = true;
        this._view.yindaoBag.visible = true;
        egret.Tween.get(this._view.bagHand, { loop: true })
            .set({ y: this.bagY })
            .to({ y: this.bagY - 40 }, 600)
            .to({ y: this.bagY }, 800)
            .wait(100);
    }

    /**引导背包点击 */
    private yd_bagImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaoBag.visible = false;
        // this.beibaoBtnTouch();
        this.beibaoBtn.onTouch();
    }

    /**微博引导点击 */
    private yd_weiboImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaoWei.visible = false;
        App.data.game2Center.DataCenter.weiboGuide = true;
        App.sound.playSoundSwitchClient1(SoundManager.button);
        this.outAnimation(EnumPanelID.G2_WeiboPanel);
    }

    /**恋爱引导 */
    private yd_lianaiImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaolianaiGroup.visible = false;
        App.data.game2Center.DataCenter.loveGuide = true;//电话二级引导
        egret.Tween.removeTweens(this._view.lianaiHand);

        App.sound.playSoundSwitchClient1(SoundManager.button);
        this.outAnimation(EnumPanelID.G2_LovePanel);
    }
    /**工作引导 */
    private yd_gongzuoImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaoGongzuoGroup.visible = false;
        App.data.game2Center.DataCenter.workGuide = true;//电话二级引导
        egret.Tween.removeTweens(this._view.gongzuoHand);

        App.sound.playSoundSwitchClient1(SoundManager.button);
        this.outAnimation(EnumPanelID.G2_WorkPanel);
    }

    /**视频引导 */
    private yd_shipinImgTouch() {
        this._view.yindaoGroup.visible = false;
        this._view.yindaoShipinGroup.visible = false;
        App.data.game2Center.DataCenter.shipinGuide = true;//视频引导
        egret.Tween.removeTweens(this._view.shipinHand);
        this.shipinBtnTouch();
        // this.outAnimation(EnumPanelID.G2_ShipinPanel);
    }

    /**心动币Group点击 */
    private coinGroupTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        //App.PanelManager.open(PanelRegister.G2_ShopPanel, ShopPage.Gold);
        PanelOpenManager.openPanel(EnumPanelID.G2_SHOP_COIN_PANEL, { type: 1 });

    }

    /**金币Group点击 */
    private goldGroupTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        //App.PanelManager.open(PanelRegister.G2_ShopPanel, ShopPage.Gold);
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGoldPanel);

    }

    /**砖石Group点击 */
    private diamondGroupTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        // App.PanelManager.open(PanelRegister.G2_ShopPanel, ShopPage.Diamond);
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopDiamondPanel, null, false);

    }

    /**体力Group点击 */
    private powerGroupTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGiftToolPanel, 1);

    }

    /**体力图片点击 */
    private tiliImgTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        this.outAnimation(EnumPanelID.G2_GAME_LOGIN_SCENE);
    }
    /**设置点击 */
    private setTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
    }

    /**福利按钮点击 */
    private fuliBtnTouch() {

    }
    // /**签到按钮点击 */
    // private qiandaoBtnTouch() {
    //     PanelOpenManager.openPanel(EnumPanelID.G2_WorkProPanel);
    //     let love = <LoveProPanel>App.data.game2Center.PanelManager.getPanel(PanelRegister.G2_WorkProPanel);
    //     let count = 100;
    //     let delay = 10000 / 100;
    //     love.countDown(delay, count);
    // }

    /**活动按钮点击 */
    private huodongBtnTouch() {
        TipsHeat.showHeat(10);
        App.sound.playSoundSwitchClient1(SoundManager.button);
    }
    /**福利按钮点击 */
    private fuBtnTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
    }
    /**设置按钮点击 */
    private setBtnTouch() {
        this.getMail();
    }

    // /**恋爱按钮点击 */
    // private lianaiBtnTouch() {
    //     App.sound.playSoundSwitchClient1(SoundManager.button);
    //     this.outAnimation(EnumPanelID.G2_LovePanel);
    // }

    // /**工作按钮点击 */
    // private gongzuoBtnTouch() {
    //     App.sound.playSoundSwitchClient1(SoundManager.button);
    //     this.outAnimation(EnumPanelID.G2_WorkPanel);
    // }

    /**商城按钮点击 */
    private shopTouch() {
        this.outAnimation(EnumPanelID.G2_ShopGiftToolPanel);
    }

    // /**背包按钮点击 */
    // private beibaoBtnTouch() {
    //     App.sound.playSoundSwitchClient1(SoundManager.button);
    //     this.outAnimation(new FunctionVO(this.ctrl.reqBags, this));
    // }

    //活动中心
    private onActTouch() {
        this.ctrl.reqLoginReward();
    }

    //每日红包
    private onRedPacketTouch() {
        PanelOpenManager.openPanel(EnumPanelID.G2_RedPacketPanel);
    }

    /**设置爱心 */
    public setXinText(str, h) {
        if (h && h != "") {
            this._view.heartPlugin.setJindu(str, h);
        }
    }

    /**设置天数 */
    public setDateText(str) {
        if (str && str != "") {
            if (str >= 10 && str < 100) {
                this._view.dateLabel.scaleX = 0.8;
                this._view.dateLabel.scaleY = 0.8;
            }
            if (str >= 100 && str < 1000) {
                this._view.dateLabel.scaleX = 0.6;
                this._view.dateLabel.scaleY = 0.6;
            }
            if (str >= 1000) {
                this._view.dateLabel.scaleX = 0.4;
                this._view.dateLabel.scaleY = 0.4;
            }

            this._view.dateLabel.text = str;
        }
    }

    /**设置心动币 */
    public setCoinText() {
        this._view.coinUI.setCoin(App.global.userInfo.xdCoin);
    }

    /**设置砖石 */
    public setDiaMondText(str) {
        this._view.diamondUI.setDiamond(str);
    }

    /**配置数值 */
    public setConfig() {
        // GameLog.log("config", App.data.game2Center.DataCenter.UserInfo.days);
        this.setDateText(App.data.game2Center.DataCenter.UserInfo.days);
        this._view.coinUI.setCoin(App.global.userInfo.xdCoin);
        this._view.diamondUI.setDiamond(App.data.game2Center.DataCenter.UserInfo.diamond);
        this._view.goldUI.setGold(App.data.game2Center.DataCenter.UserInfo.gold);
        this._view.powerUI.setPower(App.data.game2Center.DataCenter.UserInfo.power);
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    /**现阶段可操作选项 */
    public setActive() {
        this._view.taskTipUI.visible = false;
        let power = App.data.game2Center.DataCenter.UserInfo.power;  //体力
        let workCount = App.data.game2Center.DataCenter.UserInfo.workCount; //剩余工资次数
        let nextWeixin = App.data.game2Center.DataCenter.UserInfo.nextWechat; //是否有下阶段微信
        let nextTel = App.data.game2Center.DataCenter.UserInfo.nextTel; //是否有下阶段电话
        let main_event = App.data.game2Center.DataCenter.ConfigInfo.main_event;//必须完成的主事件
        let finish_event = App.data.game2Center.DataCenter.ConfigInfo.finish_main_event;//已经完成的主事件
        let mail = App.data.game2Center.DataCenter.mail;                       //邮件

        //第一阶段微信在电话打完后出现
        if (App.data.game2Center.DataCenter.ConfigInfo.days == 1 && App.data.game2Center.DataCenter.UserInfo.tel_main) {
            let ispush = false;
            for (let i = 0; i < this.btnList.length; i++) {
                if (this.btnList[i] == 2) {
                    ispush = true;
                }
            }
            if (!ispush) {
                this.btnList.push(2);
            }
            this.setBottomBtn(this.btnList);
            this.setGuide();
        }

        // GameLog.log("tel", nextTel, "we", nextWeixin);
        // GameLog.log("uheart", App.data.game2Center.DataCenter.UserInfo.hearts, "cheart", App.data.game2Center.DataCenter.ConfigInfo.hearts);
        //微博
        let nextWeibo = false;//是否有可操作微博
        let weibo = App.data.game2Center.DataCenter.Weibo;
        for (let i = 0; i < weibo.data.length; i++) {
            if (weibo.data[i].is_approve == 0 || weibo.data[i].is_reply == 0) {
                nextWeibo = true;
                break;
            }
        }
        if (nextWeibo) {
            this.weiboBtn && this.weiboBtn.showRedPoint(true);
        } else {
            this.weiboBtn && this.weiboBtn.showRedPoint(false);
        }

        // //微信
        if (nextWeixin && App.data.game2Center.DataCenter.UserInfo.tel_main) {
            GameLog.log(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts)
            if (App.data.game2Center.DataCenter.UserInfo.hearts >= App.data.game2Center.DataCenter.ConfigInfo.hearts) {
                this.weixinBtn && this.weixinBtn.showRedPoint(true);
                this._view.taskTipUI.visible = true;
                this._view.taskTipUI.setTip("快给小野发个微信吧~");
            } else {
                this.weixinBtn && this.weixinBtn.showRedPoint(true);
            }
        } else {
            this.weixinBtn && this.weixinBtn.showRedPoint(false);
        }

        //电话
        if (nextTel) {
            if (App.data.game2Center.DataCenter.UserInfo.hearts >= App.data.game2Center.DataCenter.ConfigInfo.hearts) {
                this.dianhuaBtn.showRedPoint(true);
                this._view.taskTipUI.visible = true;
                this._view.taskTipUI.setTip("快给小野打个电话吧~");
            } else {
                this.dianhuaBtn.showRedPoint(true);
            }
        } else {
            this.dianhuaBtn.showRedPoint(false);
        }

        //更新红点提示
        App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);
    }

    private reqGameInfo(data?: any): void {
        if (data && data.delay) {
            //微信支付红包延迟请求刷新数据
            App.timer.doTimeOnce(this, data.delay, this.onDelayRequest)
        } else {
            this.onDelayRequest();
        }
    }

    private onDelayRequest(): void {
        App.timer.clearTimer(this, this.onDelayRequest);
        this.ctrl && this.ctrl.reqGameInfo();
    }

    /**检查是否能够升级 */
    private onCheckUpgrade() {
        if (this.isUpgrade()) {
            this.upGrade();
        }
    }

    /**能否升级 */
    public isUpgrade() {
        let tel_event = App.data.game2Center.DataCenter.UserInfo.tel_main;//电话主事件
        let wechat_event = App.data.game2Center.DataCenter.UserInfo.wechat_main;//微信主事件
        // GameLog.log("tel_event", tel_event, "wechat_event", wechat_event);
        let myhearts = App.data.game2Center.DataCenter.UserInfo.hearts;
        let configHeart = App.data.game2Center.DataCenter.ConfigInfo.hearts;

        if (tel_event && wechat_event && myhearts >= configHeart) {
            return true;
        } else {
            return false;
        }
    }

    private setGameConfig(): void {
        this.setConfig();
        this.setActiveBtn();
        this.setBottomBtn(this.btnList);
        this.setGuide();
        this.setActive();
    }

    /**升级 */
    public upGrade() {
        App.data.game2Center.gameSceneCenter.checkUpGrade();
    }

    /**获取邮件列表 */
    private getMail() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.mailList, {}, new FunctionVO(this.mailBack, this));
    }

    /**获取邮件列表返回 */
    private mailBack(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.mail = data.data;
            this.outAnimation(EnumPanelID.G2_SetPanel);
            //更新红点提示
            App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**
     * 主界面的引导
     */
    public setGuide() {
        if (Config.skipVideo)
            return;
        let guide = App.data.game2Center.DataCenter.guide;
        let type = guide.emph_zone;
        GameLog.log("GameScene >> 当前引导:", guide);
        if (guide.video) {
            let param = { ossvid: guide.video };
            App.data.game2Center.gameSceneCenter.sendPlayVideo(param);
            if (!DeviceUtil.IsNative) {
                this.guideBack();
            }
        } else if (guide.fill_nick_name) {
            PanelOpenManager.openPanel(EnumPanelID.G2_InputNamePanel);
        } else {
            this.checkFirstLogin();
            this.checkShouChong();
        }

        switch (type) {
            case "ZONE_PHONE":
                this._view.yindaoGroup.visible = true;
                this._view.yindaodianhuaGroup.visible = true;
                egret.Tween.get(this._view.dianhuaHand, { loop: true })
                    .set({ y: this.dianhuaHandY })
                    .to({ y: this.dianhuaHandY - 40 }, 600)
                    .to({ y: this.dianhuaHandY }, 800).wait(100);

                break;
            case "ZONE_WEIXIN":
                this._view.yindaoGroup.visible = true;
                this._view.yindaoweixinGroup.visible = true;
                egret.Tween.get(this._view.weixinHand, { loop: true })
                    .set({ y: this.weixinHandY })
                    .to({ y: this.weixinHandY - 40 }, 600)
                    .to({ y: this.weixinHandY }, 800).wait(100);
                break;
            case "ZONE_LOVE":
                this._view.yindaoGroup.visible = true;
                this._view.yindaolianaiGroup.visible = true;
                egret.Tween.get(this._view.lianaiHand, { loop: true })
                    .set({ y: this.lianaiHandY })
                    .to({ y: this.lianaiHandY - 40 }, 600)
                    .to({ y: this.lianaiHandY }, 800).wait(100);
                break;
            case "ZONE_WORK":
                this._view.yindaoGroup.visible = true;
                this._view.yindaoGongzuoGroup.visible = true;
                egret.Tween.get(this._view.gongzuoHand, { loop: true })
                    .set({ y: this.gongzuoHandY })
                    .to({ y: this.gongzuoHandY - 40 }, 600)
                    .to({ y: this.gongzuoHandY }, 800).wait(100);
                break;
            case "ZONE_VIDEO":
                if (ClientConfig.video == 1) {
                    this._view.shipinBtn.visible = true;
                    this._view.yindaoGroup.visible = true;
                    this._view.yindaoShipinGroup.visible = true;
                    egret.Tween.get(this._view.shipinHand, { loop: true })
                        .set({ y: this.shipinHandY })
                        .to({ y: this.shipinHandY - 40 }, 600)
                        .to({ y: this.shipinHandY }, 800).wait(100);
                }
                break;
            case "ZONE_WEIBO":
                this._view.yindaoGroup.visible = true;
                this._view.yindaoWei.visible = true;
                egret.Tween.get(this._view.weiHand, { loop: true })
                    .set({ y: this.weiY })
                    .to({ y: this.weiY - 40 }, 600)
                    .to({ y: this.weiY }, 800).wait(100);
                break;
        }
    }

    private setWeiBoGuide() {
        if (App.data.game2Center.DataCenter.guide.emph_zone == "ZONE_WEIBO") {
            this._view.yindaoGroup.visible = true;
            this._view.yindaoWei.visible = true;
            egret.Tween.get(this._view.weiHand, { loop: true })
                .set({ y: this.weiY })
                .to({ y: this.weiY - 40 }, 600)
                .to({ y: this.weiY }, 800).wait(100);
        }
    }

    /**引导视频结束 */
    private guideBack() {
        //非游戏场景，不处理该请求
        // if (App.data.game2Center.SceneManager.getCurScene() != this) {
        //     return;
        // }
        if (App.data.game2Center.DataCenter.guide.video) {
            this.finishGuide();
        }
    }

    /**完成引导 */
    private finishGuide() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, {}, new FunctionVO(this.finishGuideBack, this));
    }

    /**引导完成返回 */
    private finishGuideBack(data) {
        if (data.code == 200) {
            this._view.yindaoGroup.visible = false;
            egret.Tween.removeTweens(this._view.dianhuaHand);
            App.data.game2Center.DataCenter.dianhuaGuide = false;
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;
            this.setGuide();
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**设置解锁按钮 */
    private setActiveBtn() {
        this.btnList = [];
        let data = App.data.game2Center.DataCenter.ConfigInfo.avilable_event;
        for (let i = 0; i < data.length; i++) {
            switch (data[i].type) {
                case "tel":
                    this.btnList.push(1);
                    break;
                case "wechat":
                    if (App.data.game2Center.DataCenter.ConfigInfo.days != 1 || App.data.game2Center.DataCenter.guide.emph_zone != "ZONE_PHONE") {
                        this.btnList.push(2);
                    }
                    break;
                case "love":
                    this.btnList.push(3);
                    break;
                case "work":
                    this.btnList.push(4);
                    break;
                case "weibo":
                    this.btnList.push(5);
                    break;
                case "back":
                    this.btnList.push(6);
                    break;
                case "shop":
                    this.btnList.push(7);
                    break;
                case "video":
                    this.btnList.push(8);
                    break;
            }
        }
    }

    //更新游戏场景中红心提示
    private onUpdateRedTip() {
        //邮件提示
        let mail = App.data.game2Center.DataCenter.mail;
        if (mail && mail.length > 0) {
            this._view.setBtn.showRedPoint(true);
        } else {
            this._view.setBtn.showRedPoint(false);
        }

        //soeasy某些渠道屏蔽邮件，红点不显示
        if (Config.soEasy && SoEasySdk.shieldChannel()) {
            this._view.setBtn.showRedPoint(false);
        }

        //活动中心提示
        if (App.data.game2Center.DataCenter.isPower ||
            App.data.game2Center.DataCenter.login_reward == LoginRewardStatus.RedTip ||
            !App.data.game2Center.DataCenter.first_gift ||
            App.data.game2Center.DataCenter.accumulative_recharge == 1
            || (App.data.game2Center.DataCenter.month_cards &&
                (App.data.game2Center.DataCenter.month_cards.month_cards == 0 ||
                    App.data.game2Center.DataCenter.month_cards.month_cards == 1))) {
            this._view.actBtn.showRedPoint(true);
        } else {
            this._view.actBtn.showRedPoint(false);
        }

        //首冲按钮显示
        this.checkShouChong();
        //恋爱红点提示
        this.lianaiBtn && this.lianaiBtn.showRedPoint(App.data.game2Center.DataCenter.UserInfo.isCanLove());
        //工作红点提示
        this.gongzuoBtn && this.gongzuoBtn.showRedPoint(App.data.game2Center.DataCenter.UserInfo.isCanWork());
        //背包红点提示
        this.beibaoBtn && this.beibaoBtn.showRedPoint(App.data.game2Center.DataCenter.UserInfo.isHaveActiveItem());
    }

    /**视频播放完成 */
    public onVideoFinish() {//开场视频播放完成，显示soeasy 清风游戏公告
        if (Config.soEasy) {
            QingFengSdk.getInstance().noticeSdk();
        }
    }

    /**当有首冲标志位true时，显示首冲按钮*/
    private checkShouChong() {
        //首冲不显示
        // if (App.DataCenter.first_gift == false) {
        //     this.shouChongBtn.visible = true;
        //     CommomBtn.btnClick(this.shouChongBtn, this.onShouChongTouch, this);
        // } else {
        this._view.shouChongBtn.visible = false;
        // }
    }

    /**点击首冲礼包 */
    private onShouChongTouch() {
        this.ctrl.reqLoginReward(2);
    }

    /**检查是否首次登录(首次登录，自动打开活动中心)*/
    private checkFirstLogin() {
        if (App.data.game2Center.DataCenter.is_first_login) {
            App.data.game2Center.DataCenter.is_first_login = false;
            App.data.game2Center.DataCenter.isFirstEnterGame = false;
            this.ctrl.reqLoginReward();
        } else {
            if (!App.data.game2Center.DataCenter.isFirstEnterGame) return;
            App.data.game2Center.DataCenter.isFirstEnterGame = false;
            if (App.data.game2Center.DataCenter.offer || App.data.game2Center.DataCenter.announcement) {
                this.ctrl.reqLoginReward();
            }
        }
    }

    /**检查分享功能是否显示 */
    private checkShareFun() {
        //隐藏按钮
        this._view.shareBtn.visible = false;
        this._view.qrCodeBtn.visible = false;
        this._view.sendToDeBtn.visible = false;

        //soeasy渠道显示分享功能
        if (Config.soEasy) {
            //用户信息
            var userinfo = ZmSdk.getInstance().getUserInfo();
            GameLog.log("用户信息:", userinfo);
            // 分享
            if (ZmSdk.getInstance().isSupportMethod("share")) {
                this._view.shareBtn.visible = true;
                //3500渠道
                if (SoEasySdk.isCurChannel(SoEasySdk.channelList.h5_3500)) {
                    this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                        H5_3500_Sdk.getInstance().game35.share({
                            title: SoEasySdk.shareData.title,
                            content: SoEasySdk.shareData.content
                        });
                        H5_3500_Sdk.getInstance().game35.onShareOK(function () {
                            GameLog.log("分享成功");  //自定义
                        });
                    }, this, this._view.shareBtn);
                } else {
                    this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                        ZmSdk.getInstance().share(SoEasySdk.shareData, function (ret) {
                            GameLog.log("分享结果:", ret);
                        });
                    }, this, this._view.shareBtn);
                }
            }
            //二维码关注
            if (ZmSdk.getInstance().isSupportMethod("showQRCode")) {
                this._view.qrCodeBtn.visible = true;
                this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onShowQRCode, this, this._view.qrCodeBtn);
            }
            //已关注，则隐藏关注按钮
            if (userinfo && userinfo.userdata.isSubscribe == "true") {
                this._view.qrCodeBtn.visible = false;
            }
            //发送桌面
            if (ZmSdk.getInstance().isSupportMethod("sendToDesktop")) {
                GameLog.log("发送桌面");
                this._view.sendToDeBtn.visible = true;
                this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, ZmSdk.getInstance().sendToDesktop({}, (ret) => {
                    GameLog.log("发送桌面：", ret);
                }), this, this._view.sendToDeBtn);
            }
        } else if (WanBaSDK.getIntance().wanBaData) {
            //玩吧渠道显示分享等功能
            this._view.shareBtn.visible = true;//分享
            this._view.shareBtn.x = 5;
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                WanBaSDK.getIntance().showShareMenu();
            }, this, this._view.shareBtn);
            this._view.sendToDeBtn.visible = true;//收藏
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                WanBaSDK.getIntance().collectSendToDesktop(function (rev) {
                    GameLog.log("发送到桌面回调!", rev);
                });
            }, this, this._view.sendToDeBtn);
        }
    }

    private onShowQRCode(e: egret.TouchEvent): void {
        ZmSdk.getInstance().showQRCode({}, function (ret) {
            this._view.qrCodeBtn.visible = false;
            GameLog.log("关注结果:", ret);
        });
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}