/**
 * 发送桌面按钮
 */

class RedPacketBtn extends BaseView {
	private btn: eui.Button;
	private tip: eui.Image;

	public constructor() {
		super("RedPacketBtnSkin");
	}

	public showTip() {
		this.tip.visible = true;
	}

	public hideTip() {
		this.tip.visible = false;
	}
}