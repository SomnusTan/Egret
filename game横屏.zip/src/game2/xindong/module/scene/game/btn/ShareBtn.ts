/**
 * 分享按钮
 */
class ShareBtn extends BaseView {
	private btn: eui.Button;
	private tip: eui.Image;

	public constructor() {
		super("ShareBtnSkin");
	}

	public showTip() {
		this.tip.visible = true;
	}

	public hideTip() {
		this.tip.visible = false;
	}
}