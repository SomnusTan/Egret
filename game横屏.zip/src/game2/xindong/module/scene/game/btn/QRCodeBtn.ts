/**
 * 关注按钮
 */

class QRCodeBtn extends BaseView {
	private btn: eui.Button;
	private tip: eui.Image;

	public constructor() {
		super("QRCodeBtnSkin");
	}

	public showTip() {
		this.tip.visible = true;
	}

	public hideTip() {
		this.tip.visible = false;
	}
}