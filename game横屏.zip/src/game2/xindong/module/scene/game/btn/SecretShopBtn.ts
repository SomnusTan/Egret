class SecretShopBtn extends BaseUI {
	public red: eui.Image;
	private theTimer: egret.Timer;

	private setTime: any;
	public heartCha: boolean = false;


	public constructor() {
		super("SecretShopBtnSkin");
		SecretShopBtn.instance = this;
	}

	private static instance: SecretShopBtn;
	public static getInstance() {
		return SecretShopBtn.instance;
	}

	protected childrenCreated() {

	}

	protected onEnable() {

		this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
		let self = this;
		this.setTime = setInterval(this.heartChange, 800);
	}

	public heartChange() {
		if (SecretShopBtn.getInstance().heartCha == false) {
			egret.Tween.get(SecretShopBtn.getInstance().red).set({ scaleX: 0.9, scaleY: 0.9 }).to({ scaleX: 1.1, scaleY: 1.1 }, 800);
			// SecretShopBtn.getInstance().red.scaleX = 0.9;
			// SecretShopBtn.getInstance().red.scaleY = 0.9;
			SecretShopBtn.getInstance().heartCha = true;
		} else if (SecretShopBtn.getInstance().heartCha == true) {
			// SecretShopBtn.getInstance().red.scaleX = 1;
			// SecretShopBtn.getInstance().red.scaleY = 1;
			egret.Tween.get(SecretShopBtn.getInstance().red).set({ scaleX: 1.1, scaleY: 1.1 }).to({ scaleX: 0.9, scaleY: 0.9 }, 800);
			SecretShopBtn.getInstance().heartCha = false;
		}
	}

	private onTouch() {
		PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainDoc);
		clearInterval(this.setTime);
		this.red.visible = false;
	}

	public timerFunc() {

	}

	public timerComFunc() {

	}
}