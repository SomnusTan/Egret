/**
 * 工作进度面板
 * @author xiongjian
 * @deta 2017/9/5
 */
class WorkProPanel extends BasePanel {
    private _view: WorkProPanelUI;

    public recData;
    /**倒计时次数 */
    private count = 1;
    private proInitW: number = 60;   //进度条初始宽度，防止宽度过短时，原型变成矩形

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new WorkProPanelUI();
        this.addChild(this._view);
    }

    public show(data?: any): void {
        super.show(data);

        App.data.game2Center.SoundManager.stopBGM();
        this.recData = data;
        this._view.proImg.width = this.proInitW;
        this._view.ProLabel.text = "0%";
        App.sound.playSoundSwitchClient1(SoundManager.time_click, true);
        if (this.recData && this.recData.pic) this._view.TypeImg.source = this.recData.pic;
        if (this.recData && this.recData.title) this._view.typeLabel.text = this.recData.title;

        CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);
        CommomBtn.btnClick(this._view.finishBtn, this.finishNow, this, 1);

        this.showLoveTip();
        this.showCDImg();

        this.countDown(this.recData.duration * 10, 100);
    }

    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.backBtn, this.close, this);
        CommomBtn.removeClick(this._view.finishBtn, this.finishNow, this);
        this.hideCDImg();
        this.removeTimer();
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
        this._view.proImg.width = this.proInitW;
        this._view.ProLabel.text = "0%";
        App.dispatcher.dispatchEvent(EventConst.WorkWaitTime, this.recData);
        this.recData = null;
    }

    /**倒计时
     * @delay  延迟时间
     * @repeatCount 执行次数
     */
    private countDown(delay, repeatCount) {
        this.count = 1;
        let t = parseInt(delay);
        let count = parseInt(repeatCount);
        if (t && count) {
            App.timer.doTimeLoop(this, t, this.showProbar, [count])
        }
    }

    private showProbar(maxCount: number): void {
        this.jindu(this.count);
        if (this.count == maxCount) {
            this.timerComFunc();
        }
        this.count++;
    }

    /**倒计时结束 */
    private timerComFunc() {
        this.removeTimer();
        this.finish();
    }

    private jindu(count) {
        if (count) {
            this._view.ProLabel.text = count + "%";
            this._view.proImg.width = this.proInitW + count * (this._view.probg.width - this.proInitW) / 100;
        }
    }

    /**清楚倒计时 */
    private removeTimer() {
        App.timer.clearTimer(this, this.showProbar);
        this.count = 1;
        App.sound.stopSoundSwitchClient1(SoundManager.time_click);
    }

    /**关闭 */
    private close() {
        this.closePanel();
    }

    /**计时结束完成 */
    public finish() {
        let data = this.recData;

        let json = ProtocolHttp.workFinish;
        json.wid = data.id;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.workFinish, json, new FunctionVO(this.workFinish, this));
    }

    /**工作完成 */
    private workFinish(data) {
        if (data.code == 200) {
            App.sound.playSoundSwitchClient1(SoundManager.work_done);
            GameLog.log(data.data);
            let obj = new Object();
            obj["lid"] = this.recData.lid;
            obj["data"] = data.data;
            App.data.game2Center.DataCenter.UserInfo.updateWorkData(obj);
            // App.dispatcher.dispatchEvent(EventConst.WorkWaitTime, data.data);
            // App.SoundManager.playEffect(SoundManager.success);
            let text = "获得" + (data.data.gold - App.data.game2Center.DataCenter.UserInfo.gold) + "金币"
            PanelOpenManager.openPanel(EnumPanelID.G2_FinishWorkPanel, text);
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            this.close();
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);
            this.recData = data.data;
        }
    }
    /**立即结束接口 */
    private finishNow() {
        let data = this.recData;

        let json = ProtocolHttp.workFinish;
        json.wid = data.id;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.workFinishNow, json, new FunctionVO(this.loveFinishNowBack, this));
    }

    /**立即结束返回 */
    private loveFinishNowBack(data) {
        if (data.code == 200) {
            App.sound.playSoundSwitchClient1(SoundManager.work_done);
            GameLog.log(data.data);
            this.close();
            let obj = new Object();
            obj["data"] = data.data;
            App.data.game2Center.DataCenter.UserInfo.updateWorkData(obj);
            // App.dispatcher.dispatchEvent(EventConst.WorkWaitTime, data.data);
            // App.SoundManager.playEffect(SoundManager.success);
            let text = "获得" + (data.data.gold - App.data.game2Center.DataCenter.UserInfo.gold) + "金币"
            PanelOpenManager.openPanel(EnumPanelID.G2_FinishWorkPanel, text);
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);
            this.recData = data.data;
        } else {
            Notice.showBottomCenterMessage("" + data.info);
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoFinishPanel);
        }
    }
    /**设置恋爱类型 */
    public setTextType(str) {
        if (str && str != "") {
            this._view.typeLabel.text = str;
        }
    }

    /**设置恋爱背景 */
    public setImgType(url) {
        if (url && url != "") {
            this._view.TypeImg.source = url;
        }
    }

    //显示恋爱秘籍
    private tipJson;
    private showLoveTip() {
        if (this.tipJson == null) {
            this.tipJson = RES.getRes("lovetips_json");
        }
        if (this.tipJson != null) {
            let tips = this.tipJson.tips;
            let len = tips.length;
            this._view.tipLabel.text = tips[NumberTool.getRandInt(0, len - 1)];
        }
    }

    //显示提示购买无冷却
    private showCDImg() {
        if (App.data.game2Center.DataCenter.keybuy.yijian.hasbuy == false) {
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this, this);
            this._view.cdBtn.visible = true;
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this, this._view.cdBtn);
        }
    }

    //隐藏提示购买无冷却
    private hideCDImg() {
        this._dispatcher.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this, this);
        this._view.cdBtn.visible = false;
        this._dispatcher.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this, this._view.cdBtn);
    }

    //隐藏提示购买无冷却
    private onCDBtnTouch(e: egret.TouchEvent) {
        this.hideCDImg();
        this.showLiBao();
    }

    //显示礼包
    private showLiBao() {
        if (App.data.game2Center.DataCenter.keybuy.yijian.hasbuy == false) {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoFinishPanel);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

}