/**
 * 工作面板
 * @author xiongjian
 * @deta 2017/9/5
 */
class WorkPanel extends BasePanel {
    private _view: WorkPanelUI;

    public xinLabel: eui.Label;
    public upgrade_exp: number //经验条上限

    private inited: boolean = false //

    private handX: number;
    private handTimeY: number;
    private handExpY: number;
    private handBackY: number;

    private guideFlag: boolean;
    private backGuideFlag: boolean;
    /**工作盒子列表 */
    private workBoxList: WorkBox[];

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new WorkPanelUI();
        this.addChild(this._view);
        this._view.itemGroup.removeChildren();

        this.handX = this._view.workHand.x;
        this.handTimeY = this._view.loveHand0.y;
        this.handExpY = this._view.loveHand1.y;
        this.handBackY = this._view.backHand.y;
        this.inited = true;
    }

    public show(data?: any): void {
        super.show(data);
        // this.reqWorks();
        this.addItem();
        this.setConfig();
        GameLog.log("exps", App.data.game2Center.DataCenter.Work[0].exps, this.workBoxList);
        if (this.workBoxList && this.workBoxList[0]) {
            this.workBoxList[0].setEXP(App.data.game2Center.DataCenter.Work[0].exps, this.upgrade_exp);
        }

        // this.backBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.close, this);
        this._dispatcher.addEventListener(EventConst.WorkWaitTime, this.waitLisenter, this);
        // this.startBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.startTouch, this);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.goldGroupTouch, this, this._view.goldGroup);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.diamondGroupTouch, this, this._view.diamondGroup);
        this.setGuide();
        CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);
        CommomBtn.btnClick(this._view.startBtn, this.startTouch, this, 1);

        this._dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.updateSiwei, this);
        this._dispatcher.addEventListener(EventConst.ADD_WORD_ITEM, this.addItem, this);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.timeGuideTouch, this, this._view.yd_loveImg0);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.expGuideTouch, this, this._view.yd_loveImg1);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.backGuideTouch, this, this._view.backCircle);

    }
    /**获取恋爱列表 */
    private reqWorks() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.works, {}, new FunctionVO(this.revWorks, this));
    }

    /**恋爱列表返回 */
    private revWorks(data) {
        if (data.code == 200) {
            let json = data.data;
            App.data.game2Center.DataCenter.Work = json;
            this.addItem();
        }
    }

    public hide(): void {
        super.hide();
        this.clearList();
        CommomBtn.removeClick(this._view.backBtn, this.close, this);
        CommomBtn.removeClick(this._view.startBtn, this.startTouch, this);
        App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
    }

    /**更新四维 */
    private updateSiwei() {
        this.setConfig();
    }

    /**start 按钮点击 */
    private startTouch() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, {}, new FunctionVO(this.finishGuideBack, this));
    }

    /**引导完成返回 */
    private finishGuideBack(data) {
        if (data.code == 200) {
            this._view.yindaoGroup.visible = false;
            egret.Tween.removeTweens(this._view.workHand);
            App.data.game2Center.DataCenter.workGuide = false;
            let work = App.data.game2Center.DataCenter.Work;
            if (work[0].cd > 0) {
                this.guideFlag = true;
            } else {
                this.backGuideFlag = true;
            }
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;

            let json = ProtocolHttp.workStart;
            json.wid = App.data.game2Center.DataCenter.Work[0].id;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.workStart, json, new FunctionVO(this.sendBack, this));
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**请求返回 */
    private sendBack(data) {
        if (data.code == 200) {
            if (App.data.game2Center.DataCenter.Work[0] && App.data.game2Center.DataCenter.Work[0].duration) {
                PanelOpenManager.openPanel(EnumPanelID.G2_WorkProPanel, App.data.game2Center.DataCenter.Work[0]);
            } else {
                Notice.showBottomCenterMessage("数据错误");
            }
        }
        if (data.code !== 200) {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**关闭 */
    private close() {
        this.closePanel();
    }

    private clearList(): void {
        if (this.workBoxList) {
            for (var i: number = 0; i < this.workBoxList.length; i++) {
                this.workBoxList[i].dispose();
            }
        }
        this.workBoxList = [];
    }

    /**创建Item */
    public addItem() {
        this.clearList();
        let wrok = App.data.game2Center.DataCenter.Work;
        for (let i = 0; i < wrok.length; i++) {
            let data = wrok[i];
            let item = new WorkBox();
            this.workBoxList.push(item);   //添加进列表
            item.setData(data, i);
            if (i == 0) {
                //经验条
                this.upgrade_exp = data.upgrade_exp;
            }
            //item.x = (item.width + 40) * i + 40;
            this._view.itemGroup.addChild(item);
        }
        ScrollerCenter.hideVerticalScrollBar(this._view.workBoxScroller);
    }

    /**更新数据,刷新计时 */
    private refreshData(data) {
        if (data) {
            for (let i = 0; i < data.length; i++) {
                let cd = data[i].cd;
                let wait = data[i].wait;
                let endTime = data[i].endTime;
                let item: WorkBox = this.workBoxList[i];
                if (cd == 0) {
                    item.showCD(false);
                } else {
                    item.showCD(true);
                    item.setTimeText(cd, wait, endTime);
                }
                // item.setTimeText(60,3710);
            }
        }
    }

    /**接受到等待更新等待时间事件 */
    private waitLisenter(data) {
        this.setTimeGuide();
        GameLog.log("wait", data, "upgrade_exp", this.upgrade_exp);
        if (data) {
            let item: WorkBox = this.workBoxList[0];
            item.setData(data, 0);
            // item.setEXP(data.exps, this.upgrade_exp);
            App.data.game2Center.DataCenter.UserInfo.workCount = data.left_times;//修改剩余工作次数
            this.setGoldText(data.gold);
        }
    }

    /**配置数值 */
    private setConfig() {
        this.setDiamendText(App.data.game2Center.DataCenter.UserInfo.diamond);
        this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    /**设置爱心 */
    public setXinText(str, h) {
        if (h && h != "") {
            this._view.heartPlugin.setJindu(str, h);
        }
    }

    /**设置金币 */
    public setGoldText(str) {
        this._view.goldLabel.text = str;

    }
    /**设置砖石 */
    public setDiamendText(str) {
        this._view.diamendLabel.text = str;
    }

    /**金币Group点击 */
    public goldGroupTouch() {
        // App.PanelManager.open(PanelRegister.G2_ShopPanel,  ShopPage.Gold);
        // let shop = <ShopPanel>App.PanelManager.getPanel(PanelRegister.G2_ShopPanel);
        // shop.isBack = true;
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGoldPanel);
    }

    /**砖石Group点击 */
    public diamondGroupTouch() {
        // App.PanelManager.open(PanelRegister.G2_ShopPanel,  ShopPage.Diamond);
        // let shop = <ShopPanel>App.PanelManager.getPanel(PanelRegister.G2_ShopPanel);
        // shop.isBack = true;
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopDiamondPanel, null, false);
    }

    /**引导 */
    public setGuide() {
        if (App.data.game2Center.DataCenter.workGuide) {
            this._view.yindaoGroup.visible = true;
            egret.Tween.get(this._view.workHand, { loop: true })
                .set({ x: this.handX, y: 614 })
                .to({ x: this.handX + 40, y: 614 }, 600)
                .to({ x: this.handX, y: 614 }, 800)
                .wait(100);
        }
    }

    /**时间引导 */
    private setTimeGuide() {
        if (this.guideFlag) {
            this._view.yindaoGroup0.visible = true;
        } else {
            if (this.backGuideFlag) {
                this.timeGuideTouch();
            }
        }
    }

    private timeGuideTouch() {
        this._view.yindaoGroup0.visible = false;
        this.setExpGuide();
    }

    /**经验引导 */
    private setExpGuide() {
        this._view.yindaoGroup1.visible = true;
    }

    private expGuideTouch() {
        this._view.yindaoGroup1.visible = false;
        this.setBackGuide();
    }

    /**返回引导 */
    private setBackGuide() {
        this._view.yindaoBack.visible = true;
        egret.Tween.get(this._view.backHand, { loop: true })
            .set({ y: this.handBackY })
            .to({ y: this.handBackY + 40 }, 600)
            .to({ y: this.handBackY }, 800)
            .wait(100);
    }

    private backGuideTouch() {
        this._view.yindaoBack.visible = false;
        this.guideFlag = false;
        this.backGuideFlag = false;
        this.close();
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

}