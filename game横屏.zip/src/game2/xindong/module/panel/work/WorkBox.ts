/**
 * 恋爱组件
 * @author xiongjian 
 * @date 2017/9/5
 */
class WorkBox extends BaseView {

    public typeImg: eui.Image;
    public typeLabel: eui.Label;
    public cishuLabel: eui.Label;
    public jinyanLabel: eui.Label;
    public goldLabel: eui.Label;
    public jinyanGroup: eui.Group;
    public jindutiao: eui.Image;
    public jindutiaodi: eui.Image;
    public jinyantiaoLabel: eui.Label;
    public startBtn: eui.Button;
    public shenzhiBtn: eui.Button;
    public suoGroup: eui.Group;
    public suoBtn: eui.Button;
    public cdGroup: eui.Group;
    public cdTypeLabel: eui.Label;
    public timeLabel: eui.Label;
    public shenyutype: eui.Label;

    public type: number;

    private transData;//传递数据
    private waitTime: number;
    private cdTime = 0;

    private cdBtn: eui.Button;   //提示购买无冷却

    public constructor() {
        super("WorkBoxSkin");
    }

    public show(data?: any): void {
        super.show(data);

        this.hideCDImg();
        CommomBtn.btnClick(this.startBtn, this.startBtnTouch, this, 1);
        CommomBtn.btnClick(this.shenzhiBtn, this.shenzhiBtnTouch, this, 1);
        this._dispatcher.addEventListener(EventConst.UPDATE_RED_TIP, this.onUpdateRedTip, this);
    }

    public hide(): void {
        super.hide();
        this.hideCDImg();
        this.removeTimer();
        CommomBtn.removeClick(this.startBtn, this.startBtnTouch, this);
        CommomBtn.removeClick(this.shenzhiBtn, this.shenzhiBtnTouch, this);
    }

    private onUpdateRedTip(): void {
        //工作红点提示
        let workList = App.data.game2Center.DataCenter.Work;
        var data: any = workList[this.type];
        this.setData(data, this.type);
    }

    public setData(data: any, i: number): void {
        if (i == 0) {
            this.showJinyan(true);
            this.showShengzhi(false);
            this.showGongzuo(true);
            this.showSuo(false);
            this.setShengyuType(true);
            this.setEXP(data.exps, data.upgrade_exp);

            this.setCishu(data.left_times);
            if (data.cd == 0) {
                this.showCD(false);
            } else {
                this.showCD(true);
                this.setTimeText(data.cd, data.wait, data.endTime);
            }
        }
        else if (i == 1) {
            this.showJinyan(false);
            this.showShengzhi(true);
            this.showGongzuo(false);
            this.showSuo(false);
            this.setShengyuType(false);
            this.setCishu(data.times);
            this.showCD(false);
        }
        else {
            this.showJinyan(false);
            this.showShengzhi(false);
            this.showGongzuo(false);
            this.showSuo(true);
            this.setShengyuType(false);
            this.setCishu(data.times);
            this.showCD(false);
        }

        this.setGoldText(data.gain_gold);
        this.setJinyanText(data.gain_exp);
        //类型
        this.setImg(data.pic);
        this.setTypeText(data.title);
        this.setType(i);
    }

    /**开始按钮点击 */
    private startBtnTouch() {
        GameLog.log("type", this.type);
        let work = App.data.game2Center.DataCenter.Work;
        this.transData = work[this.type];
        this.sendHttp();
    }

    /**升职按钮点击 */
    private shenzhiBtnTouch() {
        GameLog.log("type", this.type);
        let work = App.data.game2Center.DataCenter.Work;
        this.transData = work[this.type];
        this.shengzhiHttp();
    }

    /**设置类型 */
    public setTypeText(str) {
        if (str && str != "") {
            this.typeLabel.text = str;
        }
    }

    /**显示cd */
    public showCD(bo: boolean) {
        if (bo) {
            this.cdGroup.visible = true;
        } else {
            this.cdGroup.visible = false;
        }
    }

    /**设置金币 */
    public setGoldText(num) {
        if (num != "") {
            this.goldLabel.text = num;
        }
    }

    /**设置剩余次数 */
    public setCishu(num) {
        this.cishuLabel.text = num;
    }

    /**显示锁 */
    public showSuo(bo: boolean) {
        if (bo) {
            this.suoGroup.visible = true;
        } else {
            this.suoGroup.visible = false;
        }
    }

    /**显示工作 */
    public showGongzuo(bo: boolean) {
        if (bo) {
            this.startBtn.visible = true;
        } else {
            this.startBtn.visible = false;
        }
    }

    /**显示升职 */
    public showShengzhi(bo: boolean) {
        if (bo) {
            this.shenzhiBtn.visible = true;
        } else {
            this.shenzhiBtn.visible = false;
        }
    }

    /**显示经验条 */
    public showJinyan(bo: boolean) {
        if (bo) {
            this.jinyanGroup.visible = true;
        } else {
            this.jinyanGroup.visible = false;
        }
    }

    /**
     * 设置经验值
     */
    public setEXP(a, b) {
        this.setJinyantiaoText(a, b);
        this.setJinyanJindu(a, b);
    }

    /**
     * 设置经验条值
     */
    public setJinyantiaoText(a, b) {
        if (b && b != "") {
            this.jinyantiaoLabel.text = a + "/" + b;
        }
    }

    /**
     * 设置经验条进度
     */
    public setJinyanJindu(num1, num2) {
        if (num2 && num2 != "") {
            if (num1 / num2 > 1) {
                this.jindutiao.width = this.jindutiaodi.width;
            } else {
                this.jindutiao.width = num1 / num2 * this.jindutiaodi.width;
            }
        }
    }

    /**设置获得经验值 */
    public setJinyanText(str) {
        if (str && str != "") {
            this.jinyanLabel.text = str;
        }
    }

    /**设置可工作次数 */
    public setWorkNum(num) {
        if (num && num != "") {
            this.cishuLabel.text = num;
        }
    }

    /**设置剩余工作类型 */
    public setShengyuType(bo: boolean) {
        if (bo) {
            this.shenyutype.text = "剩余次数：";
        } else {
            this.shenyutype.text = "工作次数：";
        }
    }

    /**设置时间 */
    public setTimeText(cd, wait, endTime) {
        if (endTime <= ServerTime.serverTime) {
            this.cdTime = cd;
            GameLog.log("cd", cd);
            if (cd && cd != "") {
                if (cd < 60) {
                    this.timeLabel.text = cd + "分钟";
                }
                if (cd >= 60 && cd < 120) {
                    let s = cd - 60
                    if (s == 0) {
                        this.timeLabel.text = "1小时";
                    }
                    if (s > 0) {
                        this.timeLabel.text = "1小时" + s + "分钟";
                    }
                }
                if (cd >= 120 && cd < 180) {
                    let s = cd - 120
                    if (s == 0) {
                        this.timeLabel.text = "2小时";
                    }
                    if (s > 0) {
                        this.timeLabel.text = "2小时" + s + "分钟";
                    }
                }
            }
        } else {
            this.removeTimer();
            App.timer.serverTimeEnd(this, this.timerFunc, endTime);

            //新增，提示购买无冷却
            this.showCDImg();
        }
    }

    /**设置等待时间 */
    public setWaitText(str) {
        if (str) {
            let fen = Math.floor(str / 60);//分钟
            let miao = Math.floor(str % 60);//秒
            let shi = Math.floor(str / 60 / 60);//时
            //秒
            if (fen < 1) {
                if (str < 10) {
                    this.timeLabel.text = "00:0" + str;
                } else {
                    this.timeLabel.text = "00:" + str;
                }
            }
            //分
            if (fen >= 1 && fen < 60) {
                if (miao < 10) {
                    this.timeLabel.text = fen + ":0" + miao;
                } else {
                    this.timeLabel.text = fen + ":" + miao;
                }
            }
            //时
            if (shi >= 1) {
                let time = str - shi * 3600;//分秒
                let f = Math.floor(time / 60);//分钟
                let m = Math.floor(time % 60);//秒
                if (f < 10) {
                    if (m < 10) {
                        this.timeLabel.text = shi + ":0" + f + ":0" + m;
                    } else {
                        this.timeLabel.text = shi + ":0" + f + ":" + m;
                    }
                } else {
                    if (m < 10) {
                        this.timeLabel.text = shi + ":" + f + ":0" + m;
                    } else {
                        this.timeLabel.text = shi + ":" + f + ":" + m;
                    }
                }
            }
        }
    }


    /**每秒倒计时 */
    private timerFunc(serverTimeData: ServerTimeData) {
        if (serverTimeData.spuleTime > 0) {
            this.setWaitText(serverTimeData.spuleTime);
        }
        else {
            this.timerComFunc();
        }
    }

    /**倒计时结束 */
    private timerComFunc() {
        this.removeTimer();
        if (this.transData) {
            this.cdTime = this.transData.cd;
        }
        GameLog.log("cd", this.cdTime);
        this.setTimeText(this.cdTime, 0, 0);
        //隐藏cd无冷却
        this.hideCDImg();
    }

    /**清楚倒计时 */
    private removeTimer() {
        App.timer.clearTimer(this, this.timerFunc);
    }

    /**设置图片 */
    public setImg(url) {
        if (url && url != "") {
            this.typeImg.source = url;
        }
    }

    /**设置类型 */
    public setType(num) {
        this.type = num;
    }

    /**发送开始请求 */
    public sendHttp() {
        let data = ProtocolHttp.workStart;
        data.wid = this.transData.id;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.workStart, data, new FunctionVO(this.sendBack, this));
    }

    /**请求返回 */
    private sendBack(data) {
        if (data.code == 200) {
            if (this.transData && this.transData.duration) {
                PanelOpenManager.openPanel(EnumPanelID.G2_WorkProPanel, this.transData);
            } else {
                Notice.showBottomCenterMessage("数据错误");
            }
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
        //809冷却中且未购买礼包,弹礼包
        if (data.code == 809 && !App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy) {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoCDPanel);
        }
    }

    private shengzhiHttp() {
        let work = App.data.game2Center.DataCenter.Work;
        if (work && work[0]) {
            // if (work[0].exps >= work[0].upgrade_exp) {

            let data = ProtocolHttp.workStart;
            data.wid = this.transData.id;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.workPromotion, data, new FunctionVO(this.shengzhiBack, this));
            // } else {
            //     Notice.showBottomCenterMessage("经验值不足");
            // }
        }
    }

    private shengzhiBack(data) {
        GameLog.log("shengzhi", data);
        if (data.code == 200) {
            App.data.game2Center.DataCenter.Work = data.data;
            // let panel = <WorkPanel>App.data.game2Center.PanelManager.getPanel(EnumPanelID.G2_WorkPanel);
            // panel.addItem();
            App.dispatcher.dispatchEvent(EventConst.ADD_WORD_ITEM)
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    //显示提示购买无冷却
    private showCDImg() {
        if (App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy == false) {
            App.stage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this);

            this.cdBtn.visible = true;
            this.cdBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this);
        }
    }

    //隐藏提示购买无冷却
    private hideCDImg() {
        App.stage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this);

        this.cdBtn.visible = false;
        this.cdBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this);
    }

    //隐藏提示购买无冷却
    private onCDBtnTouch(e: egret.TouchEvent) {
        this.hideCDImg();
        this.showLiBao();
    }

    //显示礼包
    private showLiBao() {
        if (App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy == false) {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoCDPanel);
        }
    }
}

enum WorkBoxType {
    one,
    two,
    there,
    four,
    five,
    six,
    seven,
    eight,
    nine,
    ten
}