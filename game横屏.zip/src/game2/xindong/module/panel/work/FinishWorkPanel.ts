/**
 * 完成工作面板
 * @author xiongjian
 * @deta 2017/9/5
 */
class FinishWorkPanel extends BasePanel {
    private _view: FinishWorkPanelUI;
    public recData;

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new FinishWorkPanelUI();
        this.addChild(this._view);
    }

    public show(data?: any): void {
        super.show(data);
        this.recData = data;
        this.recData && this.setLabel(this.recData);
        CommomBtn.btnClick(this._view.okBtn, this.okBtnTouch, this, 1);
    }

    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.okBtn, this.okBtnTouch, this);
    }

    /**设置文本 */
    private setLabel(num) {
        this._view.xinLabel.text = "" + num;
    }

    /**按钮点击 */
    private okBtnTouch() {
        this.closePanel();
    }

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }
    

}