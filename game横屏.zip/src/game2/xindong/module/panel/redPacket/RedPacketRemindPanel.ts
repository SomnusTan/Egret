class RedPacketRemindPanel extends BasePanel {
	private _view: RedPacketRemindPanelUI;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new RedPacketRemindPanelUI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this._view.exitImage);
	}

	private onTouch(e: egret.TouchEvent) {
		this.closePanel();
	}

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

}