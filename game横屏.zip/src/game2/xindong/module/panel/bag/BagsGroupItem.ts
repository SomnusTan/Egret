/**
 * 背包列表Item 
 * @author xiongjian 
 * @date 2017/9/11
 */
class BagsGroupItem extends BaseView {

    public daojuImg: eui.Image;
    public typeLabel: eui.Label;
    public countLabel: eui.Label;
    public maskImg: eui.Image;

    private transData;

    public constructor() {
        super("BagsGroupItemSkin");
    }

    public show(data?: any): void {
        super.show(data);
        if (data) {
            this.transData = data;
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this);
            this._dispatcher.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.hide, this, this);
        }
    }

    /**点击 */
    private onTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        PanelOpenManager.openPanel(EnumPanelID.G2_UseToolPanel, this.transData);
    }

    /**请求返回 */
    private onTouchBack(data) {
        if (data.code == 200) {
            Notice.showBottomCenterMessage("使用成功");
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**设置图片 */
    public setImg(url) {
        if (url && url != "") {
            this.daojuImg.source = url;
        }
    }

    /**道具类型 */
    public setTypeText(str) {
        if (str && str != "") {
            this.typeLabel.text = str;
        }
    }

    /**设置道具个数 */
    public setToolsCount(num) {
        if (num && num != "") {
            this.countLabel.text = "x " + num;
        }
    }

}