/**
 * 使用道具面板
 * @author xiongjian 
 * @date 2017-9-22
 */
class UseToolPanel extends BasePanel {
    private _view: UseToolPanelUI;
    public recData;
    private count = 1;

    public constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new UseToolPanelUI();
        this.addChild(this._view);
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    /**添加到场景中*/
    public show(data?: any): void {
        super.show(data);
        this.recData = data;
        this.count = 1;

        if (this.count >= this.recData.count) {
            this.showHuijia(true);
        } else {
            this.showHuijia(false);
        }
        this.showHuijian(true);
        this.setCountLabel(this.count);
        this.setContentLabel(this.recData.des);
        this.setTitleLabel(this.recData.cname);
        this.setGiftImg(this.recData.pic);
        this.setMyCount(this.recData.count);
        this.setToolCanUse();

        this._view.countGroup.visible = true;

        if (this.recData.cname == "恋爱宝典") {
            this._view.countGroup.visible = false;
        }

        GameLog.log("transdata", this.recData);

        CommomBtn.btnClick(this._view.okBtn, this.okTouch, this, 1);
        CommomBtn.btnClick(this._view.canelBtn, this.canelTouch, this, 1);
        CommomBtn.btnClick(this._view.jianBtn, this.jianTouch, this, 1);
        CommomBtn.btnClick(this._view.jiaBtn, this.jiaTouch, this, 1);
        CommomBtn.btnClick(this._view.canelMidBtn, this.closePanel, this, 1);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jiaBtnTouchBegin, this, this._view.jiaBtn);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jianBtnTouchBegin, this, this._view.jianBtn);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.bgTouch, this, this._view.bgImg);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onStageTouchEnd, this, App.stage);
    }

    /**从场景中移除*/
    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.okBtn, this.okTouch, this);
        CommomBtn.removeClick(this._view.canelBtn, this.canelTouch, this);
        CommomBtn.removeClick(this._view.jianBtn, this.jianTouch, this);
        CommomBtn.removeClick(this._view.jiaBtn, this.jiaTouch, this);
        CommomBtn.removeClick(this._view.canelMidBtn, this.closePanel, this);
    }

    /**确定点击 */
    private okTouch() {
        if (this.recData && this.recData.id) {
            let param = { gid: 0, count: 0 }
            param.gid = this.recData.id;
            param.count = this.count;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.useTool, param, new FunctionVO(this.useBtnTouchBack, this));
        }
    }

    /**购买返回 */
    private useBtnTouchBack(data) {
        if (data.code == 200) {
            this.closePanel();
            if (data.data.hearts - App.data.game2Center.DataCenter.UserInfo.hearts != 0) {
                TipsHeat.showHeat(data.data.hearts - App.data.game2Center.DataCenter.UserInfo.hearts);
            }

            App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
            App.data.game2Center.DataCenter.UserInfo.power = data.data.power;
            if (this.recData.id == 37) {
                let exp = data.data.exps - App.data.game2Center.DataCenter.Work[0].exps;
                Notice.showBottomCenterMessage("增加" + exp + "工作经验");
                App.data.game2Center.DataCenter.Work[0].exps = data.data.exps;
            }
            // let panel = <BagsPanel>App.data.game2Center.PanelManager.getPanel(EnumPanelID.G2_BagsPanel);
            // panel.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
            //通过抛事件来更新
            App.dispatcher.dispatchEvent(EventConst.UPDATE_BAG_XIN, App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts)
            App.dispatcher.dispatchEvent(EventConst.REQ_UPDATE_BAGS);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**取消点击 */
    private canelTouch() {
        this.closePanel();
    }

    /**加点击 */
    private jiaTouch() {
        this.count += 1;
        this.showHuijian(false);
        if (this.count >= this.recData.count) {
            this.count = this.recData.count;
            this.showHuijia(true);
        } else {
            this.showHuijia(false);
            App.sound.playSoundSwitchClient1(SoundManager.number_add);
        }
        this.setCountLabel(this.count);
    }

    /**减点击 */
    private jianTouch() {
        this.showHuijia(false);
        if (this.count > 1) {
            this.count -= 1;
            if (this.count == 1) {
                this.showHuijian(true);
            } else {
                this.showHuijian(false);
            }
            App.sound.playSoundSwitchClient1(SoundManager.number_reduce);
        } else {
            this.count = 1;
            this.showHuijian(true);
        }
        this.setCountLabel(this.count);
    }

    /**加点击开始 */
    private jiaBtnTouchBegin() {
        egret.Tween.get(this._view.jiaBtn, { loop: true }).wait(250).call(() => {
            this.jiaTouch();
        }, this);
    }

    /**减点击开始 */
    private jianBtnTouchBegin() {
        egret.Tween.get(this._view.jianBtn, { loop: true }).wait(250).call(() => {
            this.jianTouch();
        }, this);
    }

    /**加点击或减点击结束 */
    private onStageTouchEnd() {
        egret.Tween.removeTweens(this._view.jiaBtn);
        egret.Tween.removeTweens(this._view.jianBtn);
    }

    /**背景点击 */
    private bgTouch() {
        this.closePanel();
    }

    /**礼物图片设置 */
    private setGiftImg(url) {
        if (url && url != "") {
            this._view.giftImg.source = url;
        }
    }


    /**内容设置 */
    private setContentLabel(str) {
        if (str != "") {
            this._view.contentLabel.text = str;
        }
    }

    /**标题设置 */
    private setTitleLabel(str) {
        if (str != "") {
            this._view.titleLabel.text = str;
        }
    }

    /**设置购买数量 */
    private setCountLabel(num) {
        if (num != "") {
            this._view.countLabel.text = num;
        }
    }


    /**显示加灰色 */
    private showHuijia(bo: boolean) {
        if (bo) {
            this._view.nojiaBtn.visible = true;
        } else {
            this._view.nojiaBtn.visible = false;
        }

    }

    /**显示减灰色 */
    private showHuijian(bo: boolean) {
        if (bo) {
            this._view.nojianBtn.visible = true;
        } else {
            this._view.nojianBtn.visible = false;
        }
    }

    /**设置拥有数量 */
    private setMyCount(num) {
        if (num != "") {
            this._view.myCount.text = num;
        }
    }

    //设置道具可用界面
    private setToolCanUse() {
        let initiative = this.recData.initiative;
        if (initiative == true) {   //可主动使用，显示+ - 
            this._view.okBtn.visible = true;
            this._view.canelBtn.visible = true;
            this._view.jiaBtn.visible = true;
            this._view.jianBtn.visible = true;
            this._view.canelMidBtn.visible = false;
        } else {   //不可主动使用，只展示信息，不显示+ -
            this._view.okBtn.visible = false;
            this._view.canelBtn.visible = false;
            this._view.jiaBtn.visible = false;
            this._view.jianBtn.visible = false;
            this._view.canelMidBtn.visible = true;
            this._view.countLabel.text = this.recData.count + "";
            this._view.contentLabel.text += "（不能在背包中使用）";
            this._view.nojianBtn.visible = false;
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}