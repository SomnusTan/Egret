/**
 * 背包面板
 * @author xiongjian
 * @date 2017/9/11
 */
class BagsPanel extends BasePanel {

    private _view: BagsPanelUI;

    private handY: number;

    private _items: BagsGroupItem[];

    public constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new BagsPanelUI();
        this.addChild(this._view);
        this._view.giftGroup.removeChildren();

        this.handY = this._view.backHand.y;
    }

    public dispose(): void {
        this.clearItems();
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

    private clearItems(): void {
        if (this._items) {
            for (var i: number = 0; i < this._items.length; i++) {
                this._items[i] && this._items[i].dispose();
                this._items[i] = undefined;
            }
        }
        this._items = null;
    }

    /**添加到场景中*/
    public show(data?: any): void {
        super.show(data);

        this.initView();

        CommomBtn.btnClick(this._view.backBtn, this.closePanel, this, 2);
        CommomBtn.btnClick(this._view.gotoShop, this.gotoTouch, this, 1);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yindaoTouch, this, this._view.yindaoTip);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yindaoBackTouch, this, this._view.backCircle);
        this._dispatcher.addEventListener(EventConst.UPDATE_BAG_XIN, this.setXinText, this);
        this._dispatcher.addEventListener(EventConst.INIT_BAG, this.initView, this);

        this.setGuide();
    }

    /**从场景中移除*/
    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.backBtn, this.closePanel, this);
        CommomBtn.removeClick(this._view.gotoShop, this.gotoTouch, this);

        App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
    }

    private initView() {
        let bags = App.data.game2Center.DataCenter.Bags;
        GameLog.log("bags", bags);
        if (bags.length > 0) {
            this.showNothingGroup(false);
        } else {
            this.showNothingGroup(true);
        }
        this.clearItems();
        this._items = [];
        for (let i = 0; i < bags.length; i++) {
            let tool = bags[i];
            let item = new BagsGroupItem();
            //item.x = Math.floor(i % 3) * (366+48) + 48
            //item.y = Math.floor(i / 3) * 486 + 20;
            item.setImg(tool.pic);
            item.setTypeText(tool.cname);
            item.setToolsCount(tool.count);
            item.show(tool);
            this._view.giftGroup.addChild(item);
            this._items.push(item);
        }
        ScrollerCenter.hideVerticalScrollBar(this._view.giftScroller);
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    /**显示没有道具 */
    public showNothingGroup(bo: boolean) {
        if (bo) {
            this._view.nothingGroup.visible = true;
        } else {
            this._view.nothingGroup.visible = false;
        }
    }

    /**设置爱心 */
    private setXinText(str, h) {
        if (h && h != "") {
            this._view.heartPlugin.setJindu(str, h);
        }
    }

    /**去商城 */
    private gotoTouch() {
        //     App.PanelManager.open(EnumPanelID.G2_ShopPanel, ShopPage.DaoJu);
        //    let shop =<ShopPanel> App.PanelManager.getPanel(EnumPanelID.G2_ShopPanel);
        //    shop.isBack = true;
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGiftToolPanel, 0);
    }

    private setGuide() {
        if (App.data.game2Center.DataCenter.bagGuide) {
            this._view.yindaoTip.visible = true;
        }
    }

    private yindaoTouch() {
        this._view.yindaoTip.visible = false;
        this.setBackGuide();
    }

    private setBackGuide() {
        this._view.yindaoBack.visible = true;
        egret.Tween.get(this._view.backHand, { loop: true })
            .set({ y: this.handY })
            .to({ y: this.handY + 40 }, 600)
            .to({ y: this.handY }, 800)
            .wait(100);
    }

    private yindaoBackTouch() {
        this._view.yindaoBack.visible = false;
        App.data.game2Center.DataCenter.bagGuide = false;
        this.closePanel();
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}