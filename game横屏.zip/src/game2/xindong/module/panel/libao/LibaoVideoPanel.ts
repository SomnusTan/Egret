/**
 * 视频礼包
 * @author xiongjian
 * @date 2017/10/9 
 */

class LibaoVideoPanel extends BasePanel {
    private _view: LibaoVideoPanelUI;

    private order_id;
    private open_window;
    private t: number;

    public constructor() {
        super();
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

    protected init(): void {
        this._view = new LibaoVideoPanelUI();
        this.addChild(this._view);
    }

    public show(data?: any): void {
        super.show(data);

        CommomBtn.btnClick(this._view.buyBtn, this.buyBtnTouch, this, 1);
        CommomBtn.btnClick(this._view.closeBtn, this.close, this, 2);
    }

    public hide(): void {
        super.hide();
        this.open_window = null;
        App.timer.clearTimer(this, this.onTimer);
        CommomBtn.removeClick(this._view.buyBtn, this.buyBtnTouch, this);
        CommomBtn.removeClick(this._view.closeBtn, this.close, this);
    }

    /**购买 */
    private buyBtnTouch() {
        let param = { gid: 0 };
        param = AddSomeMsgUtils.addSomeMsgByGiftBuy(param);
        param.gid = App.data.game2Center.DataCenter.keybuy.shiping.id;
        let channel = window["channel"];
        if (channel) param["channel"] = channel;
        //新ios下单，增加渠道标识
        // if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
        //     param["channel"] = IOSConfig.channel;
        // }
        //小米渠道
        if (MilletSDK.getInstance().millet) {
            param["channel"] = "xiaomi";
        }
        //vivo渠道
        if (H5_Vivo_SDK.getInstance().vivoData) {
            param["channel"] = "vivo";
        }
        //网页
        if (DeviceUtil.IsWeb) {
            //360渠道
            if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
                param["channel"] = "360";
            } else {
                param["channel"] = "web_alipay";
            }
        }
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, param, new FunctionVO(this.buyBack, this));
    }

    /**购买礼包返回 */
    private buyBack(data) {
        if (data.code == 200) {
            this.close();
            if (DeviceUtil.IsWeb) {
                this.order_id = data.data.order_id;
                if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
                    H5_360_Sdk.getInstance().pay360Param = data.data.params;
                    H5_360_Sdk.getInstance().order_id = data.data.order_id;
                    H5_360_Sdk.getInstance().paySdk();
                    GameLog.log("360支付订单号" + this.order_id);
                } else {
                    let url = data.data.aliparams;
                    let url0 = App.data.game2Center.DataCenter.setSelect(url);
                    // 窗口打开页面
                    // this.open_window.location.href = "/shop/web/switch/?url=" + url0;
                    WebParams.openWindow("/shop/web/switch/?url=" + url0, this.open_window);
                }
                this.getBuy();
                return;
            }
            else if (DeviceUtil.IsNative && DeviceUtil.IsIos && App.data.game2Center.DataCenter.keybuy.shiping.coin_type == "rmb") {
                App.nativeBridge.sendIOSPay(data.data.order_id, data.data.product_id);
            }
            else if (App.data.game2Center.DataCenter.keybuy.shiping.coin_type == "rmb") {
                App.nativeBridge.sendPay(data);
            }
            else if (App.data.game2Center.DataCenter.keybuy.shiping.coin_type == "diamond") {
                Notice.showBottomCenterMessage("购买成功")
                App.data.game2Center.DataCenter.keybuy.shiping.hasbuy = true;
                this.reqVideoList();
            }

        } else if (data.code == 981) {
            App.nativeBridge.sendPay(data);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**关闭页面 */
    private close() {
        this.closePanel();
    }

    private reqVideoList() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoList, {}, new FunctionVO(this.revVideoList, this));
    }

    //接收视频列表
    private revVideoList(data) {
        if (data.code == 200) {
            //保存视频数据
            App.data.game2Center.DataCenter.Video.mem = data.data.mem;
            App.data.game2Center.DataCenter.Video.fav = data.data.fav;
            //更新视频
            App.dispatcher.dispatchEvent(EventConst.UPDATE_LIBAO);
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    //获得购买的状态
    private getBuy() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.payBack, this));
    }

    private payBack(data: any): void {
        if (data.code == 200) {
            Notice.showBottomCenterMessage("支付成功");
            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
            App.data.game2Center.LoadingLock.unlock();
            this.close();
        } else {
            this.t = 0;
            this._needSendBuy = true;
            App.timer.clearTimer(this, this.onTimer);
            App.timer.doTimeLoop(this, 3000, this.onTimer);
        }
    }
    private _needSendBuy: boolean;//请求是否支付成功

    private onTimer(): void {
        this.t += 3;
        if (this.t >= 600) {
            GameLog.log("-------------10分钟内支付失败");
            App.timer.clearTimer(this, this.onTimer);
            return;
        }
        if (this._needSendBuy) {
            this._needSendBuy = false;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.onPaySuccess, this, true));
        }
    }

    private onPaySuccess(data: any): void {
        if (data.code == 200) {
            Notice.showBottomCenterMessage("支付成功");
            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
            App.timer.clearTimer(this, this.onTimer);
            App.data.game2Center.LoadingLock.unlock();
            this.close();
        } else {
            GameLog.log("-------------未支付，继续检测----------");
            this._needSendBuy = true;
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}