/**
 * 秒回礼包
 * @author xiongjian
 * @date 2017/10/9 
 */

class LibaomiaohuiPanel extends BasePanel {
    private _view: LibaomiaohuiPanelUI;

    private t;
    private order_id;
    private open_window;

    public constructor() {
        super();
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new LibaomiaohuiPanelUI();
        this.addChild(this._view);
    }

    /**添加到场景中*/
    public show(data?: any) {
        super.show(data);
        CommomBtn.btnClick(this._view.buyBtn, this.buyBtnTouch, this, 1);
        CommomBtn.btnClick(this._view.closeBtn, this.closePanel, this, 2);
    }

    /**从场景中移除*/
    public hide() {
        super.hide();
        this.open_window = null;
        App.timer.clearTimer(this, this.onTimer);
        App.timer.clearTimer(this, this.sendGetEndOrder);
        CommomBtn.removeClick(this._view.buyBtn, this.buyBtnTouch, this);
        CommomBtn.removeClick(this._view.closeBtn, this.closePanel, this);
    }

    private buyGiftBack(): void {
		Notice.showBottomCenterMessage("购买成功");
		App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
        this.close();
	}

    /**购买 */
    private buyBtnTouch() {

        GameLog.log("keybuy", App.data.game2Center.DataCenter.keybuy.miaohui);
        let obj = App.data.game2Center.DataCenter.keybuy.miaohui;

        Game2PayUtil.pay(obj.id, obj.title, obj.balance_money, 1, new FunctionVO(this.buyGiftBack, this));
        return;

        //TODO u8支付
        if (Config.U8Login) {
            App.nativeBridge.sendU8PayOld("libao", obj);
            return;
        }

        //soEasy支付
        if (Config.soEasy) {
            platform.payOrder(App.data.game2Center.DataCenter.keybuy.miaohui.id);
            return;
        }

        //Android支付,sdk自己下单         
        if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
            let packages = obj.package;
            let { price } = obj;
            let goodsDes = {
                name: packages[0]["cname"],
                price: price + "元",
                desc: "解锁" + packages[0]["cname"] + "功能,加送" + packages[1]["num"] + packages[1]["cname"]
            };
            App.nativeBridge.sendAndroidPay(obj.id, goodsDes);
        } else {

            let param: any = { gid: 0 };
            param = AddSomeMsgUtils.addSomeMsgByGiftBuy(param);
            param.gid = App.data.game2Center.DataCenter.keybuy.miaohui.id;
            let channel = window["channel"];
            if (channel) param["channel"] = channel;
            //新ios下单，增加渠道标识
            // if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
            //     param["channel"] = IOSConfig.channel;
            // }
            //小米渠道
            if (MilletSDK.getInstance().millet) {
                param["channel"] = "xiaomi";
            }
            //vivo渠道
            if (H5_Vivo_SDK.getInstance().vivoData) {
                param["channel"] = "vivo";
            }
            //网页
            if (DeviceUtil.IsWeb) {
                //360渠道
                if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
                    param["channel"] = "360";
                } else {
                    param["channel"] = "web_alipay";
                }
                param.setting = DeviceUtil.currentSetting;
                if (Config.soEasy || H5_360_Sdk.getInstance().config360) {
                    ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, param, new FunctionVO(this.buyBack, this));
                } else {
                    param.price = obj.price;
                    param.closeHandler = new FunctionVO(this.onChooseBack, this);
                    Alert.choosePay(param);
                    // if (Config.skipVideo) {
                    // } else {
                    //     param.payType = EnumPayType.PAY_ALIPAY;
                    //     this.onChooseBack(param);
                    // }
                }
            }else{
                ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, param, new FunctionVO(this.buyBack, this));
            }
        }
    }
    /**
     *  payType:支付类型 1：微信，2：支付宝
     */
    private onChooseBack(param: any): void {
        if (param.payType == EnumPayType.PAY_WECHAT && DeviceUtil.isMobile) { //手机端微信支付
            var url: string = WebParams.ip + ProtocolHttpUrlGame2.giftBuy + "?channel=weixin&gid=" + param.gid + "&setting=" + DeviceUtil.currentSetting +
                "&Authorization=" + App.data.game2Center.DataCenter.skey + "&AuthorizationID=" + App.global.userInfo.uid;
            this.open_window = window.open(url, "_blank");
            App.timer.doTimeOnce(this, 3000, this.sendGetEndOrder, [param.gid]);
        } else if (!Config.isRelease || param.payType == EnumPayType.PAY_ALIPAY || (!DeviceUtil.isMobile && param.payType == EnumPayType.PAY_WECHAT)) { //支付宝 || 微信web
            if (param.payType == EnumPayType.PAY_ALIPAY)
                this.open_window = WebParams.openWindow(WebParams.defaultURL);
            param.closeHandler = "";
            if (param.payType == EnumPayType.PAY_WECHAT) {
                param.channel = "weixin";
            }
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, param, new FunctionVO(this.buyBack, this, param.payType));
        }
    }

    private sendGetEndOrder(gid): void {
        App.timer.clearTimer(this, this.sendGetEndOrder);
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.shop_end_order, { good_id: gid }, new FunctionVO(this.checkOrder, this));
    }

    private checkOrder(data): void {
        if (data.code == 200) {
            this.order_id = data.data;
            this.getBuy();
        }
    }

    /**购买砖石返回 */
    private buyBack(data, type?: number) {
        if (data.code == 200) {
            if (DeviceUtil.IsWeb) {
                this.order_id = data.data.order_id;
                if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
                    H5_360_Sdk.getInstance().pay360Param = data.data.params;
                    H5_360_Sdk.getInstance().order_id = data.data.order_id;
                    H5_360_Sdk.getInstance().paySdk();
                    GameLog.log("360支付订单号" + this.order_id);
                } else {
                    if (type == EnumPayType.PAY_WECHAT) {
                        data.data.payType = type;
                        PanelOpenManager.openPanel(EnumPanelID.WECHAT_QRCODE, data.data);
                    } else if (type == EnumPayType.PAY_ALIPAY) {
                        let url = data.data.aliparams;
                        let url0 = App.data.game2Center.DataCenter.setSelect(url);
                        WebParams.openWindow("/shop/web/switch/?url=" + url0, this.open_window);
                    }
                }
                this.getBuy();
                return;
            }
            else if (DeviceUtil.IsNative && DeviceUtil.IsIos && App.data.game2Center.DataCenter.keybuy.miaohui.coin_type == "rmb") {
                App.nativeBridge.sendIOSPay(data.data.order_id, data.data.product_id);
            }
            else if (App.data.game2Center.DataCenter.keybuy.miaohui.coin_type == "rmb") {
                App.nativeBridge.sendPay(data);
            }
            else if (App.data.game2Center.DataCenter.keybuy.miaohui.coin_type == "diamond") {
                Notice.showBottomCenterMessage("购买成功")
                App.data.game2Center.DataCenter.keybuy.miaohui.hasbuy = true;
            }
            this.closePanel();
        } else if (data.code == 981) {
            App.nativeBridge.sendPay(data);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    private close(): void {
        PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
        this.closePanel();
    }

    //获得购买的状态
    private getBuy() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.payBack, this));
    }

    private payBack(data: any): void {
        if (data.code == 200) {
            Notice.showBottomCenterMessage("支付成功");
            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
            App.data.game2Center.LoadingLock.unlock();
            this.close();
        } else {
            this.t = 0;
            this._needSendBuy = true;
            App.timer.clearTimer(this, this.onTimer);
            App.timer.doTimeLoop(this, 3000, this.onTimer);
        }
    }
    private _needSendBuy: boolean;//请求是否支付成功

    private onTimer(): void {
        this.t += 3;
        if (this.t >= 600) {
            GameLog.log("-------------10分钟内支付失败");
            App.timer.clearTimer(this, this.onTimer);
            return;
        }
        if (this._needSendBuy) {
            this._needSendBuy = false;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.onPaySuccess, this, true));
        }
    }

    private onPaySuccess(data: any): void {
        if (data.code == 200) {
            Notice.showBottomCenterMessage("支付成功");
            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
            App.timer.clearTimer(this, this.onTimer);
            App.data.game2Center.LoadingLock.unlock();
            this.close();
        } else {
            GameLog.log("-------------未支付，继续检测----------");
            this._needSendBuy = true;
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}