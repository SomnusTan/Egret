/**
 * 设置面板
 * @author xiongjian 
 * @date 2017/8/31
 */
class SetPanel extends BasePanel {

    private _view: SetPanelUI;

    private _type: number;

    public constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new SetPanelUI();
        this.addChild(this._view);
        this._view.kaiguan.selected = true;
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    /**添加到场景中*/
    public show(data?: any): void {
        super.show();
        if (App.data.game2Center.DataCenter.mail && App.data.game2Center.DataCenter.mail.length > 0) {
            this._view.xin.visible = true;
        } else {
            this._view.xin.visible = false;
        }
        this._type = 0;

        //soeasy某些渠道，屏蔽邮件
        if (Config.soEasy && SoEasySdk.shieldChannel()) {
            this._view.xin.visible = false;
        }

        this._view.versionLabel.text = GlobalConfig.version_obj.main_version;

        this._dispatcher.addEventListener(egret.TouchEvent.CHANGE, this.yinyueTouch, this, this._view.kaiguan);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.xieyiTouch, this, this._view.jianyiGroup);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.youjianTouch, this, this._view.youjianGroup);

        CommomBtn.btnClick(this._view.guanbiBtn, this.close, this, 2);


        this._view.zhuName.text = App.data.game2Center.DataCenter.UserInfo.nickName;
        this._view.zhuId.text = App.data.game2Center.DataCenter.UserInfo.id + "";
        this.musicOff();

        //登出游戏功能
        CommomBtn.btnClick(this._view.quitGameBtn, this.onQuitGame, this);
    }

    /**从场景中移除*/
    public hide() {
        super.hide();
        CommomBtn.removeClick(this._view.guanbiBtn, this.close, this);
        CommomBtn.removeClick(this._view.quitGameBtn, this.onQuitGame, this);
        this._view.setGroup.scaleX = this._view.setGroup.scaleY = this._view.setGroup.alpha = 1;
        egret.Tween.removeTweens(this._view.setGroup);
        if (this._type == 0 && Config.hasEnterGame)
            App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
    }

    /**显示音乐开关 */
    private musicOff() {
        if (App.data.game2Center.SoundManager.allowPlayBGM) {
            this._view.kaiguan.selected = true;
            this._view.sndLine.visible = false;
        } else {
            this._view.kaiguan.selected = false;
            this._view.sndLine.visible = true;
        }
    }

    /**音乐点击 */
    private yinyueTouch() {
        this.playClick();
        if (this._view.kaiguan.selected) {
            App.data.game2Center.SoundManager.allowPlayBGM = true;
            App.data.game2Center.SoundManager.allowPlayEffect = true;
            this._view.sndLine.visible = false;
        } else {
            App.data.game2Center.SoundManager.allowPlayBGM = false;
            App.data.game2Center.SoundManager.allowPlayEffect = false;
            this._view.sndLine.visible = true;
        }
    }

    /**关闭音乐点击 */
    private yinyue1Touch() {
        this.playClick();
    }

    /**邮件点击 */
    private youjianTouch() {
        this.playClick();
        this._type = 1;
        // if (App.DataCenter.mail && App.DataCenter.mail.length > 0) {
        PanelOpenManager.openPanel(EnumPanelID.G2_MailPanel);
        this.closePanel();
        // }
    }

    /**协议点击 */
    private xieyiTouch() {
        this.playClick();
        this._type = 1;
        PanelOpenManager.openPanel(EnumPanelID.G2_ProtocolPanel);
        this.closePanel();
    }

    /**播放点击音乐 */
    private playClick() {
        App.sound.playSoundSwitchClient1(SoundManager.click);
    }


    /**关闭按钮点击 */
    private close() {
        this.outAnimation();
    }

    /**显示心 */
    private showXin(bo: boolean) {
        if (bo) {
            this._view.xin.visible = true;
        } else {
            this._view.xin.visible = false;
        }
    }

    /**出场动画 */
    private outAnimation() {
        this.closePanel();
        // egret.Tween.get(this._view.setGroup).set({ alpha: 1, scaleX: 1, scaleY: 1 }).to({ alpha: 0.4, scaleX: 0.4, scaleY: 0.4 }, 300).call(this.closePanel, this);
    }

    //退出游戏
    private onQuitGame() {
        Alert.show2("是否返回大厅？", "", new FunctionVO((data: any) => {
            if (data.type == Alert.OK) {
                this._type = 1;
                GameManager.exitGame();
                PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
            }
        }, this));
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}
