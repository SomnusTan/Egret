/**
 * 邮件面板
 * @author xiongjian
 * @date 2017/10/9 
 */

class MailPanel extends BasePanel {

    private _view: MailPanelUI;

    private _type: number;

    public constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new MailPanelUI()
        this.addChild(this._view);

        this._view.mailList.itemRenderer = MailListItem;
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    /**添加到场景中*/
    public show(data?: any): void {
        super.show(data);
        this._type = 1;
        //soeasy，某些渠道屏蔽邮件
        if (Config.soEasy && SoEasySdk.shieldChannel()) {

        } else {
            this.setData();
        }
        CommomBtn.btnClick(this._view.backBtn, this.closePanel, this, 2);
    }

    /**从场景中移除*/
    public hide() {
        super.hide();
        CommomBtn.removeClick(this._view.backBtn, this.closePanel, this);
        if (this._type == 0 && Config.hasEnterGame)
            PanelOpenManager.openPanel(EnumPanelID.G2_SetPanel);
    }

    /**设置数据 */
    public setData() {
        let data = App.data.game2Center.DataCenter.mail;
        if (data && data.length > 0) {
            this._view.noText.visible = false;
        } else {
            this._view.noText.visible = true;
        }
        let ac = new eui.ArrayCollection();
        let arr = [];
        arr = data;
        GameLog.log("arr", arr);
        ac.source = arr;
        this._view.mailList.dataProvider = ac;
        ScrollerCenter.hideVerticalScrollBar(this._view.maillScroller);
    }

    public closePanel(): void {
        this._type = 0;
        super.closePanel();
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}