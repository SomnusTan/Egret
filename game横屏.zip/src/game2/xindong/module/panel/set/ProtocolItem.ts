class ProtocolItem extends ItemRenderer {
	public txt: eui.Label;
	private _isChanged: boolean;
	public constructor() {
		super();
	}

	/**添加到舞台 */
	protected onAddStage(e?: egret.Event): void {
		super.onAddStage(e);
		if (this._isChanged) {
			this._isChanged = false;
			this.getLabel().text = this.data;
		}
	}

	protected dataChanged(): void {
		if (this.parent) {
			this.getLabel().text = this.data;
			this._isChanged = false;
		}
		else
			this._isChanged = true;
		// GameLog.log('data:', this.data);
	}

	private getLabel(): eui.Label {
		if (!this.txt) {
			this.txt = new eui.Label();
			this.txt.x = 19;
			this.txt.y = 19;
			this.txt.size = 24;
			this.txt.lineSpacing = 5;
			this.txt.fontFamily = 'fzyc';
			this.txt.width = 727;
			this.txt.textColor = 0x6f4b4b;
			this.addChild(this.txt);
		}
		return this.txt;
	}
}