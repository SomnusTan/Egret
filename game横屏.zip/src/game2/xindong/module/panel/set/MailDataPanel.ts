/**
 * 邮件面板
 * @author xiongjian
 * @date 2017/10/9 
 */

class MailDataPanel extends BasePanel {
    private _view: MailDataPanelUI;

    private recData: any;
    private _items: MailDataGroupItem[];

    public constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new MailDataPanelUI();
        this.addChild(this._view);
        this._view.giftGroup.removeChildren();
    }

    private clearItems(): void {
        if (this._items) {
            for (var i: number = 0; i < this._items.length; i++) {
                this._items[i] && this._items[i].dispose();
                this._items[i] = undefined;
            }
        }
        this._items = null;
    }

    public dispose(): void {
        this.clearItems();
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    /**添加到场景中*/
    public show(data?: any) {
        super.show(data);

        this.recData = data;
        CommomBtn.btnClick(this._view.backBtn, this.closePanel, this, 2);
        CommomBtn.btnClick(this._view.linquBtn, this.linquBtnTouch, this, 1);
        this.setData();
    }

    /**从场景中移除*/
    public hide() {
        super.hide();
        this.recData = null;
        CommomBtn.removeClick(this._view.backBtn, this.closePanel, this);
        CommomBtn.removeClick(this._view.linquBtn, this.linquBtnTouch, this);
        PanelOpenManager.openPanel(EnumPanelID.G2_MailPanel, null, false);
    }

    /**设置数据 */
    public setData() {
        this._view.text.text = this.recData.title;
        this._view.content.text = this.recData.content;
        GameLog.log("tool", this.recData.tool);
        this.clearItems();
        this._items = [];
        let data = this.recData.tool;
        let gift = new MailDataGroupItem();
        gift.x = 20;
        gift.y = 20;
        gift.setName(data.cname);
        gift.setCount(this.recData.num);
        gift.setImage(data.pic);
        this._view.giftGroup.addChild(gift);
        this._items.push(gift);
    }

    /**领取 */
    private linquBtnTouch() {

        let param = { mid: 0 };
        param.mid = this.recData.id;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.mailLingqu, param, new FunctionVO(this.lingquBack, this));
    }

    /**领取邮件返回 */
    private lingquBack(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
            App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            App.data.game2Center.DataCenter.UserInfo.power = data.data.power;

            //删除本条邮件
            let mail = App.data.game2Center.DataCenter.mail;
            for (let i = 0; i < mail.length; i++) {
                if (mail[i].id == this.recData.id) {
                    App.data.game2Center.DataCenter.mail.splice(i, 1);
                }
            }
            this.closePanel();
            //更新红点提示
            App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);

            Notice.showBottomCenterMessage(LanConst.mail0_00);
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}