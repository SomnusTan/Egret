/**
 * @author xiongjian 
 * @date 2017/10/9
 * 邮件列表item
 */
class MailListItem extends eui.ItemRenderer {

    private oldData;
    public text: eui.Label;
    public timeLabel: eui.Label;

    public constructor() {
        super();
        this.skinName = "MailListItemSkin";
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.itemTouch, this);
    }

    protected dataChanged() {
        if (this.oldData == this.data) {
            return;
        }

        this.text.text = this.data.title

        this.oldData = this.data;
    }

    /**item点击 */
    private itemTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        PanelOpenManager.openPanel(EnumPanelID.G2_MailDataPanel, this.data, false);
        PanelOpenManager.removePanel(EnumPanelID.G2_MailPanel);
    }

}