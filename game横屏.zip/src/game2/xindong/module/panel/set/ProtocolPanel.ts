/**
 * 协议面板
 * @author chenkai
 * @since 2017/10/17
 */
class ProtocolPanel extends BasePanel {

	private _view: ProtocolPanelUI;

	public constructor() {
		super();
	}

	protected init() {
		super.init();
		this._view = new ProtocolPanelUI();
		this.addChild(this._view);
		this._view.dataList.useVirtualLayout = true;
		this._view.dataList.itemRenderer = ProtocolItem;
		this._view.protocalScroller.viewport = this._view.dataList;
	}


	public show(data?: any): void {
		super.show(data);
		this._view.dataList.dataProvider = new eui.ArrayCollection([App.global.userInfo.userAgreeInfo.content1]);

		App.timer.doTimeOnce(this, 500, this.updateContent);
		ScrollerCenter.hideVerticalScrollBar(this._view.protocalScroller);

		CommomBtn.btnClick(this._view.guanbiBtn, this.onClose, this, 2);
		CommomBtn.btnClick(this._view.okBtn, this.onClose, this, 1);

		if (this._view.protocalScroller.viewport)
			this._view.protocalScroller.viewport.scrollV = 0;
	}

	public hide(): void {
		super.hide();
		this._view.protocalScroller.stopAnimation();
		this._view.dataList.dataProvider = new eui.ArrayCollection([]);
		App.timer.clearTimer(this, this.updateContent);
		CommomBtn.removeClick(this._view.guanbiBtn, this.onClose, this);
		CommomBtn.removeClick(this._view.okBtn, this.onClose, this);

		PanelOpenManager.openPanel(EnumPanelID.G2_SetPanel);
	}

	private updateContent(): void {
		var content: string = App.global.userInfo.userAgreeInfo.content1 + App.global.userInfo.userAgreeInfo.content2;
		var conArr: string[] = content.split("\n");
		var divisor: number = 20;//除数
		var remainder: number = conArr.length % divisor;//余数
		var quotient: number = Math.floor(conArr.length / divisor);//商
		var add: string;
		var addStr: string[] = [];
		var length: number = divisor + (remainder > 0 ? 1 : 0);
		for (var i: number = 0; i < length; i++) {
			add = "";
			for (var j: number = quotient * i; j < quotient * (i + 1); j++) {
				if (j >= conArr.length) break;
				if (j < quotient * (i + 1)) {
					if (addStr.length == 0 && add == "") {
						add += conArr[j];
					} else {
						add += "\n" + conArr[j];
					}
				}
			}
			addStr.push(add);
		}
		this._view.dataList.dataProvider = new eui.ArrayCollection(addStr);
	}

	private onClose() {
		this.closePanel();
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

}