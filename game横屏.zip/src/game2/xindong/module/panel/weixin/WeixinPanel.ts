/**
 * 微信面板
 * @author xiongjian
 * @date 2017/08/24
 */
class WeixinPanel extends BasePanel {

    private _view: WeixinPanelUI;
    /**是否显示金币回复 */
    public showGold = false;
    /**字数 */
    private chatLen = 0;
    /**是否正在发送消息中 */
    public bSending: boolean = false;
    /**等待下一条消息 */
    private waitnextmsg;

    private backFlag: boolean;

    //private arr = []; //list数据
    /**list 控制器 */
    private ac: eui.ArrayCollection;
    /**历史消息 */
    private history: any[];
    /**应答id */
    private reply;
    /**开始id */
    private start_id;

    /**新手指引手指初始位置 */
    private handY: number;
    private handYH: number;
    private handYB: number;
    /**是否需要弹礼包 在金币不足时弹一次*/
    private bOpenLiBao: boolean = true;

    private bFirstCD: boolean;      //是否第一次提示购买无等待

    private constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();

        this._view = new WeixinPanelUI();
        this.addChild(this._view);

        this._view.yindaoBack.visible = false;
        this._view.yindaoGroup.visible = false;
        this._view.yindaoHeart.visible = false;
        //初始化UI
        this.handY = this._view.weixinHand.y;
        this.handYH = this._view.dianhuaHand0.y;
        this.handYB = this._view.backHand.y;
        this._view.grilImg.mask = this._view.maskImg;
        if (App.data.game2Center.DataCenter.Wechat) {
            this._view.grilImg.source = App.data.game2Center.DataCenter.Wechat.head;
        }
    }

    /**添加到场景中*/
    public show(data?: any): void {
        super.show(data);
        //初始化滚动容器
        this.ac = new eui.ArrayCollection();
        this._view.messageList.useVirtualLayout = false;  //关闭虚拟布局，防止item项高度不一致时抖动
        this._view.messageList.dataProvider = this.ac;
        this._view.messageList.itemRenderer = MessageListItem;

        //初始化女主名字
        this._view.grilname.text = App.data.game2Center.DataCenter.ConfigInfo.girl_name;

        //重置打开礼包标志位
        this.bOpenLiBao = true;
        this.openLibao();

        //提示购买无冷却
        this.hideCDImg();
        this.bFirstCD = true;

        //引导
        this.hideSelect();
        this.setGuide();

        //显示历史数据
        this.getHistory();
        this.addHistoryChat();
        this.setScolltoEnd();

        //显示数值
        this.setConfig();

        //电话主事件完成，才能继续
        if (App.data.game2Center.DataCenter.UserInfo.tel_main) {
            if (this.isWaitingReply == false) {
                this._view.sendMessage.showGold(false);
                this.showGold = false;
                this.sendnext();
            }
            else {
                this._view.sendMessage.showGold(true);
                App.timer.serverTimeEnd(this, this.timerFunc, App.data.game2Center.DataCenter.weixinWaitTimeEnd);
                this.showCDImg();
            }
            //电话主事件未完成，啥也不干
        } else {
            this._view.sendMessage.showInput(false);
        }

        this._view.sendMessage.send.addEventListener(egret.TouchEvent.TOUCH_TAP, this.sendMessageTouch, this);
        this._view.sendMessage.labelGroup.addEventListener(egret.TouchEvent.TOUCH_TAP, this.labelTouch, this);
        this._view.sendMessage.goldGroup.addEventListener(egret.TouchEvent.TOUCH_TAP, this.goldTouch, this);
        this._view.yd_weixinImg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_weixinImgTouch, this);
        this._view.yd_dianhuaImg0.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_dianhuaImgTouchHeart, this);
        this._view.ydsend.addEventListener(egret.TouchEvent.TOUCH_TAP, this.ydsendTouch, this);
        this._view.goldGroup.addEventListener(egret.TouchEvent.TOUCH_TAP, this.goldGroupTouch, this);
        this._view.messageScroller.addEventListener(eui.UIEvent.CHANGE_END, this.msgScrollChangeEnd, this);

        CommomBtn.btnClick(this._view.backBtn, this.backTouch, this, 2);
        this._view.backCircle.addEventListener(egret.TouchEvent.TOUCH_TAP, this.backGuideTouch, this);

        App.dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.updateSiwei, this);
        App.dispatcher.addEventListener(EventConst.UPDATE_LIBAO, this.updateSiwei, this);
    }

    /**从场景中移除*/
    public hide(): void {
        super.hide();
        this._view.sendMessage.send.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.sendMessageTouch, this);
        this._view.sendMessage.labelGroup.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.labelTouch, this);
        this._view.sendMessage.goldGroup.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.goldTouch, this);
        this._view.yd_weixinImg.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_weixinImgTouch, this);
        this._view.yd_dianhuaImg0.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_dianhuaImgTouchHeart, this);
        this._view.ydsend.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.ydsendTouch, this);
        this._view.goldGroup.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.goldGroupTouch, this);
        this._view.messageScroller.removeEventListener(eui.UIEvent.CHANGE_END, this.msgScrollChangeEnd, this);

        CommomBtn.removeClick(this._view.backBtn, this.backTouch, this);

        this.removeTimer();

        this.stopBackBtnAnim();

        this.hideCDImg();
        App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);

    }

    /**更新四维 */
    private updateSiwei() {
        this.setConfig();
    }

    /**微信引导点击 */
    private yd_weixinImgTouch() {

        let param = {};
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, param, new FunctionVO(this.finishGuideBack, this));

    }

    /**引导完成返回 */
    private finishGuideBack(data) {
        if (data.code == 200) {
            this._view.yindaoGroup.visible = false;
            egret.Tween.removeTweens(this._view.weixinHand);
            // App.DataCenter.weixinGuide = false;
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;

            if (App.data.game2Center.DataCenter.weixinSendMsg.length == 2) {
                this._view.sendMessage.showInput(false);
                this.showSelect(App.data.game2Center.DataCenter.weixinSendMsg);
            }
            if (App.data.game2Center.DataCenter.weixinSendMsg.length == 3) {
                this._view.sendMessage.showInput(false);
                this.showSelect(App.data.game2Center.DataCenter.weixinSendMsg);
            }
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**引导发送 */
    private ydsendTouch() {
        this.sendMessageTouch();
    }

    /**退出 */
    private backTouch() {
        this._view.sendMessage.setText("");
        this.hideSelect();
        this._view.sendMessage.showInput(true);
        this.closePanel();
    }

    /**金币Group点击 */
    private goldGroupTouch() {
        // App.PanelManager.open(PanelRegister.G2_ShopPanel, ShopPage.Gold);
        // let shop = <ShopPanel>App.PanelManager.getPanel(PanelRegister.G2_ShopPanel);
        // shop.isBack = true;
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGoldPanel);
    }

    //聊天信息滚动改变结束
    private msgScrollChangeEnd() {
        if (this._view.messageScroller.viewport.scrollV <= 200) {
            this.addHistoryChat();
        }
    }

    /**一次增加10条历史聊天记录到List组件中 防止一次性添加卡顿*/
    private addHistoryChat() {
        let curChatNum = this._view.messageList.dataProvider.length;
        let totalChatNum = this.history.length;
        //当前还有聊天记录未加入到list中时，选择10条加入list中
        if (curChatNum < totalChatNum) {
            let lastContentHeight = this._view.messageScroller.viewport.contentHeight;
            let curIndex = totalChatNum - curChatNum;
            let startIndex = curIndex - 10;
            startIndex = (startIndex < 0) ? 0 : startIndex;
            let chatData = this.history.slice(startIndex, curIndex);
            let chatLen = chatData.length;
            for (let i = chatLen - 1; i >= 0; i--) {
                this.ac.addItemAt(chatData[i], 0);
            }
            this._view.messageScroller.viewport.validateNow();
            this._view.messageScroller.viewport.scrollV = this._view.messageScroller.viewport.contentHeight - lastContentHeight;
        }
		ScrollerCenter.hideVerticalScrollBar(this._view.messageScroller);
    }


    /**获取历史数据 */
    private getHistory() {
        let wechat = App.data.game2Center.DataCenter.Wechat;
        let arr = []
        let history = wechat.history;

        for (let i = 0; i < history.length; i++) {
            let json = ProtocolHttpData.wechat
            json = history[i];

            for (let i = 0; i < json.dialog.length; i++) {
                let obj = new Object();
                let dialog = ProtocolHttpData.dialog;
                dialog = json.dialog[i];
                obj["msg"] = dialog;
                arr.push(obj);
            }
        }

        //等待回复时，不重置数据
        if (this.isWaitingReply == false && App.data.game2Center.DataCenter.UserInfo.weChatFinish) {
            App.data.game2Center.DataCenter.weixinSendMsg = wechat.nextwechat;
        }

        this.history = arr;
        return arr;
    }

    /**如果第一条是服务器回话，请求下一段话 */
    private sendnext() {
        GameLog.log("sendnext:", App.data.game2Center.DataCenter.weixinSendMsg, App.data.game2Center.DataCenter.weixinSendMsg.length);

        //有聊天信息发送
        if (App.data.game2Center.DataCenter.weixinSendMsg.length == 1) {
            let msg = App.data.game2Center.DataCenter.weixinSendMsg[0];

            if (msg.reply == -1) {
                this._view.sendMessage.showInput(false);
                return;
            }
            this.bSending = true;
            this._view.sendMessage.send.enabled = false;


            let data = ProtocolHttp.chat;
            data.id = msg.id;
            data.pid = msg.pid;
            data.sid = msg.sid;
            data.instant = 0;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.chat, data, new FunctionVO(this.sendnextBack, this));
        }
        //显示我要选择的回答
        else if (App.data.game2Center.DataCenter.weixinSendMsg.length > 1) {
            if (!this.showGold) {
                this._view.sendMessage.showGold(false);
                this._view.sendMessage.showInput(true);
            } else {
                this._view.sendMessage.showGold(true);
                this._view.sendMessage.showInput(true);
            }
        }
        //没有聊天
        else if (App.data.game2Center.DataCenter.weixinSendMsg.length == 0) {
            this._view.sendMessage.showInput(false);
        }
    }

    /**发送下一段话返回 */
    private sendnextBack(data) {
        this.showGold = false;
        if (data.code == 200) {
            this._view.sendMessage.showGold(false);
            if (data.data.chat && data.data.chat.length > 0) {
                //先刷新再赋值
                let msg = App.data.game2Center.DataCenter.weixinSendMsg[0];
                let obj = new Object();
                obj["msg"] = msg;
                this.refresh(obj);
                App.data.game2Center.DataCenter.weixinSendMsg = data.data.chat;
                App.data.game2Center.DataCenter.Wechat.nextwechat = data.data.chat;
                App.data.game2Center.DataCenter.UserInfo.nextWechat = true;
                App.data.game2Center.DataCenter.UserInfo.weChatFinish = false;
                this._view.sendMessage.setGoldText(data.data.chat[0].instant_gold);
            } else {
                //先刷新再赋值
                let msg = App.data.game2Center.DataCenter.weixinSendMsg[0];
                let obj = new Object();
                obj["msg"] = msg;
                this.refresh(obj);
                App.data.game2Center.DataCenter.UserInfo.nextWechat = false;
                App.data.game2Center.DataCenter.UserInfo.weChatFinish = true;
                App.data.game2Center.DataCenter.Wechat.nextwechat = [];
                this._view.sendMessage.showInput(false);
                App.data.game2Center.DataCenter.UserInfo.wechat_main = true;//主事件完成

                //增加返回提示
                this.playBackBtnAnim();
                this.setBackGuide();
            }

        }

    }

    /**发送按钮点击 */
    private sendMessageTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        if (App.data.game2Center.DataCenter.weixinMsgType && App.data.game2Center.DataCenter.weixinMsgType.id && this.bSending == false) {
            this.bSending = true;
            this._view.sendMessage.send.enabled = false;

            let data = ProtocolHttp.chat;
            data.id = App.data.game2Center.DataCenter.weixinMsgType.id;
            data.pid = App.data.game2Center.DataCenter.weixinMsgType.pid;
            data.sid = App.data.game2Center.DataCenter.weixinMsgType.sid;
            data.instant = 0;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.chat, data, new FunctionVO(this.sendMsgBack, this));
        } else {
            Notice.showBottomCenterMessage("点击左侧输入框，选择回复内容");
        }

    }

    /**发送消息返回 */
    private sendMsgBack(data) {
        this.showGold = false;
        if (data.code == 200) {
            //重置输入文本
            this._view.sendMessage.setText(" ");

            //保存聊天记录，并显示聊天到界面上
            let obj = new Object();
            obj["msg"] = App.data.game2Center.DataCenter.weixinMsgType;
            this.refresh(obj);

            //心动值
            let heart = data.data.hearts;
            if (heart != 0 && data.data.chat.length == 1) {
                TipsHeat.showHeat(heart);
                App.data.game2Center.DataCenter.UserInfo.hearts += heart;
                this.setConfig();
                this._view.sendMessage.setGoldText(data.data.chat[0].instant_gold);
            }

            //等待下一条回复
            let waitMsg = data.data.chat;
            this.waitnextmsg = data.data.chat;

            if (waitMsg && waitMsg.length == 1) {
                App.data.game2Center.DataCenter.weixinSendMsg = waitMsg;
                this.waitMsg(waitMsg[0]);
            }
            else if (waitMsg.length == 0) {
                App.data.game2Center.DataCenter.weixinSendMsg = [];
                this._view.sendMessage.showInput(false);
            }

            this.setHeartGuide()
        }
    }

    /**等待下一条回复 */
    private waitMsg(msg) {
        let wait = msg.wait;
        if(Config.skipVideo)
            wait = 0;
        //秒回
        if (wait == 0) {
            App.timer.doTimeOnce(this, 1000, this.dealySendNext);
            //非秒回，设置计时器等待
        } else {
            this._view.sendMessage.showGold(true);
            this.removeTimer();
            App.data.game2Center.DataCenter.weixinWaitTimeEnd = ServerTime.serverTime + wait;
            App.timer.serverTimeEnd(this, this.timerFunc, App.data.game2Center.DataCenter.weixinWaitTimeEnd);
            this.showCDImg();
        }
    }

    private dealySendNext(): void {
        this._view.sendMessage.showGold(false);
        this.sendnext();
    }


    /**输入框文本点击 */
    private labelTouch(e: TouchEvent) {
        GameLog.log("labelTouch:", App.data.game2Center.DataCenter.weixinSendMsg, App.data.game2Center.DataCenter.weixinSendMsg.length);
        if (App.data.game2Center.DataCenter.weixinSendMsg.length >= 2) {
            this._view.sendMessage.showInput(false);
            this.showSelect(App.data.game2Center.DataCenter.weixinSendMsg);
        }
    }

    /**msglist 点击返回 */
    private selectHandler(select: MessageSelectEnum) {
        GameLog.log("msgListTouch:", select);
        this.bSending = false;
        this._view.sendMessage.send.enabled = true;

        this.hideSelect();
        this._view.sendMessage.showInput(true);
        this._view.sendMessage.setText(App.data.game2Center.DataCenter.weixinSendMsg[select].says);
        App.data.game2Center.DataCenter.weixinMsgType = App.data.game2Center.DataCenter.weixinSendMsg[select];
    }

    /**保存历史聊天，并添加聊天到界面上 */
    private refresh(msg) {
        //保存历史聊天
        this.history.push(msg);
        if (App.data.game2Center.DataCenter.Wechat && App.data.game2Center.DataCenter.Wechat.history && App.data.game2Center.DataCenter.Wechat.history.length > 0) {
            let len = App.data.game2Center.DataCenter.Wechat.history.length;
            App.data.game2Center.DataCenter.Wechat.history[len - 1].dialog.push(msg["msg"]);
        }

        //计算聊天文字长度
        if (msg.msg && msg.msg.says) {
            this.chatLen = msg.msg.says.length;
        } else {
            this.chatLen = 0;
        }

        //添加聊天到界面上
        this.ac.addItem(msg);
        this.setScolltoEnd1();
        App.sound.playSoundSwitchClient1(SoundManager.sent_msg);
    }

    /**设置scroll到末尾 */
    private setScolltoEnd(bUseTween: boolean = true) {
        this._view.messageScroller.validateNow();
        App.timer.doTimeOnce(this, 100, this.scrollToEnd);
    }

    private scrollToEnd(): void {
        if (this._view.messageScroller.viewport.contentHeight > this._view.messageScroller.height) {
            this._view.messageScroller.viewport.scrollV = this._view.messageScroller.viewport.contentHeight - this._view.messageScroller.height;
        }
        else {
            this._view.messageScroller.viewport.scrollV = 0;
        }
    }

    /**刷新调到末尾 */
    private setScolltoEnd1() {
        App.timer.doTimeOnce(this, 50, this.scrollToEnd1);
    }

    private scrollToEnd1(): void {
        if (this._view.messageScroller.viewport.contentHeight > this._view.messageScroller.height) {
            let count = Math.floor(this.chatLen / 11);
            let scrollV = this._view.messageScroller.viewport.contentHeight - this._view.messageScroller.height + count * 30;
            egret.Tween.get(this._view.messageScroller.viewport).to({ scrollV }, 200);
        }
    }

    /**每秒倒计时 */
    private timerFunc(serverTimeData: ServerTimeData) {
        if (serverTimeData.spuleTime <= 0) {
            this.showGold = false;
            this.sendnext();
            this.removeTimer();
        } else {
            this.showGold = true;
        }
    }

    /**清楚倒计时 */
    private removeTimer() {
        App.timer.clearTimer(this, this.timerFunc);
    }

    /**配置数值 */
    public setConfig() {
        var gold: number = App.data.game2Center.DataCenter.UserInfo.gold;
        this._view.goldLabel.text = gold + "";
        this._view.heartPlugin.setJindu(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    /**金币立即回复点击 */
    private goldTouch() {
        GameLog.log("goldTouch");
        this.bSending = true;
        this._view.sendMessage.send.enabled = false;
        this._view.sendMessage.goldGroup.touchEnabled = false;


        let data = ProtocolHttp.chat;
        data.id = this.waitnextmsg[0].id;
        data.pid = this.waitnextmsg[0].pid;
        data.sid = this.waitnextmsg[0].sid;
        data.instant = 1;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.chat, data, new FunctionVO(this.goldTouchBack, this));
    }

    /**金币立即回复返回 */
    private goldTouchBack(data) {
        this.showGold = false;
        this._view.sendMessage.goldGroup.touchEnabled = true;

        if (data.code == 200) {
            GameLog.log("goldTouchBack:", data);
            this._view.sendMessage.showGold(false);
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            this.setConfig();
            if (data.data.chat && data.data.chat.length > 0) {
                //先刷新再赋值
                let msg = App.data.game2Center.DataCenter.weixinSendMsg[0];
                let obj = new Object();
                obj["msg"] = msg;
                this.refresh(obj);
                App.data.game2Center.DataCenter.weixinSendMsg = data.data.chat;

                this.removeTimer();

                App.data.game2Center.DataCenter.Wechat.nextwechat = data.data.chat;
                App.data.game2Center.DataCenter.UserInfo.nextWechat = true;
                App.data.game2Center.DataCenter.UserInfo.weChatFinish = false;

            } else {
                //先刷新再赋值
                let msg = App.data.game2Center.DataCenter.weixinSendMsg[0];
                let obj = new Object();
                obj["msg"] = msg;
                this.refresh(obj);
                App.data.game2Center.DataCenter.weixinSendMsg = data.data.chat;

                this.removeTimer();

                App.data.game2Center.DataCenter.UserInfo.nextWechat = false;
                App.data.game2Center.DataCenter.UserInfo.weChatFinish = true;
                App.data.game2Center.DataCenter.Wechat.nextwechat = [];
                this._view.sendMessage.showInput(false);
                App.data.game2Center.DataCenter.UserInfo.wechat_main = true;//主事件完成

                //增加返回提示
                this.playBackBtnAnim();
            }

        } else {
            //金币不足，弹出礼包提示，且只弹一次
            if (data.code == 809 && App.data.game2Center.DataCenter.keybuy.miaohui.hasbuy == false && this.bOpenLiBao == true) {
                this.bOpenLiBao = false;
                PanelOpenManager.openPanel(EnumPanelID.G2_LibaomiaohuiPanel);
            }
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**引导 */
    public setGuide() {
        if (App.data.game2Center.DataCenter.weixinGuide) {
            this._view.yindaoGroup.visible = true;
            egret.Tween.get(this._view.weixinHand, { loop: true })
                .set({ y: this.handY })
                .to({ y: this.handY - 40 }, 600)
                .to({ y: this.handY }, 800)
                .wait(100);
        }
    }

    /**弹礼包面板 */
    public openLibao() {
        //随机生成一个一到四的数
        let num = Math.floor(Math.random() * App.data.game2Center.DataCenter.UserInfo.randNum) + 1
        if (num == 1 && !App.data.game2Center.DataCenter.keybuy.miaohui.hasbuy && App.data.game2Center.DataCenter.guide.emph_zone != "ZONE_WEIXIN") {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaomiaohuiPanel);
        }
    }

    /**是否在等待女主回复 */
    private get isWaitingReply() {
        return App.data.game2Center.DataCenter.weixinWaitTimeEnd > ServerTime.serverTime;
    }

    private playBackBtnAnim() {
        egret.Tween.get(this._view.backBtn, { loop: true }).to({ scaleX: 1.15, scaleY: 1.15 }, 500).to({ scaleX: 1, scaleY: 1 }, 500);
    }

    private stopBackBtnAnim() {
        this._view.backBtn.scaleX = 1;
        this._view.backBtn.scaleY = 1;
        egret.Tween.removeTweens(this._view.backBtn);
    }

    /**显示回答列表 */
    private showSelect(msg) {
        this._view.selectGroup.visible = true;
        this._view.selectBg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.lookChat, this);
        this._view.selectList.showMsg(msg);
        this._view.selectList.setOK(this.selectHandler, this);
    }

    /**隐藏回答列表 */
    private hideSelect() {
        this._view.selectGroup.visible = false;
    }

    /**关闭选择框，并查看聊天 */
    private lookChat() {
        this.hideSelect();
        if (!this.showGold) {
            this._view.sendMessage.showGold(false);
            this._view.sendMessage.showInput(true);
        } else {
            this._view.sendMessage.showGold(true);
            this._view.sendMessage.showInput(true);
        }
    }

    /**心动值引导 */
    private setHeartGuide() {
        if (this.ac.length != 1 || !App.data.game2Center.DataCenter.weixinGuide) {
            return;
        }
        this._view.yindaoHeart.visible = true;
        egret.Tween.get(this._view.dianhuaHand0, { loop: true })
            .set({ y: this.handYH })
            .to({ y: this.handYH - 40 }, 600)
            .to({ y: this.handYH }, 800)
            .wait(100);
    }

    /**心动值引导点击 */
    private yd_dianhuaImgTouchHeart() {
        this._view.yindaoHeart.visible = false;
        egret.Tween.removeTweens(this._view.dianhuaHand0);
        App.data.game2Center.DataCenter.weixinGuide = false;
        this.backFlag = true;
    }

    /**退出引导 */
    private setBackGuide() {
        if (!this.backFlag) {
            return;
        }
        this._view.yindaoBack.visible = true;
        egret.Tween.get(this._view.backHand, { loop: true })
            .set({ y: this.handYB })
            .to({ y: this.handYB + 40 }, 600)
            .to({ y: this.handYB }, 800)
            .wait(100);
    }

    private backGuideTouch() {
        this._view.yindaoBack.visible = false;
        App.data.game2Center.DataCenter.weixinGuide = false;
        this.backTouch();
    }

    //显示提示购买无冷却
    private showCDImg() {
        if (this.bFirstCD == true && App.data.game2Center.DataCenter.keybuy.miaohui.hasbuy == false) {
            this.bFirstCD = false;
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this, this);
            this._view.cdBtn.visible = true;
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this, this._view.cdBtn);
        }
    }

    //隐藏提示购买无冷却
    private hideCDImg() {
        this._dispatcher.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this, this);
        this._view.cdBtn.visible = false;
        this._dispatcher.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this, this._view.cdBtn);
    }

    //隐藏提示购买无冷却
    private onCDBtnTouch(e: egret.TouchEvent) {
        this.hideCDImg();
        this.showLiBao();
    }

    //显示礼包
    private showLiBao() {
        if (App.data.game2Center.DataCenter.keybuy.miaohui.hasbuy == false) {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaomiaohuiPanel);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}