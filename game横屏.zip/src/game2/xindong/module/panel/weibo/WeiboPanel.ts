/**
 * 微博面板
 * @author xiongjian
 * @date 2017/09/20
 */
class WeiboPanel extends BasePanel {

    private _view: WeiBoPanelUI;

    private sendData: any;

    private zanHandY: number;

    private pinHandY: number;
    /**微博总数据 */
    private allWeiboList: any[];
    /**list 控制器 */
    private ac: eui.ArrayCollection;

    private MAX_ITEM_COUNT: number = 4;
    /**当前页数 */
    private page: number;
    /**总页数 */
    private count: number;
    /**需要显示下一页数据 */
    private needNext: boolean = false;

    private constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new WeiBoPanelUI();
        this.addChild(this._view);

        this.zanHandY = this._view.zanHand.y;
        this.pinHandY = this._view.pinHand.y;

        this.ac = new eui.ArrayCollection();
        this._view.weiboList.useVirtualLayout = false;
        this._view.weiboList.itemRenderer = WeiboListItem;
        this._view.weiboList.dataProvider = this.ac;
    }

    /**添加到场景中*/
    public show(data?: any): void {
        super.show(data);
        //微博选择框点击后自动关闭
        this._view.selectGroup.visible = false;
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchSelected, this, this._view.selectGroup);
        this._dispatcher.addEventListener(eui.UIEvent.CHANGE, this.onMoveScroll, this, this._view.weiboScoller);
        this._dispatcher.addEventListener(eui.UIEvent.CHANGE_END, this.onMoveScrollEnd, this, this._view.weiboScoller);

        this.initView();
        this._view.headImg.mask = this._view.maskImg;
        this.setHeart(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);

        CommomBtn.btnClick(this._view.backBtn, this.closePanel, this, 2);
        this.setZanGuide();
    }
    /**从场景中移除*/
    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.backBtn, this.closePanel, this);
        App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
        this.ac.removeAll();
    }

    public dispose(): void {
        this.ac = null;
        if (this._view) {
            this._view.remove();
            this._view = null;
        }
    }

    private onTouchSelected(e: egret.TouchEvent): void {
        this._view.selectGroup.visible = false;
    }

    private callBackFunction(type: number, ...arg): void {
        if (type == 1) {
            this.showSelect.apply(this, arg);
        }
        else if (type == 2) {
            this.hideSelect();
        }
        else if (type == 3) {
            this.setHeart.apply(this, arg);
        }
    }

    private initView() {

        this.allWeiboList = [];

        let weibo = App.data.game2Center.DataCenter.Weibo;
        if (weibo) {
            let data = weibo.data;
            this._view.girlNeme.text = weibo.name;
            this._view.headImg.source = weibo.weibo_head;

            this.allWeiboList = data;
        }
        this.count = Math.ceil(this.allWeiboList.length / this.MAX_ITEM_COUNT);
        this.page = 0;
        var arr = this.getCurrentPage();
        this.ac.source = arr;
        GameLog.log(`页数:${this.page}/${this.count},${this.ac.length}`);
        this.page++;
        App.timer.doFrameOnce(this, 1, this.onDelayRender);
    }

    private getCurrentPage(): any[] {
        if (this.allWeiboList == null)
            return null;
        if (this.page < this.count - 1) {
            return this.allWeiboList.slice(this.page * this.MAX_ITEM_COUNT, (this.page + 1) * this.MAX_ITEM_COUNT);
        }
        else if (this.page == this.count - 1) {
            return this.allWeiboList.slice(this.page * this.MAX_ITEM_COUNT);
        }
        else {
            return null;
        }
    }

    private onMoveScroll(e: eui.UIEvent): void {
        if (!this.needNext && this._view.weiboList.scrollV >= this._view.weiboList.contentHeight - this._view.weiboScoller.height) {
            this.needNext = true;
        }
    }

    /**
     * 拉到顶部请求数据
     */
    private onMoveScrollEnd(e: eui.UIEvent): void {
        if (this.needNext) {
            this.needNext = false;
            if (this.page <= this.count - 1) {
                var addList: any[] = this.getCurrentPage();
                this.page++;
                if (addList && addList.length > 0) {
                    for (var i: number = 0, len: number = addList.length; i < len; i++) {
                        this.ac.addItem(addList[i]);
                    }
                }
                App.timer.doFrameOnce(this, 1, this.onDelayRender);
            }
        }
    }

    private onDelayRender(): void {
        GameLog.log(`总对象数:${this._view.weiboList.numElements}`);
        var item: WeiboListItem;
        for (var i: number = 0, len: number = this._view.weiboList.numElements; i < len; i++) {
            item = this._view.weiboList.getVirtualElementAt(i) as WeiboListItem;
            item.callBackFunction = new FunctionVO(this.callBackFunction, this);
        }
        ScrollerCenter.hideVerticalScrollBar(this._view.weiboScoller);
    }

    /**设置心动值 */
    public setHeart(str, h) {
        if (h && h != "") {
            this._view.heartPlugin.setJindu(str, h);
        }
    }

    /**显示回答列表 */
    public showSelect(msg, cb: Function, obj: any) {
        this._view.selectGroup.visible = true;
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideSelect, this, this._view.selectBg);
        this._view.selectList.showMsg(msg);
        this._view.selectList.setOK(cb, obj);
    }

    /**隐藏回答列表 */
    public hideSelect() {
        this._view.selectGroup.visible = false;
    }

    /**赞引导 */
    private setZanGuide() {
        if (App.data.game2Center.DataCenter.weiboGuide) {
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.zanGuideTouch, this, this._view.zanCricle);
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.pinGuideTouch, this, this._view.pinCricle);
            this._view.yindaoZan.visible = true;
            egret.Tween.get(this._view.zanHand, { loop: true })
                .set({ y: this.zanHandY })
                .to({ y: this.zanHandY - 40 }, 600)
                .to({ y: this.zanHandY }, 800)
                .wait(100);
        }
    }

    private zanGuideTouch() {
        (<WeiboListItem>this._view.weiboList.getVirtualElementAt(0)).zanTouch();
        this._view.yindaoZan.visible = false;
        egret.Tween.removeTweens(this._view.zanHand);
        this.setPinGuide();
    }

    /**评论引导 */
    private setPinGuide() {
        this._view.yindaoPin.visible = true;
        egret.Tween.get(this._view.pinHand, { loop: true })
            .set({ y: this.pinHandY })
            .to({ y: this.pinHandY - 40 }, 600)
            .to({ y: this.pinHandY }, 800)
            .wait(100);
    }

    private pinGuideTouch() {
        (<WeiboListItem>this._view.weiboList.getVirtualElementAt(0)).pinlunTouch();
        this._view.yindaoPin.visible = false;
        egret.Tween.removeTweens(this._view.pinHand);
        App.data.game2Center.DataCenter.weiboGuide = false;

        let param = {};
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, param, new FunctionVO(this.finishGuideBack, this));
    }

    /**引导完成返回 */
    private finishGuideBack(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}