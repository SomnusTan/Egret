class ShopGoldPanel extends BasePanel {
	private goldListData: any[] = [];
	private _view: ShopGoldPanelUI;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new ShopGoldPanelUI();
		this.addChild(this._view);
		this._view.goldGrp.removeChildren();

		let shop = App.data.game2Center.DataCenter.Shop;

		this.goldListData = shop.golds;

		/**金币道具 */
		for (let i = 0; i < this.goldListData.length; i++) {
			let item = new ShopGoldItem();
			item.setData(this.goldListData[i]);
			this._view.goldGrp.addChild(item);
		}

		this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
	}

	public show(data?: any): void {
		super.show(data);
		this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);

		CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);

		this._dispatcher.addEventListener(EventConst.payBack, this.payback, this);
		this._dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.onUpdateSiwei, this);

		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onDiamond, this, this._view.diamondGroup);
	}

	public hide(): void {
		super.hide();
		App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
		CommomBtn.removeClick(this._view.backBtn, this.close, this);
	}

	private onDiamond(e: egret.TouchEvent) {
		PanelOpenManager.openPanel(EnumPanelID.G2_ShopDiamondPanel, null, false);
	}

	private onUpdateSiwei() {
		this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
	}

	/**设置金币 */
	public setGoldText(str) {
		this._view.goldLabel.text = str + "";
	}

	/**设置砖石 */
	public setDiaMondText(str) {
		this._view.diamondLabel.text = str + "";
	}

	/**设置爱心 */
	public setXinText(str, h) {
		if (h && h != "") {
			this._view.heartPlugin.setJindu(str, h);
		}
	}

	/**支付返回 */
	private payback() {
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
		this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
	}

	/**关闭面板 */
	private close() {
		this.closePanel();
	}

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

	public dispose(): void {
		var item: ShopGoldItem;
		for (var i: number = 0; i < this._view.goldGrp.numChildren; i++) {
			item = this._view.goldGrp.getChildAt(i) as ShopGoldItem;
			if(item) {
				item.dispose();
				item = undefined;
			}
		}
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

}