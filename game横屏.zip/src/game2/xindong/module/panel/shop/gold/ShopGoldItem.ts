class ShopGoldItem extends BaseView {
	private priceLabel: eui.BitmapLabel;
	private goldLabel: eui.Label;
	private goldImage: eui.Image;

	public transData: any;
	private t: number;
	private order_id;
	private open_window;
	public constructor() {
		super("ShopGoldItemSkin");
	}

	public setPrice(data: number) {
		this.priceLabel.text = data + "";
	}

	public goldNum(data: number) {
		this.priceLabel.text = data + "";
	}

	public setImg(url: string) {
		this.goldImage.source = url + "";
	}

	public setNum(num: number) {
		this.goldLabel.text = "x" + num + "";
	}


	/**设置数据 */
	public setData(data) {
		this.transData = data;
		this.setImg(this.transData.new_pic);
		this.setPrice(this.transData.price);
		this.setNum(this.transData.package[0].num);
	}

	public show(data?: any): void {
		super.show(data);
		//this.daojuImg.mask = this.maskImg;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.diamondsItemTouch, this, this);
	}

	public hide(): void {
		super.hide();
		this.open_window = null;
	}

	/**砖石Item点击 */
	private diamondsItemTouch() {
		App.sound.playSoundSwitchClient1(SoundManager.button);

		var html: string = StringUtil.substitute(EnumAlertContent.BUY_USE_DIAMOND, this.transData.price);
		Alert.show2(html, "", new FunctionVO((data: any) => {
			if (data.type == Alert.OK) {
				this.sendGiftBuy();
			}
		}, this), "", true);
	}

	private sendGiftBuy() {
		let data = ProtocolHttp.giftBuy;
		data = AddSomeMsgUtils.addSomeMsgByGiftBuy(data);
		data.gid = this.transData.id;
		let channel = window["channel"];
		if (channel) data["channel"] = channel;
		//新ios下单，增加渠道标识
		// if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
		// 	data["channel"] = IOSConfig.channel;
		// }
		//小米渠道
		if (MilletSDK.getInstance().millet) {
			data["channel"] = "xiaomi";
		}
		//vivo渠道
		if (H5_Vivo_SDK.getInstance().vivoData) {
			data["channel"] = "vivo";
		}
		// //网页
		// if (DeviceUtil.IsWeb) {
		// 	//360渠道
		// 	if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
		// 		data["channel"] = "360";
		// 	} /*else {
		// 		data["channel"] = "web_alipay";
		// 	}*/
		// }
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, data, new FunctionVO(this.buyDiamondsBack, this));
	}

	/**购买砖石返回 */
	private buyDiamondsBack(data) {
		if (data.code == 200) {
			if (this.transData.coin_type == "diamond") {
				Notice.showBottomCenterMessage("购买成功")
				App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
				App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
				App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
				App.data.game2Center.DataCenter.UserInfo.power = data.data.power;
				//更新四维
				App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);
			}
		} else if (data.code == 981) {
			App.nativeBridge.sendPay(data);
		} else {
			//Notice.showBottomCenterMessage("" + data.info);
			//钻石不足，提示去购买钻石
			Alert.show2("钻石数量不足，是否充值钻石？", "", new FunctionVO((data: any) => {
				if (data.type == Alert.OK) {
					PanelOpenManager.openPanel(EnumPanelID.G2_ShopDiamondPanel, {price:this.transData.price}, false);
				}
			}, this));
		}
	}

	//获得购买的状态
	private getBuy() {
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.payBack, this));
	}

	private payBack(data: any): void {
		if (data.code == 200) {
			Notice.showBottomCenterMessage("支付成功");
			App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
			App.data.game2Center.LoadingLock.unlock();
			PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
		} else {
			this.t = 0;
			this._needSendBuy = true;
			App.timer.clearTimer(this, this.onTimer);
			App.timer.doTimeLoop(this, 3000, this.onTimer);
		}
	}
	private _needSendBuy: boolean;//请求是否支付成功

	private onTimer(): void {
		this.t += 3;
		if (this.t >= 600) {
			GameLog.log("-------------10分钟内支付失败");
			App.timer.clearTimer(this, this.onTimer);
			return;
		}
		if (this._needSendBuy) {
			this._needSendBuy = false;
			ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.onPaySuccess, this, true));
		}
	}

	private onPaySuccess(data: any): void {
		if (data.code == 200) {
			Notice.showBottomCenterMessage("支付成功");
			App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
			App.timer.clearTimer(this, this.onTimer);
			App.data.game2Center.LoadingLock.unlock();
			PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
		} else {
			GameLog.log("-------------未支付，继续检测----------");
			this._needSendBuy = true;
		}
	}


}