/**
 * 神秘商店Item
 * 
 * @author syy
 * @deta 2018/4/17
 */
class MysteriousShopItem extends BaseView {
    private iconImg: eui.Image;
    private iconType: eui.Image;
    private numStr: eui.BitmapLabel;
    private titleStr: eui.Label;
    private contextText: eui.Label;
    private isSouOver: eui.Group;

    private dataConfig: any;

    public constructor() {
        super("MysteriousShopItemSkin");
    }

    public show(data?: any): void {
        if (!data) {
            return;
        }

        this.dataConfig = data;
        if (data.status == 1) {
            this.isSouOver.visible = true;
        } else {
            this.isSouOver.visible = false;
        }
        if (data.coin_type == "diamond") {
            this.iconType.source = "shop2_zhuanshi_png";
        } else {
            this.iconType.source = "shop2_jinbi2_png";
        }
        this.iconImg.source = data.package[0].pic;
        this.titleStr.text = data.package[0].cname + "X" + data.package[0].num;
        this.contextText.text = data.des + "";
        this.numStr.text = data.price + "";
        //
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchUs, this, this);
    }

    private touchUs(): void {
        let data: any = this.dataConfig;
        if (data.status == 1) {
            Notice.showBottomCenterMessage("已售罄");
            return;
        }
        let str: string = "确定花费"
        str += data.price;
        if (data.coin_type == "diamond") {
            str += "钻石";
        } else {
            str += "金币";
        }
        str += "购买 " + data.title + "吗？";
        Alert.show2(str, "", new FunctionVO((retData) => {
            if (retData.type == Alert.OK)
                App.dispatcher.dispatchEvent(G2_GameSceneEvent.BUY_SHENMISHOP, data);
        }, this), LanConst.dialog0_00)
    }

}