/**
 * 礼包购买 整体部分
 * lidan
 * 2018/4/23
 */
class ShopGiftPart extends BaseUI {
	private giftPart: ShopGiftToolPart;
	private giftGrp: eui.Group;
	public giftItem: ShopGiftToolItem[];
	private giftScroller: eui.Scroller;
	public constructor() {
		super("ShopGiftPartSkin");
		this.giftGrp.removeChildren();
	}

	public init() {
		let shop = App.data.game2Center.DataCenter.Shop;
		let giftpcak = shop.limitpack;
		if (this.giftScroller.viewport)
			this.giftScroller.viewport.scrollV = 0;

		this.setBuyPart(giftpcak[0]);

		if (this.giftItem && this.giftItem.length > 0) {
			for (var i: number = 0; i < this.giftItem.length; i++) {
				this.giftItem[i].dispose();
			}
		}
		this.giftItem = [];

		for (var k in shop.giftpcak) {
			giftpcak.push(shop.giftpcak[k]);
		}

		var item: ShopGiftToolItem;
		for (let i = 0; i < giftpcak.length; i++) {
			item = new ShopGiftToolItem();
			item.setImgPlace("gift");
			item.type = 1;
			item.setData(giftpcak[i]);
			item.setVisible(false);
			item.limitGrp.visible = false;
			this.giftGrp.addChild(item);
			this.giftItem.push(item);
		}
		App.dispatcher.addEventListener(EventConst.UPDATE_LIBAO, this.updateSiwei, this);
	}

	private updateSiwei(): void {
		let shop = App.data.game2Center.DataCenter.Shop;
		let giftpcak = shop.limitpack.concat();
		for (var k in shop.giftpcak) {
			giftpcak.push(shop.giftpcak[k]);
		}
		for (var i: number = 0; i < giftpcak.length; i++) {
			if (i < this.giftItem.length) {
				this.giftItem[i].setData(giftpcak[i]);
			}
		}
		for (; i < this.giftItem.length; i++) {
			this.giftItem.splice(i, 1)[0].dispose();
			i--;
		}
	}

	public setBuyPart(data) {
		this.giftPart.setData(data);
		this.giftPart.sureGift = 1;
		this.giftPart.limitGrp.visible = false;
		this.giftPart.contentGrp.visible = false;
		this.giftPart.setGiftLimit();
		this.giftPart.showHuijia(true);
		this.giftPart.showHuijian(true);
	}

	public changeLimit(id: number, left_times: number) {
		let shop = App.data.game2Center.DataCenter.Shop;
		let giftpcak = shop.giftpcak;
		let limitpack = shop.limitpack;

		for (let j = 0; j < giftpcak.length; j++) {
			if (id == giftpcak[j].id && giftpcak[j].is_limit) {
				App.data.game2Center.DataCenter.Shop.giftpcak[j].left_times = left_times;
				return;
			}
		}

		for (let j = 0; j < limitpack.length; j++) {
			if (id == limitpack[j].id && limitpack[j].is_limit) {
				App.data.game2Center.DataCenter.Shop.limitpack[j].left_times = left_times;
				return;
			}
		}
	}

	public dispose(): void {
		this.giftPart.dispose();
		if (this.giftItem) {
			for (var i: number = 0; i < this.giftItem.length; i++) {
				this.giftItem[i] && this.giftItem[i].dispose();
				this.giftItem[i] = undefined;
			}
		}
		App.dispatcher.removeEventListener(EventConst.UPDATE_LIBAO, this.updateSiwei, this);
		super.dispose();
	}
}