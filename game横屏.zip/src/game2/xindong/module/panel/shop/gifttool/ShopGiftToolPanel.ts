/**
 * 礼包 道具弹框
 * 2018/4/24
 * lidan
 */

class ShopGiftToolPanel extends BasePanel {
	private _view: ShopGiftToolPanelUI;
	private radioList;                   //单选按钮数组

	constructor() {
		super();
	}

	protected init(): void {
		this._view = new ShopGiftToolPanelUI();
		this.addChild(this._view);
		//初始化
		this.radioList = [this._view.radioBtn0, this._view.radioBtn1];

		this._view.shopToolPart.init();
		this._view.shopGiftPart.init();
		this.changeView();
	}

	private changeView() {
		if (DeviceUtil.isIPhoneX) {
			this._view.viewStack.left += 35;
			this._view.viewStack.scaleY = 0.9;
		}
	}

	public show(data?: any): void {
		super.show(data);
		//按钮监听
		CommomBtn.btnClick(this._view.backBtn, this.onCloseTouch, this);

		this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setCoinText(App.global.userInfo.xdCoin);

		this._dispatcher.addEventListener(eui.UIEvent.CHANGE, this.onPageChange, this, this._view.radioBtn0.group);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onDiamond, this, this._view.diamondGroup);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onGold, this, this._view.goldGroup);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCoin, this, this._view.coinGroup);
		this._dispatcher.addEventListener(EventConst.payBack, this.payback, this);
		this._dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.onUpdateSiwei, this);
		this._dispatcher.addEventListener(EventConst.UPDATE_SHOP_GIFT_GOLD, this.setGoldText, this);
		this._dispatcher.addEventListener(G2_GameSceneEvent.CHANGEBUYLIMIT, this.changeBuyLimit, this);
		this._dispatcher.addEventListener(G2_GameSceneEvent.SETBUYPART, this.setbuypart, this);
		this._dispatcher.addEventListener(G2_GameSceneEvent.SETGOLDTEXT, this.setGoldText, this);
		this._dispatcher.addEventListener(G2_GameSceneEvent.SETDIAMONDTEXT, this.setDiaMondText, this);
		this._dispatcher.addEventListener(EventType.UPDATE_COIN, this.updateCoin, this);

		if (data) {
			for (let i: number = 0; i < this._view.radioGrp.numChildren; i++) {
				let radioBtn: eui.RadioButton = this._view.radioGrp.getElementAt(i) as eui.RadioButton;
				if (i == data) {
					radioBtn.selected = true;
				} else {
					radioBtn.selected = false;
				}
			}
			this._view.viewStack.selectedIndex = 1;
		} else {
			for (let i: number = 0; i < this._view.radioGrp.numChildren; i++) {
				let radioBtn: eui.RadioButton = this._view.radioGrp.getElementAt(i) as eui.RadioButton;
				if (i == 0) {
					radioBtn.selected = true;
				} else {
					radioBtn.selected = false;
				}
			}
			this._view.viewStack.selectedIndex = 0;
		}

	}

	public hide(): void {
		super.hide();
		CommomBtn.removeClick(this._view.backBtn, this.onCloseTouch, this);
		App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
	}

	private setbuypart(data: any, type: number): void {
		if (type == 0) {
			this._view.shopToolPart.setBuyPart(data);
			this._view.coinGroup.visible = false;
			this._view.goldGroup.visible = true;
		} else {
			this._view.shopGiftPart.setBuyPart(data);
			this._view.coinGroup.visible = true;
			this._view.goldGroup.visible = false;
		}
	}

	private changeBuyLimit(id: any, left_times: number): void {
		this._view.shopToolPart.changeBuyLimit(id, left_times);
	}

	private onGold(e: egret.TouchEvent) {
		PanelOpenManager.openPanel(EnumPanelID.G2_ShopGoldPanel);
	}
	private onCoin(e: egret.TouchEvent) {
		PanelOpenManager.openPanel(EnumPanelID.G2_SHOP_COIN_PANEL, {type:1});
	}

	private onDiamond(e: egret.TouchEvent) {
		PanelOpenManager.openPanel(EnumPanelID.G2_ShopDiamondPanel, null, false);
	}

	/**点击单选按钮 切换页面 */
	private onPageChange(e: eui.UIEvent) {
		App.sound.playSoundSwitchClient1(SoundManager.button);
		let group: eui.RadioButtonGroup = e.target;
		GameLog.log(group.selectedValue);
		this.switchPage(group.selectedValue);
	}

	/**切换页面 */
	public switchPage(page) {
		//如果该页面存在，才会切换页面。否则切换到当前存在的第一页
		if (this.radioList[page].parent) {
			this._view.radioBtn0.group.selectedValue = page;
			this._view.viewStack.selectedIndex = page;
			this._view.coinGroup.visible = page == 1;
			this._view.goldGroup.visible = page == 0;
		} else {
			this.switchFirstPage();
		}
	}

	/**切换到第一页 某些任务在完成后会消失，所以需要判断谁在第一页*/
	private switchFirstPage() {
		this._view.validateNow();
		let len = this.radioList.length;
		for (let i = 0; i < len; i++) {
			if (this.radioList[i].parent) {
				this.switchPage(i);
				break;
			}
		}
	}

	private updateCoin(): void {
		this.setCoinText(App.global.userInfo.xdCoin);
	}

	/**支付返回 */
	private payback() {
		this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setCoinText(App.global.userInfo.xdCoin);
	}

	private onUpdateSiwei() {
		this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setCoinText(App.global.userInfo.xdCoin);
	}

	/**设置金币 */
	public setGoldText(str) {
		this._view.goldLabel.text = str + "";
	}

	/**设置砖石 */
	public setDiaMondText(str) {
		this._view.diamondLabel.text = str + "";
	}
	/**设置心动币 */
	public setCoinText(str) {
		this._view.coinGroup.setCoin(str);
	}

	/**关闭页面 */
	private onCloseTouch() {
		// this.hide();
		// var gamescene = App.SceneManager.getScene(SceneConst.GameScene) as GameScene;
		// gamescene.enterAnimation();
		this.closePanel();
	}

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

}