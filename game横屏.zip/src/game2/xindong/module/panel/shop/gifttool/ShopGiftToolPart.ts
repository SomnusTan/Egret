/**
 * 道具礼包购买部分
 * 2018/4/23
 * lidan
 */

class ShopGiftToolPart extends BaseUI {
	public giftImg: eui.Image;
	public limitGrp: eui.Group;
	public limitLabel: eui.Label;
	public maxcountLabel: eui.Label;
	public contentGrp: eui.Group;
	public titleLabel: eui.Label;
	public contentLabel: eui.Label;
	public xiangouGroup: eui.Group;
	public jianBtn: eui.Button;
	public jiaBtn: eui.Button;
	public countLabel: eui.Label;
	public nojianBtn: eui.Button;
	public nojiaBtn: eui.Button;
	public buyLabel: eui.Label;
	public buyButton: eui.Button;
	public buyedLabel: eui.Label;
	public payImage: eui.Image;
	public goldLabel: eui.BitmapLabel;

	public count = 1;
	public recData: any;

	public sureGift = 0;
	public sureTool = 0;

	private t: number;
	private order_id;
	private open_window;

	public constructor() {
		super("ShopGiftToolPartSkin");
	}

	public setData(data) {
		this.recData = data;
		this.count = 1;
		this.init();

		this.jiaBtn.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jiaBtnTouchBegin, this);
		this.jianBtn.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jianBtnTouchBegin, this);
		// this.bgImg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.bgTouch, this);
		App.stage.addEventListener(egret.TouchEvent.TOUCH_END, this.onStageTouchEnd, this);
		App.dispatcher.addEventListener(EventConst.UPDATE_LIBAO, this.updateSiwei, this);

		CommomBtn.btnClick(this.buyButton, this.okTouch, this, 1);
		CommomBtn.btnClick(this.jiaBtn, this.jiaTouch, this, 1);
		CommomBtn.btnClick(this.jianBtn, this.jianTouch, this, 1);
	}

	private updateSiwei(): void {
		let shop = App.data.game2Center.DataCenter.Shop;
		for (var i: number = 0; i < shop.limitpack.length; i++) {
			if (shop.limitpack[i].id == this.recData.id) {
				this.refreshData(shop.limitpack[i]);
				return;
			}
		}
		for (i = 0; i < shop.giftpcak.length; i++) {
			if (shop.giftpcak[i].id == this.recData.id) {
				this.refreshData(shop.giftpcak[i]);
				return;
			}
		}
		this.refreshData(shop.limitpack[0]);
	}

	public refreshData(data): void {
		this.setData(data);
		this.sureGift = 1;
		this.limitGrp.visible = false;
		this.contentGrp.visible = false;
		this.setGiftLimit();
		this.showHuijia(true);
		this.showHuijian(true);
	}

	/**设置数据 */
	public init() {
		this.showHuijia(false);
		this.showHuijian(true);
		this.setCountLabel(this.count);
		this.setTitleLabel(this.recData.cname);
		this.setGoldLabel(this.recData.coin_type == "rmb" ? this.recData.balance_money : this.recData.price);
		this.setGiftImg(this.recData.new_pic);

		if (this.recData.des) {
			this.setGiftTool(true);
			this.setContentLabel(this.recData.des, this.recData.quantity);
		} else {
			this.setGiftTool(false);
		}


		if (!this.recData.coin_type) {
			this.payImage.source = "main2_jinbi_png";
		} else if (this.recData.coin_type && this.recData.coin_type == "rmb") {
			// this.payImage.source = "shop2_renminbi_png";
			this.payImage.source = "charge_coin_big";
		} else if (this.recData.coin_type && this.recData.coin_type == "diamond") {
			this.payImage.source = "shop2_zhuanshi_png";
		}
	}

	//道具限制
	public setToolLimit() {
		if (this.recData.is_limit) {
			this.limitGrp.visible = true;
			this.setMaxCount(this.recData.left_times, this.recData.buy_times);

			if (this.count == this.recData.left_times || this.recData.left_times <= 1) {
				this.showHuijia(true);
			}

			if (this.recData.left_times <= 0) {
				this.buyButton.visible = false;
			} else {
				this.buyButton.visible = true;
			}
		} else {
			this.limitGrp.visible = false;
			this.buyButton.visible = true;
		}
		this.buyedLabel.visible = !this.buyButton.visible;
	}

	public setGiftLimit() {
		if (this.recData.is_limit) {
			if (this.count == this.recData.left_times || this.recData.left_times <= 1) {
				this.showHuijia(true);
			}

			if (this.recData.left_times <= 0) {
				this.buyButton.visible = false;
			} else {
				this.buyButton.visible = true;
			}

		} else {
			this.limitGrp.visible = false;
			this.buyButton.visible = true;
		}
		this.buyedLabel.visible = !this.buyButton.visible;
	}

	/**设置今日可购买 */
	public setBuyLimit(is_limit: boolean, buy_times: number, left_times: number) {
		if (is_limit) {
			this.limitLabel.text = "今日可购买:" + left_times + "/" + buy_times;
			this.limitGrp.visible = true;
		} else {
			this.limitLabel.text = "";
			this.limitGrp.visible = false;
		}
	}

	/**礼包 道具 
	 * 礼包不可见
	 * 道具可见
	*/
	public setGiftTool(vis: boolean) {
		if (vis == true) {
			this.contentGrp.visible = true;
			this.limitGrp.visible = true;
		} else if (vis == false) {
			this.contentGrp.visible = false;
			this.limitGrp.visible = false;
		}
	}

	/**从场景中移除*/
	public dispose() {
		this.open_window = null;
		this.jiaBtn.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jiaBtnTouchBegin, this);
		this.jianBtn.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jianBtnTouchBegin, this);
		// this.bgImg.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.bgTouch, this);
		App.stage.removeEventListener(egret.TouchEvent.TOUCH_END, this.onStageTouchEnd, this);
		App.dispatcher.removeEventListener(EventConst.UPDATE_LIBAO, this.updateSiwei, this);

		CommomBtn.removeClick(this.buyButton, this.okTouch, this);
		CommomBtn.removeClick(this.jiaBtn, this.jiaTouch, this);
		CommomBtn.removeClick(this.jianBtn, this.jianTouch, this);
		App.timer.clearTimer(this, this.onTimer);
		App.timer.clearTimer(this, this.sendGetEndOrder);
		super.dispose();
	}

	/**确定点击 */
	private okTouch() {
		if (this.recData && this.recData.id) {
			if (this.recData.coin_type) {
				this.sendGiftBuy();
			} else {
				let gid = this.recData.id;

				let data = ProtocolHttp.toolsBuy;
				data.gid = gid;
				data.count = this.count;
				ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.toolsBuy, data, new FunctionVO(this.buyBtnTouchBack, this));
				GameLog.log("BuyToolPanel >> 发送购买道具，购买个数:", this.count);
			}
		}
	}

	private buyGiftBack(): void {
		Notice.showBottomCenterMessage("购买成功");
		App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
	}

	private sendGiftBuy() {
		if (this.recData.coin_type == "rmb") {
			Game2PayUtil.pay(this.recData.id, this.recData.title, this.recData.balance_money, 1, new FunctionVO(this.buyGiftBack, this));
			return;
		}

		//TODO u8支付
		if (Config.U8Login && this.recData.coin_type == "rmb") {
			App.nativeBridge.sendU8PayOld("libao", this.recData);
			return;
		}

		//soEasy支付
		if (Config.soEasy && this.recData.coin_type == "rmb") {
			platform.payOrder(this.recData.id);
			return;
		}

		//Android支付,sdk自己下单         
		if (DeviceUtil.IsAndroid && DeviceUtil.IsNative && this.recData.coin_type == "rmb") {
			let packages = this.recData.package;
			let { price } = this.recData;
			let goodsDes = {
				name: packages[0]["cname"],
				price: price + "元",
				desc: "解锁" + packages[0]["cname"] + "功能,加送" + packages[1]["num"] + packages[1]["cname"]
			};
			App.nativeBridge.sendAndroidPay(this.recData.id, goodsDes);
		}
		else {
			let data: any = {};
			data = AddSomeMsgUtils.addSomeMsgByGiftBuy(data);
			data.gid = this.recData.id;
			let channel = window["channel"];
			if (channel) data["channel"] = channel;
			//新ios下单，增加渠道标识
			// if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
			// 	data["channel"] = IOSConfig.channel;
			// }
			//小米渠道
			if (MilletSDK.getInstance().millet) {
				data["channel"] = "xiaomi";
			}
			//vivo渠道
			if (H5_Vivo_SDK.getInstance().vivoData) {
				data["channel"] = "vivo";
			}
			//网页
			if (DeviceUtil.IsWeb) {
				//360渠道
				if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
					data["channel"] = "360";
				} else {
					data["channel"] = "web_alipay";
				}
				data.setting = DeviceUtil.currentSetting;
				if (this.recData.coin_type == "diamond" || Config.soEasy || H5_360_Sdk.getInstance().config360) {
					ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, data, new FunctionVO(this.buyBack, this));
				} else {
					data.price = this.recData.price;
					data.closeHandler = new FunctionVO(this.onChooseBack, this);
					Alert.choosePay(data);
					// if (Config.skipVideo) {
					// } else {
					// 	data.payType = EnumPayType.PAY_ALIPAY;
					// 	this.onChooseBack(data);
					// }
				}
			}
			else {
				ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, data, new FunctionVO(this.buyBack, this));
			}
		}
	}
    /**
     *  payType:支付类型 1：微信，2：支付宝
     */
	private onChooseBack(param: any): void {
		if (param.payType == EnumPayType.PAY_WECHAT && DeviceUtil.isMobile) { //手机端微信支付
			var url: string = WebParams.ip + ProtocolHttpUrlGame2.giftBuy + "?channel=weixin&gid=" + param.gid + "&setting=" + DeviceUtil.currentSetting +
				"&Authorization=" + App.data.game2Center.DataCenter.skey + "&AuthorizationID=" + App.global.userInfo.uid;
			this.open_window = window.open(url, "_blank");
			App.timer.doTimeOnce(this, 3000, this.sendGetEndOrder, [param.gid]);
		} else if (!Config.isRelease || param.payType == EnumPayType.PAY_ALIPAY || (!DeviceUtil.isMobile && param.payType == EnumPayType.PAY_WECHAT)) { //支付宝 || 微信web
			if (param.payType == EnumPayType.PAY_ALIPAY)
				this.open_window = WebParams.openWindow(WebParams.defaultURL);
			param.closeHandler = "";
			if (param.payType == EnumPayType.PAY_WECHAT) {
				param.channel = "weixin";
			}
			ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, param, new FunctionVO(this.buyBack, this, param.payType));
		}
	}

	private sendGetEndOrder(gid): void {
		App.timer.clearTimer(this, this.sendGetEndOrder);
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.shop_end_order, { good_id: gid }, new FunctionVO(this.checkOrder, this));
	}

	private checkOrder(data): void {
		if (data.code == 200) {
			this.order_id = data.data;
			this.getBuy();
		}
	}

	/**购买砖石返回 */
	private buyBack(data, type?: number) {
		if (data.code == 200) {
			this.count = 1;
			this.setCountLabel(this.count);
			this.setGoldLabel(this.recData.price);

			if (DeviceUtil.IsWeb && this.recData.coin_type == "rmb") {
				this.order_id = data.data.order_id;
				if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
					H5_360_Sdk.getInstance().pay360Param = data.data.params;
					H5_360_Sdk.getInstance().order_id = data.data.order_id;
					H5_360_Sdk.getInstance().paySdk();
					GameLog.log("360支付订单号" + this.order_id);
				} else {
					if (type == EnumPayType.PAY_WECHAT) {
						data.data.payType = type;
						PanelOpenManager.openPanel(EnumPanelID.WECHAT_QRCODE, data.data);
					} else if (type == EnumPayType.PAY_ALIPAY) {
						let url = data.data.aliparams;
						let url0 = App.data.game2Center.DataCenter.setSelect(url);
						WebParams.openWindow("/shop/web/switch/?url=" + url0, this.open_window);
					}
				}
				this.getBuy();
				return;
			}
			else if (DeviceUtil.IsNative && DeviceUtil.IsIos && this.recData.coin_type == "rmb") {
				App.nativeBridge.sendIOSPay(data.data.order_id, data.data.product_id);
			}
			else if (this.recData.coin_type == "rmb") {
				App.nativeBridge.sendPay(data);
			}
			else if (this.recData.coin_type == "diamond") {
				Notice.showBottomCenterMessage("购买成功")
				App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
				App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
				App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
				App.data.game2Center.DataCenter.UserInfo.power = data.data.power;

				let gold = App.data.game2Center.DataCenter.UserInfo.gold + "";
				let diamond = App.data.game2Center.DataCenter.UserInfo.diamond + "";
				App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETGOLDTEXT, gold);
				App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETDIAMONDTEXT, diamond);

				//更新四维
				App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);

				//购买成功，更新背包数据
				App.dispatcher.dispatchEvent(EventConst.REQ_UPDATE_BAGS);

				if (this.recData.left_times) {
					this.recData.left_times = data.data.left_times;
					App.dispatcher.dispatchEvent(G2_GameSceneEvent.CHANGEBUYLIMIT, this.recData.id, this.recData.left_times);
					if (this.recData.left_times <= 0) {
						this.buyButton.visible = false;
					}
				}
				this.buyedLabel.visible = !this.buyButton.visible;
			}

		} else if (data.code == 981) {
			App.nativeBridge.sendPay(data);
		} else if (data.code == 817) {
			Notice.showBottomCenterMessage(data.info);
		} else {
			//Notice.showBottomCenterMessage("" + data.info);
			//钻石不足，提示去购买钻石
			Alert.show2("钻石数量不足，是否充值钻石？", "", new FunctionVO((data: any) => {
				if (data.type == Alert.OK) {
					PanelOpenManager.openPanel(EnumPanelID.G2_ShopDiamondPanel, {price:this.recData.price}, false);
				}
			}, this));
		}
	}

	/**购买返回 */
	private buyBtnTouchBack(data) {
		GameLog.log("tool", data);
		if (data.code == 200) {
			this.count = 1;
			this.setCountLabel(this.count);
			this.setGoldLabel(this.recData.price);


			App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
			App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
			App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
			App.data.game2Center.DataCenter.UserInfo.power = data.data.power;

			let gold = App.data.game2Center.DataCenter.UserInfo.gold + "";
			let diamond = App.data.game2Center.DataCenter.UserInfo.diamond + "";
			App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETGOLDTEXT, gold);
			App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETDIAMONDTEXT, diamond);

			//更新限购次数
			GameLog.log("BuyToolPanel >> 购买返回，剩余限购次数:", data.data.left_times);
			let leftTimes = { "id": this.recData.id, "left_times": data.data.left_times };
			App.dispatcher.dispatchEvent(EventConst.UPDATE_LEFT_TIMES, leftTimes);

			//更新四维
			App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);

			if (this.recData.left_times) {
				this.showXiangouGroup(true);
				this.recData.left_times = data.data.left_times;
				this.setMaxCount(this.recData.left_times, this.recData.buy_times);

				if (this.recData.left_times <= 0) {
					this.buyButton.visible = false;
				} else {
					this.buyButton.visible = true;
				}

				//礼包
				if (this.sureGift == 1 && this.sureTool == 0) {
				} else if (this.sureGift == 0 && this.sureTool == 1) {  //道具
					App.dispatcher.dispatchEvent(G2_GameSceneEvent.CHANGEBUYLIMIT, this.recData.id, this.recData.left_times);
				}
			} else {
				this.buyButton.visible = true;
			}
			this.buyedLabel.visible = !this.buyButton.visible;

			Notice.showBottomCenterMessage("购买成功");
			App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETGOLDTEXT, gold);
			App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETDIAMONDTEXT, diamond);

			//请求更新背包数据
			App.dispatcher.dispatchEvent(EventConst.REQ_UPDATE_BAGS);
		} else {
			Notice.showBottomCenterMessage("" + data.info);
		}
	}

	//因为数据中心和Item绑定的数据不一致，临时加个方法，来修改限购次数
	public setXiangou(left_times) {
		if (this.recData.is_limit) {
			this.showXiangouGroup(true);
			this.recData.left_times = left_times;
			this.setMaxCount(this.recData.left_times, this.recData.buy_times);
		}
	}


	/**取消点击 */
	private canelTouch() {
		this.close();
	}

	/**加点击 */
	private jiaTouch() {
		//判断当前金币数是否足够
		if (this.recData.price * (this.count + 1) > App.data.game2Center.DataCenter.UserInfo.gold) {
			this.showHuijia(true);
			return;
		}


		this.count += 1;
		this.showHuijian(false);
		if (this.recData.is_limit) {
			if (this.count >= this.recData.left_times) {
				this.showHuijia(true);
				this.count = this.recData.left_times;
			} else {
				this.showHuijia(false);
			}
			this.setCountLabel(this.count);
			this.setGoldLabel(this.recData.price * this.count);

			if (this.count == this.recData.left_times) {
				this.showHuijia(true);
			}

		} else {
			this.setCountLabel(this.count);
			this.setGoldLabel(this.recData.price * this.count);
		}
	}

	/**减点击 */
	private jianTouch() {
		this.showHuijia(false);
		if (this.count > 1) {
			this.count -= 1;
			if (this.count == 1) {
				this.showHuijian(true);
			} else {
				this.showHuijian(false);
			}
		} else {
			this.count = 1;
			this.showHuijian(true);
		}

		this.setCountLabel(this.count);
		this.setGoldLabel(this.recData.price * this.count);
	}

	/**加点击开始 */
	private jiaBtnTouchBegin() {
		egret.Tween.get(this.jiaBtn, { loop: true }).wait(250).call(() => {
			this.jiaTouch();
		}, this);
	}

	/**减点击开始 */
	private jianBtnTouchBegin() {
		egret.Tween.get(this.jianBtn, { loop: true }).wait(250).call(() => {
			this.jianTouch();
		}, this);
	}

	/**点击加或减结束 */
	private onStageTouchEnd() {
		egret.Tween.removeTweens(this.jiaBtn);
		egret.Tween.removeTweens(this.jianBtn);
	}

	/**背景点击 */
	private bgTouch() {
		this.close();
	}

	/**礼物图片设置 */
	private setGiftImg(url) {
		if (url && url != "") {
			this.giftImg.source = url;
		}
	}

	/**设置金币 */
	private setGoldLabel(str) {
		if (str != null) {
			this.goldLabel.text = str;
		}
	}

	/**内容设置 */
	private setContentLabel(str, quantity) {
		if (str != "") {
			if (quantity == 0) {
				this.contentLabel.text = str;
			} else {
				this.contentLabel.textFlow = <Array<egret.ITextElement>>[
					{ text: "送给女生可获得", style: { "textColor": 0xB2B4B3 } },
					{ text: quantity + "", style: { "textColor": 0xF48664 } },
					{ text: "亲密度", style: { "textColor": 0xB2B4B3 } }
				]
			}
		}
	}

	/**标题设置 */
	private setTitleLabel(str) {
		if (str != "") {
			this.titleLabel.text = str;
		}
	}

	/**设置购买数量 */
	private setCountLabel(num) {
		if (num != "") {
			this.countLabel.text = num;
		}
	}

	/**显示限购 */
	private showXiangouGroup(bo: boolean) {
		if (bo) {
			this.xiangouGroup.visible = true;
		} else {
			this.xiangouGroup.visible = false;
		}

	}

	/**设置最大购买次数 */
	private setMaxCount(left, max) {
		if (max && max != "") {
			this.maxcountLabel.text = left + "/" + max;
		}
	}

	/**显示加灰色 */
	public showHuijia(bo: boolean) {
		if (bo) {
			this.nojiaBtn.visible = true;
		} else {
			this.nojiaBtn.visible = false;
		}

	}

	/**显示减灰色 */
	public showHuijian(bo: boolean) {
		if (bo) {
			this.nojianBtn.visible = true;
		} else {
			this.nojianBtn.visible = false;
		}
	}

	/**关闭 */
	private close() {
		// this.hide();
		this.count = 1;
	}

	//获得购买的状态
	private getBuy() {
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.payBack, this));
	}

	private payBack(data: any): void {
		if (data.code == 200) {
			Notice.showBottomCenterMessage("支付成功");
			App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
			App.data.game2Center.LoadingLock.unlock();
			PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
		} else {
			this.t = 0;
			this._needSendBuy = true;
			App.timer.clearTimer(this, this.onTimer);
			App.timer.doTimeLoop(this, 3000, this.onTimer);
		}
	}
	private _needSendBuy: boolean;//请求是否支付成功

	private onTimer(): void {
		this.t += 3;
		if (this.t >= 600) {
			GameLog.log("-------------10分钟内支付失败");
			App.timer.clearTimer(this, this.onTimer);
			return;
		}
		if (this._needSendBuy) {
			this._needSendBuy = false;
			ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.onPaySuccess, this, true));
		}
	}

	private onPaySuccess(data: any): void {
		if (data.code == 200) {
			Notice.showBottomCenterMessage("支付成功");
			App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
			App.timer.clearTimer(this, this.onTimer);
			App.data.game2Center.LoadingLock.unlock();
			PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
		} else {
			GameLog.log("-------------未支付，继续检测----------");
			this._needSendBuy = true;
		}
	}
}