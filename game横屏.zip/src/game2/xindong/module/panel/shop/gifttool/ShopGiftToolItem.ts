/**
 * 礼包 工具item
 * lidan
 * 2018/4/23
 */
class ShopGiftToolItem extends BaseView {
	public limitGrp: eui.Group;
	private limitLabel: eui.Label;
	private nameLabel: eui.Label;
	private contentLabel: eui.Label;
	private goldLabel: eui.BitmapLabel;
	private goldImage: eui.Image;
	private daojuImg: eui.Image;

	private nameGrp: eui.Group;

	private zhuanshiImg: eui.Image;
	private renminbiImg: eui.Image;

	public type: number = -1; //0代表道具 1代表礼包

	private recData: any;
	public constructor() {
		super("ShopGiftToolItemSkin");
	}

	/**添加到场景中*/
	public show(data?: any): void {
		super.show(data);
		//this.daojuImg.mask = this.maskImg;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.buyBtnTouch, this, this);
	}

	public setInfo(data) {
	}

	public setImgPlace(str: string) {
		if (str == "tool") {
			this.daojuImg.x = 2;
		} else if (str == "gift") {
			this.daojuImg.x = 0;
		}
	}

	public setData(data) {
		this.recData = data;
		this.setImg(this.recData.new_pic);
		if (this.recData.coin_type == "rmb")
			this.setGold(this.recData.balance_money);
		else
			this.setGold(this.recData.price);
	}

	/**中文名 */
	public setCName(str) {
		if (str && str != "") {
			this.nameLabel.text = str;
		}
	}

	/**道具图片 */
	public setImg(url) {
		if (url && url != "") {
			this.daojuImg.source = url;
		}
	}

	/**描述 */
	public setMiaoShu(des, quantity) {
		if (quantity == 0) {
			this.contentLabel.text = des;
		} else {
			this.contentLabel.textFlow = <Array<egret.ITextElement>>[
				{ text: "送给女生可获得", style: { "textColor": 0xB2B4B3 } },
				{ text: quantity + "", style: { "textColor": 0xF48664 } },
				{ text: "亲密度", style: { "textColor": 0xB2B4B3 } }
			]
		}
	}

	/**设置金币 */
	public setGold(str) {
		if (str && str != "") {
			this.goldLabel.text = str;
		}
	}

	/**设置今日可购买 */
	public setBuyLimit(is_limit: boolean, buy_times: number, left_times: number) {
		if (is_limit) {
			this.limitLabel.text = "今日可购买:" + left_times + "/" + buy_times;
			this.limitGrp.visible = true;
		} else {
			this.limitLabel.text = "";
			this.limitGrp.visible = false;
		}
	}

	/**购买按钮点击 */
	private buyBtnTouch(e: egret.TouchEvent) {
		App.sound.playSoundSwitchClient1(SoundManager.button);
		App.dispatcher.dispatchEvent(G2_GameSceneEvent.SETBUYPART, this.recData, this.type);
	}

	//礼包隐藏，道具显示
	public setVisible(vis: boolean) {
		if (vis == true) {
			this.limitGrp.visible = true;
			this.nameGrp.visible = true;
			this.zhuanshiImg.visible = false;
			this.renminbiImg.visible = false;
		} else if (vis == false) {
			this.nameGrp.visible = false;
			this.goldImage.visible = false;
			if (this.recData.coin_type == "rmb") {
				this.showtype(2);
			}
			if (this.recData.coin_type == "diamond") {
				this.showtype(1);
			}
		}
	}

	/**显示购买类型 */
	public showtype(num) {
		switch (num) {
			case 1:
				this.zhuanshiImg.visible = true;
				this.renminbiImg.visible = false;
				break;
			case 2:
				this.zhuanshiImg.visible = false;
				this.renminbiImg.visible = true;
				break;
		}
	}
}