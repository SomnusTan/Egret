/**
 * 道具购买 整体部分
 * lidan
 * 2018/4/23
 */

class ShopToolPart extends BaseUI {
	private toolPart: ShopGiftToolPart;
	private toolGrp: eui.Group;
	public toolsItem: ShopGiftToolItem[];
	private toolScroller: eui.Scroller;
	public constructor() {
		super("ShopToolPartSkin");
	}

	public init() {
		let shop = App.data.game2Center.DataCenter.Shop;
		let tools = shop.tools;
		this.toolGrp.removeChildren();

		this.setBuyPart(tools[0]);
		if (this.toolScroller.viewport)
			this.toolScroller.viewport.scrollV = 0;

		this.toolsItem = [];

		for (let i: number = 0; i < tools.length; i++) {
			this.toolsItem[i] = new ShopGiftToolItem();
			// this.toolsItem[i].skinName = "ShopToolItemSkin";
			this.toolsItem[i].setImgPlace("tool");
			this.toolsItem[i].type = 0;
			this.toolsItem[i].setData(tools[i]);
			this.toolsItem[i].setImg(tools[i].new_pic);
			this.toolsItem[i].setGold(tools[i].price);
			this.toolsItem[i].setVisible(true);
			this.toolsItem[i].setCName(tools[i].cname);
			this.toolsItem[i].setMiaoShu(tools[i].des, tools[i].quantity);
			this.toolsItem[i].setBuyLimit(tools[i].is_limit, tools[i].buy_times, tools[i].left_times);

			this.toolGrp.addChild(this.toolsItem[i]);
		}
	}

	public setBuyPart(data) {
		this.toolPart.setData(data);
		this.toolPart.sureTool = 1;
		this.toolPart.setToolLimit();
	}

	//限购后，页面显示文字的变化
	public changeBuyLimit(id: any, left_times: number) {
		let i: number = 0;
		let shop = App.data.game2Center.DataCenter.Shop;
		let tools = shop.tools;
		for (i = 0; i < tools.length; i++) {
			if (id == tools[i].id) {
				App.data.game2Center.DataCenter.Shop.tools[i].left_times = left_times;
				tools[i].left_times = left_times;
				this.toolsItem[i].setBuyLimit(tools[i].is_limit, tools[i].buy_times, tools[i].left_times);
				break;
			}
		}
	}

	public dispose(): void {
		this.toolPart.dispose();
		if (this.toolsItem) {
			for (var i: number = 0; i < this.toolsItem.length; i++) {
				this.toolsItem[i] && this.toolsItem[i].dispose();
				this.toolsItem[i] = undefined;
			}
		}
		super.dispose();
	}

}