/**
 * 神秘商店
 * 
 * @author syy
 * @deta 2018/4/17
 */
class MysteriousShop extends BasePanel {
    private _view: MysteriousShopUI;
    private _shopItems: MysteriousShopItem[];

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new MysteriousShopUI();
        this.addChild(this._view);

        this._view.showListGrp.removeChildren();
        this._shopItems = [];
    }

    /**添加到场景中*/
    public show(data?: any) {
        super.show(data);

        CommomBtn.btnClick(this._view.closeBtn, this.onRemoveSmshop, this);
        CommomBtn.btnClick(this._view.gotoShop, this.onGotoShop, this);

        this._dispatcher.addEventListener(G2_GameSceneEvent.BUY_SHENMISHOP, this.sendUserSGB, this)
        this.sendSpecialGoods();
    }

    private onRemoveSmshop(e: TouchEvent): void {
        PanelOpenManager.removePanel(EnumPanelID.G2_MysteriousShop);
    }

    private onGotoShop(e: TouchEvent): void {
        this.sendUserSGR();
    }
    /**购买商品 */
    private sendUserSGB(data: any): void {
        let param = { gid: data.id, index: data.index };
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userSGB, param, new FunctionVO((data) => {
            if (data.code == 200) {
                App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                this.sendSpecialGoods();
                Notice.showBottomCenterMessage("购买成功");
            } else {
                Notice.showBottomCenterMessage("" + data.info);
            }
        }, this));
    }

    private sendUserSGR(): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userSGR, {}, new FunctionVO((data) => {
            if (data.code == 200) {
                App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                //更新列表
                this.sendSpecialGoods();
                Notice.showBottomCenterMessage("刷新成功");
            } else {
                Notice.showBottomCenterMessage(data.info + "");
            }
        }, this));
    }

    private sendSpecialGoods(): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userSpecialGoods, {}, new FunctionVO(this.initShow, this));
    }

    private initShow(data: any): void {
        if (data.code == 200) {
            PanelOpenManager.removePanel(EnumPanelID.G2_DlcMainDoc);
            App.data.game2Center.DataCenter.smShopData = data.data;
            let datas: any = App.data.game2Center.DataCenter.smShopData;
            // this.refresh_time.text = datas.refresh_time;
            //刷新
            if (datas.refresh_type == "diamond") {
                //钻石
                this._view.iconImg.source = "shop2_zhuanshi_png";
            } else {
                this._view.iconImg.source = "main2_jinbi_png";
            }
            this._view.refresh_text.text = datas.refresh_cons + "";
            //
            var len: number = datas.goods.length;
            let item: MysteriousShopItem;
            for (let i = 0; i < len; i++) {
                if (i < this._shopItems.length) {
                    item = this._shopItems[i];
                } else {
                    item = new MysteriousShopItem();
                    this._view.showListGrp.addChild(item);
                    this._shopItems.push(item);
                }
                item.show(datas.goods[i]);
            }
        } else {
            Notice.showBottomCenterMessage(data.info + "");
        }
    }

    public hide(): void {
        super.hide();
        CommomBtn.btnClick(this._view.closeBtn, this.onRemoveSmshop, this);
        CommomBtn.btnClick(this._view.gotoShop, this.onGotoShop, this);
        for (var i: number = 0; i < this._shopItems.length; i++) {
            this._shopItems[i].hide();
        }
    }

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

    public dispose(): void {
        for(var i: number = 0; i < this._shopItems.length; i++) {
            if(this._shopItems[i]) {
                this._shopItems[i].dispose();
                this._shopItems[i] = undefined;
            }
        }
        this._shopItems = undefined;
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }
    

}