/**
 * 使用道具面板
 * @author xiongjian 
 * @date 2017-9-22
 */
class BuyToolPanel extends BasePanel {
    public recData: any;
    private count = 1;

    private _view: buyToolPanelUI;

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new buyToolPanelUI();
        this.addChild(this._view);
    
        this.showHuijia(false);
        this.showHuijian(true);
        this.setCountLabel(this.count);
        this.setContentLabel(this.recData.des);
        this.setTitleLabel(this.recData.cname);
        this.setGoldLabel(this.recData.price);
        this.setGiftImg(this.recData.pic);
        if (this.recData.is_limit) {
            this.showXiangouGroup(true);
            this.setMaxCount(this.recData.left_times, this.recData.buy_times);
        } else {
            this.showXiangouGroup(false);
        }
    }

    public show(data?: any): void {
        super.show(data);
        this.recData = data;
        this.count = 1;

        this._view.jiaBtn.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jiaBtnTouchBegin, this);
        this._view.jianBtn.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.jianBtnTouchBegin, this);
        App.stage.addEventListener(egret.TouchEvent.TOUCH_END, this.onStageTouchEnd, this);
        App.dispatcher.addEventListener(EventConst.UPDATE_LIMIT_NUM, this.setXiangou, this);

        CommomBtn.btnClick(this._view.okBtn, this.okTouch, this, 1);
        CommomBtn.btnClick(this._view.canelBtn, this.canelTouch, this, 1);
        CommomBtn.btnClick(this._view.jiaBtn, this.jiaTouch, this, 1);
        CommomBtn.btnClick(this._view.jianBtn, this.jianTouch, this, 1);
    }

    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.okBtn, this.okTouch, this);
        CommomBtn.removeClick(this._view.canelBtn, this.canelTouch, this);
        CommomBtn.removeClick(this._view.jiaBtn, this.jiaTouch, this);
        CommomBtn.removeClick(this._view.jianBtn, this.jianTouch, this);
    }

    /**确定点击 */
    private okTouch() {
        if (this.recData && this.recData.id) {
            let gid = this.recData.id

            let data = ProtocolHttp.toolsBuy;
            data.gid = gid;
            data.count = this.count;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.toolsBuy, data, new FunctionVO(this.buyBtnTouchBack, this));
            GameLog.log("BuyToolPanel >> 发送购买道具，购买个数:", this.count);
        }
    }

    /**购买返回 */
    private buyBtnTouchBack(data) {
        GameLog.log("tool", data);
        if (data.code == 200) {

            App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
            App.data.game2Center.DataCenter.UserInfo.power = data.data.power;

            //更新限购次数
            GameLog.log("BuyToolPanel >> 购买返回，剩余限购次数:", data.data.left_times);
            let leftTimes = { "id": this.recData.id, "left_times": data.data.left_times };
            App.dispatcher.dispatchEvent(EventConst.UPDATE_LEFT_TIMES, leftTimes);

            //更新四维
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);

            GameLog.log("=======", this.recData);
            if (this.recData.is_limit) {
                this.showXiangouGroup(true);
                this.recData.left_times = data.data.left_times;
                this.setMaxCount(this.recData.left_times, this.recData.buy_times);
            }

            Notice.showBottomCenterMessage("购买成功");
            // let panel:ShopPanel = App.data.game2Center.PanelManager.getPanel(EnumPanelID.G2_ShopPanel);
            // panel.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SHOP_GOLD, App.data.game2Center.DataCenter.UserInfo.gold);
            this.close();

            //请求更新背包数据
            App.dispatcher.dispatchEvent(EventConst.REQ_UPDATE_BAGS);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**
     * 因为数据中心和Item绑定的数据不一致，临时加个方法，来修改限购次数
     */
    private setXiangou(left_times) {
        if (this.recData.is_limit) {
            this.showXiangouGroup(true);
            this.recData.left_times = left_times;
            this.setMaxCount(this.recData.left_times, this.recData.buy_times);
        }
    }

    /**取消点击 */
    private canelTouch() {
        this.close();
    }

    /**加点击 */
    private jiaTouch() {
        //判断当前金币数是否足够
        if (this.recData.price * (this.count + 1) > App.data.game2Center.DataCenter.UserInfo.gold) {
            this.showHuijia(true);
            return;
        }


        this.count += 1;
        this.showHuijian(false);
        if (this.recData.is_limit) {
            if (this.count >= this.recData.left_times) {
                this.showHuijia(true);
                this.count = this.recData.left_times;
            } else {
                this.showHuijia(false);
            }
            this.setCountLabel(this.count);
            this.setGoldLabel(this.recData.price * this.count);
        } else {
            this.setCountLabel(this.count);
            this.setGoldLabel(this.recData.price * this.count);
        }
    }

    /**减点击 */
    private jianTouch() {
        this.showHuijia(false);
        if (this.count > 1) {
            this.count -= 1;
            if (this.count == 1) {
                this.showHuijian(true);
            } else {
                this.showHuijian(false);
            }
        } else {
            this.count = 1;
            this.showHuijian(true);
        }
        this.setCountLabel(this.count);
        this.setGoldLabel(this.recData.price * this.count);
    }

    /**加点击开始 */
    private jiaBtnTouchBegin() {
        egret.Tween.get(this._view.jiaBtn, { loop: true }).wait(250).call(() => {
            this.jiaTouch();
        }, this);
    }

    /**减点击开始 */
    private jianBtnTouchBegin() {
        egret.Tween.get(this._view.jianBtn, { loop: true }).wait(250).call(() => {
            this.jianTouch();
        }, this);
    }

    /**点击加或减结束 */
    private onStageTouchEnd() {
        egret.Tween.removeTweens(this._view.jiaBtn);
        egret.Tween.removeTweens(this._view.jianBtn);
    }

    /**礼物图片设置 */
    private setGiftImg(url) {
        if (url && url != "") {
            this._view.giftImg.source = url;
        }
    }

    /**设置金币 */
    private setGoldLabel(str) {
        if (str != null) {
            this._view.goldLabel.text = str;
        }
    }

    /**内容设置 */
    private setContentLabel(str) {
        if (str != "") {
            this._view.contentLabel.text = str;
        }
    }

    /**标题设置 */
    private setTitleLabel(str) {
        if (str != "") {
            this._view.titleLabel.text = str;
        }
    }

    /**设置购买数量 */
    private setCountLabel(num) {
        if (num != "") {
            this._view.countLabel.text = num;
        }
    }

    /**显示限购 */
    private showXiangouGroup(bo: boolean) {
        if (bo) {
            this._view.xiangouGroup.visible = true;
        } else {
            this._view.xiangouGroup.visible = false;
        }

    }

    /**设置最大购买次数 */
    private setMaxCount(left, max) {
        if (max && max != "") {
            this._view.maxcountLabel.text = left + "/" + max;
        }
    }

    /**显示加灰色 */
    private showHuijia(bo: boolean) {
        if (bo) {
            this._view.nojiaBtn.visible = true;
        } else {
            this._view.nojiaBtn.visible = false;
        }

    }

    /**显示减灰色 */
    private showHuijian(bo: boolean) {
        if (bo) {
            this._view.nojianBtn.visible = true;
        } else {
            this._view.nojianBtn.visible = false;
        }
    }

    /**关闭 */
    private close() {
        this.closePanel();
        this.count = 1;
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }
    

}