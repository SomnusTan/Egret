/**
 *电话呼叫中面板
 * @author xiongjian
 * @date 2017/08/24
 */
class ShopPanel extends BasePanel {
    private _view: ShopUI;

    private goldListData: any[] = [];
    private diamondsListData: any[] = [];
    private giftpcakListData: any[] = [];
    private xiangouListData: any[] = [];
    private limitListData: any[] = [];

    public isBack = false;
    public select = 0;

    private _items: BaseView[];

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new ShopUI();
        this.addChild(this._view);

        let shop = App.data.game2Center.DataCenter.Shop;
        let tools = shop.tools;
        this.goldListData = shop.golds;
        this.diamondsListData = shop.diamonds;
        this.giftpcakListData = shop.giftpcak;
        this.limitListData = shop.limitpack;

        this._items = [];
        //添加道具
        for (let i = 0; i < tools.length; i++) {
            let item = new DaojuListItem();
            //item.x = (366 + 48) * i + 48;
            //item.y = 20;
            // item.x = 366 * (i % 3) + 48;
            // item.y = 10 + Math.floor(i / 2) * 215;
            item.setData(tools[i]);
            item.setImg(tools[i].pic);
            item.setGold(tools[i].price);
            item.setEName(tools[i].ename);
            item.setCName(tools[i].cname);
            item.setMiaoShu(tools[i].des, tools[i].quantity);
            item.setBuyLimit(tools[i].is_limit, tools[i].buy_times, tools[i].left_times);
            // this._view.daojuGroup.addChild(item);
            (this._view.shopViewStack.getChildAt(4) as eui.Group).addChild(item);
            this._items.push(item);
        }

        /**金币道具 */
        for (let i = 0; i < this.goldListData.length; i++) {
            let item = new ShopGoldListItem();
            item.updateCallBack = new FunctionVO(this.updateCallBack, this);
            item.setData(this.goldListData[i]);
            //item.x = (366 + 48) * i + 48;
            //item.y = 20;
            // this._view.goldGroup.addChild(item);
            (this._view.shopViewStack.getChildAt(3) as eui.Group).addChild(item);
            this._items.push(item);
        }
        /**砖石道具 */
        for (let i = 0; i < this.diamondsListData.length; i++) {
            let item = new ShopDiamondsListItem();
            item.updateCallBack = new FunctionVO(this.updateCallBack, this);
            item.setData(this.diamondsListData[i]);
            item.setFirstPay(this.diamondsListData[i].first_pay);
            item.x = (366 + 48) * i + 48;
            item.y = 20;
            // this._view.zhuanshiGroup.addChild(item);
            (this._view.shopViewStack.getChildAt(2) as eui.Group).addChild(item);
            this._items.push(item);
        }
        /**限购礼包道具 */
        for (let i = 0; i < this.limitListData.length; i++) {
            let item = new ShopXiangouListItem();
            item.updateCallBack = new FunctionVO(this.updateCallBack, this);
            item.setData(this.limitListData[i]);
            item.x = (366 + 48) * i + 48;
            item.y = 20;
            // this._view.xiangouGroup.addChild(item);
            (this._view.shopViewStack.getChildAt(0) as eui.Group).addChild(item);
            this._items.push(item);
        }
        /**礼包道具 */
        for (let i = 0; i < this.giftpcakListData.length; i++) {
            let item = new ShopXiangouListItem();
            item.updateCallBack = new FunctionVO(this.updateCallBack, this);
            item.setData(this.giftpcakListData[i]);
            item.x = (366 + 48) * i + 48;
            item.y = 20;
            // this._view.chaozhiGroup.addChild(item);
            (this._view.shopViewStack.getChildAt(1) as eui.Group).addChild(item);
            this._items.push(item);
        }

        this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
        this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    public show(data?: any): void {
        super.show(data);
        if (data != null) {
            this.select = data;
            this._view.shopViewStack.selectedIndex = this.select;
            this.setRadioBtn(this.select);
        }

        this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
        this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);

        this._view.xiangouScroller.viewport.scrollH = 0;
        this._view.chaozhiScroller.viewport.scrollH = 0;
        this._view.zhuanshiScroller.viewport.scrollH = 0;
        this._view.goldScroller.viewport.scrollH = 0;
        this._view.daojuScroller.viewport.scrollH = 0;

        this._dispatcher.addEventListener(eui.UIEvent.CHANGE, this.changeViewStack, this, this._view.xiangouRadioBtn.group);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.goldGroup1Touch, this, this._view.goldGroup1);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.diamondGroup1Touch, this, this._view.diamondGroup1);
        CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);

        this._dispatcher.addEventListener(EventConst.payBack, this.payback, this);

        this._dispatcher.addEventListener(EventConst.UPDATE_FIRST_PAY, this.onUpdateFirstPay, this);
        this._dispatcher.addEventListener(EventConst.UPDATE_LEFT_TIMES, this.onUpdateLeftTimes, this);
        this._dispatcher.addEventListener(EventConst.TURN_DIAMOND_PAGE, this.onTurnDiamondPage, this);
        this._dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.onUpdateSiwei, this);
        this._dispatcher.addEventListener(EventConst.UPDATE_SHOP_GOLD, this.setGoldText, this);
        for (var i: number = 0; i < this._items.length; i++) {
            this._items[i] && this._items[i].show();
        }
    }

    public hide(): void {
        super.hide();
        if (this._items) {
            for (var i: number = 0; i < this._items.length; i++) {
                this._items[i] && this._items[i].hide();
            }
        }
        CommomBtn.removeClick(this._view.backBtn, this.close, this);
    }

    private onUpdateSiwei() {
        this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
        this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    //更新商城道具(修改限购次数)
    private onUpdateLeftTimes(data) {
        let id = data.id;
        let left_times = data.left_times;
        var len = this._view.daojuGroup.numChildren;
        for (var i = 0; i < len; i++) {
            var item: DaojuListItem = this._view.daojuGroup.getChildAt(i) as DaojuListItem;
            if (item.recData.id == id && item.recData.is_limit) {
                item.recData.left_times = left_times;
                item.setBuyLimit(true, item.recData.buy_times, item.recData.left_times);
            }
        }
    }

    //跳转到购买钻石页面
    private onTurnDiamondPage() {
        this._view.shopViewStack.selectedIndex = 2;
        this.setRadioBtn(2);
    }

    //购买钻石道具成功，设置首次双倍显示
    private onUpdateFirstPay() {
        let diamondList = App.data.game2Center.DataCenter.Shop.diamonds;
        let dLen = diamondList.length;
        let len = this._view.zhuanshiGroup.numChildren;
        for (let i = 0; i < len; i++) {
            let item: ShopDiamondsListItem = this._view.zhuanshiGroup.getChildAt(i) as ShopDiamondsListItem;
            for (let j = 0; j < dLen; j++) {
                let diamonds = diamondList[j];
                if (item.transData.id == diamonds.id) {
                    item.setFirstPay(diamonds.first_pay);
                }
            }
        }
    }

    private updateCallBack(): void {
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
        this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
        this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
    }

    /**切换ViewStark */
    private changeViewStack(e: eui.UIEvent) {
        var group: eui.RadioButtonGroup = e.target;
        this._view.shopViewStack.selectedIndex = group.selectedValue;
        GameLog.log("g", group.selectedValue, "viewstack" + this._view.shopViewStack.selectedIndex);
        App.sound.playSoundSwitchClient1(SoundManager.page_switch);
    }

    /**设置金币 */
    public setGoldText(str) {
        this._view.goldLabel.text = str + "";
    }

    /**设置砖石 */
    public setDiaMondText(str) {
        this._view.diamendLabel.text = str + "";
    }

    /**设置radioBtn */
    public setRadioBtn(select) {
        switch (select) {
            case 0:
                this._view.xiangouRadioBtn.selected = true;
                this._view.goumaiRadioBtn.selected = false;
                this._view.goldRadioBtn.selected = false;
                this._view.diamontRadioBtn.selected = false;
                this._view.daojuRadioBtn.selected = false;
                break;
            case 1:
                this._view.xiangouRadioBtn.selected = false;
                this._view.goumaiRadioBtn.selected = true;
                this._view.goldRadioBtn.selected = false;
                this._view.diamontRadioBtn.selected = false;
                this._view.daojuRadioBtn.selected = false;
                break;
            case 2:
                this._view.xiangouRadioBtn.selected = false;
                this._view.goumaiRadioBtn.selected = false;
                this._view.goldRadioBtn.selected = false;
                this._view.diamontRadioBtn.selected = true;
                this._view.daojuRadioBtn.selected = false;
                break;
            case 3:
                this._view.xiangouRadioBtn.selected = false;
                this._view.goumaiRadioBtn.selected = false;
                this._view.goldRadioBtn.selected = true;
                this._view.diamontRadioBtn.selected = false;
                this._view.daojuRadioBtn.selected = false;
                break;
            case 4:
                this._view.xiangouRadioBtn.selected = false;
                this._view.goumaiRadioBtn.selected = false;
                this._view.goldRadioBtn.selected = false;
                this._view.diamontRadioBtn.selected = false;
                this._view.daojuRadioBtn.selected = true;
                break;
        }
    }

    /**设置爱心 */
    public setXinText(str, h) {
        if (h && h != "") {
            this._view.heartPlugin.setJindu(str, h);
        }
    }

    /**头部金币点击 */
    public goldGroup1Touch() {
        this._view.shopViewStack.selectedIndex = 1;
        this.setRadioBtn(1);
    }

    /**头部砖石点击 */
    public diamondGroup1Touch() {
        this._view.shopViewStack.selectedIndex = 2;
        this.setRadioBtn(2);
    }

    /**关闭面板 */
    private close() {
        if (this.isBack) {
            this.closePanel();
            this.isBack = false;
            //请求背包数据
            if (PanelManager.isShowing(PanelRegister.G2_BagsPanel)) {
                this.getBags();
            }
        } else {
            this.closePanel();
            App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
        }
    }

    /**请求背包数据 */
    private getBags() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.bags, {}, new FunctionVO(this.dataBack, this));
    }
    /**背包数据返回 */
    private dataBack(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.Bags = data.data;
            App.dispatcher.dispatchEvent(EventConst.INIT_BAG);
        }
    }

    /**支付返回 */
    private payback() {
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
        this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
        this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

    public dispose(): void {
        if (this._items) {
            for (var i: number = 0; i < this._items.length; i++) {
                this._items[i] && this._items[i].dispose();
            }
            this._items = undefined;
        }
        // for (var i: number = 0; i < 5; i++) {
        //     var group: eui.Group = this._view.shopViewStack.getChildAt(i) as eui.Group;
        //     if (group) {
        //         for (var i: number = 0; i < group.numChildren; i++) {
        //             if (group.getChildAt(i))
        //                 group.getChildAt(i)["dispose"]();
        //         }
        //     }
        // }
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

}