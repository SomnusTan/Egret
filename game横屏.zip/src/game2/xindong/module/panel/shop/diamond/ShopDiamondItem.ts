class ShopDiamondItem extends BaseView {
	private priceLabel: eui.BitmapLabel;
	private diamondLabel: eui.Label;
	private diamondImage: eui.Image;

	private doubleImage: eui.Image;

	private order_id;
	private open_window;
	private t: number;

	public transData;
	public constructor() {
		super("ShopDiamondItemSKin");
		this.touchChildren = false;
		this.touchEnabled = true;
	}

	public setPrice(data: number) {
		this.priceLabel.text = data + "";
	}

	public diamondNum(data: number) {
		this.priceLabel.text = data + "";
	}

	public setImg(photo: string) {
		this.diamondImage.source = photo;
	}

	public setNum(num: number) {
		this.diamondLabel.text = "x" + num + "";
	}

	//设置是否显示首次双倍
	public setFirstPay(bFirst: boolean) {
		this.transData.first_pay = bFirst;
		this.doubleImage.visible = bFirst;
	}

	/**设置数据 */
	public setData(data) {
		this.transData = data;
		this.setImg(this.transData.new_pic);
		// this.setPrice(this.transData.price);
		this.setPrice(this.transData.balance_money);
		this.setNum(this.transData.package[0].num);
	}

	/**添加到场景中*/
	public show(data?: any): void {
		super.show(data);
		//this.daojuImg.mask = this.maskImg;
		this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.diamondsItemTouch, this);
	}

	/**从场景中移除*/
	public hide(): void {
		super.hide();
		this.open_window = null;
		App.timer.clearTimer(this, this.onTimer);
		App.timer.clearTimer(this, this.sendGetEndOrder);
		this.filters = null;
		this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.diamondsItemTouch, this);
	}

	/**砖石Item点击 */
	private diamondsItemTouch() {
		App.sound.playSoundSwitchClient1(SoundManager.button);
		this.sendGiftBuy();
	}

	private buyGiftBack(): void {
		Notice.showBottomCenterMessage("购买成功");
		App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
	}

	private sendGiftBuy() {
		Game2PayUtil.pay(this.transData.id, this.transData.title, this.transData.balance_money, 1, new FunctionVO(this.buyGiftBack, this));
		return;
		//TODO u8支付
		if (Config.U8Login) {
			App.nativeBridge.sendU8PayOld("diamond", this.transData);
			return;
		}

		//soEasy支付
		if (Config.soEasy) {
			platform.payOrder(this.transData.id);
			return;
		}

		//Android支付,sdk自己下单         
		if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
			let goodPro = this.transData.package[0];
			let { price } = this.transData;
			let goodsDes = {
				name: "购买" + goodPro["num"] + goodPro["cname"],
				price: price + "元",
				desc: `只需${price}元即可获得${goodPro["num"]}${goodPro["cname"]}`
			};
			App.nativeBridge.sendAndroidPay(this.transData.id, goodsDes);
		} else {

			let data: any = {};
			data = AddSomeMsgUtils.addSomeMsgByGiftBuy(data);
			data.gid = this.transData.id;
			let channel = window["channel"];
			if (channel) data["channel"] = channel;
			//新ios下单，增加渠道标识
			// if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
			// 	data["channel"] = IOSConfig.channel;
			// }
			//小米渠道
			if (MilletSDK.getInstance().millet) {
				data["channel"] = "xiaomi";
			}
			//vivo渠道
			if (H5_Vivo_SDK.getInstance().vivoData) {
				data["channel"] = "vivo";
			}
			//网页
			if (DeviceUtil.IsWeb) {
				//360渠道
				if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
					data["channel"] = "360";
				} else {
					data["channel"] = "web_alipay";
				}
				data.setting = DeviceUtil.currentSetting;
				if (Config.soEasy || H5_360_Sdk.getInstance().config360) {
					ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, data, new FunctionVO(this.buyBack, this));
				} else {
					data.price = this.transData.price;
					data.closeHandler = new FunctionVO(this.onChooseBack, this);
					Alert.choosePay(data);
				}
			}
			else {
				ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, data, new FunctionVO(this.buyBack, this));
			}
		}
	}
    /**
     *  payType:支付类型 1：微信，2：支付宝
     */
	private onChooseBack(param: any): void {
		if (param.payType == EnumPayType.PAY_WECHAT && DeviceUtil.isMobile) { //手机端微信支付
			var url: string = WebParams.ip + ProtocolHttpUrlGame2.giftBuy + "?channel=weixin&gid=" + param.gid + "&setting=" + DeviceUtil.currentSetting +
				"&Authorization=" + App.data.game2Center.DataCenter.skey + "&AuthorizationID=" + App.global.userInfo.uid;
			this.open_window = window.open(url, "_blank");
			App.timer.doTimeOnce(this, 3000, this.sendGetEndOrder, [param.gid]);
		} else if (!Config.isRelease || param.payType == EnumPayType.PAY_ALIPAY || (!DeviceUtil.isMobile && param.payType == EnumPayType.PAY_WECHAT)) { //支付宝 || 微信web
			if (param.payType == EnumPayType.PAY_ALIPAY)
				this.open_window = WebParams.openWindow(WebParams.defaultURL);
			delete param.closeHandler;
			if (param.payType == EnumPayType.PAY_WECHAT) {
				param.channel = "weixin";
			}
			ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, param, new FunctionVO(this.buyBack, this, param.payType));
		}
	}

	private sendGetEndOrder(gid): void {
		App.timer.clearTimer(this, this.sendGetEndOrder);
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.shop_end_order, { good_id: gid }, new FunctionVO(this.checkOrder, this));
	}

	private checkOrder(data): void {
		if (data.code == 200) {
			this.order_id = data.data;
			this.getBuy();
		}
	}

	/**购买砖石返回 */
	private buyBack(data, type?: number) {
		GameLog.log(data);
		if (data.code == 200) {
			if (DeviceUtil.IsWeb && this.transData.coin_type == "rmb") {
				this.order_id = data.data.order_id;
				if (H5_360_Sdk.getInstance().config360 && H5_360_Sdk.getInstance().config360.time != false) {
					H5_360_Sdk.getInstance().pay360Param = data.data.params;
					H5_360_Sdk.getInstance().order_id = data.data.order_id;
					H5_360_Sdk.getInstance().paySdk();
					GameLog.log("360支付订单号" + this.order_id);
				} else {
					if (type == EnumPayType.PAY_WECHAT) {
						data.data.payType = type;
						PanelOpenManager.openPanel(EnumPanelID.WECHAT_QRCODE, data.data);
					} else if (type == EnumPayType.PAY_ALIPAY) {
						let url = data.data.aliparams;
						let url0 = App.data.game2Center.DataCenter.setSelect(url);
						WebParams.openWindow("/shop/web/switch/?url=" + url0, this.open_window);
					}
				}
				this.getBuy();
				return;
			}
			else if (DeviceUtil.IsNative && DeviceUtil.IsIos && this.transData.coin_type == "rmb") {
				App.nativeBridge.sendIOSPay(data.data.order_id, data.data.product_id);
			}
			else if (this.transData.coin_type == "rmb") {
				App.nativeBridge.sendPay(data);
			}
			else if (this.transData.coin_type == "diamond") {
				Notice.showBottomCenterMessage("购买成功")
				App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
				App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
				App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
				App.data.game2Center.DataCenter.UserInfo.power = data.data.power;

				//更新四维
				App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);

			}

		} else if (data.code == 981) {
			App.nativeBridge.sendPay(data);
		} else {
			Notice.showBottomCenterMessage("" + data.info);
		}
	}

	//获得购买的状态
	private getBuy() {
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.payBack, this));
	}

	private payBack(data: any): void {
		if (data.code == 200) {
			Notice.showBottomCenterMessage("支付成功");
			App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
			App.data.game2Center.LoadingLock.unlock();
			PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
		} else {
			this.t = 0;
			this._needSendBuy = true;
			App.timer.clearTimer(this, this.onTimer);
			App.timer.doTimeLoop(this, 3000, this.onTimer);
		}
	}
	private _needSendBuy: boolean;//请求是否支付成功

	private onTimer(): void {
		this.t += 3;
		if (this.t >= 600) {
			GameLog.log("-------------10分钟内支付失败");
			App.timer.clearTimer(this, this.onTimer);
			return;
		}
		if (this._needSendBuy) {
			this._needSendBuy = false;
			ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, { order_id: this.order_id }, new FunctionVO(this.onPaySuccess, this, true));
		}
	}

	private onPaySuccess(data: any): void {
		if (data.code == 200) {
			Notice.showBottomCenterMessage("支付成功");
			App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
			App.timer.clearTimer(this, this.onTimer);
			App.data.game2Center.LoadingLock.unlock();
			PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
		} else {
			GameLog.log("-------------未支付，继续检测----------");
			this._needSendBuy = true;
		}
	}

}