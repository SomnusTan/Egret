class ShopDiamondPanel extends BasePanel {
	private diamondsListData: any[] = [];
	private _view: ShopDiamondPanelUI;

	private _items: ShopDiamondItem[];

	private _price: number;


	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new ShopDiamondPanelUI();
		this.addChild(this._view);
		this._view.diamondGrp.removeChildren();
		this._view.diamondGrp.touchEnabled = false;

		let shop = App.data.game2Center.DataCenter.Shop;
		this.diamondsListData = shop.diamonds;
		this._items = [];
		/**砖石道具 */
		for (let i = 0; i < this.diamondsListData.length; i++) {
			let item = new ShopDiamondItem();
			item.setData(this.diamondsListData[i]);
			item.setFirstPay(this.diamondsListData[i].first_pay);
			this._view.diamondGrp.addChild(item);
			this._items.push(item);
		}

		this.setCoinText(App.global.userInfo.xdCoin);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
	}

	public show(data?: any): void {
		super.show(data);
		this.setCoinText(App.global.userInfo.xdCoin);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);

		CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCoin, this, this._view.coinGroup);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchItem, this, this._view.diamondGrp);

		this._dispatcher.addEventListener(EventConst.payBack, this.payback, this);
		this._dispatcher.addEventListener(EventConst.UPDATE_FIRST_PAY, this.onUpdateFirstPay, this);
		this._dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.onUpdateSiwei, this);
		this._dispatcher.addEventListener(EventType.UPDATE_COIN, this.onUpdateCoin, this);
		this._price = data && data.hasOwnProperty("price") ? data.price : -1;
		for (var i: number = 0; i < this._items.length; i++) {
			this._items[i] && this._items[i].show();
		}
		this._view.imgSelected.visible = true;
		this.updateFocus();
	}

	public hide(): void {
		super.hide();
		this.clearItems();
		CommomBtn.removeClick(this._view.backBtn, this.close, this);
		this._dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
	}

	private updateFocus(): void {
		var hasShow: boolean = false;
		var needPrice: number = this._price - App.data.game2Center.DataCenter.UserInfo.diamond;
		for (var i: number = 0; i < this._items.length; i++) {
			if (this._items[i]) {
				if (!hasShow && needPrice <= this._items[i].transData.package[0].num) {
					hasShow = true;
					App.timer.doFrameOnce(this, 2, this.updateFocusItemPos, [this._items[i]]);
				}
			}
		}
		if (hasShow == false) {
			App.timer.doFrameOnce(this, 2, this.updateFocusItemPos, [this._items[i - 1]]);
		}
		else if (this._price == -1) {
			this._view.imgSelected.visible = false;
		}
	}

	private onTouchItem(e: egret.TouchEvent): void {
		var item: ShopDiamondItem = e.target;
		if (item instanceof ShopDiamondItem) {
			this.updateFocusItemPos(item);
		}
	}

	private updateFocusItemPos(item: ShopDiamondItem): void {
		if (item) {
			this._view.imgSelected.x = this._view.scroller.x + item.x - 5;
			this._view.imgSelected.y = this._view.scroller.y + item.y - 2;
		}
	}

	private clearItems(): void {
		if (this._items) {
			for (var i: number = 0; i < this._items.length; i++) {
				this._items[i] && this._items[i].hide();
			}
		}
	}

	//购买钻石道具成功，设置首次双倍显示
	private onUpdateFirstPay() {
		let diamondList = App.data.game2Center.DataCenter.Shop.diamonds;
		let dLen = diamondList.length;
		let len = this._view.diamondGrp.numChildren;
		for (let i = 0; i < len; i++) {
			let item: ShopDiamondItem = this._view.diamondGrp.getChildAt(i) as ShopDiamondItem;
			for (let j = 0; j < dLen; j++) {
				let diamonds = diamondList[j];
				if (item.transData.id == diamonds.id) {
					item.setFirstPay(diamonds.first_pay);
				}
			}
		}
	}

	/**
	 * 更新心动币
	 */
	private onUpdateCoin() {
		this.setCoinText(App.global.userInfo.xdCoin);
	}

	private onUpdateSiwei() {
		this.setCoinText(App.global.userInfo.xdCoin);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
		if (this._price > 0) {
			if (App.data.game2Center.DataCenter.UserInfo.diamond - this._price >= 0)
				this.closePanel();
			else
				this.updateFocus();
		}
	}

	private onCoin(e: egret.TouchEvent) {
		PanelOpenManager.openPanel(EnumPanelID.G2_SHOP_COIN_PANEL, { type: 1 });
	}

	/**设置金币 */
	public setCoinText(str) {
		this._view.coinLabel.text = str + "";
	}

	/**设置砖石 */
	public setDiaMondText(str) {
		this._view.diamondLabel.text = str + "";
	}

	/**设置爱心 */
	public setXinText(str, h) {
		if (h && h != "") {
			this._view.heartPlugin.setJindu(str, h);
		}
	}

	/**支付返回 */
	private payback() {
		this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
		this.setCoinText(App.global.userInfo.xdCoin);
		this.setDiaMondText(App.data.game2Center.DataCenter.UserInfo.diamond);
		if (this._price > 0) {
			if (App.data.game2Center.DataCenter.UserInfo.diamond - this._price >= 0)
				this.closePanel();
			else
				this.updateFocus();
		}
	}


	/**关闭面板 */
	private close() {
		this.closePanel();
	}

	public dispose(): void {
		if (this._items) {
			for (var i: number = 0; i < this._items.length; i++) {
				this._items[i] && this._items[i].dispose();
			}
			this._items = undefined;
		}
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}


	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}
}