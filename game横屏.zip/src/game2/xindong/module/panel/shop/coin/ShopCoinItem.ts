class ShopCoinItem extends BaseUI {
    public img: eui.Image;
    public txtTotal: eui.Label;
    public fontPrice: eui.BitmapLabel;

    public data: ChargeVo;

    public constructor() {
        super("ShopCoinItemSkin");
        this.touchChildren = false;
        this.touchEnabled = true;
    }

    public show(data: ChargeVo): void {
        this.data = data;
        this.img.source = "shop_coin" + this.data.index + "_png";
        this.fontPrice.text = this.data.money.toString();
        this.txtTotal.text = this.data.num.toString();
    }

    public dispose(): void {
        this.data = null;
        super.dispose();
    }
}