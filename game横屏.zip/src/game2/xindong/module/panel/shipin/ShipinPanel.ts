/**
 * 视频面板
 * @author xiongjian
 * @date 2017-9-15
 */
class ShipinPanel extends BasePanel {

    private _view: ShipinPanelUI;

    private handX: number;
    private handY: number;

    private _items: ShiPinScrollerItem[];

    private _huiyi: boolean;

    private _zhencang: boolean;

    private _beijing: boolean;
    /**当前选中索引 */
    private _curIndex: number;

    public constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init(): void {
        super.init();
        this._view = new ShipinPanelUI();
        this.addChild(this._view);
        this._view.itemGroup.removeChildren();
        this._view.item2Group.removeChildren();
        this._view.item3Group.removeChildren();

        this._view.yindaoBack.visible = false;
        this._view.yindaoGroup.visible = false;
        this.handX = this._view.shipinHand.x;
        this.handY = this._view.backHand.y;
        //
        this._items = [];
    }

    public reset(): void {
        this._huiyi = false;
        this._zhencang = false;
        this._beijing = false;
        this._view.itemGroup.scrollV = 0;
        this._view.item2Group.scrollV = 0;
        this._view.item3Group.scrollV = 0;
    }

    public dispose(): void {
        this.clearItems();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
        super.dispose();
    }

    /**
     * 添加到场景中
     */
    public show(data?: any): void {
        super.show(data);
        this.reset();
        this.setGuide();
        this.openLibao();
        this.showIndex(0, false);
        this._view.kaiguan.selected = false;
        this.setGoldtext(App.data.game2Center.DataCenter.UserInfo.gold);
        // this.kaiguanTouch();

        CommomBtn.btnClick(this._view.backBtn, this.closePanel, this, 2);
        // this.setGuide();

        this._dispatcher.addEventListener(EventConst.UPDATE_LIBAO, this.updateSiwei, this);
        this._dispatcher.addEventListener(EventConst.UPDATE_SHIPIN_GOLD, this.setGoldtext, this);

        this._dispatcher.addEventListener(egret.TouchEvent.CHANGE, this.kaiguanTouch, this, this._view.kaiguan);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.goldGroupTouch, this, this._view.goldGroup);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.guideBack, this, this._view.backCircle);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_shipinImgTouch, this, this._view.yd_shipinImg);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.selectGrp, this, this._view.rag);
    }

    /**
     * 从场景中移除
     */
    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.backBtn, this.closePanel, this);
        App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
        this.clearItems();
        this._items = [];
        this._curIndex = -1;
        this.reset();
    }

    private showIndex(index: number, playSound: boolean = true): void {
        switch (index) {
            case 0:
                this._curIndex = index;
                this._view.huiyiScroller.visible = true;
                this._view.shoucangScroller.visible = false;
                this._view.bgScroller.visible = false;
                if (!this._huiyi)
                    this.initHuiyi();
                break;
            case 1:
                this._curIndex = index;
                this._view.huiyiScroller.visible = false;
                this._view.shoucangScroller.visible = true;
                this._view.bgScroller.visible = false;
                if (!this._zhencang)
                    this.initZhencang();
                break;
            case 2:
                this._view.huiyiScroller.visible = false;
                this._view.shoucangScroller.visible = false;
                this._view.bgScroller.visible = true;
                if (!this._beijing)
                    this.initBeijing();
                break;
            default:
                return;
        }
        for (var i: number = 0, len: number = this._view.rag.numChildren; i < len; i++) {
            (this._view.rag.getChildAt(i) as eui.RadioButton).selected = i == index;
        }
        this._curIndex = index;
        if (playSound)
            App.sound.playSoundSwitchClient1(SoundManager.button);
    }

    private selectGrp(evt: egret.TouchEvent): void {
        this.showIndex(this._view.rag.getChildIndex(evt.target));
    }

    /**
     * 引导方块点击
     */
    private yd_shipinImgTouch() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, {}, new FunctionVO(this.finishGuideBack, this));
    }

    /**引导完成返回 */
    private finishGuideBack(data) {
        if (data.code == 200) {
            this._view.yindaoGroup.visible = false;
            egret.Tween.removeTweens(this._view.shipinHand);
            App.data.game2Center.DataCenter.shipinGuide = false;
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;
            this.setBackGuide();

            let json = App.data.game2Center.DataCenter.Video.mem[0];
            //回忆视频 
            if (json && json.types == 0) {
                if (json.locked == 0) {
                    let param = { ossvid: json.ossvid };
                    ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoUrl, param, new FunctionVO(this.videoUrlBack, this));
                } else {
                    Notice.showBottomCenterMessage("第" + json.days + "天开放")
                }
            }
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**web视频Url */
    public videoUrlBack(data) {
        if (data.code == 200) {
            if (DeviceUtil.IsWeb && DeviceUtil.isMobile) {
                let dialog: PlayVideoDialog = new PlayVideoDialog();
                dialog.setContent("观看视频");
                dialog.setOk(() => {
                    App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this));
                }, this);
                dialog.show(false);
            } else {
                App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this));
            }
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    private onPlayVideoComplete(): void {
        Video.instance().dispose();
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
    }

    /**请求视频Url */
    private urlBack(data) {
        if (data.code == 200) {
            App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data, new FunctionVO(this.onPlayVideoComplete, this));
            // App.nativeBridge.sendPlayVideo("2", data.data);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    private clearItems(): void {
        if (this._items) {
            for (var i: number = 0; i < this._items.length; i++) {
                this._items[i] && this._items[i].dispose();
                this._items[i] = undefined;
            }
        }
        this._items = null;
    }

    private initHuiyi(): void {
        this._huiyi = true;
        let video = App.data.game2Center.DataCenter.Video;
        let mem = video.mem;
        //回忆
        for (let k = 0; k < mem.length; k++) {
            let data = mem[k];
            let item1 = new ShiPinScrollerItem();
            item1.showGoldGroup(false);

            let type = "回忆" + (k + 1);
            item1.setTypeText(data.name);
            item1.setVideoImg(data.preview);
            if (data.locked == 0) {
                item1.showMask(false);
                item1.showLock(false);
                item1.showPlay(true);
                item1.showDate(false);
            } else {
                item1.showMask(true);
                item1.showLock(true);
                item1.showPlay(false);
                item1.showDate(true);
                let date = "游戏第" + data.days + "天开放"
                item1.setDateText(date);
            }

            item1.setData(data);

            item1.x = (k % 3) * (35 + 366) + 40;
            item1.y = (Math.floor(k / 3)) * (35 + 287) + 40;
            this._view.item2Group.addChild(item1);
            this._items.push(item1);
        }
    }

    private initZhencang(): void {
        this._zhencang = true;
        let video = App.data.game2Center.DataCenter.Video;
        let fav = video.fav;
        //收藏
        for (let i = 0; i < fav.length; i++) {
            let data = fav[i];
            let item = new ShiPinScrollerItem();

            item.showDate(false);
            let type = "珍藏" + (i + 1);
            item.setTypeText(data.name);
            item.setVideoImg(data.preview);
            if (data.locked == 0) {
                item.showMask(false);
                item.showLock(false);
                item.showPlay(true);
                item.showGoldGroup(false);
            } else {
                item.showMask(true);
                item.showLock(true);
                item.showPlay(false);
                item.showGoldGroup(true);
                item.setGoldText(data.price);
            }
            item.setData(data);
            item.x = (i % 3) * (35 + 366) + 40;
            item.y = (Math.floor(i / 3)) * (35 + 287) + 40;
            this._view.itemGroup.addChild(item);
            this._items.push(item);
        }
    }

    /**添加选项 */
    private initBeijing() {
        this._beijing = true;
        let video = App.data.game2Center.DataCenter.Video;
        let bgs = video.bgi;
        //背景
        for (let k = 0; k < bgs.length; k++) {
            let data = bgs[k];
            let item1 = new ShiPinScrollerItem();
            let type = "背景" + (k + 1);
            item1.setTypeText(data.title);
            item1.setVideoImg(data.uri, true, false);//game_bg_10a_png
            item1.setIconImg("game_bg_icon_1_png");
            if (data.use_status == 1) {
                item1.showRectMask(false);
            } else {
                item1.setVideoImg(data.uri, true, true);//game_bg_10a_png
            }
            if (data.locked == 0) {
                item1.showMask(false);
                item1.showLock(false);
                item1.showPlay(false);
                item1.showDate(false);
                item1.showGoldGroup(false);
            } else {
                item1.showMask(true);
                item1.showLock(true);
                item1.showPlay(false);
                item1.showDate(true);
                item1.setDateText("");
                item1.showGoldGroup(true);
                item1.setGoldText(data.cons);
            }

            item1.setData(data);

            item1.x = (k % 3) * (35 + 366) + 40;
            item1.y = (Math.floor(k / 3)) * (35 + 287) + 40;
            this._view.item3Group.addChild(item1);
            this._items.push(item1);
        }
    }

    /**设置金币 */
    public setGoldtext(str): void {
        if (str != "") {
            this._view.goldLabel.text = str;
        }
    }

    /**显示收藏或回忆 */
    private kaiguanTouch() {
        if (this._view.kaiguan.selected) {
            this._view.huiyiScroller.visible = false;
            this._view.shoucangScroller.visible = true;
            App.sound.playSoundSwitchClient1(SoundManager.button);
        } else {
            this._view.huiyiScroller.visible = true;
            this._view.shoucangScroller.visible = false;
            App.sound.playSoundSwitchClient1(SoundManager.button);
        }
    }

    /**金币Group点击 */
    public goldGroupTouch() {
        // App.SoundManager.playEffect(SoundManager.button);
        // App.PanelManager.open(EnumPanelID.G2_ShopPanel, ShopPage.Gold);
        // let shop = <ShopPanel>App.PanelManager.getPanel(EnumPanelID.G2_ShopPanel);
        // shop.isBack = true;
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGoldPanel);
    }

    /**引导 */
    public setGuide() {
        if (App.data.game2Center.DataCenter.shipinGuide) {
            this._view.yindaoGroup.visible = true;
            egret.Tween.get(this._view.shipinHand, { loop: true })
                .set({ x: this.handX })
                .to({ x: this.handX - 40 }, 600)
                .to({ x: this.handX }, 800)
                .wait(100);
        }
        if (this._view.huiyiScroller && this._view.huiyiScroller.verticalScrollBar) {
            this._view.huiyiScroller.verticalScrollBar.autoVisibility = false;
            this._view.huiyiScroller.verticalScrollBar.visible = false;
        }
        if (this._view.shoucangScroller && this._view.shoucangScroller.verticalScrollBar) {
            this._view.shoucangScroller.verticalScrollBar.autoVisibility = false;
            this._view.shoucangScroller.verticalScrollBar.visible = false;
        }
        if (this._view.bgScroller && this._view.bgScroller.verticalScrollBar) {
            this._view.bgScroller.verticalScrollBar.autoVisibility = false;
            this._view.bgScroller.verticalScrollBar.visible = false;
        }
    }

    /**弹礼包面板 */
    public openLibao() {
        //如果未购买礼包，则显示购买珍藏视频礼包
        if (App.data.game2Center.DataCenter.keybuy.shiping.hasbuy == false) {
            let num = Math.floor(Math.random() * App.data.game2Center.DataCenter.UserInfo.randNum) + 1
            GameLog.log("num" + num, App.data.game2Center.DataCenter.keybuy.shiping.hasbuy);
            if (num == 1 && !App.data.game2Center.DataCenter.keybuy.shiping.hasbuy && App.data.game2Center.DataCenter.guide.emph_zone != "ZONE_VIDEO") {
                PanelOpenManager.openPanel(EnumPanelID.G2_LibaoVideoPanel);
            }
        }
    }

    /**更新数据 */
    private updateSiwei() {
        this.reset();
        this.showIndex(this._curIndex);
        this.setGoldtext(App.data.game2Center.DataCenter.UserInfo.gold);
    }

    /**设置退出引导 */
    private setBackGuide() {
        this._view.yindaoBack.visible = true;
        egret.Tween.get(this._view.backHand, { loop: true })
            .set({ y: this.handY })
            .to({ y: this.handY + 40 }, 600)
            .to({ y: this.handY }, 800)
            .wait(100);
    }

    private guideBack() {
        this._view.yindaoBack.visible = false;
        this.closePanel();
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}