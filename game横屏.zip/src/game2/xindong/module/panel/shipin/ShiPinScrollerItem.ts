/**
 * 视频item 
 * @author xiongjian 
 * @date 2017/9/19
 */
class ShiPinScrollerItem extends BaseView {
    private iconImg: eui.Image;
    public videoImg: eui.Image;
    public maskImg: eui.Image;
    public rectMask: eui.Rect;
    public playImg: eui.Image;
    public lockImg: eui.Image;
    public goldGroup: eui.Group;
    public goldText: eui.Label;
    public dateText: eui.Label;
    public typeText: eui.Label;
    public dateGroup: eui.Group;

    public islock: true;

    public transData: any;

    public constructor() {
        super("ShiPinScrollerItemSkin");
    }

    // /**组件创建完毕*/
    // protected createComplete() {
    //     super.createComplete();
    //     //this.videoImg.mask = this.maskImg;
    //     this.show();
    // }

    public show(data?: any): void {
        super.show(data);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this);
        this._dispatcher.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.hide, this, this);
    }

    /**从场景中移除*/
    public hide(): void {
        super.hide();
    }

    private onOK(data: any): void {
        if (data.type == Alert.OK) {
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userBgiSet, { bid: this.transData.id }, new FunctionVO(this.setBgBack, this))
        }
    }

    private onOK2(data: any): void {
        if (data.type == Alert.OK) {
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userBgiUnlock, { bid: this.transData.id }, new FunctionVO(this.bgBack, this));
        }
    }

    private onOK3(data: any): void {
        if (data.type == Alert.OK) {
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoBuy, { vid: this.transData.id }, new FunctionVO(this.buyBack, this));
        }
    }

    /**点击 */
    private onTouch() {
        App.sound.playSoundSwitchClient1(SoundManager.button);
        GameLog.log("item", this.transData);
        let data = this.transData;
        //背景
        if (data.types == 2) {
            if (data.use_status == 1) {
                return;
            }
            if (data.locked == 0) {//解锁了
                Alert.show2(LanConst.video0_02, "", new FunctionVO(this.onOK, this), LanConst.dialog0_00);
            } else {
                Alert.show2(LanConst.video0_01, "", new FunctionVO(this.onOK2, this), LanConst.dialog0_00);
            }
        }

        //珍藏视频
        if (data.types == 1) {
            if (data.locked == 0) {
                let param = { ossvid: data.ossvid };
                ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoUrl, param, new FunctionVO(this.videoUrlBack, this));
                GameLog.log(data.ossvid);
            } else {
                Alert.show2(LanConst.video0_00, "", new FunctionVO(this.onOK3, this), LanConst.dialog0_00);
            }
        }
        //回忆视频 
        else if (data.types == 0) {
            if (data.locked == 0) {
                let param = { ossvid: data.ossvid };
                ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoUrl, param, new FunctionVO(this.videoUrlBack, this));
            } else {
                Notice.showBottomCenterMessage("第" + data.days + "天开放")
            }
        }
    }

    /**
     * 设置背景
     */
    private setBgBack(data): void {
        if (data.code == 200) {//成功
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userCollections, {}, new FunctionVO(this.revVideoList, this));
            //通知切换背景
            App.dispatcher.dispatchEvent(G2_GameSceneEvent.CHANGE_BG, this.transData.uri + "_bg");
            Notice.showBottomCenterMessage("设置成功");
            return;
        }
        Notice.showBottomCenterMessage("" + data.info);
    }

    /**
     * 背景
     */
    public bgBack(data): void {
        if (data.code == 200) {//成功
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userCollections, {}, new FunctionVO(this.revVideoList, this));
            Notice.showBottomCenterMessage("购买成功");
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    //接收视频列表
    private revVideoList(data) {
        if (data.code == 200) {
            //保存视频数据
            App.data.game2Center.DataCenter.Video.mem = data.data.mem;//回忆
            App.data.game2Center.DataCenter.Video.fav = data.data.fav;//收藏
            App.data.game2Center.DataCenter.Video.bgi = data.data.bgi;//背景
            App.dispatcher.dispatchEvent(EventConst.UPDATE_LIBAO);
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**web视频Url */
    public videoUrlBack(data) {
        if (data.code == 200) {
            if (DeviceUtil.IsWeb && DeviceUtil.isMobile) {
                let dialog: PlayVideoDialog = new PlayVideoDialog();
                dialog.setContent("观看视频");
                dialog.setOk(() => {
                    App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this));
                }, this);
                dialog.show(false);
            } else {
                App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data.url, new FunctionVO(this.onPlayVideoComplete, this));
            }
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    private onPlayVideoComplete(): void {
        Video.instance().dispose();
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
    }

    /**购买返回 */
    private buyBack(data) {
        if (data.code == 200) {
            this.transData.locked = 0;
            for (let i = 0; i < data.data.fav.length; i++) {
                if (data.data.fav[i].id == this.transData.id) {
                    this.transData.ossvid = data.data.fav[i].ossvid;
                }
            }
            App.data.game2Center.DataCenter.Video = data.data;

            this.showPlay(true);
            this.showMask(false);
            this.showLock(false);
            this.showGoldGroup(false);

            App.data.game2Center.DataCenter.UserInfo.gold = App.data.game2Center.DataCenter.UserInfo.gold - this.transData.price;
            // let panel = <ShipinPanel>App.data.game2Center.PanelManager.getPanel(EnumPanelID.G2_ShipinPanel);
            // panel.setGoldtext(App.data.game2Center.DataCenter.UserInfo.gold);
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SHIPIN_GOLD, App.data.game2Center.DataCenter.UserInfo.gold);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**请求视频Url */
    private urlBack(data) {
        if (data.code == 200) {
            App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, data.data, new FunctionVO(this.onPlayVideoComplete, this));
            // App.nativeBridge.sendPlayVideo("2", data.data);
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**设置数据 */
    public setData(data) {
        this.transData = data;
    }

    /**设置金币 */
    public setGoldText(str) {
        if (str != "") {
            this.goldText.text = str;
        }
    }

    /**设置视频图片 */
    public setVideoImg(url, isBg: boolean = false, isMarsk: boolean = false) {
        if (url && url != "") {
            if (isBg) {
                if (isMarsk) {
                    this.videoImg.source = url + "_b_png";
                    return;
                }
                this.videoImg.source = url + "_png";
                return;
            }
            this.videoImg.source = url;
        }
    }

    /**
     * 设置icon的图标
     */
    public setIconImg(url): void {
        this.iconImg.source = url;
    }

    /**设置遮罩 */
    public showMask(boo) {
        //遮罩不显示，在H5会有问题
        return;
        // if (boo) {
        //     this.maskImg.visible = true;
        // } else {
        //     this.maskImg.visible = false;
        // }
    }

    /**
     * 设置师傅显示阴影
     */
    public showRectMask(boo) {
        this.rectMask.visible = boo;
    }

    /**显示锁 */
    public showLock(boo) {
        if (boo) {
            this.lockImg.visible = true;
        } else {
            this.lockImg.visible = false;
        }
    }

    /**显示金币group */
    public showGoldGroup(boo) {
        if (boo) {
            this.goldGroup.visible = true;
        } else {
            this.goldGroup.visible = false;
        }
    }

    /**显示播放 */
    public showPlay(boo) {
        if (boo) {
            this.playImg.visible = true;
        } else {
            this.playImg.visible = false;
        }
    }

    /**显示天数 */
    public showDate(boo) {
        if (boo) {
            this.dateGroup.visible = true;
        } else {
            this.dateGroup.visible = false;
        }

    }

    /**设置游戏开启时间 */
    public setDateText(str) {
        if (str != "") {
            this.dateText.text = str;
        } else {
            this.dateText.text = "";
        }
    }


    /**设置类型text */
    public setTypeText(str) {
        this.typeText.text = str;
    }



}

