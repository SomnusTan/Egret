/**
 * 恋爱面板
 * @author xiongjian
 * @deta 2017/9/5
 */
class LovePanel extends BasePanel {
    private _view: LovePanelUI;

    private inited: boolean = false //
    private timeGuideFlag: boolean;
    private backGuideFlag: boolean;

    private handX: number;
    private handY: number;
    private handBY: number;

    private _items: LoveBox[];

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new LovePanelUI();
        this.addChild(this._view);
        this._view.itemGroup.removeChildren();
        this.handX = this._view.loveHand.x;
        this.handY = this._view.loveHand0.y;
        this.handBY = this._view.backHand.y;
        this.inited = true;
    }

    public show(data?: any): void {
        super.show(data);
        this.setConfig();

        this._dispatcher.addEventListener(EventConst.WaitTime, this.waitLisenter, this);
        this._dispatcher.addEventListener(EventConst.UPDATE_SIWEI, this.updateSiwei, this);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.goldGroupTouch, this, this._view.goldGroup);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.powerGroupTouch, this, this._view.powerGroup);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.guideTouch, this, this._view.yd_loveImg0);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.guideBack, this, this._view.backCircle);

        CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);
        CommomBtn.btnClick(this._view.startBtn, this.startTouch, this, 1);

        this.setGuide();
        this.addItem();

        // this.reqLoves();
    }
    /**获取恋爱列表 */
    private reqLoves() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loves, {}, new FunctionVO(this.revLoves, this));
    }

    /**恋爱列表返回 */
    private revLoves(data) {
        if (data.code == 200) {
            let json = data.data;
            App.data.game2Center.DataCenter.Love = json;
            this.addItem();
            // PanelOpenManager.openPanel(EnumPanelID.G2_LovePanel, json);
        }
    }

    public hide(): void {
        super.hide();
        this.clearItems();
        CommomBtn.removeClick(this._view.backBtn, this.close, this);
        CommomBtn.removeClick(this._view.startBtn, this.startTouch, this);
        App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
    }

    /**更新四维 */
    private updateSiwei() {
        this.setConfig();
    }

    /**接受到等待更新等待时间事件 */
    private waitLisenter(data) {
        this.setTimeGuide();
        let lid = data.lid;
        let json = data.data;
        if (lid >= 0) {
            if (json.cd == 0) {
                this._items[lid - 1] && this._items[lid - 1].showCD(false);
            } else {
                let love = App.data.game2Center.DataCenter.Love;
                for (let i = 0; i < love.length; i++) {
                    if (lid == love[i].lid) {
                        if (this._items[i]) {
                            this._items[i].showCD(true);
                            this._items[i].setTimeText(love[i].cd, love[i].wait, love[i].endTime);
                        }
                        break;
                    }
                }
                GameLog.log(json.power);
                // this.setPowerText(App.DataCenter.UserInfo.power);
            }
        }
    }

    private clearItems(): void {
        if (this._items) {
            for (var i: number = 0; i < this._items.length; i++) {
                this._items[i] && this._items[i].dispose();
                this._items[i] = undefined;
            }
        }
        this._items = null;
    }

    /**创建Item */
    private addItem() {
        this.clearItems();
        this._items = [];
        let love = App.data.game2Center.DataCenter.Love;
        for (let i = 0; i < love.length; i++) {
            let data = love[i];
            let item = new LoveBox();
            this._items.push(item);   //添加进列表
            item.setData(data, i);
            this._view.itemGroup.addChild(item);
        }

        this.jiesuoItem();
    }

    /**更新数据,刷新计时 */
    private refreshData(data) {
        if (data) {
            for (let i = 0; i < data.length; i++) {
                let cd = data[i].cd;
                let wait = data[i].wait;
                let endTime = data[i].endTime;
                let item: LoveBox = this._items[i];
                if (cd == 0) {
                    item.showCD(false);
                } else {
                    item.showCD(true);
                    item.setTimeText(cd, wait, endTime);
                }
                // item.setTimeText(60,3710);
            }
        }
    }

    /**start 按钮点击 */
    private startTouch() {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, {}, new FunctionVO(this.finishGuideBack, this));
    }

    /**引导完成返回 */
    private finishGuideBack(data) {
        if (data.code == 200) {
            this._view.yindaoGroup.visible = false;
            egret.Tween.removeTweens(this._view.loveHand);
            App.data.game2Center.DataCenter.loveGuide = false;
            let love = App.data.game2Center.DataCenter.Love;
            if (love[0].cd > 0) {
                this.timeGuideFlag = true;
            } else {
                this.backGuideFlag = true;
            }
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;

            let json = ProtocolHttp.loveStart;
            json.lid = love[0].lid;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loveStart, json, new FunctionVO(this.sendBack, this));
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    /**请求返回 */
    private sendBack(data) {
        if (data.code == 200) {
            if (App.data.game2Center.DataCenter.Love[0] && App.data.game2Center.DataCenter.Love[0].duration) {
                PanelOpenManager.openPanel(EnumPanelID.G2_LoveProPanel, App.data.game2Center.DataCenter.Love[0]);
            } else {
                Notice.showBottomCenterMessage("数据错误");
            }
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }

    }

    /**根据天数解锁 */
    private jiesuoItem() {
        let love = App.data.game2Center.DataCenter.Love;
        for (let i = 0; i < love.length; i++) {
            let item: LoveBox = this._items[i];
            // GameLog.log("loveBoxList",this.loveBoxList);
            if (App.data.game2Center.DataCenter.UserInfo.days >= love[i].available_days) {
                item && item.showBtn(true);
            } else {
                item && item.showBtn(false);
                item && item.setKaifangText(love[i].available_days);
            }
        }
        ScrollerCenter.hideVerticalScrollBar(this._view.loveBoxScroller);
    }

    /**关闭按钮点击 */
    private close() {
        this.closePanel();
    }

    /**配置数值 */
    private setConfig() {
        this.setPowerText(App.data.game2Center.DataCenter.UserInfo.power);
        this.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
        this.setXinText(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    /**设置爱心 */
    public setXinText(str, h) {
        if (h && h != "") {
            this._view.heartPlugin.setJindu(str, h);
        }
    }
    /**设置金币 */
    public setGoldText(str) {
        this._view.goldLabel.text = str;
    }
    /**设置体力 */
    public setPowerText(str) {
        this._view.powerLabel.text = str + "/100";
    }

    /**金币Group点击 */
    public goldGroupTouch() {
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGoldPanel);
        // App.PanelManager.open(EnumPanelID.G2_ShopPanel, ShopPage.Gold);
        // let shop = <ShopPanel>App.PanelManager.getPanel(EnumPanelID.G2_ShopPanel);
        // shop.isBack = true;
    }

    /**体力Group点击 */
    public powerGroupTouch() {
        // App.PanelManager.open(EnumPanelID.G2_ShopPanel, ShopPage.GouMai);
        // let shop = <ShopPanel>App.PanelManager.getPanel(EnumPanelID.G2_ShopPanel);
        // shop.isBack = true;
        PanelOpenManager.openPanel(EnumPanelID.G2_ShopGiftToolPanel, 1);
    }


    /**引导 */
    public setGuide() {
        if (App.data.game2Center.DataCenter.loveGuide) {
            this._view.yindaoGroup.visible = true;
            egret.Tween.get(this._view.loveHand, { loop: true })
                .set({ x: this.handX })
                .to({ x: this.handX + 40 }, 600)
                .to({ x: this.handX }, 800)
                .wait(100);
        }
    }

    /**设置冷却引导 */
    private setTimeGuide() {
        if (this.timeGuideFlag) {
            this._view.yindaoGroup0.visible = true;
            egret.Tween.get(this._view.loveHand0, { loop: true })
                .set({ y: this.handY })
                .to({ y: this.handY - 40 }, 600)
                .to({ y: this.handY }, 800)
                .wait(100);
        } else {
            if (this.backGuideFlag) {
                this.guideTouch();
            }
        }
    }

    /**冷却引导点击 */
    private guideTouch() {
        this._view.yindaoGroup0.visible = false;
        this.setBackGuide();
    }

    /**设置退出引导 */
    private setBackGuide() {
        this._view.yindaoBack.visible = true;
        egret.Tween.get(this._view.backHand, { loop: true })
            .set({ y: this.handBY })
            .to({ y: this.handBY + 40 }, 600)
            .to({ y: this.handBY }, 800)
            .wait(100);
    }

    private guideBack() {
        this._view.yindaoBack.visible = false;
        this.timeGuideFlag = false;
        this.backGuideFlag = false;
        App.data.game2Center.DataCenter.bagGuide = true;
        this.close();
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

}