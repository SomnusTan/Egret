/**
 * 恋爱组件
 * @author xiongjian 
 * @date 2017/9/5
 */
class LoveBox extends BaseView {

    public typeImg: eui.Image;
    public timeLabel: eui.Label;
    public typeLabel: eui.Label;
    public tiliLabel: eui.Label;
    public daojuLabel: eui.Label;
    public kaifangLabel: eui.Label;
    public kaifangGroup: eui.Group;
    public startBtn: eui.Button;

    public xinLabel: eui.Label;
    public cdGroup: eui.Group;
    public daojuGroup: eui.Group;

    public type: number;

    private transData;//传递数据

    private waitTime: number;
    private cdTime = 0;

    private cdBtn: eui.Button;  //无冷却购买提示

    public constructor() {
        super("LoveBoxSkin");
    }

    /**组件创建完毕*/
    public show(data?: any) {
        super.show(data);
        this.hideCDImg();
        CommomBtn.btnClick(this.startBtn, this.startBtnTouch, this, 1);
        this._dispatcher.addEventListener(EventConst.UPDATE_RED_TIP, this.onUpdateRedTip, this);
    }

    /**从场景中移除*/
    public hide() {
        super.hide();
        this.hideCDImg();
        this.removeTimer();
        CommomBtn.removeClick(this.startBtn, this.startBtnTouch, this);
    }

    private onUpdateRedTip(): void {
        //工作红点提示
        let loveList = App.data.game2Center.DataCenter.Love;
        var data: any = loveList[this.type];
        this.setData(data, this.type);
    }

    public setData(data: any, i: number): void {
        this.setImg(data.pic);
        this.showBtn(true);
        if (data.need_tool == 0) {
            this.showDaoju(false);
        } else {
            this.showDaoju(true);
        }
        this.setTiliText(data.cons_power);
        this.setXinText(data.score)
        this.setTypeText(data.title);
        if (data.cd == 0) {
            this.showCD(false);
        } else {
            this.showCD(true);
            this.setTimeText(data.cd, data.wait, data.endTime);
        }
        this.setType(i);
        //this.x = (this.width + 40) * i + 40;
        if (data.need_tool == 0) {
            this.showDaoju(false);
        } else {
            this.showDaoju(true);
            this.setDaojuText(data.tool_name);
        }

        if (App.data.game2Center.DataCenter.UserInfo.days >= data.available_days) {
            this.showBtn(true);
        } else {
            this.showBtn(false);
            this.setKaifangText(data.available_days);
        }
    }

    /**开始按钮点击 */
    private startBtnTouch() {
        GameLog.log("type", this.type);
        let love = App.data.game2Center.DataCenter.Love;
        this.transData = love[this.type];
        this.sendHttp();
    }

    /**是否显示按钮 */
    public showBtn(boo: boolean) {
        if (boo) {
            this.startBtn.visible = true;
            this.kaifangGroup.visible = false;
        } else {
            this.startBtn.visible = false;
            this.kaifangGroup.visible = true;
        }
    }

    /**设置开放天数 */
    public setKaifangText(num) {
        if (num != "") {
            this.kaifangLabel.text = "游戏内时间第" + num + "天开放";
        }
    }

    /**设置类型 */
    public setTypeText(str) {
        if (str != "") {
            this.typeLabel.text = str;
        }
    }

    /**设置体力 */
    public setTiliText(num) {
        if (num != "") {
            this.tiliLabel.text = num;
        }
    }

    /**设置道具 */
    public setDaojuText(str) {
        if (str != "") {
            this.daojuLabel.text = str;
        }
    }

    /**道具显示 */
    public showDaoju(bo: boolean) {
        if (bo) {
            this.daojuGroup.visible = true;
        } else {
            this.daojuGroup.visible = false;
        }
    }


    /**显示cd */
    public showCD(bo: boolean) {
        if (bo) {
            this.cdGroup.visible = true;
        } else {
            this.cdGroup.visible = false;
        }
    }

    /**设置心 */
    public setXinText(num) {
        if (num && num != "") {
            this.xinLabel.text = num;
        }
    }


    /**设置时间 */
    public setTimeText(cd, wait, endTime) {
        if (endTime <= ServerTime.serverTime) {
            this.cdTime = cd;
            if (cd && cd != "") {
                if (cd < 60) {
                    this.timeLabel.text = cd + "分钟";
                }
                if (cd >= 60 && cd < 120) {
                    let s = cd - 60
                    if (s == 0) {
                        this.timeLabel.text = "1小时";
                    }
                    if (s > 0) {
                        this.timeLabel.text = "1小时" + s + "分钟";
                    }
                }
                if (cd >= 120 && cd < 180) {
                    let s = cd - 120
                    if (s == 0) {
                        this.timeLabel.text = "2小时";
                    }
                    if (s > 0) {
                        this.timeLabel.text = "2小时" + s + "分钟";
                    }
                }
            }
        } else {

            this.removeTimer();
            App.timer.serverTimeEnd(this, this.timerFunc, endTime);
            // this.timer = new DateTimer(1000, wait);
            // this.timer.addEventListener(egret.TimerEvent.TIMER, this.timerFunc, this);
            // this.timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, this.timerComFunc, this);
            // this.timer.start();

            //新增，提示购买无冷却
            this.showCDImg();
        }
    }



    /**设置等待时间 */
    public setWaitText(str) {
        if (str) {
            let fen = Math.floor(str / 60);//分钟
            let miao = Math.floor(str % 60);//秒
            let shi = Math.floor(str / 60 / 60);//时
            //秒
            if (fen < 1) {
                if (str < 10) {
                    this.timeLabel.text = "00:0" + str;
                } else {
                    this.timeLabel.text = "00:" + str;
                }

            }
            //分
            if (fen >= 1 && fen < 60) {
                if (miao < 10) {
                    this.timeLabel.text = fen + ":0" + miao;
                } else {
                    this.timeLabel.text = fen + ":" + miao;
                }

            }
            //时
            if (shi >= 1) {
                let time = str - shi * 3600;//分秒
                let f = Math.floor(time / 60);//分钟
                let m = Math.floor(time % 60);//秒
                if (f < 10) {
                    if (m < 10) {
                        this.timeLabel.text = shi + ":0" + f + ":0" + m;
                    } else {
                        this.timeLabel.text = shi + ":0" + f + ":" + m;
                    }

                } else {
                    if (m < 10) {
                        this.timeLabel.text = shi + ":" + f + ":0" + m;
                    } else {
                        this.timeLabel.text = shi + ":" + f + ":" + m;
                    }
                }

            }
        }
    }


    /**每秒倒计时 */
    private timerFunc(serverTimeData: ServerTimeData) {
        if (serverTimeData.spuleTime > 0) {
            this.setWaitText(serverTimeData.spuleTime);
        }
        else {
            this.removeTimer();
            if (this.transData) {
                this.cdTime = this.transData.cd;
            }
            this.setTimeText(this.cdTime, 0, 0);
            //隐藏cd无冷却
            this.hideCDImg();
        }
    }

    /**清楚倒计时 */
    private removeTimer() {
        App.timer.clearTimer(this, this.timerFunc);
    }

    /**设置图片 */
    public setImg(url) {
        if (url && url != "") {
            this.typeImg.source = url;
        }
    }

    /**设置类型 */
    public setType(num) {
        this.type = num;
    }

    /**发送开始请求 */
    public sendHttp() {
        let data = ProtocolHttp.loveStart;
        data.lid = this.transData.lid;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loveStart, data, new FunctionVO(this.sendBack, this));

    }

    /**请求返回 */
    private sendBack(data) {
        if (data.code == 200) {
            if (this.transData && this.transData.duration) {
                PanelOpenManager.openPanel(EnumPanelID.G2_LoveProPanel, this.transData);
            } else {
                Notice.showBottomCenterMessage("数据错误");
            }
            //811提示请购买   812道具不足
        } else if (data.code == 811 || data.code == 812) {
            this.askBuyLoveTool();
        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }

        //809冷却中且未购买礼包，则弹礼包
        if (data.code == 809 && !App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy) {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoCDPanel);
        }

    }

    //询问购买恋爱道具
    private askBuyLoveTool() {
        if (this.transData.need_tool > 0) {
            //获取所需恋爱道具信息
            let tools = App.data.game2Center.DataCenter.Shop.tools;
            let price: number = 0;
            let tool_name = this.transData.tool_name
            let tool_id = this.transData.tool_id;
            let need_tool = this.transData.need_tool;
            for (let key in tools) {
                let toolObj = tools[key];
                if (toolObj.id == this.transData.tool_id) {
                    price = toolObj.price;
                    break;
                }
            }
            var html: string = StringUtil.substitute(EnumAlertContent.BUY_LOVE_ITEM, tool_name, price);
            Alert.show2(html, "", new FunctionVO((data) => {
                if (data.type == Alert.OK)
                    this.sendBuyLoveTool(tool_id, need_tool);
            }, this), "", true);
        }
    }

    //发送购买恋爱道具
    private sendBuyLoveTool(tool_id, need_tool) {
        let gid = tool_id;

        let data = ProtocolHttp.toolsBuy;
        data.gid = gid;
        data.count = need_tool;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.toolsBuy, data, new FunctionVO(this.revBuyLoveTool, this));
    }

    //购买恋爱道具返回
    private revBuyLoveTool(data) {
        GameLog.log("tool", data);
        if (data.code == 200) {
            App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
            App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
            App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;
            App.data.game2Center.DataCenter.UserInfo.power = data.data.power;

            //更新限购次数
            GameLog.log("BuyToolPanel >> 购买返回，剩余限购次数:", data.data.left_times);
            let leftTimes = { "id": this.transData.tool_id, "left_times": data.data.left_times };
            App.dispatcher.dispatchEvent(EventConst.UPDATE_LEFT_TIMES, leftTimes);

            //更新四维
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);

            //DataCenter里数据不是唯一的...
            //DataCenter和BuyToolPanel、DaojuListItem里面分别保存了三份数据，而数据不一致...
            //这里先应付下更新数据问题...
            // let buyToolPanel: BuyToolPanel = App.data.game2Center.PanelManager.getPanel(EnumPanelID.G2_BuyToolPanel);
            // buyToolPanel && buyToolPanel.setXiangou(data.data.left_times);
            App.dispatcher.dispatchEvent(EventConst.UPDATE_LIMIT_NUM, data.data.left_times);
            let tools = App.data.game2Center.DataCenter.Shop.tools;
            let tool_id = this.transData.tool_id;
            let need_tool = this.transData.need_tool;
            for (let key in tools) {
                let toolObj = tools[key];
                if (toolObj.id == this.transData.tool_id) {
                    toolObj.left_times = data.data.left_times;
                    break;
                }
            }

            Notice.showBottomCenterMessage("购买成功");

            // let panel:ShopGiftToolPanel = App.data.game2Center.PanelManager.getPanel(EnumPanelID.G2_ShopGiftToolPanel);
            // panel && panel.setGoldText(App.data.game2Center.DataCenter.UserInfo.gold);
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SHOP_GIFT_GOLD, App.data.game2Center.DataCenter.UserInfo.gold);

        } else {
            Notice.showBottomCenterMessage("" + data.info);
        }
    }

    //显示提示购买无冷却
    private showCDImg() {
        if (App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy == false) {
            App.stage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this);

            this.cdBtn.visible = true;
            this.cdBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this);
        }
    }

    //隐藏提示购买无冷却
    private hideCDImg() {
        App.stage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this);

        this.cdBtn.visible = false;
        this.cdBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this);
    }

    //隐藏提示购买无冷却
    private onCDBtnTouch(e: egret.TouchEvent) {
        this.hideCDImg();
        this.showLiBao();
    }

    //显示礼包
    private showLiBao() {
        if (App.data.game2Center.DataCenter.keybuy.wulengque.hasbuy == false) {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoCDPanel);
        }
    }
}

enum LoveBoxType {
    one,
    two,
    there,
    four,
    five,
    six,
    seven,
    eight,
    nine,
    ten
}