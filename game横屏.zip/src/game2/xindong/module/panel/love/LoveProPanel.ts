/**
 * 恋爱进度面板
 * @author xiongjian
 * @deta 2017/9/5
 */
class LoveProPanel extends BasePanel {
    private _view: LoveProPanelUI;

    public recData: any;
    private _currentSoundKey: string;

    /**倒计时次数 */
    private count = 1;
    private proInitW: number = 60;    //进度条初始宽度，防止宽度过短时，原型变成矩形

    public constructor() {
        super();
    }

    protected init(): void {
        this._view = new LoveProPanelUI();
        this.addChild(this._view);
    }

    /**添加到场景中*/
    public show(data?: any) {
        super.show(data);
        this.recData = data;
        this._view.proImg.width = this.proInitW;
        this._view.ProLabel.text = "0%";
        App.data.game2Center.SoundManager.stopBGM();
        App.sound.stopSoundSwitchClient1(this._currentSoundKey);
        if (this.recData && this.recData.title) {
            App.timer.doTimeOnce(this, 500, this.playMusicTitle);
        }
        if (this.recData && this.recData.pic) {
            this.setImgType(this.recData.pic);
        }

        if (this.recData && this.recData.title) this._view.typeLabel.text = this.recData.title;

        CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);
        CommomBtn.btnClick(this._view.finishBtn, this.finishTouch, this, 1);

        this.showLoveTip();

        this.hideCDImg();
        this.showCDImg();

        this.countDown(this.recData.duration * 10, 100);
    }

    public hide(): void {
        super.hide();
        CommomBtn.removeClick(this._view.backBtn, this.close, this);
        CommomBtn.removeClick(this._view.finishBtn, this.finishTouch, this);
        this.hideCDImg();
        this.removeTimer();
        this._view.proImg.width = this.proInitW;
        this._view.ProLabel.text = "0%";
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
    }

    private playMusicTitle(): void {
        App.timer.clearTimer(this, this.playMusicTitle);
        this.playMusic(this.recData.title);
    }

    /**倒计时
     * @delay  延迟时间
     * @repeatCount 执行次数
     */
    private countDown(delay, repeatCount) {
        this.count = 1;
        let t = parseInt(delay);
        let count = parseInt(repeatCount);
        if (t && count) {
            App.timer.doTimeLoop(this, t, this.showProbar, [count])
        }
    }

    private showProbar(maxCount: number): void {
        this.jindu(this.count);
        if (this.count == maxCount) {
            this.timerComFunc();
        }
        this.count++;
    }

    /**倒计时结束 */
    private timerComFunc() {
        this.removeTimer();
        this.finish();
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
    }

    /**计时结束完成 */
    private finish() {
        let data = this.recData;

        let json = ProtocolHttp.loveFinish;
        json.lid = data.lid;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loveFinish, json, new FunctionVO(this.loveFinish, this));
    }

    /**恋爱完成 */
    private loveFinish(data) {
        if (data.code == 200) {
            App.sound.playSoundSwitchClient1(SoundManager.love_done);
            GameLog.log(data.data);
            let obj = new Object();
            obj["lid"] = this.recData.lid;
            obj["data"] = data.data;
            App.data.game2Center.DataCenter.UserInfo.updateLoveData(obj);
            App.dispatcher.dispatchEvent(EventConst.WaitTime, obj);
            // App.SoundManager.playEffect(SoundManager.success);
            let text = "获得" + data.data.hearts + "心动值"
            PanelOpenManager.openPanel(EnumPanelID.G2_FinishLovePanel, text);
            //心动值
            let heart = data.data.hearts;
            TipsHeat.showHeat(heart);
            let userheart = App.data.game2Center.DataCenter.UserInfo.hearts
            App.data.game2Center.DataCenter.UserInfo.hearts = userheart + heart;
            this.close();
            // let lovepanel = <LovePanel>App.data.game2Center.PanelManager.getPanel(EnumPanelID.G2_LovePanel);
            App.data.game2Center.DataCenter.UserInfo.power = data.data.power;
            // lovepanel.setConfig();
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);
            //提示碎片
            if (data.data.extra_lost) {
                Alert.show2(data.data.extra_lost.des, "确定", null);
            }
        }
    }

    private jindu(count) {
        if (count) {
            this._view.ProLabel.text = count + "%";
            this._view.proImg.width = this.proInitW + count * (this._view.probg.width - this.proInitW) / 100;
        }
    }

    /**清楚倒计时 */
    private removeTimer() {
        App.timer.clearTimer(this, this.showProbar);
        this.count = 1;
        App.sound.stopSoundSwitchClient1(this._currentSoundKey);

    }

    /**关闭 */
    private close() {
        this.closePanel();
    }

    /**立即完成 */
    public finishTouch() {
        this.finishNow();
    }

    /**立即结束接口 */
    private finishNow() {
        let data = this.recData;

        let json = ProtocolHttp.loveFinish;
        json.lid = data.lid;
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.loveFinishNow, json, new FunctionVO(this.loveFinishNowBack, this));
    }

    /**立即结束返回 */
    private loveFinishNowBack(data) {
        if (data.code == 200) {
            App.sound.playSoundSwitchClient1(SoundManager.love_done);
            this.close();
            GameLog.log(data.data);
            let obj = new Object();
            obj["lid"] = this.recData.lid;
            obj["data"] = data.data;
            App.data.game2Center.DataCenter.UserInfo.updateLoveData(obj);
            App.dispatcher.dispatchEvent(EventConst.WaitTime, obj);
            // App.SoundManager.playEffect(SoundManager.success);
            let text = "获得" + data.data.hearts + "心动值"
            PanelOpenManager.openPanel(EnumPanelID.G2_FinishLovePanel, text);
            //心动值
            let heart = data.data.hearts;
            TipsHeat.showHeat(heart);
            let userheart = App.data.game2Center.DataCenter.UserInfo.hearts
            App.data.game2Center.DataCenter.UserInfo.hearts = userheart + heart;
            App.data.game2Center.DataCenter.UserInfo.power = data.data.power;
            App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);
            //碎片提示
            if (data.data.extra_lost) {
                Alert.show2(data.data.extra_lost.des, "确定", null);
            }
        } else {
            Notice.showBottomCenterMessage("" + data.info);
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoFinishPanel);
        }
    }

    /**设置恋爱类型 */
    public setTextType(str) {
        if (str && str != "") {
            this._view.typeLabel.text = str;
        }
    }

    /**设置恋爱背景 */
    public setImgType(url) {
        if (url && url != "") {

            this._view.TypeImg.source = url;
            // let sr = RES.getRes("work_1_png");
            // var blurFliter = new egret.BlurFilter(1, 1);
            // var colorMatrix = [
            //     0.3, 0.6, 0, 0, 0,
            //     0.3, 0.6, 0, 0, 0,
            //     0.3, 0.6, 0, 0, 0,
            //     0, 0, 0, 1, 0
            // ];
            // var colorFlilter = new egret.ColorMatrixFilter(colorMatrix);
            // this.TypeImg.filters = [colorFlilter];
        }
    }

    /**设置类型文本 */
    public setType() {

    }


    /**出场动画 */
    public outAnimation(finishCallback: Function = null) {

    }

    /**入场动画 */
    public enterAnimation() {

    }

    /**播放音乐 */
    private playMusic(type) {
        switch (type) {
            case "泡图书馆":
                this._currentSoundKey = SoundManager.library;
                break;
            case "约吃饭":
                this._currentSoundKey = SoundManager.canteen;
                break;
            case "看电影":
                this._currentSoundKey = SoundManager.canteen;
                break;
            case "逛街":
                this._currentSoundKey = SoundManager.canteen;
                break;
            case "唱歌":
                this._currentSoundKey = SoundManager.shopping;
                break;
            case "游公园":
                this._currentSoundKey = SoundManager.park;
                break;
            case "做运动":
                this._currentSoundKey = SoundManager.gym;
                break;
            case "逗猫":
                this._currentSoundKey = SoundManager.cat;
                break;
            case "游乐园":
                this._currentSoundKey = SoundManager.carnie;
                break;
            default:
                this._currentSoundKey = SoundManager.time_click;
                break;
        }
        App.sound.playSoundSwitchClient1(this._currentSoundKey, true);
    }

    //显示恋爱秘籍
    private tipJson;
    private showLoveTip() {
        if (this.tipJson == null) {
            this.tipJson = RES.getRes("lovetips_json");
        }
        if (this.tipJson != null) {
            let tips = this.tipJson.tips;
            let len = tips.length;
            this._view.tipLabel.text = tips[NumberTool.getRandInt(0, len - 1)];
        }
    }

    //显示提示购买无冷却
    private showCDImg() {
        if (App.data.game2Center.DataCenter.keybuy.yijian.hasbuy == false) {
            this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this);
            this._view.cdBtn.visible = true;
            this._view.cdBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this);
        }
    }

    //隐藏提示购买无冷却
    private hideCDImg() {
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hideCDImg, this);
        this._view.cdBtn.visible = false;
        this._view.cdBtn.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onCDBtnTouch, this);
    }

    //隐藏提示购买无冷却
    private onCDBtnTouch(e: egret.TouchEvent) {
        this.hideCDImg();
        this.showLiBao();
    }

    //显示礼包
    private showLiBao() {
        if (App.data.game2Center.DataCenter.keybuy.yijian.hasbuy == false) {
            PanelOpenManager.openPanel(EnumPanelID.G2_LibaoFinishPanel);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}