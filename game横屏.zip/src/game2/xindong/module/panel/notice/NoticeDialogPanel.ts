class NoticeDialogPanel extends BasePanel {
	private _view: NoticeDialogPanelUI;
	private radioList;                   //单选按钮数组

	// private LIANDONG: number = 0;
	private YOUXI: number = 0;
	private XITONG: number = 1;
	private LIANXI: number = 2;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new NoticeDialogPanelUI();
		this.addChild(this._view);
		//初始化
		this.radioList = [this._view.radioBtn0, this._view.radioBtn1, this._view.radioBtn2];
		this._view.gameContent.text = "";
		this._view.systemLabel.text = "";
	}

	public show(data) {
		//按钮监听
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.qqTouch, this, this._view.QQgift);
		this._dispatcher.addEventListener(eui.UIEvent.CHANGE, this.onPageChange, this, this._view.radioBtn0.group);
		CommomBtn.btnClick(this._view.closeBtn, this.onCloseTouch, this);
		this._view.gameContent.text = data.data.game.content;
		this._view.systemLabel.text = data.data.system.content;
		// this._view.liandongContent.text = data.data.announcement[0].depict;

		if (Config.soEasy && SoEasySdk.shieldChannel()) {
			this._view["radioBtn" + this.LIANXI].visible = false;
			this._view.radioBtn0.selected = true;
			this._view.viewStack.selectedIndex = 0;
			this._view.radioBtn0.group.selectedValue = 0;
		} else {
			this._view["radioBtn" + this.LIANXI].visible = true;
			this.switchPage(this.LIANXI);
			for (let i: number = 0; i < this._view.radioGrp.numChildren; i++) {
				let radioBtn: eui.RadioButton = this._view.radioGrp.getElementAt(i) as eui.RadioButton;
				if (i == this.LIANXI) {
					radioBtn.selected = true;
				} else {
					radioBtn.selected = false;
				}
			}
		}
	}

	private qqTouch(e: egret.TouchEvent) {
		if (DeviceUtil.IsNative) {
			let data: any = { key: App.data.game2Center.DataCenter.shareContent.key, group: App.data.game2Center.DataCenter.shareContent.group };
			App.nativeBridge.pushQQGroup("pushQQGroup", data);
		} else {
			//window.open("https://jq.qq.com/?_wv=1027&k=5M9qH37");
			window.open("https://jq.qq.com/?_wv=1027&k=5DC9mi9");
		}
	}

	/**点击单选按钮 切换页面 */
	private onPageChange(e: eui.UIEvent) {
		App.sound.playSoundSwitchClient1(SoundManager.button);
		let group: eui.RadioButtonGroup = e.target;
		this.switchPage(group.selectedValue);
	}

	/**切换页面 */
	public switchPage(page) {
		//如果该页面存在，才会切换页面。否则切换到当前存在的第一页
		if (this.radioList[page].parent) {
			this._view.radioBtn0.group.selectedValue = page;
			this._view.viewStack.selectedIndex = page;
		} else {
			this.switchFirstPage();
		}
	}

	/**切换到第一页 某些任务在完成后会消失，所以需要判断谁在第一页*/
	private switchFirstPage() {
		this._view.validateNow();
		let len = this.radioList.length;
		for (let i = 0; i < len; i++) {
			if (this.radioList[i].parent) {
				this.switchPage(i);
				break;
			}
		}
	}

	public hide() {
		super.hide();
		CommomBtn.removeClick(this._view.closeBtn, this.onCloseTouch, this);
	}

	/**关闭页面 */
	private onCloseTouch() {
		this.closePanel();
	}

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

}