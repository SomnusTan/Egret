/**
 * 电话聊天历史
 * @author xiongjian
 * @date 2017/9/7 
 */
class CallHistoryPanel extends BasePanel {
    private _view: CallHistoryPanelUI;
    public recData: any;

    public constructor() {
        super();
    }

    /**组件创建完毕*/
    protected init() {
        super.init();
        this._view = new CallHistoryPanelUI();
        this.addChild(this._view);
    }

    /**添加到场景中*/
    public show(data?: any) {
        super.show(data);
        this.recData = data;
        this._view.grilImg.mask = this._view.maskImg;
        if (App.data.game2Center.DataCenter.Tel) {
            this._view.grilImg.source = App.data.game2Center.DataCenter.Tel.head;
        }
        CommomBtn.btnClick(this._view.backBtn, this.close, this, 2);
        this.setData();

    }

    /**从场景中移除*/
    public hide() {
        super.hide();
        CommomBtn.removeClick(this._view.backBtn, this.close, this);
    }

    /**设置数据 */
    private setData() {
        let ac = new eui.ArrayCollection();
        let arr = [];
        var data = this.recData.dialog;
        arr = data;
        GameLog.log("arr", arr);
        ac.source = arr;
        this._view.dataList.dataProvider = ac;
        this._view.dataList.itemRenderer = CallHistoryListItem;
    }

    /**关闭页面 */
    private close() {
        PanelManager.removePanelByName(this.panelName);
        PanelOpenManager.openPanel(EnumPanelID.G2_DianhuaPanel);
        App.data.game2Center.TalkManager.stopSound();
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}