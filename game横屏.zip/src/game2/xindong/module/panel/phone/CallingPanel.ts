/**
 *电话呼叫中面板
 * @author xiongjian
 * @date 2017/08/24
 */
class CallingPanel extends BasePanel {

    private _view: CallingPanelUI;


    public constructor() {
        super();
    }

    protected init() {
        super.init();
        this._view = new CallingPanelUI();
        this.addChild(this._view);
    }

    public show(data?: any) {
        super.show(data);
        this._view.grilImg.mask = this._view.maskImg;
        if (App.data.game2Center.DataCenter.Tel) {
            this._view.grilImg.source = App.data.game2Center.DataCenter.Tel.head;
        }
        this.startOverTimer();
        this._view.heartPlugin.setJindu(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    public hide() {
        this.stopOverTimer();
    }

    //开始超时计时
    private startOverTimer() {
        App.sound.playSoundSwitchClient1(SoundManager.calling, true);
        App.timer.doTimeOnce(this, 3000, this.onTimerComplete);
    }

    //停止超时计时
    private stopOverTimer() {
        App.timer.clearTimer(this, this.onTimerComplete);
    }


    //超时
    private onTimerComplete() {
        PanelOpenManager.openPanel(EnumPanelID.G2_JietongPanel);
        App.sound.stopSoundSwitchClient1(SoundManager.calling);
        this.close();
        this.stopOverTimer();

    }

    /**关闭面板 */
    private close() {
        PanelManager.removePanelByName(this.panelName);
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}