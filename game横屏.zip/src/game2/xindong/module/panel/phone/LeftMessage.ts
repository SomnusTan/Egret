/**
 * 左边消息
 * @author xiongjian 
 * @date 2017/8/31
 */
class LeftMessage extends BaseUI {

    public text: eui.Label;
    public zhuname: eui.Label;//主角名字
    public talkImg: eui.Image;
    public zhuImg: eui.Image;
    public labelBG:eui.Image;

    public constructor() {
        super("LeftMessageSkin");
    }

    /**添加到场景中*/
    protected createComplete() {
        this.text.fontFamily = "fzyc";
        this.zhuname.fontFamily = "fzyc";
    }

    /**设置文本 */
    public setText(str: string) {
        if (str && str != "") {
            this.text.text = StringTool.formatWrap(str,25);
            this.labelBG.width = this.text.width + 50;
        }
    }

    /**设置主角名字 */
    public setZhuName(str) {
        if (str && str != "") {
            this.zhuname.text = str;
        }
    }

    /**是否显示主角名字 */
    public showName(bo: boolean) {
        if (bo) {
            this.zhuname.visible = true;
        } else {
            this.zhuname.visible = false;
        }
    }

    /**是否显示talk图标 */
    public showTalk(boo) {
        if (boo) {
            this.talkImg.visible = true;
        } else {
            this.talkImg.visible = false;
        }
    }

    /**设置主角头像 */
    public setImg(url) {
        this.zhuImg.source = url;
    }

    /**显示喇叭动画 移动端web不能主动播放声音，使用一个喇叭动画提示让玩家点击 */
    public showTalkAnim(){
        this.talkImg.visible = true;
        egret.Tween.get(this.talkImg,{loop:true}).set({scaleX:1,scaleY:1}).to({scaleX:1.3,scaleY:1.3},500).to({scaleX:1,scaleY:1},500);
    }

    /**隐藏喇叭动画 */
    public hideTalkAnim(){
        this.talkImg.visible = false;
        egret.Tween.removeTweens(this.talkImg);
    }
}