/**
 *电话接通面板
 * @author xiongjian
 * @date 2017/08/24
 */
class JietongPanel extends BasePanel {

    private _view: JietongPanelUI;
    /**聊天数组集合 */
    private ac: eui.ArrayCollection;
    /**上一条聊天记录 */
    private oldMsg;
    /**历史消息 */
    private history;
    /**下一步准备要发送的消息 */
    private nexttel: any[];
    /**当前说的话 */
    private msgType;

    private handY: number;

    private handYH: number;

    /**声音 */
    private sound: egret.Sound;
    /**声道 */
    public channel: egret.SoundChannel;


    /**通话计时计数 */
    private count: number = 0;

    /**是否正在发送中。用于通话中退出界面再次进入时，如果处于发送中，则继续发送；不在发送中，则请求下一条*/
    //private bSending: boolean = false;


    public constructor() {
        super();
    }

    protected init() {
        super.init();
        this._view = new JietongPanelUI();
        this.addChild(this._view);

    }

    public show(data?: any): void {
        super.show(data);
        //初始化头像和昵称
        this._view.grilImg.mask = this._view.maskImg;
        if (App.data.game2Center.DataCenter.Tel) {
            this._view.grilImg.source = App.data.game2Center.DataCenter.Tel.head;
        }
        this._view.girlName.text = App.data.game2Center.DataCenter.ConfigInfo.girl_name;
        this.handY = this._view.dianhuaHand.y;
        this.handYH = this._view.dianhuaHand0.y;

        //停止背景音乐
        App.data.game2Center.SoundManager.stopBGM();

        //初始化亲密度
        this.hideSelect();
        this.setHeart();

        //初始化通话记录
        this.initHistory();
        this.setScolltoEnd();

        //开始通话计时
        this.startOverTimer();

        //引导
        this.setGuide();

        this.dealRevMsg(App.data.game2Center.DataCenter.Tel.nexttel);

        // if (this.bSending) {
        //     this.sendMessageTouch();
        // } else {
        //     this.dealRevMsg(this.nexttel);
        // }
        //按钮监听
        CommomBtn.btnClick(this._view.guaduanBtn, this.guanduanTouch, this, 1);
        this._view.yd_dianhuaImg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_dianhuaImgTouch, this);
        this._view.yd_dianhuaImg0.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_dianhuaImgTouchHeart, this);
    }
    public hide(): void {
        super.hide();
        App.timer.clearTimer(this, this.scrollToEnd);
        CommomBtn.removeClick(this._view.guaduanBtn, this.guanduanTouch, this);
        App.data.game2Center.TalkManager.stopSound();
        this.stopTryPlaySound();
        this.stopOverTimer();
        App.data.game2Center.LoadingLock.unLockScreen();
        App.timer.clearTimer(this,this.updateMessage);

        //退出后，电话二级引导结束
        App.data.game2Center.DataCenter.dianhuaGuide = false;
    }

    /**初始化通话记录 */
    private initHistory() {
        this.ac = new eui.ArrayCollection();
        this.history = [];
        var data = this.getLastHistory();
        this.history = data;
        this.ac.source = ArrayTool.copyArr(this.history);
        this._view.messageList.dataProvider = this.ac;
        this._view.messageList.itemRenderer = MessageListItem;
        this._view.messageList.useVirtualLayout = false;
    }

    /**获取最后一条通话历史记录 */
    private getLastHistory() {
        let tel = App.data.game2Center.DataCenter.Tel;
        let arr = []
        let history = tel.history;

        //拿最后一条电话历史
        let json = ProtocolHttpData.wechat;
        json = history[0];

        for (let i = 0, len = json.dialog.length; i < len; i++) {
            let obj = new Object();
            let dialog = ProtocolHttpData.dialog;
            dialog = json.dialog[i];
            obj["msg"] = dialog;
            arr.push(obj);
        }

        this.nexttel = tel.nexttel;
        this.history = arr;

        return arr;
    }

    /**处理接收到的数据，女主数据播放声音，男主数据则显示选择框 */
    private dealRevMsg(nexttel) {
        GameLog.log("JietongPanel >> 发送下一条数据:", nexttel);

        //没有消息，则不处理
        if (nexttel == null) {
            return;
        }

        //表示对话结束
        if (nexttel.length == 0) {
            App.data.game2Center.DataCenter.Tel.nexttel = [];
            App.data.game2Center.DataCenter.UserInfo.tel_main = true;//主事件完成
            App.data.game2Center.DataCenter.UserInfo.nextTel = false;
            this.getNewTel();
            //消息只有一条，表示女主说话
        } else if (nexttel.length == 1) {
            if (nexttel != this.oldMsg) {
                let obj = new Object();
                obj["msg"] = nexttel[0];
                this.addMsg(obj);
            }
            this.oldMsg = nexttel;

            //播放女主声音
            let url = nexttel[0].audio;
            this.msgType = nexttel[0];

            if (this.parent) {
                App.data.game2Center.TalkManager.playSound(url, this.onSoundComplete, this.onError, this.onLoaded, this);
            }
            //消息>=1条，表示我说话
        } else if (nexttel.length > 1) {
            this.showSelect(nexttel);
        }
    }

    //声音加载完成后，等待50ms，不主动播放的移动端web用户，显示喇叭，用户点击后播放声音
    private onLoaded() {
        if (DeviceUtil.isMobile && DeviceUtil.IsWeb) {
            //是否存在聊天框
            if (this._view.messageList.numChildren >= 1) {
                let item: MessageListItem = this._view.messageList.getChildAt(this._view.messageList.numChildren - 1) as MessageListItem;
                if (item) {
                    //等待50ms判断声音是否播放成功，不成功，则显示喇叭
                    egret.Tween.get(App.data.game2Center.TalkManager).wait(50).call(() => {
                        if (App.data.game2Center.TalkManager.channel && App.data.game2Center.TalkManager.channel.position == 0) {
                            item.leftMessage.showTalkAnim();
                            item.leftMessage.talkImg.once(egret.TouchEvent.TOUCH_TAP, this.tryPlaySound, this);
                        }
                    }, this);
                }
            }
        }
    }

    //尝试播放语音
    private tryPlaySound() {
        if (this.parent) {
            App.data.game2Center.TalkManager.tryPlaySound();
        }
        this.stopTryPlaySound();
    }

    //停止尝试播放语音
    private stopTryPlaySound() {
        egret.Tween.removeTweens(App.data.game2Center.TalkManager);
        if (this._view.messageList.numChildren >= 1) {
            let item: MessageListItem = this._view.messageList.getChildAt(this._view.messageList.numChildren - 1) as MessageListItem;
            if (item) {
                item.leftMessage.hideTalkAnim();
                item.leftMessage.talkImg.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.tryPlaySound, this);
            }
        }
    }

    /**选择回答后的处理 */
    private selectHandler(select: MessageSelectEnum) {
        //隐藏选择
        this.hideSelect();

        //选项在规定范围内
        if (select >= MessageSelectEnum.one && select <= MessageSelectEnum.four) {
            //发送的数据存在，this.nexttel不知哪里来的...
            if (this.nexttel[select] && this.nexttel[select].says) {
                //将我选择的话保存
                this.msgType = this.nexttel[select];
                let obj = new Object();
                obj["msg"] = this.msgType;
                this.addMsg(obj);

                //发送我说的话
                this.sendMessageTouch();
            }
        }
    }

    /**添加消息 */
    private addMsg(msg) {
        let tel = App.data.game2Center.DataCenter.Tel;

        if (this.ac && this.ac.length > 0) {
            if (this.ac.getItemAt(this.ac.length - 1).msg.says == msg.msg.says) {
                return;
            }
        }

        //防止和历史聊天记录最后一条重复
        if (this.history.length > 0) {
            if (this.history[this.history.length - 1].msg != msg.msg) {
                this.history.push(msg);
            }
        }


        //将说过的话放进历史记录
        if (App.data.game2Center.DataCenter.Tel && App.data.game2Center.DataCenter.Tel.history && App.data.game2Center.DataCenter.Tel.history.length > 0) {
            App.data.game2Center.DataCenter.Tel.history[0].dialog.push(msg["msg"]);
        }

        //添加聊天到数据源
        this.ac.addItem(msg);
        this.setScolltoEnd(true);
        App.sound.playSoundSwitchClient1(SoundManager.sent_msg);
    }

    /**
     * 延迟设置scroll到末尾
     */
    private setScolltoEnd(bUseTween: boolean = false) {
        App.timer.doTimeOnce(this, 100, this.scrollToEnd, [bUseTween])
    }

    /**
     * 设置scroll到末尾
     */
    private scrollToEnd(bUseTween: boolean): void {
        if (this._view.msgScroller.viewport.contentHeight > this._view.msgScroller.height) {
            let scrollV = this._view.msgScroller.viewport.contentHeight - this._view.msgScroller.height;
            if (bUseTween) {
                egret.Tween.get(this._view.msgScroller.viewport).to({ scrollV }, 200);
            }
            if (this._view.msgScroller.viewport)
                this._view.msgScroller.viewport.scrollV = scrollV;
        }
        ScrollerCenter.hideVerticalScrollBar(this._view.msgScroller);
    }

    /**发送点击点击 */
    private sendMessageTouch() {
        GameLog.log("JietongPanel >> 发送的话:", this.msgType);
        //this.bSending = true;
        //延迟1秒后，发送要说的话
        //this.timeID = setTimeout(() => {
        if (this.msgType && this.msgType.id) {
            let data = ProtocolHttp.chat;
            data.id = this.msgType.id;
            data.pid = this.msgType.pid;
            data.sid = this.msgType.sid;
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.chat, data, new FunctionVO(this.sendMsgBack, this));
        }
        //}, 1000);
    }

    //TODO  还未返回数据时，挂断并退出了界面，这个消息仍然会处理。引发bug。

    /**发送消息返回 */
    private sendMsgBack(data) {
        //this.bSending = false;
        if (data.code == 200) {
            App.data.game2Center.LoadingLock.lockScreen();
            App.timer.doTimeOnce(this, 1000, this.updateMessage, [data]);
        }
    }

    private updateMessage(data: any): void {
        App.data.game2Center.LoadingLock.unLockScreen();
        //显示和保存亲密度
        let heart = data.data.hearts;
        if (heart != 0) {
            TipsHeat.showHeat(heart);
            App.data.game2Center.DataCenter.UserInfo.hearts += heart;
            this.setHeart();
        }
        //有回复
        if (data.data.chat.length >= 1) {
            App.data.game2Center.DataCenter.Tel.nexttel = data.data.chat;
            this.nexttel = data.data.chat;

            if (App.data.game2Center.DataCenter.dianhuaGuide && this.nexttel.length == 1 && this.ac && this.ac.length == 2) {
                this.setHeartGuide();
            }
            else {
                this.dealRevMsg(this.nexttel);
            }
            //没有回复
        } else {
            this.nexttel = data.data.chat;
            App.data.game2Center.DataCenter.Tel.nexttel = [];
            App.data.game2Center.DataCenter.UserInfo.tel_main = true;//主事件完成
            App.data.game2Center.DataCenter.UserInfo.nextTel = false;

            this.getNewTel();
        }
    }

    /**引导拨打电话 */
    private reqFinishGuide() {
        let param = {};
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.guideDone, param, new FunctionVO(this.revFinishGuide, this));
    }

    /**引导完成返回 */
    private revFinishGuide(data) {
        if (data.code == 200) {
            App.data.game2Center.DataCenter.dianhuaGuide = false;
            App.data.game2Center.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
            App.data.game2Center.DataCenter.guide.emph_zone = data.data.emph_zone;
            App.data.game2Center.DataCenter.guide.video = data.data.video;

            //自动退出，并跳转到电话界面
            this.closePanel();
            App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
            App.timer.clearTimer(this, this.scrollToEnd);
            PanelOpenManager.openPanel(EnumPanelID.G2_DianhuaPanel, App.data.game2Center.DataCenter.UserInfo.tel_main);
        } else {
            Notice.showBottomCenterMessage(data.info);
        }
    }

    /**获取新的电话历史 */
    private getNewTel() {
        let data = {};
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.userChats, data, new FunctionVO(this.getTelBack, this));
    }

    /**获取电话历史返回 */
    private getTelBack(data) {
        GameLog.log(data);
        if (data.code == 200) {
            //更新微信
            let wechat = data.data.wechat;
            if (wechat) {
                App.data.game2Center.DataCenter.Wechat = wechat;
            }
            //更新电话
            let tel = data.data.tel
            if (tel) {
                App.data.game2Center.DataCenter.Tel = tel;
            }

            //TODO 如果是指引，则完成指引
            if (App.data.game2Center.DataCenter.ConfigInfo.days == 1) {
                this.reqFinishGuide();
            } else {
                //自动退出，并跳转到电话界面
                this.closePanel();
                App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
                App.timer.clearTimer(this, this.scrollToEnd);
                PanelOpenManager.openPanel(EnumPanelID.G2_DianhuaPanel, App.data.game2Center.DataCenter.UserInfo.tel_main);
            }
        }

    }

    //开始超时计时
    private startOverTimer() {
        App.timer.doTimeLoop(this, 1000, this.onTimer);
    }

    //停止超时计时
    private stopOverTimer() {
        this.count = 0;
        App.timer.clearTimer(this, this.onTimer);
    }

    /**每秒监听 */
    private onTimer() {
        this._view.timeLabel.text = StringTool.formatClock(this.count);
        this.count++
    }

    /**挂断按钮点击 */
    private guanduanTouch() {
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
        this.hideSelect();
        this.closePanel();
        PanelOpenManager.openPanel(EnumPanelID.G2_DianhuaPanel);
        App.timer.clearTimer(this, this.scrollToEnd);
        this._view.timeLabel.text = "00:00";
        App.data.game2Center.TalkManager.stopSound();
        this.stopTryPlaySound();
    }


    /**加载失败 */
    private onError() {
        //加载失败后，继续下一步，不影响游戏正常流程
        GameLog.log("JietongPanel >> 声音加载错误");
        Notice.showBottomCenterMessage("声音加载失败");
        this.onSoundComplete();
    }


    /*播放完成监听 */
    private onSoundComplete(): void {
        //egret.log("onSoundComplete");
        this.stopTryPlaySound();
        this.sendMessageTouch();
    }

    /**设置亲密度 */
    public setHeart() {
        this._view.heartPlugin.setJindu(App.data.game2Center.DataCenter.UserInfo.hearts, App.data.game2Center.DataCenter.ConfigInfo.hearts);
    }

    /**显示回答列表 */
    private showSelect(msg) {
        this.showGuide();
        if (this._view.yindaoGroup.visible) {
            this._view.yindaoGroup.touchEnabled = false;
            this._view.yindaoGroup.touchChildren = false;
        }
        this._view.selectGroup.visible = true;
        this._view.selectList.showMsg(msg);
        this._view.selectList.setOK(this.selectHandler, this);
    }

    /**隐藏回答列表 */
    private hideSelect() {
        this._view.yindaoGroup.touchEnabled = false;
        this._view.yindaoGroup.touchChildren = true;
        this.setGuide();
        this._view.selectGroup.visible = false;
    }

    /**-----------------引导相关 ----------------*/
    /**引导点击 */
    private yd_dianhuaImgTouch() {
        this._view.yindaoGroup.visible = false;
        egret.Tween.removeTweens(this._view.dianhuaHand);
    }

    /**引导 */
    private setGuide() {
        if (App.data.game2Center.DataCenter.dianhuaGuide && this.ac && this.ac.length <= 2) {
            egret.Tween.get(this._view.dianhuaHand, { loop: true })
                .set({ y: this.handY })
                .to({ y: this.handY - 40 }, 600)
                .to({ y: this.handY }, 800)
                .wait(100);

            // 暂时隐藏里面内容
            this._view.yindaoSGro.visible = false;
            this._view.yindaoHeart.visible = false;
        }
        else {
            this._view.yindaoSGro.visible = false;
            this._view.yindaoHeart.visible = false;
            this._view.yindaoGroup.visible = false;
        }
    }

    /**回复选项出来时，显示引导内容 */
    private showGuide() {
        if (App.data.game2Center.DataCenter.dianhuaGuide && this.ac && this.ac.length == 1) {
            this._view.yindaoGroup.visible = true;
            this._view.yindaoSGro.visible = true;
        }
    }

    /**心动值引导 */
    private setHeartGuide() {
        if (this.ac && this.ac.length != 2) {
            return;
        }
        this._view.yindaoGroup.visible = true;
        egret.Tween.get(this._view.dianhuaHand0, { loop: true })

            .set({ y: this.handYH })
            .to({ y: this.handYH - 40 }, 600)
            .to({ y: this.handYH }, 800)
            .wait(100);

        this._view.yindaoSGro.visible = false;
        this._view.yindaoHeart.visible = true;
    }

    /**心动值引导点击 */
    private yd_dianhuaImgTouchHeart() {
        this._view.yindaoGroup.visible = false;
        egret.Tween.removeTweens(this._view.dianhuaHand0);
        App.data.game2Center.DataCenter.dianhuaGuide = false;

        this.dealRevMsg(this.nexttel);
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }
}