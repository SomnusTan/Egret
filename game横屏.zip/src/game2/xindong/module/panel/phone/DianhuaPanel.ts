/**
 *电话面板
 * @author xiongjian
 * @date 2017/08/24
 */
class DianhuaPanel extends BasePanel {

    private _view: DianhuaPanelUI;
    public recData;

    private arr = []; //list数据
    /**list 控制器 */
    private ac: eui.ArrayCollection;
    /**详细数据 */
    private itemData = [];

    /**历史消息 */
    private history: any[];

    private handY: number;

    public constructor() {
        super();
    }

    protected init() {
        super.init();
        this._view = new DianhuaPanelUI();
        this.addChild(this._view);
    }

    public show(data: any = null) {
        super.show(data);

        this._view.girlName.fontFamily = "fzyc";
        this.handY = this._view.dianhuaHand.y;
        this.recData = data;
        this._view.grilImg.mask = this._view.maskImg;
        if (App.data.game2Center.DataCenter.Tel) {
            this._view.grilImg.source = App.data.game2Center.DataCenter.Tel.head;
        }

        this.initView();
        this._view.girlName.text = App.data.game2Center.DataCenter.ConfigInfo.girl_name;

        this._view.dianhuaList.addEventListener(eui.ItemTapEvent.ITEM_TAP, this.itemTouch, this);
        this._view.yd_dianhuaImg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_dianhuaImgTouch, this);

        CommomBtn.btnClick(this._view.backBtn, this.backTouch, this, 2);
        CommomBtn.btnClick(this._view.callBtn, this.callBtnTouch, this, 1);

        //从接通面板，完成通话事件后返回。recData保存着tel_main主事件
        //由于recData是持久化的，而不是在onEnable中作为参数传入，所以每次退出得清零...
        if (this.recData == true) {
            this.playBackBtnAnim();
        }
    }

    public hide() {
        super.hide();
        this._view.dianhuaList.removeEventListener(eui.ItemTapEvent.ITEM_TAP, this.itemTouch, this);
        this._view.yd_dianhuaImg.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.yd_dianhuaImgTouch, this);

        CommomBtn.removeClick(this._view.backBtn, this.backTouch, this);
        CommomBtn.removeClick(this._view.callBtn, this.callBtnTouch, this);

        egret.Tween.removeTweens(this._view.dianhuaHand);

        this.stopBackBtnAnim();
        this.recData = null;
    }

    /**拨号按钮监听 */
    private callBtnTouch() {
        PanelOpenManager.openPanel(EnumPanelID.G2_CallingPanel);
        PanelManager.removePanelByName(this.panelName);
    }

    /**item点击 */
    private itemTouch(e: eui.ItemTapEvent) {
        GameLog.log("item", e.itemIndex);
        let tel = App.data.game2Center.DataCenter.Tel;
        if (this.itemData) {
            let data = this.itemData[e.itemIndex];
            GameLog.log("data", data);
            PanelOpenManager.openPanel(EnumPanelID.G2_CallHistoryPanel, data);
            PanelManager.removePanelByName(this.panelName);
        }

    }

    /**引导拨打电话 */
    private yd_dianhuaImgTouch() {
        //隐藏二级引导
        this._view.yindaoGroup.visible = false;
        egret.Tween.removeTweens(this._view.dianhuaHand);
        // App.DataCenter.dianhuaGuide = false; 延后至选择答案
        //跳转界面
        PanelOpenManager.openPanel(EnumPanelID.G2_CallingPanel);
        PanelManager.removePanelByName(this.panelName);
    }

    // /**引导拨打电话 */
    // private yd_dianhuaImgTouch() {
    //     
    //     let param = {};
    //     ProtocolGame2.sendCommom(ProtocolHttpUrl.guideDone, param, this.finishGuideBack, this);
    // }

    // /**引导完成返回 */
    // private finishGuideBack(data) {
    //     if (data.code == 200) {
    //         this.yindaoGroup.visible = false;
    //         egret.Tween.removeTweens(this.dianhuaHand);
    //         App.DataCenter.dianhuaGuide = false;
    //         App.DataCenter.guide.fill_nick_name = data.data.fill_nick_name;
    //         App.DataCenter.guide.emph_zone = data.data.emph_zone;
    //         App.DataCenter.guide.video = data.data.video;
    //         App.PanelManager.open(EnumPanelID.G2_CallingPanel);
    //         PanelManager.removePanelByName(this.panelName);
    //     } else {
    //         Notice.showBottomCenterMessage("" + data.info);
    //     }
    // }

    /**返回按钮监听 */
    private backTouch() {
        PanelManager.removePanelByName(this.panelName);
        App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
    }

    private initView() {

        this.ac = new eui.ArrayCollection();
        this.arr = [];
        var data = this.setData();
        this.arr = data;
        this.ac.source = this.arr;
        this._view.dianhuaList.dataProvider = this.ac;
        this._view.dianhuaList.itemRenderer = CallListItem;
		ScrollerCenter.hideVerticalScrollBar(this._view.dianhuaScroller);

        //引导
        this.setGuide();
    }

    /**数据处理 */
    private setData() {
        let tel = App.data.game2Center.DataCenter.Tel;
        let replyId = 0;
        let arr = []
        this.itemData = [];
        GameLog.log("tel", tel);
        let history = tel.history;
        let nexttel = tel.nexttel;
        GameLog.log("nexttel", nexttel);
        if (nexttel && nexttel.length > 0) {
            this.showCallBtn(true);
        } else {
            this.showCallBtn(false);
        }

        let count = 1;
        for (let i = 0; i < history.length; i++) {
            if (history[i].dialog.length == 0) {
                continue;
            } else {
                //GameLog.log(count);
                let obj = new Object();
                obj["num"] = count;
                obj["history"] = history[i]
                if (history[i].dialog && history[i].dialog.length > 0) {
                    arr.push(obj);
                    this.itemData.push(history[i]);
                }
                count++;
            }

        }
        GameLog.log("arr", arr);
        return arr;
    }

    /**刷新数据 */
    private refresh(msg) {
        this.history.push(msg);
        let data = this.history;
        GameLog.log("refresh", data);
        this.arr = data;
        this.ac.source = this.arr;
    }


    /**显示拨打按钮 */
    private showCallBtn(boo: boolean) {
        if (boo) {
            this._view.callBtn.visible = true;
        } else {
            this._view.callBtn.visible = false;
        }

    }

    /**出场动画 */
    public outAnimation(finishCallback: Function = null) {

    }

    /**入场动画 */
    public enterAnimation() {

    }

    /**引导 */
    public setGuide() {
        if (App.data.game2Center.DataCenter.dianhuaGuide) {
            this._view.yindaoGroup.visible = true;
            egret.Tween.get(this._view.dianhuaHand, { loop: true })
                .set({ y: this.handY })
                .to({ y: this.handY - 40 }, 600)
                .to({ y: this.handY }, 800)
                .wait(100);
        }
    }

    private playBackBtnAnim() {
        egret.Tween.get(this._view.backBtn, { loop: true }).to({ scaleX: 1.15, scaleY: 1.15 }, 500).to({ scaleX: 1, scaleY: 1 }, 500);
    }

    private stopBackBtnAnim() {
        this._view.backBtn.scaleX = 1;
        this._view.backBtn.scaleY = 1;
        egret.Tween.removeTweens(this._view.backBtn);
    }

    public get width():number{
        return this._view.width;
    }

    public get height():number{
        return this._view.height;
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

}