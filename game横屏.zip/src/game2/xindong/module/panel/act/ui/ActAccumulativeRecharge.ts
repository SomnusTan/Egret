/**
 * 累计充值
 * @author lidan
 * @date 2018/3/20
 */

class ActAccumulativeRecharge extends eui.Component {
	private contentLabel: eui.Label;
	private yiLingquBtn: eui.Button;
	private lingquBtn: ActLingQuBtn;
	private idNum: number;
	public constructor() {
		super();
		this.skinName = "ActAccumulativeRechargeSkin";
	}

	public childrenCreated() {
		this.contentLabel.text = "";
	}

	//更新界面
	public updateView(data, index) {
		this.idNum = data.id;

		var showText: string = data.pay_money + "元  ";
		if (data.gift && data.gift.package) {
			var arr: any[] = data.gift.package;
			for (var i: number = 0; i < arr.length; i++) {
				showText += arr[i].cname + "*" + arr[i].num + "  ";
			}
		}
		this.contentLabel.text = showText;
		//奖励物品图片、名字、数量
		// switch (index) {
		// 	case 0:
		// 		this.contentLabel.text = "10元  心动碎片*3 体力*30 小蛋糕*5";
		// 		break;
		// 	case 1:
		// 		this.contentLabel.text = "50元  心动碎片*7 体力*60 巧克力*10 金币*3000 钻石*100";
		// 		break;
		// 	case 2:
		// 		this.contentLabel.text = "100元  心动碎片*10 体力*90 小公仔*5 金币*5000 钻石*300";
		// 		break;
		// 	case 3:
		// 		this.contentLabel.text = "198元  心动碎片*10 体力*120 玫瑰花*5 金币*10000 钻石*500";
		// 		break;
		// 	case 4:
		// 		this.contentLabel.text = "588元  心动碎片*20 体力*150 口红*5 金币*50000 1500钻石";
		// 		break;
		// }

		//领取状态
		let status = data.status;
		if (status == 1) {    //未领取，但是可领取
			this.yiLingquBtn.visible = false;
			this.lingquBtn.visible = true;
			this.lingquBtn.showRed(true);
			this.lingquBtn.btn.enabled = true;
			CommomBtn.btnClick(this.lingquBtn, this.reqLoginReward, this);
		} else if (status == -1) {  //已领取
			this.yiLingquBtn.visible = true;
			this.lingquBtn.visible = false;
		} else if (status == 0) {   //累计充值未够，不能领取
			this.yiLingquBtn.visible = false;
			this.lingquBtn.visible = true;
			this.lingquBtn.showRed(false);
			this.lingquBtn.btn.enabled = false;
			CommomBtn.removeClick(this.lingquBtn, this.reqLoginReward, this);
		}
	}

	//请求领取当条的奖励
	private reqLoginReward() {
		GameLog.log("DayRewardUI >> 请求第" + this.idNum + "条奖励");
		
		let params = { "tid": this.idNum };
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.getTotal_pay, params, new FunctionVO(this.revLoginReward, this));
	}

	//接收领取当条的奖励
	private revLoginReward(data) {
		if (data.code == 200) {
			//更新领取按钮
			this.yiLingquBtn.visible = true;
			this.lingquBtn.visible = false;

			//更新本地数据为已领取
			let total_payData = App.data.game2Center.DataCenter.total_pay;
			let len = total_payData.rewards.length;
			for (let i = 0; i < len; i++) {
				let rewardData = total_payData.rewards[i];
				if (this.idNum == rewardData.id) {
					total_payData.rewards[i].status = -1;
					App.data.game2Center.DataCenter.total_pay.rewards[i].status = -1;
					break;
				}
			}

			//判断是否还有登录有奖可以领取
			App.data.game2Center.DataCenter.accumulative_recharge = 0;
			for (let i = 0; i < len; i++) {
				let rewardData = total_payData.rewards[i];
				if (rewardData.status == 1) {
					App.data.game2Center.DataCenter.accumulative_recharge = 1;
					break;
				}
			}

			//更新背包
			App.dispatcher.dispatchEvent(EventConst.REQ_UPDATE_BAGS);

			//更新四维
			App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
			App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
			App.data.game2Center.DataCenter.UserInfo.power = data.data.power;
			App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);

			//更新标签
			App.dispatcher.dispatchEvent(EventConst.BUY_MONTH_CARDS_SUCCESS);
		}
	}


	//销毁
	public destoryMe() {
		this.parent && this.parent.removeChild(this);
		// this.rewardImgList.length = 0;
		// this.rewardLabelList.length = 0;
		// CommomBtn.removeClick(this.lingquBtn, this.reqLoginReward, this);
	}
}