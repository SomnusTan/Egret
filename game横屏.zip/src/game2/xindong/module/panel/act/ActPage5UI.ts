/**
 * 累计充值
 * @author lidan
 * @date 2018/3/20
 */
class ActPage5UI extends eui.Component {
	public scroller: eui.Scroller;
	public scrollerGroup: eui.Group;
	public contentLabel: eui.Label;

	private sDate: string;//开始时间
	private eDate: string;//结束时间


	public constructor() {
		super();
		this.skinName = "ActPage5UISkin";
	}

	public show(data?:any):void{
		
	}

	//更新界面  累计充值后台配置，奖励的UI数量可能会变化。
	public updateView() {
		let data = App.data.game2Center.DataCenter.total_pay;
		GameLog.log(data);
		this.sDate = this.getDate(data.sdate);
		this.eDate = this.getDate(data.edate);

		//奖励的数量
		let len = data.rewards.length;

		//soeasy某些渠道屏蔽qq号
		if (Config.soEasy && SoEasySdk.shieldChannel()) {
			App.data.game2Center.DataCenter.actAwardInfo.content = App.data.game2Center.DataCenter.actAwardInfo.content.replace("QQ：202963048", "");
		}
		var rules: string;
		if (len > 0) {
			rules = StringUtil.substitute(App.data.game2Center.DataCenter.actAwardInfo.content, data.rewards[len - 1].pay_money);
		} else {
			rules = StringUtil.substitute(App.data.game2Center.DataCenter.actAwardInfo.content, 1288);
		}
		this.contentLabel.text = "活动时间：" + this.sDate + "-" + this.eDate + "\n" + rules;

		//清理原有UI
		let oldUI: ActAccumulativeRecharge;
		let childNum = this.scrollerGroup.numChildren;
		for (let i = childNum - 1; i >= 1; i--) {
			oldUI = this.scrollerGroup.getChildAt(i) as ActAccumulativeRecharge;
			oldUI.destoryMe();
		}

		//创建新的UI
		let rewardUI: ActAccumulativeRecharge;
		for (let i = 0; i < len; i++) {
			rewardUI = new ActAccumulativeRecharge();
			this.scrollerGroup.addChild(rewardUI);
			rewardUI.updateView(data.rewards[i], i);
		}
		if (this.scroller && this.scroller.verticalScrollBar) {
			this.scroller.verticalScrollBar.autoVisibility = false;
			this.scroller.verticalScrollBar.visible = false;
		}
	}

	private getDate(DateStr: string) {
		let iStart = this.find(DateStr, ".", 1);
		let eStart = this.find(DateStr, ".", 2);
		let i = eStart - iStart - 1;
		let monStr = DateStr.substr(iStart + 1, i);
		let dayStr = DateStr.substr(eStart + 1);

		let findMonthZero = monStr.indexOf("0");
		let findDayZero = dayStr.indexOf("0");
		if (findMonthZero == 0) {
			monStr = monStr.substr(findMonthZero + 1);
		}
		if (findDayZero == 0) {
			dayStr = dayStr.substr(findDayZero + 1);
		}
		let dateStr = monStr + "月" + dayStr + "日";
		return dateStr;
	}

    /*str:字符串
	*cha:查找的字符
	*num:字符第几次出现的位置
	*/
	private find(str: string, cha: string, num: number) {
		var x = str.indexOf(cha);
		let realNum = num - 1;
		for (var i = 0; i < realNum; i++) {
			x = str.indexOf(cha, x + 1);
		}
		return x;
	}

	public dispose(): void {
		let oldUI: ActAccumulativeRecharge;
		let childNum = this.scrollerGroup.numChildren;
		for (let i = childNum - 1; i >= 1; i--) {
			oldUI = this.scrollerGroup.getChildAt(i) as ActAccumulativeRecharge;
			oldUI.destoryMe();
		}
	}
}