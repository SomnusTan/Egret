class ActPage7UI extends eui.Component {
	public imgBg: eui.Image;
	public txtPrice: eui.Label;
	public btnBuy: eui.Button;
	public txtTime: eui.Label;
	public txtBaught: eui.Label;

	public constructor() {
		super();
		this.skinName = "ActPage7UISkin";
		this.btnBuy.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBuy, this);
	}

	public show(data: any): void {
		var offer: any = App.data.game2Center.DataCenter.offer;
		this.btnBuy.visible = !offer.is_shop_good;
		this.txtBaught.visible = !this.btnBuy.visible;
		this.txtPrice.text = offer.balance_money + "心动币！";
		this.imgBg.source = offer.image;
		if (offer.start_time && offer.stop_time) {
			this.txtTime.text = "优惠活动时间：" + StringUtil.format(new Date(offer.start_time * 1000), "Y年M月D日") + " - " + StringUtil.format(new Date(offer.stop_time * 1000), "Y年M月D日");
		} else if (offer.start_time == 0 && offer.stop_time) {
			App.timer.serverTimeEnd(this, this.onActTimer, offer.stop_time);
		} else {
			this.txtTime.text = "优惠时间永久有效";
		}
	}

	private onActTimer(data: ServerTimeData): void {
		if (data.spuleTime > 0) {
			this.txtTime.text = "优惠时间剩余 " + StringUtil.formatLeftTimeDHM(data.spuleTime);
		} else {
			App.dispatcher.dispatchEvent(EventConst.REFRESH_ACT7PAGE);
			App.timer.clearTimer(this, this.onActTimer);
		}
	}

	private onBuy(e: egret.TouchEvent) {
		PanelOpenManager.openPanel(EnumPanelID.G2_ShopGiftToolPanel, 1);
		PanelOpenManager.removePanel(EnumPanelID.G2_ActPanel);
	}

	public dispose(): void {
		App.timer.clearTimer(this, this.onActTimer);
		this.btnBuy.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onBuy, this);
	}


}