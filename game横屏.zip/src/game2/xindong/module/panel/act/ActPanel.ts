/**
 * 活动中心
 * @author chenkai
 * @date 2017/11/27
 */
class ActPanel extends BasePanel {
	private _view: ActPanelUI;

	private radioBtn: eui.RadioButton;   //单选按钮
	private radioList;                   //单选按钮数组
	private _data: any;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new ActPanelUI();
		this.addChild(this._view);
		for (var i: number = 0; i < 8; i++) {
			this._view["page" + i].visible = false;
		}
		this._view.radioScroller.visible = false;
		this.radioList = [this._view.radioBtn0, this._view.radioBtn1, this._view.radioBtn2, this._view.radioBtn3, this._view.radioBtn4,
		this._view.radioBtn5, this._view.radioBtn6, this._view.radioBtn7, this._view.radioBtn8];
	}

	public show(data?: any): void {
		super.show(data);
		this._data = data;
		//按钮监听
		this._dispatcher.addEventListener(eui.UIEvent.CHANGE, this.onPageChange, this, this._view.radioBtn0.group);
		CommomBtn.btnClick(this._view.closeBtn, this.onCloseTouch, this);
		//月卡购买成功
		this._dispatcher.addEventListener(EventConst.BUY_MONTH_CARDS_SUCCESS, this.updateView, this);
		this._dispatcher.addEventListener(EventConst.UPDATE_ACT_VIEW6, this.updateView6, this);
		this._dispatcher.addEventListener(EventConst.REFRESH_ACT7PAGE, this.showUpdateData, this);
		this.showUpdateData();
	}

	private showUpdateData(): void {
		if (App.data.game2Center.DataCenter.offer && App.data.game2Center.DataCenter.offer.stop_time > ServerTime.serverTime) {
			this.updataData(7);
		} else {
			this.updataData();
		}
	}

	private updataData(page: number = -1): void {
		this._view.radioScroller.visible = true;
		//刷新界面
		var pay: boolean = App.data.game2Center.DataCenter.total_pay && App.data.game2Center.DataCenter.total_pay.onoff == 1;
		var month: boolean = App.data.game2Center.DataCenter.month_cards && App.data.game2Center.DataCenter.month_cards.onoff == 1;
		var b: boolean = this._data != null && (pay || month);//此值为true，会执行下面切页的逻辑有跳转页面
		this.updateView(!b);
		if (page == -1) {
			this._view.radioBtn7.parent && this._view.radioBtn7.parent.removeChild(this._view.radioBtn7);
		} else {
			(this._view.radioScroller.getChildAt(0) as eui.Group).addChildAt(this._view.radioBtn7, 0);
		}
		var announcement: any = App.data.game2Center.DataCenter.announcement;//联动活动
		if (!announcement || announcement.length == 0) {
			this._view.radioBtn8.parent && this._view.radioBtn8.parent.removeChild(this._view.radioBtn8);
		} else {
			(this._view.radioScroller.getChildAt(0) as eui.Group).addChildAt(this._view.radioBtn8, 0);
		}
		if (this._view.radioBtn8 && this._view.radioBtn8.parent) {//联动活动
			this.switchPage(8);
		} else {
			if (this._data != null) {//切页
				//累计充值开启
				if (page != -1) {
					this.switchPage(page);
				} else if (App.data.game2Center.DataCenter.total_pay && App.data.game2Center.DataCenter.total_pay.onoff == 1) {
					this.switchPage(5);
				} else if (App.data.game2Center.DataCenter.month_cards && App.data.game2Center.DataCenter.month_cards.onoff == 1) {
					this.switchPage(6);
				} else {
					this.switchPage(this._data);
				}
			}
		}
	}

	public hide() {
		super.hide();
		this._view.page6.hide();
		CommomBtn.removeClick(this._view.closeBtn, this.onCloseTouch, this);
	}

	/**更新界面 */
	public updateView(need: boolean = true) {
		this._view.validateNow();
		//菜单按钮红点提示  (red是写在exml里的红点图片id)
		this._view.radioBtn0["red"].visible = (App.data.game2Center.DataCenter.login_reward == LoginRewardStatus.RedTip) ? true : false;
		this._view.radioBtn2["red"].visible = !App.data.game2Center.DataCenter.first_gift;
		this._view.radioBtn3["red"].visible = App.data.game2Center.DataCenter.isPower;
		this._view.radioBtn5["red"].visible = (App.data.game2Center.DataCenter.accumulative_recharge == 1) ? true : false;
		if (App.data.game2Center.DataCenter.month_cards) {
			this._view.radioBtn6["red"].visible = (App.data.game2Center.DataCenter.month_cards.month_cards == 1 || App.data.game2Center.DataCenter.month_cards.month_cards == 0) ? true : false;
		}

		//隐藏左侧不需要再显示的菜单按钮
		//登录有奖
		var showFirstPage: boolean;
		if (App.data.game2Center.DataCenter.login_reward == LoginRewardStatus.HideBtn) {
			this._view.radioBtn0.parent && this._view.radioBtn0.parent.removeChild(this._view.radioBtn0);
			showFirstPage = true;
		}
		//首冲礼包
		if (App.data.game2Center.DataCenter.first_gift == true) {
			this._view.radioBtn2.parent && this._view.radioBtn2.parent.removeChild(this._view.radioBtn2);
			showFirstPage = true;
		}

		//兑换码开关	
		if (ClientConfig.inviteCode == 0) {
			this._view.radioBtn4.parent && this._view.radioBtn4.parent.removeChild(this._view.radioBtn4);
			showFirstPage = true;                    
		}

		//累计充值
		if (App.data.game2Center.DataCenter.accumulative_recharge == -1 || App.data.game2Center.DataCenter.total_pay.onoff == 0) {
			this._view.radioBtn5.parent && this._view.radioBtn5.parent.removeChild(this._view.radioBtn5);
			showFirstPage = true;
		}
		if (App.data.game2Center.DataCenter.total_pay && App.data.game2Center.DataCenter.total_pay.onoff == 1) {
			this._view.page5.updateView();   //累计充值
		}

		//月卡
		if (!App.data.game2Center.DataCenter.month_cards || (App.data.game2Center.DataCenter.month_cards && App.data.game2Center.DataCenter.month_cards.onoff == 0)) {
			this._view.radioBtn6.parent && this._view.radioBtn6.parent.removeChild(this._view.radioBtn6);
			showFirstPage = true;
		}
		if (App.data.game2Center.DataCenter.month_cards && App.data.game2Center.DataCenter.month_cards.onoff == 1) {
			this._view.page6.updateView();
		}

		//IOS屏蔽月卡
		// if (App.DeviceUtils.IsIos && App.DeviceUtils.IsNative) {
		// 	this.radioBtn6.parent && this.radioBtn6.parent.removeChild(this.radioBtn6);
		// 	this.switchFirstPage();
		// }

		// IOS审核包，需要隐藏礼包兑换
		if (DeviceUtil.IsIos) {
			// this.radioBtn4.parent && this.radioBtn4.parent.removeChild(this.radioBtn4);
			showFirstPage = true;
		}

		//页面更新
		this._view.page0.updateView();   //登录有奖
		this._view.page1.updateView();   //首冲双倍
		this._view.page2.updateView();   //首冲礼包
		this._view.page3.updateView();   //免费体力

		if (!DeviceUtil.IsIos) {
			this._view.page4.updateView();   //礼包兑换
		}

		if (need && showFirstPage) this.switchFirstPage();

		ScrollerCenter.hideVerticalScrollBar(this._view.radioScroller);

		//更新活动中心外标签
		App.dispatcher.dispatchEvent(EventConst.UPDATE_RED_TIP);
	}

	/**月卡功能领取后页面停留在月卡 */
	public updateView6() {
		this.switchPage(6);
		this._view.radioBtn6["red"].visible = (App.data.game2Center.DataCenter.month_cards.month_cards == 1 || App.data.game2Center.DataCenter.month_cards.month_cards == 0) ? true : false;
		this._view.page6.updateView();
	}

	/**点击单选按钮 切换页面 */
	private onPageChange(e: eui.UIEvent) {
		App.sound.playSoundSwitchClient1(SoundManager.button);
		let group: eui.RadioButtonGroup = e.target;
		this.switchPage(group.selectedValue);
	}

	/**切换页面 */
	public switchPage(page) {
		//如果该页面存在，才会切换页面。否则切换到当前存在的第一页
		if (this.radioList[page].parent) {
			this._view.radioBtn0.group.selectedValue = page;
			this._view.viewStack.selectedIndex = page;
			this._view["page" + page].visible = true;
			this._view["page" + page].show();
		} else {
			this.switchFirstPage();
		}
	}

	/**切换到第一页 某些任务在完成后会消失，所以需要判断谁在第一页*/
	private switchFirstPage() {
		this._view.validateNow();
		let len = this.radioList.length;
		for (let i = 0; i < len; i++) {
			if (this.radioList[i].parent) {
				this.switchPage(i);
				break;
			}
		}
	}

	/**关闭页面 */
	private onCloseTouch() {
		this.closePanel();
		//关闭后，可能因为领取了登录奖励，达到了升级条件，所以需要判断是否升级
		App.dispatcher.dispatchEvent(EventConst.CHECK_UPGRADE);
	}

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}

	public dispose(): void {
		if (this._view) {

			this._view.page0.dispose();
			this._view.page1.dispose();
			this._view.page2.dispose();
			this._view.page3.dispose();
			this._view.page4.dispose();
			this._view.page5.dispose();
			this._view.page6.dispose();
			this._view.page7.dispose();
			this._view.page8.dispose();

			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

}