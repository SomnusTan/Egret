class ActPage8UI extends eui.Component {
	public contentLabel: eui.Label;

	public constructor() {
		super();
		this.skinName = "ActPage8UISkin";
	}

	public show(data?: any): void {
		var announcement: any = App.data.game2Center.DataCenter.announcement;
		if (announcement && announcement.length > 0) {
			this.contentLabel.text = announcement[0].depict;
		}
	}

	public dispose(): void {
	}
}