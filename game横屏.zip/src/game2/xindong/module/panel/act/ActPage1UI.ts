/**
 * 首冲双倍
 * @author chenkai
 * @date 2017/11/27
 */
class ActPage1UI extends eui.Component {
	private chongzhiBtn: eui.Button;   //充值按钮
	private dateLabel: eui.Label;      //活动时间

	public constructor() {
		super();
		this.skinName = "ActPage1UISkin";
	}

	public show(data?:any):void{
		
	}

	public childrenCreated() {
		CommomBtn.btnClick(this.chongzhiBtn, this.onChongZhi, this);
	}

	//充值
	private onChongZhi() {
		//关闭活动中心
		PanelOpenManager.removePanel(EnumPanelID.G2_ActPanel);
		//跳转到商城充值页面
		// App.PanelManager.open(EnumPanelID.G2_ShopPanel, ShopPage.Diamond);

		PanelOpenManager.openPanel(EnumPanelID.G2_ShopDiamondPanel, null, false);
	}

	/**更新视图 */
	public updateView() {
		this.dateLabel.text = "活动时间:" + App.data.game2Center.DataCenter.act_decade.sdate + "-" + App.data.game2Center.DataCenter.act_decade.edate;
	}

	public dispose(): void {
		CommomBtn.removeClick(this.chongzhiBtn, this.onChongZhi, this);
	}
}