/**
 * 礼包兑换
 * @author chenkai
 * @date 2017/11/27
 */
class ActPage4UI extends eui.Component {
	private okBtn: eui.Button;             //确认
	private inputLabel: eui.TextInput;  //兑换码输入

	public constructor() {
		super();
		this.skinName = "ActPage4UISkin";
	}

	public show(data?: any): void {
		if (this.inputLabel.textDisplay) {
			this.inputLabel.textDisplay.size = 50;
			this.inputLabel["textTemp"].size = 50;
		}
		InputTextUtil.addNativeInputTextListener(this.inputLabel);
	}

	public childrenCreated() {
		this.inputLabel.text = "";
		if (this.inputLabel.textDisplay)
			this.inputLabel.textDisplay.size = 50;
		CommomBtn.btnClick(this.okBtn, this.reqInviteGain, this);
	}

	public updateView() {
		this.inputLabel.text = "";
	}

	//请求兑换
	private reqInviteGain() {
		if (this.inputLabel.text == Config.GM_KEY) {
			Notice.showBottomCenterMessage("您已经变成GM了");
			Config.skipVideo = true;
			this.resetText();
			return;
		}
		let param = { "code": this.inputLabel.text };
		ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.inviteGain, param, new FunctionVO(this.revInviteGain, this));
	}

	//返回兑换结果
	private revInviteGain(data) {
		if (data.code == 200) {
			App.data.game2Center.DataCenter.UserInfo.gold = data.data.gold;
			App.data.game2Center.DataCenter.UserInfo.power = data.data.power;
			App.data.game2Center.DataCenter.UserInfo.diamond = data.data.diamond;
			App.data.game2Center.DataCenter.UserInfo.hearts = data.data.hearts;

			App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);
			Notice.showBottomCenterMessage("兑换成功，奖励已放入背包中");
		} else {
			Notice.showBottomCenterMessage(data.info);
		}
		this.resetText();
	}

	private resetText(): void {
		if (DeviceUtil.IsNative) {
			this.inputLabel.text = " ";
			this.inputLabel["textTemp"].text = " ";
			App.timer.doFrameOnce(this, 1, () => {
				this.inputLabel.text = " ";
			});
		}
		else {
			this.inputLabel.text = "";
		}
	}

	public dispose(): void {
		CommomBtn.removeClick(this.okBtn, this.reqInviteGain, this);
		InputTextUtil.removeNativeInputTextListener(this.inputLabel);
	}

}