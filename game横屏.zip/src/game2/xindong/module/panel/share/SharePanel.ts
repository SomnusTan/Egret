/**
 * 分享面板
 */
class SharePanel extends BasePanel {

	private _view: SharePanelUI;

	public constructor() {
		super();
	}

	protected init(): void {
		super.init();
		this._view = new SharePanelUI();
		this.addChild(this._view);
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = null;
		}
		super.dispose();
	}

	public show(data?: any): void {
		super.show(data);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchTap, this, this);
	}

	public hide(): void {
		super.hide();
	}

	private onTouchTap(e: egret.TouchEvent) {
		switch (e.target) {
			case this._view.weiboBtn:    //微博
				break;
			case this._view.qqBtn:       //QQ
				break;
			case this._view.zoneBtn:     //QQ空间
				break;
			case this._view.weixinBtn:   //微信
				break;
			case this._view.friendBtn:   //朋友圈
				break;
			case this._view.closeBtn:    //关闭
				this.hide();
				break;
			case this._view.okBtn:      //确认
				this.onShare();
				break;
		}
	}

	private onShare() {
		this.hide();

		//7k7k分享
		var auth_7k7k = window["auth_7k7k"];
		if (auth_7k7k) {
			let K7_SDK = window["K7_SDK"];
			K7_SDK.wxShare({
				title: '心动女生',
				desc: '与女神来一场轰轰烈烈的爱情吧！',
				custom: '{user:"yafet"}',
				imgUrl: 'http://www.dmgame.com:3000/xdns.png',
				isUseGuide: 'yes'
			});
		}

	}

	public get width(): number {
		return this._view.width;
	}

	public get height(): number {
		return this._view.height;
	}
}