/**
 * dlc中的额外剧情panel中的进入简介info
 * 
 * @author suyuanyang
 * @date 2018/03/13
 */
class DlcMainDoc extends BasePanel {

    private _view: DlcMainDocUI;

    //滑动列表的一些参数
    private isOnLoop: boolean = false;
    private indexScrllHArr: number[] = [];
    private endSocllH: number = 1280 * 5;
    private startTouch: number;
    private endTouch: number;
    private indexSC: number = 0;
    private stateTouch: number;
    private stateNum: number;
    private showTitles: any[] =
    [
        {
            "id": 0,
            "title": "比赛信息",
            "source": "dlc_doc_p1_jpg",
            "comeUrl": "http://www.szxinchenglong.com"
        },
        {
            "id": 1,
            "title": "《闲玩S》 诚招合作伙伴了！",
            "source": "dlc_doc_p2_jpg",
            "comeUrl": "http://www.szxinchenglong.com"
        },
        {
            "id": 2,
            "title": "公      告",
            "source": "dlc_doc_p3_jpg",
            "comeUrl": "http://www.szxinchenglong.com"
        },
        {
            "id": 3,
            "title": "分享朋友圈，免费参赛！",
            "source": "dlc_doc_p4_jpg",
            "comeUrl": "http://www.szxinchenglong.com"
        },
        {
            "id": 4,
            "title": "分享朋友圈，免费参赛！",
            "source": "dlc_doc_p5_jpg",
            "comeUrl": "http://www.szxinchenglong.com"
        }
    ];


    public constructor() {
        super();
    }
    protected init(): void {
        super.init();
        this._view = new DlcMainDocUI();
        this.addChild(this._view);
    }

    /**初始化 */
    public show(data?: any): void {
        super.show(data);
        this._view.showScroller.visible = false;
        this._view.showIndexGrp.visible = false;
        this._view.showScroller.throwSpeed = 0;
        // StageUtils.getInstance().fullSomeToStage(this._view.showScroller);
        //灯数据
        this.showSomeIndexLight(this.indexSC);
        //页
        this._view.finditemGrp.removeChildren();
        for (let i: number = 0; i < this.showTitles.length; i++) {
            let grp: eui.Group = new eui.Group();
            let fitem: eui.Image = new eui.Image();
            fitem.source = this.showTitles[i].source;
            fitem.top = fitem.bottom = fitem.left = fitem.right = 0;
            //
            grp.width = 1280;
            grp.x = 1280 * i;
            // grp.height = this.finditemGrp.height;
            grp.addChild(fitem);
            grp.touchEnabled = true;
            grp.touchChildren = false;
            this._view.finditemGrp.addChild(grp);
            grp.top = grp.bottom = 0;
            grp.name = i + "";
            this.indexScrllHArr.push((1280) * i);

        }
        this.stateNum = 0;
        // egret.Tween.get(this, { loop: true }).wait(3000).call(this.autoMoveFunc);
        //
        this.addEvent();
    }

    public hide(): void {
        super.hide();

    }

    /**
     * 自动移动定时
     */
    private autoMoveFunc(): void {
        if (this.indexSC == (this.indexScrllHArr.length - 1)) {
            this.rightConOne();
        }
        let decN: number = (this.indexScrllHArr[(this.indexSC + 1) % this.indexScrllHArr.length]);
        egret.Tween.get(this._view.showScroller.viewport)
            .to({
                scrollH: decN
            }, 200);
        this.indexSC++;
        if (this.indexSC == 5) {
            this.indexSC = 0;
        }
        this.showSomeIndexLight(this.indexSC);
    }

    /**滑动时页面的变化 */
    private showSomeIndexLight(index: number): void {
        for (let i = 0; i < this._view.showIndexGrp.numChildren; i++) {
            let indexImage: eui.Image = this._view.showIndexGrp.getChildAt(i) as eui.Image;
            if (i == index) {
                indexImage.source = "dlc_select_icon_png";
            } else {
                indexImage.source = "dlc_unselect_icon_png";
            }
        }
    }

    private changeEnd(): void {
        if (!this.startTouch || !this.endTouch) {
            return;
        }
        let difNum: number = this.startTouch - this.endTouch;
        if (difNum < -100) {
            //right
            if (this.isOnLoop) {
                if (this.indexSC == 0) {
                    this.indexSC = 5;
                }
                this.indexSC = (this.indexSC - 1) % 5;
            } else {
                if (this.indexSC > 0) {
                    this.indexSC--;
                }
            }
        } else if (difNum > 100) {
            //left
            if (this.isOnLoop) {
                this.indexSC = (this.indexSC + 1) % 5;
            } else {
                if (this.indexSC < 4) {
                    this.indexSC++;
                }
            }
        }
        this.startTouch = this.endTouch = null;
        this.showSomeIndexLight(this.indexSC);

        egret.Tween.removeTweens(this._view.showScroller.viewport);
        egret.Tween.get(this._view.showScroller.viewport).to({ scrollH: this.indexScrllHArr[this.indexSC] }, 200).call(function () {
            GameLog.log("moveEnd");
        });
        this.stateTouch = 1;
        this.stateNum++;
        if (this.stateNum == 100) {
            this.stateNum = 1;
        }
        GameLog.log(this.stateNum);
        GameLog.log(this.stateTouch);
    }

    private change(e: eui.UIEvent): void {
        if (this._view.showScroller.viewport.scrollH == 0) {
            this.leftConOne();
        } else if (this._view.showScroller.viewport.scrollH == this.endSocllH) {
            this.rightConOne();
        }
    }

    private touchHandle(e: egret.TouchEvent): void {
        if (this.stateNum == 0 || (this.stateNum > 0 && this.stateTouch == 1)) {
            switch (e.type) {
                case egret.TouchEvent.TOUCH_BEGIN:
                    this.startTouch = e.stageX;
                    break;
                case egret.TouchEvent.TOUCH_MOVE:
                    this.endTouch = e.stageX;
                    break;
            }
        }
    }

    private touchHandleButton(e: egret.TouchEvent): void {
        switch (e.target) {
            case this._view.backBtn:
                this.closePanel();
                App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
                break;
            case this._view.gotoShop:
                ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.dlc_getChapters, { Authorization: App.data.game2Center.DataCenter.skey }, new FunctionVO((data: dlc_getChapters_S) => {
                    GameLog.log("data->" + data);
                    if (data.code == 200) {
                        ProtocolHttpData.dlc_chaptersData = data;
                        ProtocolHttpData.dlc_ChatStartInfo = data.data.story;
                        ProtocolGame2.instance().send_extra_chapters_fragment_exchange(new FunctionVO(this.onExtraBack, this));
                        return;
                    }
                    let dialog: DlcConfirmDialog = new DlcConfirmDialog();
                    dialog.setBuyLove(data.info);
                    dialog.show();
                }, this));
                break;
        }
    }

    private onExtraBack(data: any): void {
        if (data.code == 200) {
            if (data.info) {
                var d: any = JSON.parse(data.info);
                if (d.sun_number) {
                    var getItem: GetItemNotice = new GetItemNotice();
                    getItem.setCallBack(new FunctionVO(this.enterDLC, this));
                    getItem.setData("已开启心动之旅，将剩余的心动碎片 x" + d.sun_number + " 兑换为", d.add_diamond, 2);
                    getItem.show();
                } else {
                    this.enterDLC();
                }
            }
        }
    }

    private enterDLC(): void {
        PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainPanel);
        this.closePanel();
    }

    /**
     * 左移动一个
     */
    private leftConOne(): void {
        let firstItem: eui.Group = this._view.finditemGrp.getChildAt(0) as eui.Group;
        // let endItem: eui.Group = this.finditemGrp.getChildAt(this.finditemGrp.numChildren - 1) as eui.Group;
        this._view.finditemGrp.removeChild(firstItem);
        this._view.finditemGrp.addChild(firstItem);
        this._view.showScroller.viewport.scrollH = this.endSocllH;
        //数据
        let firstAnyData: any = this.showTitles.shift();
        this.showTitles.push(firstAnyData);
    }
    /**
     * 右移动一个
     */
    private rightConOne(): void {
        let endItem: eui.Group = this._view.finditemGrp.getChildAt(this._view.finditemGrp.numChildren - 1) as eui.Group;
        this._view.finditemGrp.removeChild(endItem);
        this._view.finditemGrp.addChildAt(endItem, 0);
        this._view.showScroller.viewport.scrollH = 0;
        //数据
        let endAnyData: any = this.showTitles.pop();
        this.showTitles.unshift(endAnyData);
    }

    /**监听事件 */
    public addEvent(): void {
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandleButton, this, this);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchHandle, this, this._view.showScroller);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.touchHandle, this, this._view.showScroller);
        this._dispatcher.addEventListener(eui.UIEvent.CHANGE_END, this.changeEnd, this, this._view.showScroller);
        // this.showScroller.addEventListener(eui.UIEvent.CHANGE, this.change, this);
    }

    public enableTouch() {
        this.touchEnabled = true;
        this.touchChildren = true;
    }

    public disableTouch() {
        this.touchChildren = false;
        this.touchEnabled = false;
    }

    /**
     * 销毁
     */
    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
        try {
            egret.Tween.removeTweens(this);
        }
        catch (e) {

        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}