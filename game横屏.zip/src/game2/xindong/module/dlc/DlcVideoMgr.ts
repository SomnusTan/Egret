/**
 * dlc 模块下的视频管理器
 * 
 */
class DlcVideoMgr {
    /**关闭视频 */
    public static stopVideo(): void {

    }
    /**
     * 
     * 播放视频
     */
    public static playVideoByUrl(d: string, callBack: FunctionVO = null): void {
        let param = { ossvid: d };
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.videoUrl, param, new FunctionVO((e) => {
            App.dispatcher.dispatchEvent(EventConst.PLAY_WEB_VIDEO, e.data.url, callBack ? callBack : new FunctionVO(this.onPlayVideoComplete, this), EnumVideoType.XIN_DONG1);
        }, this));
    }

    private static onPlayVideoComplete(): void {
        Video.instance().dispose();
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
    }
}