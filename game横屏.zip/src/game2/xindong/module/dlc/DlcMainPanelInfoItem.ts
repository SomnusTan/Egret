/**
 * dlc中的额外剧情panel中的章节信息item info
 * 
 * @author suyuanyang
 * @date 2018/03/13
 */
class DlcMainPanelInfoItem extends eui.Component {
    private showOffImg: eui.Group;
    private title: eui.Label;
    private bgImg: eui.Image;
    //
    private showInfoImg: eui.Group;
    private rectMarsk: eui.Image;
    private showBg: eui.Image;
    private rectMa: eui.Rect;
    //
    private dataInfo: ChapterDetail;
    //
    constructor(dataInfo: ChapterDetail) {
        super();
        this.skinName = "DlcMainPanelInfoItemSkin";
    }

    protected childrenCreated(): void {
        super.childrenCreated();
        this.showBg.mask = this.rectMa;
        this.addEvent();
    }

    public update(dataInfo:ChapterDetail):void{
        this.dataInfo = dataInfo;
        this.setDataInfo(this.dataInfo);
    }

    private addEvent(): void {
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandle, this);
    }

    private touchHandle(e: egret.TouchEvent): void {
        switch (e.target) {
            case this.showInfoImg:
                App.dispatcher.dispatchEvent(EventConst.SHOW_IMG_INFO_SOURCE, this.dataInfo);
                break;
        }
    }

    /**设置属性 */
    public setDataInfo(dataInfo: ChapterDetail): void {
        if (!dataInfo) {
            return;
        }
        if (!dataInfo.locked) {
            this.showInfoImg.visible = true;
            this.showOffImg.visible = false;
            this.showBg.source = dataInfo.preview;
        } else {
            this.showInfoImg.visible = false;
            this.showOffImg.visible = true;
            this.title.text = dataInfo.name;
        }
    }

    public dispose(): void {
        this.dataInfo = null;
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandle, this);
    }
}