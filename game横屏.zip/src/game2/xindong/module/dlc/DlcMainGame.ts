/**
 * dlc中的额外剧情panel中的章节游戏
 * 
 * @author suyuanyang
 * @date 2018/03/13
 */
class DlcMainGame extends BasePanel {

    private _view: DlcMainGameUI;
    //
    private data_info: dlc_storyNexInfo[];
    //
    private indexPData: number = 0;

    private isNet: boolean = false;

    constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new DlcMainGameUI();
        this.addChild(this._view);

        this._view.selectGrp.visible = false;
        this._view.meGrp.visible = false;
        this._view.otherGrp.visible = false;
        this._view.pangGrp.visible = false;
        this._view.upBtn.visible = false;
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this.addEvent();
        if (data)
            this.setData(data);
    }

    public hide(): void {
        super.hide();
    }

    private addEvent(): void {
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandle, this, this);
    }

    private onVideoFinish(): void {
        Video.instance().dispose();
        this.showEnter();
        this.nextIdShow(this.data_info[0].id);
    }

    private showEnter(): void {
        try {
            egret.Tween.removeTweens(this._view.contentGroup);
            this._view.contentGroup.alpha = 0;
            egret.Tween.get(this._view.contentGroup).to({ alpha: 1 }, 1000);
        } catch (e) { }

    }

    private showOff(): void {
        try {
            egret.Tween.removeTweens(this._view.contentGroup);
            this._view.contentGroup.alpha = 0;
            // egret.Tween.get(this.contentGrp).to({ alpha: 0 }, 500);
        } catch (e) { }

    }

    /**
     * 设置显示数据
     */
    private setData(dataArr: dlc_storyNexInfo[]): void {
        App.data.game2Center.TalkManager.stopSound();
        // this.indexPData++;
        this.data_info = dataArr;
        egret.Tween.removeTweens(this);
        // if (this.indexPData > this.dataPanel.length) {
        //     egret.Tween.removeTweens(this);
        //     egret.Tween.get(this).wait(500).call(() => {
        //         this.setStarNum(Math.floor(Math.random() * 3));
        //     }).wait(1000).call(() => {
        //         this.destoryMe();
        //         App.PanelManager.open("DlcMainGameOver");
        //         (App.PanelManager.getPanel("DlcMainGameOver") as DlcMainGameOver).setData({ startNum: Math.floor(Math.random() * 3) });
        //     });
        //     return;
        // }
        //是否是选择
        if (dataArr.length > 1) {
            //select
            this._view.selectGrp.visible = true;
            this._view.meGrp.visible = false;
            this._view.otherGrp.visible = false;
            this._view.pangGrp.visible = false;
            this._view.upBtn.visible = false;
            this.setStarNum(0);
            this._view.titleSelect.text = "";
            let arrIndex: number[] = [0, 1, 2];
            for (let i = 0, len = dataArr.length; i < len; i++) {
                if (dataArr[i].role == 8) {
                    this._view.titleSelect.text = dataArr[i].content;
                    continue;
                }
                let rand: number = Math.floor(Math.random() * arrIndex.length);
                let ra: eui.RadioButton = this._view.showSelectGrp.getChildAt(arrIndex[rand]) as eui.RadioButton;
                ra.label = dataArr[i].content;
                ra.selected = false;
                ra.name = dataArr[i].id + "";
                arrIndex.splice(rand, 1);
            }
            return;
        }
        let data: dlc_storyNexInfo = dataArr[0]
        // DlcVideoMgr.playVideoByUrl("http://media.w3.org/2010/05/sintel/trailer.mp4");
        // return;
        //立绘效果
        // data.roleimg = "lihui3-3";
        if (data.roleimg) {
            // StageUtils.getInstance().fullSomeToStage(this._view.otherImg);
            this._view.otherImg.source = data.roleimg + "_jpg";//
            // this.otherImg.horizontalCenter = 0;
            // this.otherImg.verticalCenter = 0;
            // this.otherImg.bottom = null;
        } else {
            this._view.otherImg.source = "lihui1-1_jpg";
            // StageUtils.getInstance().fullSomeToStage(this._view.otherImg);
            // this.otherImg.scaleX = this.otherImg.scaleY = 1;
            // this.otherImg.bottom = 170;
            // this.otherImg.horizontalCenter = 0;
            // this.otherImg.verticalCenter = null;
        }
        switch (data.role) {
            case 1:
                //me
                this._view.upBtn.visible = true;
                this._view.selectGrp.visible = false;
                this._view.meGrp.visible = true;
                this._view.otherGrp.visible = false;
                this._view.pangGrp.visible = false;
                this.showSomeOneTextPrint(this._view.textInfoMe, data.content);
                break;
            case 0:
                //other 
                this._view.upBtn.visible = true;
                this._view.selectGrp.visible = false;
                this._view.meGrp.visible = false;
                this._view.otherGrp.visible = true;
                this._view.pangGrp.visible = false;
                this.showSomeOneTextPrint(this._view.textInfoOther, data.content);
                break;
            case 2:
                //pang 
                this._view.pangGrp.visible = true;
                this._view.upBtn.visible = true;
                this._view.selectGrp.visible = false;
                this._view.meGrp.visible = false;
                this._view.otherGrp.visible = false;
                this.showSomeOneTextPrint(this._view.textInfoPang, data.content);
                break;
            case 4:
                //video
                this.showOff();
                GameLog.log("播放视频-->" + data.video);
                DlcVideoMgr.playVideoByUrl(data.video, new FunctionVO(this.onVideoFinish, this));
                // egret.Tween.get(this).wait(500).call(() => {
                //     this.nextIdShow(this.data_info[0].id);
                // });
                // this.pangGrp.visible = true;
                // this.upBtn.visible = true;
                // this.selectGrp.visible = false;
                // this.meGrp.visible = false;
                // this.otherGrp.visible = false;
                // this.showSomeOneTextPrint(this.textInfoPang, data.text);
                break;
        }
        if (this.parent && data.audio) {
            let url: string = data.audio;
            GameLog.log("播放语音->" + url);
            // App.TalkManager.playSound("http://xindognvyou-file.oss-cn-beijing.aliyuncs.com/audio/" + url,
            //     this.onSoundComplete, this.onError, this.onLoaded, this);
            App.data.game2Center.TalkManager.playSound(url,
                this.onSoundComplete, this.onError, this.onLoaded, this);
        }

    }

    //声音加载完成后，等待50ms，不主动播放的移动端web用户，显示喇叭，用户点击后播放声音
    private onLoaded() {
        // if (DeviceUtil.isMobile && DeviceUtil.IsWeb) {
            //等待50ms判断声音是否播放成功，不成功，则显示喇叭
            // egret.Tween.get(App.data.game2Center.TalkManager).wait(50).call(() => {
                // if (App.TalkManager.channel && App.TalkManager.channel.position == 0) {
                //     item.leftMessage.showTalkAnim();
                //     item.leftMessage.talkImg.once(egret.TouchEvent.TOUCH_TAP, this.tryPlaySound, this);
                // }
            // }, this);
        // }
    }

    /*尝试播放语音*/
    private tryPlaySound() {
        if (this.parent) {
            App.data.game2Center.TalkManager.tryPlaySound();
        }
        this.stopTryPlaySound();
    }

    /*停止尝试播放语音*/
    private stopTryPlaySound() {
        egret.Tween.removeTweens(App.data.game2Center.TalkManager);
    }

    /*播放完成监听 */
    private onSoundComplete(): void {
        //egret.log("onSoundComplete");
        this.stopTryPlaySound();
    }

    /**加载失败 */
    private onError() {
        //加载失败后，继续下一步，不影响游戏正常流程
        GameLog.log("DlcMainGame >> 声音加载错误");
        Notice.showBottomCenterMessage("声音加载失败");
        this.onSoundComplete();
    }


    /**
     * 打印文字
     */
    private showSomeOneTextPrint(text: eui.Label, textInfo: string): void {
        egret.Tween.removeTweens(this);
        let len: number = textInfo.length;
        let index: number = 0;
        egret.Tween.get(this, { loop: true }).call(() => {
            let textStr: string = textInfo.substr(0, index + 1);
            text.text = textStr;
            index++;
            if (index == len) {
                egret.Tween.removeTweens(this);
            }
        }).wait(20);
    }

    /**
     * 设置星数目
     */
    private setStarNum(num: number): void {
        //dlc_big_start_1_png//dlc_start_3_png//dlc_start_2_png
        for (let i = 0, len = this._view.startGrp.numChildren; i < len; i++) {
            let img: eui.Image = this._view.startGrp.getChildAt(i) as eui.Image;
            if (num == 0) {
                img.source = "dlc_big_start_3_png";
            } else if (num - 2 >= 0) {
                img.source = "dlc_big_start_1_png";
                num -= 2;
            } else if (num - 1 >= 0) {
                img.source = "dlc_big_start_2_png";
                num -= 1;
            }
        }
    }

    private touchHandle(e: egret.TouchEvent): void {
        if (this.isNet) {
            return;
        }
        switch (e.target) {
            case this._view.upBtn:
                this.skipIdShow(this.data_info[0].id);
                break;
            case this._view.nextImg0:
            case this._view.nextImg1:
            case this._view.nextImg2:
                GameLog.log("next");
                this.nextIdShow(this.data_info[0].id);
                break;
            case this._view.select_0:
                this.setStarNum(this.data_info[0].score);
                egret.Tween.get(this).wait(500).call(() => {
                    egret.Tween.removeTweens(this);
                    this.nextIdShow(parseInt(this._view.select_0.name));
                });
                break;
            case this._view.select_1:
                this.setStarNum(this.data_info[1].score);
                egret.Tween.get(this).wait(500).call(() => {
                    egret.Tween.removeTweens(this);
                    this.nextIdShow(parseInt(this._view.select_1.name));
                });
                break;
            case this._view.select_2:
                this.setStarNum(this.data_info[2].score);
                egret.Tween.get(this).wait(500).call(() => {
                    egret.Tween.removeTweens(this);
                    this.nextIdShow(parseInt(this._view.select_2.name));
                });
                break;
        }
    }

    /**
     * 跳过
     */
    private skipIdShow(id: number): void {

        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.dlc_skip, { Authorization: App.data.game2Center.DataCenter.skey, id: id }, new FunctionVO((data: dlc_storyNex_S) => {
            if (data.code == 200) {
                if (data.data.story && data.data.story.length > 0) {
                    this.setData(data.data.story);
                } else {
                    try {
                        egret.Tween.removeTweens(this._view.contentGroup);
                    } catch (e) { }
                    GameLog.log("结束请求结果");
                    this.overChapter();
                }
            }
        }, this));
    }

    /**
     * 下一个
     */
    private nextIdShow(id: number): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.dlc_storyNex, { Authorization: App.data.game2Center.DataCenter.skey, id: id }, new FunctionVO((data: dlc_storyNex_S) => {
            GameLog.log("data->" + data);
            this.isNet = false;
            if (data.code == 200) {
                if (data.data.story && data.data.story.length > 0) {
                    this.setData(data.data.story);
                } else {
                    GameLog.log("结束请求结果");
                    this.overChapter();
                }
            } else {
                PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainPanel);
            }
        }, this));
    }

    private overChapter(): void {

        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.dlc_storyFinish, { Authorization: App.data.game2Center.DataCenter.skey, cid: ProtocolHttpData.gameChapterId }, new FunctionVO((data: dlc_storyFinish_S) => {
            GameLog.log("章节结束信息-->" + data);
            // DlcMainGameOver
            if (data.code == 200) {
                ProtocolHttpData.dlc_storyFinish_Info = data;
                ProtocolHttpData.dlc_chaptersData.data.chapters = data.data.chapters;//更新章节信息
                ProtocolHttpData.dlc_chaptersData.data.detail = data.data.detail;//更新章节写真简介信息
                //寻找当前的进行的章节状态
                for (let i = 0, len = ProtocolHttpData.dlc_chaptersData.data.chapters.length; i < len; i++) {
                    if (ProtocolHttpData.dlc_chaptersData.data.chapters[i].status == 1) {
                        ProtocolHttpData.gameChapterId = ProtocolHttpData.dlc_chaptersData.data.chapters[i].id;
                        break;
                    }
                }
                App.data.game2Center.TalkManager.stopSound();
                PanelOpenManager.removePanel(EnumPanelID.G2_DlcMainGame);
                PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainGameOver);
                //通知显示面板的简介
                App.dispatcher.dispatchEvent(EventConst.DLC_CHANGE_CHAPTER_DETAIL);

            } else {
                PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainPanel);
            }
        }, this));
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}