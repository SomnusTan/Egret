/**
 * dlc中的额外剧情panel中的章节信息 Over
 * 
 * @author suyuanyang
 * @date 2018/03/13
 */
class DlcMainGameOver extends BasePanel {
    private _view: DlcMainGameOverUI;
    //
    constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new DlcMainGameOverUI();
        this.addChild(this._view);
        this._view.backBtn.horizontalCenter = -150;
        this._view.nextBtn.horizontalCenter = 150;
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data)

        this.setData({ startNum: ProtocolHttpData.dlc_storyFinish_Info.data.score });
        //
        this.addEvent();
    }

    public hide(): void {
        super.hide();

    }

    private addEvent(): void {
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandle, this, this);
    }

    private touchHandle(e: egret.TouchEvent): void {
        try {
            //设置参数，下一章节的
            ProtocolHttpData.dlc_ChatStartInfo = ProtocolHttpData.dlc_storyFinish_Info.data.story;
        } catch (e) {

        }
        switch (e.target) {
            case this._view.backBtn:
                PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainPanel);
                PanelOpenManager.removePanel(EnumPanelID.G2_DlcMainGame);
                this.closePanel();
                break;
            case this._view.nextBtn:
                this.closePanel();
                PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainGame, ProtocolHttpData.dlc_ChatStartInfo, false);
                break;
        }
    }

    /**设置数据 */
    public setData(data: { startNum: number }): void {
        this.setStarNum(data.startNum);
        if (data.startNum == 0) {
            this._view.backBtn.horizontalCenter = 0;
            this._view.nextBtn.visible = false;
        }
    }

    /**设置星数目 */
    private setStarNum(num: number): void {
        //dlc_big_start_1_png//dlc_start_3_png//dlc_start_2_png
        for (let i = 0, len = this._view.startGrp.numChildren; i < len; i++) {
            let img: eui.Image = this._view.startGrp.getChildAt(i) as eui.Image;
            if (num == 0) {
                img.source = "dlc_big_start_3_png";
            } else if (num - 2 >= 0) {
                img.source = "dlc_big_start_1_png";
                num -= 2;
            } else if (num - 0.5 >= 0) {
                img.source = "dlc_big_start_2_png";
                num -= 1;
            }
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}