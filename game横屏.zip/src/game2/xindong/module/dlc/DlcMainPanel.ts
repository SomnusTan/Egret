/**
 * dlc中的额外剧情panel中的章节信息panel
 * 
 * @author suyuanyang
 * @date 2018/03/13
 */
class DlcMainPanel extends BasePanel {

    private _view: DlcMainPanelUI;

    //
    /**章节信息 */
    private dataPanel: ChapterInfo[];
    /**显示章节奖励简介 */
    private dataBgInfos: ChapterDetail[];
    //
    private dataArr: eui.ArrayCollection;
    //
    constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new DlcMainPanelUI();
        this.addChild(this._view);

        //设置当前的id 默认为当前的状态为1的
        for (let i = 0, len = ProtocolHttpData.dlc_chaptersData.data.chapters.length; i < len; i++) {
            if (ProtocolHttpData.dlc_chaptersData.data.chapters[i].status == 1) {
                ProtocolHttpData.gameChapterId = ProtocolHttpData.dlc_chaptersData.data.chapters[i].id;
                break;
            }
        }
        //
        this._view.showImggrp.visible = false;
        this._view.showImgInfo.visible = false;
        // StageUtils.getInstance().fullSomeToStage(this._view.showImgInfo);
        this.dataArr = new eui.ArrayCollection();
        this._view.panelChapterList.itemRenderer = DlcMainPanelItem;
    }

    public dispose(): void {
        super.dispose();
        for (var i: number = 0, len: number = this._view.showGrpImgInfos.numChildren; i < len; i++) {
            (this._view.showGrpImgInfos.removeChildAt(0) as DlcMainPanelInfoItem).dispose();
        }
        if (this.dataArr) {
            this.dataArr.removeAll();
            this.dataArr = null;
        }
        if (this.dataBgInfos) {
            this.dataBgInfos.length = 0;
            this.dataBgInfos = null;
        }
        this.dataPanel = null;
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this.addEvent();
        this.dataPanel = ProtocolHttpData.dlc_chaptersData.data.chapters;
        this.changeChapterDetail();
    }

    public hide(): void {
        super.hide();
    }

    private addEvent(): void {
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandle, this, this);
        this._dispatcher.addEventListener(EventConst.SHOW_IMG_INFO_SOURCE, this.showShowImgInfoSource, this);
        this._dispatcher.addEventListener(EventConst.DLC_CHANGE_CHAPTER_DETAIL, this.changeChapterDetail, this);
    }

    /**
     * 修改章节简介
     */
    private changeChapterDetail(): void {
        //列表
        this.dataArr.removeAll();
        this.dataPanel = ProtocolHttpData.dlc_chaptersData.data.chapters;
        for (let i = 0, len = this.dataPanel.length; i < len; i++) {
            this.dataArr.addItem(this.dataPanel[i]);
        }
        this._view.panelChapterList.dataProvider = this.dataArr;
        //简介写真
        this.dataBgInfos = ProtocolHttpData.dlc_chaptersData.data.detail;
        // this._view.showGrpImgInfos.removeChildren();
        for (let i = 0, len = this.dataBgInfos.length; i < len; i++) {
            let dmpii: DlcMainPanelInfoItem = this._view.showGrpImgInfos.getChildAt(i) as DlcMainPanelInfoItem;
            if (dmpii)
                dmpii.update(this.dataBgInfos[i]);
        }
        this.dataArr.refresh();
    }

    private touchHandle(e: egret.TouchEvent): void {
        switch (e.target) {
            case this._view.closeBtn:
                this.closePanel();
                App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
                break;
            case this._view.startBtn:
                PanelOpenManager.openPanel(EnumPanelID.G2_DlcMainGame, ProtocolHttpData.dlc_ChatStartInfo);
                this.closePanel();

                // 
                // ProtocolGame2.sendCommom(ProtocolHttpUrl.dlc_storyNex, { Authorization: App.DataCenter.skey, id: 54 }, (data: dlc_storyNex_S) => {
                //     GameLog.log("data->" + data);
                //     if (data.code == 200) {
                //         App.PanelManager.open("DlcMainGame");
                //         let panelGame: DlcMainGame = App.PanelManager.getPanel("DlcMainGame");
                //         panelGame.setData(data.data.story);
                //         this.destoryMe();
                //     }
                // }, this);
                break;
            case this._view.showImggrp:
                this._view.showImggrp.visible = false;
                // if (Math.abs(this.clickOneTimeSII - new Date().getTime()) < 300) {
                //     this.showImgInfo.visible = false;
                // } else {
                //     this.clickOneTimeSII = new Date().getTime();
                // }
                break;
        }
    }

    /**显示大图 */
    private showShowImgInfoSource(e: any): void {
        this._view.showImggrp.visible = true;
        this.startLoad(e.pic);
        this.startLoading();
        // this.showImgInfo.source = e.pic;
        // this.showImgInfo.visible = true;

    }

    private startLoading(): void {
        this._view.showLoading.visible = true;
        let indexNumber: number = 0;
        egret.Tween.get(this._view.showLabel, { loop: true }).wait(1000).call(() => {
            indexNumber++;
            this._view.showLabel.text = "加载中";
            for (let i = 0, len = indexNumber % 5; i < len; i++) {
                this._view.showLabel.text += ".";
            }
        });
    }

    private startLoad(url_: string): void {
        //创建 ImageLoader 对象
        var loader: egret.ImageLoader = new egret.ImageLoader();
        //添加加载完成侦听
        loader.once(egret.Event.COMPLETE, this.onLoadComplete, this);
        //开始加载
        loader.load(url_);
    }

    private onLoadComplete(event: egret.Event): void {
        var loader: egret.ImageLoader = <egret.ImageLoader>event.target;
        //获取加载到的纹理对象
        var bitmapData: egret.BitmapData = loader.data;
        //创建纹理对象
        var texture = new egret.Texture();
        texture.bitmapData = bitmapData;
        this._view.showImgInfo.texture = texture;
        this._view.showImgInfo.visible = true;
        this._view.showImgInfo.scaleX = this._view.showImgInfo.scaleY =
            App.layer.rotation == 0 ? Config.SCREEN_WIDTH / texture.textureWidth : Config.SCREEN_HEIGHT / texture.textureWidth;
        egret.Tween.removeTweens(this._view.showLabel);
        this._view.showLoading.visible = false;
        //创建 Bitmap 进行显示
        // this.addChild(new egret.Bitmap(texture));
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}