/**
 * dlc中的额外剧情panel中的章节信息item
 * @author suyuanyang
 * @date 2018/03/13
 */
class DlcMainPanelItem extends eui.ItemRenderer {
    private titleShow: eui.Label;
    private startGrp: eui.Group;
    private lockImg: eui.Image;
    private bgPanel: eui.Image;
    //
    private chapterInfo: ChapterInfo;
    //
    constructor() {
        super();
        this.skinName = "DlcMainPanelItemSkin";
    }

    protected childrenCreated(): void {
        super.childrenCreated();
        this.init();
    }

    protected dataChanged(): void {
        super.dataChanged();
        this.chapterInfo = this.data;
        this.setData(this.chapterInfo);
    }

    private init(): void {
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchHandle, this);
        this.touchHandle(null);
    }

    private touchHandle(e: egret.TouchEvent): void {
        if (!this.chapterInfo || this.chapterInfo.locked) {
            return;
        }
        
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.dlc_getChaptersDetail, { Authorization: App.data.game2Center.DataCenter.skey, cid: this.chapterInfo.id }, new FunctionVO((data: dlc_getChaptersDetail_S) => {
            if (data.code == 200) {
                ProtocolHttpData.gameChapterId = this.chapterInfo.id;
                ProtocolHttpData.dlc_ChatStartInfo = data.data.story;
                //修改奖励简介
                ProtocolHttpData.dlc_chaptersData.data.detail = data.data.detail;
                App.dispatcher.dispatchEvent(EventConst.DLC_CHANGE_CHAPTER_DETAIL);
                //
            }
        }, this));
    }

    /**设置属性 */
    public setData(data: ChapterInfo): void {
        if (data.id == ProtocolHttpData.gameChapterId) {
            this.bgPanel.source = "dlc_kuang_2_png";
        } else {
            this.bgPanel.source = "dlc_kuang_1_png";
        }
        this.titleShow.text = data.title;
        if (data.locked) {
            this.startGrp.visible = false;
            this.lockImg.visible = true;
        } else {
            this.startGrp.visible = true;
            this.lockImg.visible = false;
        }
        this.setStarNum(data.score);
    }

    /**设置星数目 */
    private setStarNum(num: number): void {
        //dlc_big_start_1_png//dlc_start_3_png//dlc_start_2_png
        for (let i = 0, len = this.startGrp.numChildren; i < len; i++) {
            let img: eui.Image = this.startGrp.getChildAt(i) as eui.Image;
            if (num == 0) {
                img.source = "dlc_big_start_3_png";
            } else if (num - 2 >= 0) {
                img.source = "dlc_big_start_1_png";
                num -= 2;
            } else if (num - 1 >= 0) {
                img.source = "dlc_big_start_2_png";
                num -= 1;
            }
        }
    }
}