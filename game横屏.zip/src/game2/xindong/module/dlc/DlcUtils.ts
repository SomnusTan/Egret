/**
 * 包含dlc模块下使用的工具
 * @author suyuanyang
 * @date 2018/03/20
 */
class DlcUtils {
    /**
     * 给某个显示体添加点击缩放效果
     */
    public static addSomeOneBtnTouchScale(obj: egret.DisplayObject, scaleTouchBegin: number = 1.1): void {
        let scaleX: number = obj.scaleX;
        let scaleY: number = obj.scaleY;
        let scaleObj: Function = function () {
            obj.scaleX = obj.scaleY = scaleTouchBegin;
        };

        let refulseObj: Function = function () {
            obj.scaleX = scaleX;
            obj.scaleY = scaleY;
        };

        let funcAddEvent: Function = function () {
            obj.addEventListener(egret.TouchEvent.TOUCH_BEGIN, scaleObj, this);
            obj.addEventListener(egret.TouchEvent.TOUCH_END, refulseObj, this);
            obj.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, refulseObj, this);
        };

        let funcRemoveEvent: Function = function () {
            obj.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, scaleObj, this);
            obj.removeEventListener(egret.TouchEvent.TOUCH_END, refulseObj, this);
            obj.removeEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, refulseObj, this);
        };
        funcAddEvent();
        obj.addEventListener(egret.Event.REMOVED_FROM_STAGE, funcRemoveEvent, this);
    }
    /**
     * 是否开启心动之旅
     */
    public static getIsOpenDLC(): boolean {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.dlc_getChapters, { Authorization: App.data.game2Center.DataCenter.skey }, new FunctionVO((data: dlc_getChapters_S) => {
            GameLog.log("data->" + data);
            if (data.code == 200) {
                return true;
            }
        }, this));
        return false;
    }

}