class GetItemNotice extends BaseDialog {
	public contentGroup: eui.Group;
	public imgIcon: eui.Image;
	public titleLabel: eui.Label;
	public contentLabel: eui.Label;
	public contentLabel1: eui.Label;
	public okBtn: eui.Button;

	private _iconType: number;

	public constructor() {
		super();
		this.skinName = "GetItemNoticeSkin";
	}

	/**
	 * 设置内容
	 * count 	物品数量
	 * iconType 0：心动碎片,1,2：钻石
	 */
	public setData(c1: string, count: number, iconType: number) {
		this.contentLabel1.text = c1;
		this._iconType = iconType;
		if (iconType == 0) {
			this.imgIcon.source = "shop2_xindongsuipian_png";
			super.setContent("心动碎片 x" + count);
		} else if (iconType == 1 || iconType == 2) {
			this.imgIcon.source = "main2_zuanshi_png";
			super.setContent("钻石 x" + count);
			App.data.game2Center.DataCenter.UserInfo.diamond += count;
			App.dispatcher.dispatchEvent(EventConst.UPDATE_SIWEI);
		}
	}
	/**显示 */
	public show() {
		super.show();
		App.layer.moduleLayer.addChild(this);
		if (PanelManager.isShowing(PanelRegister.G2_ActPanel)) {
			PanelManager.getPanel(PanelRegister.G2_ActPanel).parent.addChild(PanelManager.getPanel(PanelRegister.G2_ActPanel));
		}
	}

	protected onOkTouch() {
		if (this._iconType == 1) {
			ItemFlyEffect.fly(this.imgIcon, this.imgIcon.localToGlobal(), new egret.Point(28, 217));
		}
		super.onOkTouch();
	}

}