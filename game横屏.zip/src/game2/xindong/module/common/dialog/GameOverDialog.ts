/**
 * 游戏结束弹框
 * @author chenkai
 * @date 2017/12/5
 */
class GameOverDialog extends BaseDialog {
	private qqLabel: eui.Label;
	//private gameBtn: eui.Button;
	private closeBtn: eui.Image;
	public constructor() {
		super();
		this.skinName = "GameOverDialogSkin";
		this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
	}

	public childrenCreated() {

		//公告关闭时，隐藏公众号和玩家群等，主要用于审核
		if (ClientConfig.attention == 0 || Config.IsApplyIOS) {
			this.qqLabel.text = "";
		}
		//this.gameBtn.visible = false;
	}

	private onTouch(e: egret.TouchEvent) {
		switch (e.target) {
			case this.closeBtn:
				this.destoryMe();
				break;
			// case this.gameBtn:
			// 	if (App.DeviceUtils.IsNative) {
			// 		let data: any = { url: App.DataCenter.shareContent.url };
			// 		App.NativeBridge.pushOfficialNetwork("pushOfficialNetwork", data);
			// 	}
			// 	else {
			// 		window.open("http://www.aqgame.cn");
			// 	}
			// 	break;

		}
	}
}