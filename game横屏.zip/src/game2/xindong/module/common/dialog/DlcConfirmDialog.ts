/**
 * 心动之旅提示
 * @author lidan
 * @date 2018/5/17
 */
class DlcConfirmDialog extends BaseDialog {
	public exitRect: eui.Rect;
	public contentGroup: eui.Group;
	public titleLabel: eui.Label;
	public contentLabel: eui.Label;
	public shopBtn: eui.Button;
	public loveBtn: eui.Button;
	public kouyaBtn: eui.Button;


	public constructor() {
		super();
		this.skinName = "DlcConfirmDialogSkin";
		this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
	}


	//当恋爱道具不足时，询问购买恋爱道具
	public setBuyLove(toolNum) {
		this.contentLabel.text = "解锁心动之旅需要50个碎片，当前数量" + toolNum + "个。";
	}

	private onTouch(e: egret.TouchEvent) {
		this.destoryMe();
		switch (e.target) {
			case this.shopBtn:
				App.dispatcher.dispatchEvent(G2_GameSceneEvent.SHOW_SCENE_ANIMATION);
				PanelOpenManager.removePanel(EnumPanelID.G2_DlcMainDoc);
				PanelOpenManager.openPanel(EnumPanelID.G2_MysteriousShop);
				break;
			case this.loveBtn:
				PanelOpenManager.openPanel(EnumPanelID.G2_LovePanel);
				PanelOpenManager.removePanel(EnumPanelID.G2_DlcMainDoc);
				break;
			case this.kouyaBtn:
				PanelOpenManager.removePanel(EnumPanelID.G2_DlcMainDoc);
                GameManager.exitGame();
                PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
				break;
		}
	}


}