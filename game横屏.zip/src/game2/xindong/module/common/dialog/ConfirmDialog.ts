/**
 * 带有确认和取消的对话框
 * @author chenkai
 * @date 2017/11/22
 */
class ConfirmDialog extends BaseDialog {

	public constructor() {
		super();
		this.skinName = "ConfirmDialogSkin";
	}

}