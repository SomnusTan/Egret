/**
 * 确认框
 */
class SureDialog extends BaseDialog{
	public constructor() {
		super();
		this.skinName = "SureDialogSkin";
	}
}