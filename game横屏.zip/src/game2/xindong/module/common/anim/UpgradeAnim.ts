/**
 * 升级动画
 * @author chenkai
 * @since 2017/10/14
 */
class UpgradeAnim extends BaseMovieClip{
	public constructor() {
		super();
		this.config("upgradeAnim_json", "upgradeAnim_png", "upgradeAnim");
	}
}