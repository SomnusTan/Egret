/**
 * 自定义Video标签
 * @author xiongjian
 * @date 2017-10-24
 */

class MyVideo extends SingleClass {
    private rect: eui.Rect;   //播放视频时黑色遮罩

    public constructor() {
        super();
        this.enable();

        this.rect = new eui.Rect(App.data.game2Center.StageUtils.stageWidth, App.data.game2Center.StageUtils.stageHeight, 0x000000);
        this.rect.percentWidth = 100;
        this.rect.percentHeight = 100;


        //video适配
        if (DeviceUtil.isMobile && DeviceUtil.IsWeb) {
            //ipad不旋转
            if (DeviceUtil.IsIpad) {
                return;
            }
            //android UC不旋转
            if (DeviceUtil.IsAndroid && DeviceUtil.IsUCBrowser) {
                return;
            }

            let h = window.innerHeight;
            let w = window.innerWidth;
            let video = document.getElementById("myVideo");
            video.style.transform = "rotate(90deg) scale(" + h / w + ")";
        }
    }

    private enable() {
        var video: any = document.getElementById('myVideo');
        video.addEventListener("play", () => {
            egret.log("play");
        });

        video.addEventListener("ended", this.stopVideo, this);

        video.addEventListener("pause", () => {
            egret.log("pause");
        });

        video.addEventListener("error", () => {
            egret.log("error");
            MyVideo.getInstance().stop();
        });
    }

    private stopVideo(): void {
        egret.log("end");
        MyVideo.getInstance().stop();
    }

    public play(url) {
        // if (GlobalConfig.skipVideo) {
        //     Notice.showBottomCenterMessage("跳过视频");
        //     return;
        // }

        App.data.game2Center.DataCenter.isVideoPlaying = true;
        App.layer.popLayer.addChild(this.rect);
        App.data.game2Center.SoundManager.stopBGM();
        var video: any = document.getElementById('myVideo');
        video.src = url;
        video.autoplay = "autoplay";
        video.play();
        video.style.display = "inline";
    }

    public stop() {
        App.data.game2Center.DataCenter.isVideoPlaying = false;
        MyVideo.getInstance().rect.parent && MyVideo.getInstance().rect.parent.removeChild(MyVideo.getInstance().rect);
        App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
        var video: any = document.getElementById('myVideo');
        video.style.display = "none";
        video.pause();

        //播放视频完成
        App.dispatcher.dispatchEvent(EventConst.VIDEO_PLAY_FISNISH);
    }

}