class AddSomeMsgUtils {
    /**
     * 兼容 添加一些参数在关于用户下单的时候
     * 例如玩吧渠道
     */
    public static addSomeMsgByGiftBuy(param: any): any {
        //玩吧
        if (WanBaSDK.getIntance().wanBaData) {
            let objWanBa: any = WanBaSDK.getIntance().wanBaData;
            param.openid = objWanBa.openid;
            param.openkey = objWanBa.openkey;
            param.zoneid = objWanBa.platform;
            param.channel = "wanba";
            param.Authorization = App.data.game2Center.DataCenter.skey;
        }
        return param;
    }
}