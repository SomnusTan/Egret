/**
 * 单例rect
 * 主要用于遮住屏幕，点击任意位置后执行某项操作
 */
class LockTool{
	private group:eui.Group;
	private cb:Function;
	private thisObj:any;

	public constructor() {
		this.group = new eui.Group();
		this.group.width = App.data.game2Center.StageUtils.stageWidth;
		this.group.height = App.data.game2Center.StageUtils.stageHeight;
		this.group.percentWidth = 100;
		this.group.percentHeight = 100;
		this.group.touchEnabled = true;
		this.group.touchThrough = true;
	}

	/**
	 * 锁定
	 * @param doc 容器
	 * @param cb  回调
	 * @param thisObj 回调对象 
	 */
	public lock(doc:egret.DisplayObjectContainer, cb:Function = null, thisObj:any = null){
		//保存回调
		this.cb = cb;
		this.thisObj = thisObj;

		//显示到容器
		doc.addChild(this.group);

		//增加回调
		if(this.cb && this.thisObj){
			this.group.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
		}
	}

	//点击
	private onTouch(){
		GameLog.log("aaaaaaaaaaaaaa");
		//执行回调
		if(this.cb && this.thisObj){
			this.cb.apply(this.thisObj);
		}

		//隐藏
		this.hide();
	}

	/**隐藏 */
	public hide(){
		//隐藏
		this.group && this.group.parent && this.group.parent.removeChild(this.group);

		//移除回调
		this.group.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.hide, this);
		this.cb = null;
		this.thisObj = null;
	}


	//单例
	private static instance:LockTool;
	public static getInstance():LockTool{
		if(this.instance == null){
			this.instance = new LockTool();
		}
		return this.instance;
	}
}