/**
 * 资源加载等待时锁定动画
 * @author chenkai
 * @date 2016/9/19
 */
class LoadingLock extends eui.Component {
    /**黑色Rect底图*/
    private rect: eui.Rect;
    /**超时回调*/
    private callBack: Function;
    /**超时回调执行对象*/
    private thisObject: any;
    /**延时器编号 */
    private timeNum: number;
    /**存放动画的Group */
    private mcGroup: eui.Group;
    /**加载心形动画 */

    private loadingAnim: LoadingAnim;

    //加载文字
    private loadingLabel: eui.Label;

    public constructor() {
        super();
        this.skinName = "LoadingLockSkin";
        this.percentWidth = 100;
        this.percentHeight = 100;
    }

    /**
     * 锁定
     * @callBack 超时回调
     * @thisObject 超时回调执行对象
     * @bUseOverTime 是否使用超时计时器。true 超时后自动unlock； false 一直锁住直到手动unlock
     */
    public lock(callBack: Function = null, thisObject: any = null, bUseOverTime: boolean = true): void {
        return;
        this.callBack = callBack;
        this.thisObject = thisObject;

        //不使用超时
        bUseOverTime = false;
        bUseOverTime && this.startOverTimer();


        if (this.loadingAnim == null) {
            this.loadingAnim = new LoadingAnim();
        }

        egret.Tween.get(this).wait(1000).call(() => {
            this.mcGroup.addChild(this.loadingAnim);
            this.loadingAnim.play(-10);
            this.loadingLabel.visible = true;
            this.rect.alpha = 0.5;
        }, this);

        this.loadingLabel.visible = false;
        this.rect.alpha = 0;
        App.layer.popLayer.addChild(this);
    }


    //停止加载动画
    public unlock() {
        return;
        egret.Tween.removeTweens(this);
        this.callBack = null;
        this.thisObject = null;
        this.stopOverTimer();
        this.loadingAnim && this.loadingAnim.hide();
        this.parent && this.parent.removeChild(this);
    }

    //开始超时计时
    private startOverTimer() {
        App.timer.doTimeOnce(this, 10000, this.onTimerComplete);
    }

    //停止超时计时
    private stopOverTimer() {
        App.timer.clearTimer(this, this.onTimerComplete);
    }

    //超时
    private onTimerComplete() {
        if (this.callBack != null && this.thisObject != null) {
            this.callBack.call(this.thisObject);
        }
        this.unlock();
    }


    private screenRect: eui.Rect;
    /**锁住屏幕 为了播放视频前不让用户点击而锁...*/
    public lockScreen() {
        if (this.screenRect == null) {
            if (App.layer.rotation == 0)
                this.screenRect = new eui.Rect(App.data.game2Center.StageUtils.stageWidth, App.data.game2Center.StageUtils.stageHeight, 0x000000);
            else
                this.screenRect = new eui.Rect(App.data.game2Center.StageUtils.stageHeight, App.data.game2Center.StageUtils.stageWidth, 0x000000);
            this.screenRect.alpha = 0;
        }
        else {
            if (App.layer.rotation == 0) {
                this.screenRect.width = App.data.game2Center.StageUtils.stageWidth;
                this.screenRect.height = App.data.game2Center.StageUtils.stageHeight;
            }
            else {
                this.screenRect.width = App.data.game2Center.StageUtils.stageHeight;
                this.screenRect.height = App.data.game2Center.StageUtils.stageWidth;
            }
        }

        //只锁住scene和panel，不锁住dialog及以上层
        App.layer.commonLayer.addChild(this.screenRect);
    }

    /**解锁屏幕 */
    public unLockScreen() {
        if (this.screenRect) {
            this.screenRect.parent && this.screenRect.parent.removeChild(this.screenRect);
        }
    }
}
