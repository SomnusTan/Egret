class Config {

	/**是否正式版本 */
	public static isRelease: boolean = true;
	/**是否调试模式 (控制日志输出) */
	public static isDebug: boolean = false;

	/**跳过视频 */
	public static skipVideo: boolean = false;

	/**跳过引导 */
	public static skipGuide: boolean = true;
	/**声音资源同步加载 */
	public static soundAsyncLoad: boolean = false;

	/**是否https访问地址 主要用于h5渠道，有些渠道需要https地址 */
	public static isHttps: boolean = true;
	/**是否已经进入游戏 */
	public static hasEnterGame: boolean = false;
	/**是否开始播放音效 */
	public static startPlaySoundEffect: boolean = false;
	/**玩家是否交互过 */
	public static hasTouch: boolean = false;
	/**版本号 */
	public static version: string = "v1.2.7";

	/** 界面宽度 */
	public static MAIN_WIDTH: number = 720;
	/** 界面高度 */
	public static MAIN_HEIGHT: number = 1280;

	/**分辨率宽 */
	public static SCREEN_WIDTH: number;
	/**分辨率高 */
	public static SCREEN_HEIGHT: number;

	/**是否已经成功进入游戏*/
	public static isEnterGame: boolean = false;

	public static RESOURCE_PATH: string = "resource/";

	/**当前帧率 */
	public static currentGameFps: number = 60;

	public static orientation: string = "auto";
	/**是否初始横屏 */
	public static isLandscape: boolean = false;

	public static GM_KEY: string = "xdns666";


	//===================================渠道相关======================================

	/**soEasy渠道 H5渠道 */
	public static soEasy: boolean = false;

	/**u8登录 登录和支付流程走u8*/
	public static U8Login: boolean = false;

	/**ios审核开关，审核版本时，关闭公告和qq、公众号 */
	public static IsApplyIOS: boolean = false;
	/**是否IOS包 */
	public static isIosHybird: boolean = false;
	/**是否本地应用 */
	public static isLocalApp: boolean = false;
	/**是否广州冰雪IOS */
	public static isGZSnow: boolean = false;
}