/**
 * Created by qingzhu on 15/7/1.
 */
module qr {
    export class QRMode{
        public static MODE_NUMBER= 1;
        public static MODE_ALPHA_NUM= 2;
        public static MODE_8BIT_BYTE= 4;
        public static MODE_KANJI= 8;
    }
}