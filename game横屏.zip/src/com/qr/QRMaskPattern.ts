/**
 * Created by qingzhu on 15/7/1.
 */
module qr {
    export class QRMaskPattern{
        public static PATTERN000:number = 0;
        public static PATTERN001:number = 1;
        public static PATTERN010:number = 2;
        public static PATTERN011:number = 3;
        public static PATTERN100:number = 4;
        public static PATTERN101:number = 5;
        public static PATTERN110:number = 6;
        public static PATTERN111:number = 7;
    }
}