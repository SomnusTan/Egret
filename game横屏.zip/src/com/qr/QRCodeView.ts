class QRCodeView extends h5_engine.GSprite {
	private _qrShape: egret.Shape;

	public constructor() {
		super();
	}

	public show(url: string, icon: string): void {
		this._qrShape = qr.QRCode.create(url, 200, 200);
		this.addChild(this._qrShape);
		let logo = new eui.Image();
		logo.source = icon;
		logo.x = this._qrShape.width - 40 >> 1;
		logo.y = this._qrShape.height - 40 >> 1;
		this.addChild(logo);
	}

	public get width(): number {
		return this._qrShape ? this._qrShape.width : 200;
	}

	public dispose(): void {
		super.dispose();
		if (this._qrShape) {
			this._qrShape.parent && this._qrShape.parent.removeChild(this._qrShape);
			this._qrShape = undefined;
		}
	}

}