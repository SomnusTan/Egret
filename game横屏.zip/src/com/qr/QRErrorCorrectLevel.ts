/**
 * Created by qingzhu on 15/7/1.
 */
module qr {
    export class QRErrorCorrectLevel{
        public static L:number =1;
        public static M:number= 0;
        public static Q:number = 3;
        public static H:number = 2;
    }
}