class EventType {
    /**场景尺寸重置 */
    public static STGAE_RESIZE: string = "EventType.STGAE_RESIZE";
    /**购买成功 */
    public static BUY_SUCCESS: string = "EventType.BUY_SUCCESS";
    /**绑定手机成功 */
    public static BIND_PHONE_SUCCESS: string = "EventType.BIND_PHONE_SUCCESS";
    /**检测支付成功 */
    public static SHOP_IS_SHOP: string = "EventType.SHOP_IS_SHOP";
    /**游戏大厅点击item */
    public static GAMEHALL_ITEM_CLICK: string = "EventType.GAMEHALL_ITEM_CLICK";
    /**详情界面购买超值组合成功 */
    public static DETAIL_BUY_CZZH: string = "EventType.DETAIL_BUY_CZZH";
    /**视频返回 */
    public static VIDEO_BACK: string = "EventType.video_back";
    /**更新心动币 */
    public static UPDATE_COIN: string = "EventType.update_coin";
    /**充值成功 */
    public static CHARGE_SUCCESS: string = "EventType.charge_success";

}