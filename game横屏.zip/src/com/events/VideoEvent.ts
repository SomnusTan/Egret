class VideoEvent {
	public constructor() {
	}
	/** 重新播放视频 */
	public static REPLAYVIDEO: string = "VideoEvent.REPLAYVIDEO";
}