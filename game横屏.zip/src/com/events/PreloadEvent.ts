class PreloadEvent
{
    /**隐藏LOGO完成 */
    public static HIDE_LOGO_COMPLETE:string = "PreloadEvent.hide_logo_complete";
    /**预加载资源完成 */
    static PRELOAD_COMPLETE: string = "PreloadEvent.preload_complete";
    /**隐藏loading完成 */
    static HIDE_LOADING_COMPLETE:string = "PreloadEvent.hide_loading_complete";
    /**开始视频结束 */
    static PLAY_COMPLETE_START_VIDEO:string="PreloadEvent.play_complete_start_video"
}