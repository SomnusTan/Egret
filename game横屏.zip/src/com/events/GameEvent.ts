class GameEvent {

    /**游戏初始化 */
    public static GAME_INIT: string = "GameEvent.game_init";
    /**游戏下一步 */
    public static GAME_NEXT: string = "GameEvent.game_next";
    /**游戏资源加载完成 */
    public static GAME_RES_LOADED: string = "GameEvent.game_res_loaded";
    /**游戏随机名字 */
    public static GAME_RANDOM_NAME: string = "GameEvent.game_random_name";
    /**取名完成 */
    public static GAME_BENAME: string = "GameEvent.game_bename";
    /**继续 */
    public static GAME_CONTINE: string = "GameEvent.game_contine";
    /**更新回放数据 */
    public static GAME_REVIEW_DATA: string = "GameEvent.game_review_data";
    /**解锁成功 */
    public static GAME_UNLOCK_SUCCESS: string = "GameEvent.game_unlock_success";
    /**选择了选项 */
    public static SELECTED_OPTION: string = "EventType.selected_option";
    /**解锁章节成功 */
    public static UNLOCK_CHAPTER_SUCCESS: string = "EventType.unlock_chapter_success";
}