class LoginEvent {
    /**
     * 登录反馈
     */
    public static CHECK_LOGIN_BACK: string = "LoginEvent.check_login_back";

    /**
     * 获取手机验证码反馈
     */
    public static GET_PHONE_CODE_BACK: string = "LoginEvent.get_phone_code_back";

    /**
     * 游戏开始(进入游戏盒子)
     */
    public static GAME_START: string = "LoginEvent.game_start";

    /**
     * 游戏绑定手机号 参数 0:回到登录界面 1：登录改成绑定
     */
    public static GAME_LOGIN_RESET: string = "LoginEvent.game_login_reset";
    /**
     * 游戏绑定手机号 参数 0:解开绑定界面 1：改成新手机绑定
     */
    public static GAME_INTERFACE_DIFFERENTIATION: string = "LoginEvent.game_Interface_differentiation";

    /**获取到游戏初始化参数 */
    public static GET_AVG_SYSTEM_INIT: string = "LoginEvent.get_avg_system_init";

    /**重新登录 */
    public static RELOGIN: string = "LoginEvent.relogin";

    /**获取设备码返回 */
    public static GET_DEVICE_CODE_BACK: string = "LoginEvent.get_device_code_back";

    /**获取初始横竖屏状态返回 */
    public static GET_START_ORIENTATION_BACK: string = "LoginEvent.get_start_orientation_back";
    
    /**获取冰雪登录返回数据 */
    public static GET_SNOW_LOGIN_BACK: string = "LoginEvent.get_snow_login_back";
}