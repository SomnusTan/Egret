class MemoryEvent {
	public constructor() {
	}
	/** 切换动态壁纸 */
	public static CHANGE_BIZHI:string = "MemoryEvent.change_bizhi";
}