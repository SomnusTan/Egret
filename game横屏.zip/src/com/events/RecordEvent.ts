class RecordEvent {
	public constructor() {
	}
	/** 存档列表返回 */
	public static RECORD_LIST: string = "RecordEvent.record_list"
}