class G2_GameSceneEvent {

    /**升级引导 */
    public static LevelUpGuide: string = "G2_GameSceneEvent.LevelUpGuide";
    /**初始化配置 */
    public static SETGAMECONFIG: string = "G2_GameSceneEvent.SETGAMECONFIG";
    /**显示场景出现动画 */
    public static SHOW_SCENE_ANIMATION: string = "G2_GameSceneEvent.show_scene_animation";
    /**显示场景隐藏动画 */
    public static HIDE_SCENE_ANIMATION: string = "G2_GameSceneEvent.hide_scene_animation";
    /**更新神秘商店 */
    public static BUY_SHENMISHOP: string = "G2_GameSceneEvent.buy_shenmishop";
    /**改变场景背景 */
    public static CHANGE_BG: string = "G2_GameSceneEvent.change_bg";
    /**购买限制 */
    public static CHANGEBUYLIMIT: string = "G2_GameSceneEvent.changeBuyLimit";
    /**设置购买部分 */
    public static SETBUYPART: string = "G2_GameSceneEvent.setBuyPart";
    /**设置购买的文本 */
    public static SETGOLDTEXT: string = "G2_GameSceneEvent.setGoldText";
    /**设置购买的钻石文本 */
    public static SETDIAMONDTEXT: string = "G2_GameSceneEvent.setDiaMondText";

    /**请求后台开关配置 */
    public static REQ_UPGRADE_STATUS:string ="G2_GameSceneEvent.req_upgrade_status";
}