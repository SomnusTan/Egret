class ImageEffectInfo {

    /**当前游戏背景 */
    public bgURL: string;
    /**背景切换特效类型 */
    public bgEffectType: string;
    /**背景图是否改变 */
    public bgURLChanged: boolean;
    /**背景切换特效时间 */
    public bgEffectTime: number = 0;
    /**背景特效 */
    public bgEffect: any[] = [];

    /**角色立绘列表 */
    public roleList: RoleSkinInfo[] = [];
    /**立绘特效 */
    public roleEffectList: any[][] = [];

    /**背景和立绘效果是否一样 (用来表示同时切出切入效果)*/
    public isSameEffect: boolean = false;

    /**是否需要移除立绘 */
    public needRemoveRole: boolean;


    /**
     * 数据重置
     */
    public reset(): void {
        this.bgURL = null;
        this.bgEffectType = null;
        this.bgEffectTime = 0;
        ObjectPool.getPool("RoleSkinInfo").pushArr(this.roleList);
        this.roleList.length = 0;
        this.bgEffect.length = 0;
        this.isSameEffect = false;
    }

    /**
     * 解析背景和立绘数据
     * @param data
     * @param survivalTime 自动切换时间
     */
    public parse(data: any, survivalTime: number): number {
        this.isSameEffect = false;
        this.bgEffectTime = 0;
        this.parseBg(data);

        this.parseRole(data);

        this.bgEffect.length = 0;
        this.roleEffectList.length = 0;

        //背景效果解析
        if (data.dynamic_effect && data.dynamic_effect.length > 0) {
            var effect: any;
            var effectName: EffectName;
            for (var i: number = 0, len: number = data.dynamic_effect.length; i < len; i++) {
                effect = data.dynamic_effect[i];
                if (effect.type == "background") {
                    if (EnumImageEffect.STATIC_EFFECT_LIST.indexOf(effect.module) != -1)
                        this.bgEffect[0] = effect;
                    else
                        this.bgEffect[1] = effect;
                }
                else if (effect.type == "all") {
                    if (EnumImageEffect.STATIC_EFFECT_LIST.indexOf(effect.module) != -1)
                        this.bgEffect[0] = effect;
                    else
                        this.bgEffect[1] = effect;
                }
                if (effect.hasOwnProperty("time")) {
                    if (effectName && effectName.isOutName(effect.module) && survivalTime == 0) {
                        survivalTime = 1;
                    }
                }
            }
            var bgEffectName: string = this.bgEffect[1] ? this.bgEffect[1].module : this.bgEffectTime > 0 ? this.bgEffectType : null;
            //立绘效果解析
            for (i = 0, len = data.dynamic_effect.length; i < len; i++) {
                effect = data.dynamic_effect[i];
                if (effect.type == "all") {
                    if (EnumImageEffect.STATIC_EFFECT_LIST.indexOf(effect.module) != -1)
                        this.addRoleEffect(Number(effect.layer), effect, true);
                    else {
                        this.addRoleEffect(Number(effect.layer), effect, false);
                        if (effect.module == bgEffectName) {
                            this.isSameEffect = true;
                        }
                    }
                }
                else if (effect.type == "erect_drawing") {
                    if (EnumImageEffect.STATIC_EFFECT_LIST.indexOf(effect.module) != -1)
                        this.addRoleEffect(Number(effect.layer), effect, true);
                    else {
                        this.addRoleEffect(Number(effect.layer), effect, false);
                        if (effect.module == bgEffectName) {
                            this.isSameEffect = true;
                        }
                    }
                }
                if (effect.hasOwnProperty("time")) {
                    if (effectName && effectName.isOutName(effect.module) && survivalTime == 0)
                        survivalTime = 1;
                }
            }
        }
        else {
            if (this.bgURLChanged && this.needRemoveRole) {
                this.isSameEffect = true;
            }
        }
        return survivalTime;
    }

    /**
     * 背景解析
     */
    private parseBg(data: any): void {
        this.bgURLChanged = false;
        if (data.background) {
            if (this.bgURL != data.background.image) {
                this.bgEffectTime = Number(data.background.effect_time);
                this.bgURLChanged = true;
            }
            this.bgURL = data.background.image;
            this.bgEffectType = data.background.effect_way;
        }
        else {
            if (this.bgURL != null) {
                this.bgURL = null;
                this.bgURLChanged = true;
            }
        }
    }

    /**
     * 立绘解析
     */
    private parseRole(data: any): void {
        this.needRemoveRole = false;
        if (data.portrait) {
            var num: number = this.roleList.length;
            var roleInfo: RoleSkinInfo;
            var roleData: any;
            for (var i: number = 0, len: number = data.portrait.length; i < len; i++) {
                roleData = data.portrait[i];
                if (roleData && roleData.hasOwnProperty("image")) {
                    roleInfo = this.roleList[i];
                    if (roleInfo == null) {
                        roleInfo = ObjectPool.getPool("RoleSkinInfo").getObject();
                        this.roleList[i] = roleInfo;
                    }
                    roleInfo.roleURL = roleData.image;
                    roleInfo.alpha = roleData.opacity;
                    roleInfo.x = Number(roleData.Start_X);
                    roleInfo.y = Number(roleData.Start_Y);
                    roleInfo.effectType = roleData.effect_way;
                    roleInfo.effectTime = roleData.effect_time;
                    roleInfo.scale = Number(roleData.Ratio);
                    roleInfo.index = Number(roleData.layer);
                }
                else {
                    roleInfo = this.roleList[i];
                    if (roleInfo) {
                        ObjectPool.getPool("RoleSkinInfo").push(this.roleList[i]);
                        this.roleList[i] = null;
                        this.needRemoveRole = true;
                    }
                }
            }
        }
        else {
            ObjectPool.getPool("RoleSkinInfo").pushArr(this.roleList);
            for (var i: number = 0, len: number = this.roleList.length; i < len; i++) {
                if (this.roleList[i]) {
                    this.roleList[i] = null;
                    this.needRemoveRole = true;
                }
            }
        }
    }

    /**
     * 添加立绘效果
     */
    private addRoleEffect(i: number, effect: any, isStaticEffect: boolean): void {
        if (!this.roleEffectList[i]) {
            this.roleEffectList[i] = [];
        }
        this.roleEffectList[i][isStaticEffect ? 0 : 1] = effect;
    }

    /**
     * 通过层级获取立绘特效
     */
    public getRoleEffectByLayer(layer: number, isStaticEffect: boolean): any {
        if (this.roleEffectList && this.roleEffectList[layer]) {
            return this.roleEffectList[layer][isStaticEffect ? 0 : 1];
        }
        return null;
    }

    /**
     * 获取背景的效果
     */
    public getBgEffect(isStaticEffect: boolean): any {
        if (this.bgEffect) {
            return this.bgEffect[isStaticEffect ? 0 : 1];
        }
        return null;
    }
}