/**
 * 立绘数据
 */
class RoleSkinInfo {
    /**立绘路径 */
    public roleURL: string;
    /**透明度 */
    public alpha: number;

    public x: number;

    public y: number;
    /**效果类型 */
    public effectType: string;
    /**效果时间 */
    public effectTime: number;
    /**缩放比 */
    public scale: number;
    /**层级 */
    public index: number = 0;

    /**
     * 更新图片数据
     */
    public updateImage(img: BgImageControl, changeSrc: boolean = false): void {
        if (img) {
            img.setBaseX(this.x, changeSrc);
            img.setBaseY(this.y, changeSrc);
            img.setBaseScale(this.scale, changeSrc);
        }
    }
}