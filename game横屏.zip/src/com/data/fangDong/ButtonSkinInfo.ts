/**
 * 选项按钮皮肤数据
 */
class ButtonSkinInfo
{
    /**默认皮肤 */
    public btn_up:string;
    /**按下皮肤 */
    public btn_down:string;
    /**选中皮肤 */
    public btn_select:string;
    /**字体尺寸 */
    public size:string;
    /**点击音效 */
    public soundURL:string;
    /**默认颜色 */
    public color_up:number;
    /**点击颜色 */
    public color_down:number;
    /**选中颜色 */
    public color_select:number;
    /**按钮宽度 */
    public width:number;
    /**按钮高度 */
    public height:number;
    /**按钮间距 */
    public space:number;
    /**位置 center:居中, left:居左, left:居右 */
    public align:string;
    /**选中显示时间 0：不停顿, 1:停顿5秒, 2:停顿10秒, 3:点击后再出现 */
    public delayType:number;

    public constructor()
    {

    }

    public transform():void
    {
        
    }
}