/**
 * 对话窗口皮肤数据
 */
class WindowSkinInfo {
    /**窗口资源 */
    public url: string;
    /**窗口位置 0:不显示, 1:上, 2:中, 3:下*/
    public position: number;
    /**文本内容 */
    private _label: string;

    public labelChanged: boolean;

    public labelSize: number = 32;
    public labelLeft: number;
    public labelWidth: number;
    public labelHeight: number;
    public labelTop: number;
    public labelRight: number;
    public labelBottom: number;
    public labelColor: number = 0x333332;
    /**名称位置 0:隐藏, 1:左, 1:中, 2:右 */
    public name: string;
    public nameColor: number;
    /**名字背景资源 */
    public nameURL: string;
    public nameX: number;
    public nameY: number;

    public hasDialog: boolean = false;
    public hasName: boolean = false;
    /**语速(如果为0 ,则直接显示文本) */
    public labelSpeed: number = 0;
    /**文本播放完成后是否自动跳转 */
    public autoChange: boolean = false;
    /**对话框效果 1:无*/
    public dialogType: number = 1;

    /**
     * 解析html文本
     */
    public set label(value: string) {
        var tempLabel: string;
        if (value && value.indexOf("</font>") != -1) {
            //把<br/>和文本式的\\n换成\n
            value = value.replace(/<(\/?br.*?\/)>|\\n/g, "\n");
            var xml: egret.XML = egret.XML.parse("<data>" + value + "</data>");
            var attributes;
            var xmlNode: egret.XMLNode;
            tempLabel = "";
            for (var i: number = 0, len: number = xml.children.length; i < len; i++) {
                xmlNode = xml.children[i];
                if (xmlNode.nodeType == 1) {
                    attributes = (xmlNode as egret.XML).attributes;
                    if (attributes.hasOwnProperty("size"))
                        this.labelSize = attributes.size;
                    if (attributes.hasOwnProperty("color"))
                        this.labelColor = parseInt("0x" + String(attributes.color).slice(1));
                    tempLabel += ((xmlNode as egret.XML).children[0] as egret.XMLText).text;
                }
            }
        }
        else
            tempLabel = value;
        if (this._label != tempLabel) {
            this._label = tempLabel;
            this.labelChanged = true;
        }
        else
            this.labelChanged = false;
    }

    public get label(): string {
        return this._label;
    }

    /**
     * 窗口样式转换
     */
    public transform(boxDialog: eui.Group, imgDialog: eui.Image, txtDialog: eui.Label): void {
        boxDialog.visible = this.hasDialog;
        if (this.hasDialog) {
            /*txtDialog.width = this.labelWidth;
            txtDialog.height = this.labelHeight;*/
            // imgDialog.source = App.data.gameResourceCenter.getRes("other/s1_img_dialog0.png");
            imgDialog.source = App.data.gameResourceCenter.getRes(this.url);
            /*imgDialog.x = this.left;
            imgDialog.y = this.top;
            imgDialog.width = this.labelWidth + this.labelLeft + this.labelRight;
            imgDialog.height = this.labelHeight + this.labelTop + this.labelBottom;*/

            /*txtDialog.x = imgDialog.x + this.labelLeft;
            txtDialog.y = imgDialog.y + this.labelTop;*/

            txtDialog.textColor = this.labelColor;
            txtDialog.size = this.labelSize;
            // txtDialog.textFlow = HtmlUtil.getHtmlStr(this.label);
        }
    }

    /**
     * 名字样式转换
     */
    public transformName(boxName: eui.Group, txtName: eui.Label, imgName: eui.Image): void {
        boxName.visible = this.hasName;
        if (this.hasName) {
            txtName.text = this.name;
            imgName.source = this.nameURL;//"s1_img_name_bg0_png"
            // txtName.textColor = this.nameColor;
            // boxName.x = this.nameX;
            // boxName.y = this.nameY;
        }
    }
}