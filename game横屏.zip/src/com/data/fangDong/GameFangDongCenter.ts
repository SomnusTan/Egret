class GameFangDongCenter {
    /**游戏ID */
    public gameId: number;
    /**剧情步骤ID */
    public id: number;
    /**反馈类型  */
    public type: string;
    /**上一个节点的反馈类型  */
    public lastType: string;
    /**结局标题  */
    public endTitle: string;
    /**对话类型 1:对白, 2:微信对白, 3:微信, 4:视频, 5:条件分歧节点 */
    public chatType: number;
    /**变量组 */
    public conditions: any;
    /**选项文本 */
    public options: any[];
    /**窗口皮肤数据 */
    public windowInfo: WindowSkinInfo;
    /**背景音乐数据 */
    public bgmInfo: SoundInfo;
    /**背景立绘数据 */
    public imageEffectInfo: ImageEffectInfo;
    /**视频路径 */
    public videoURL: string;
    /**购买消耗-现价 */
    public costMoney: number;
    /**购买消耗-原价 */
    public originalMoney: number;
    /** 超值组合礼包 */
    public gift_package: any;
    /**折扣开始时间 */
    public start_time: number;
    /**折扣结束时间 */
    public stop_time: number;
    /**文字播放数据 */
    public typingSpeed: number;
    /**是否自动播放 */
    public isAutoPlay: boolean;
    /**是否正在播放语音 */
    public isPlayingVoice: boolean;
    /**是否正在播放同步音效 */
    public isPlayingSyncSound: boolean;
    /**是否读过 */
    private _hasRead: boolean = false;
    /**快进 */
    private _fastSpeedPlay: boolean = false;
    /**解锁了新的回忆--1:新的回忆壁纸 2:新的回忆视频 3:新的心跳结局 4:额外福利视频 */
    public getNewMemory: number;
    /**已解锁回忆数 */
    public hasGetMemoryNum: number;
    /**是否商城信息 */
    public in_shop_chat: boolean;
    /**回忆总数 */
    public memoryTotal: number;
    /**显示时间 */
    public survivalTime: number;
    /**是否显示GM按钮 */
    public isShowGmBtn: boolean = false;
    /**记录上一次的总分 */
    private _lastHaoGanDu: number;

    private _lastOptions: any[];
    /**全屏粒子效果 */
    public particleEffect: string;
    /**当前章 */
    public currentChapter: number;
    /**当前节 */
    public currentSection: number;
    /**下一章 */
    public nextChapter: number;
    /**下一节 */
    public nextSection: number;
    /**DLC ID*/
    public dlcID: number;
    /**好感度状态 */
    public relationshipStatus: number;

    public constructor() {
        this.windowInfo = new WindowSkinInfo();
    }

    /**
     * 游戏开始初始化
     */
    public init(gameId: number, dlcID: number): void {
        this.gameId = Number(gameId);
        this.isPlayingVoice = false;
        this.isPlayingSyncSound = false;
        this.fastSpeedPlay = false;
        this.dlcID = dlcID;
        if (this.bgmInfo == null) {
            this.bgmInfo = new SoundInfo();
        }
        else {
            this.bgmInfo.reset();
        }
        if (this.imageEffectInfo == null) {
            this.imageEffectInfo = new ImageEffectInfo();
        }
        else {
            this.imageEffectInfo.reset();
        }
        this.survivalTime = 0;
        this.updateSetting(true);
        this.dispose();
    }

    public dispose(): void {
        this.nextSection = 0;
        this.nextChapter = 0;
        this.currentSection = 0;
        this.currentChapter = 0;
    }

    /**
     * 更新默认设置
     */
    public updateSetting(isInit: boolean = false): void {
        var uid: number = App.global.userInfo.uid;
        if (isInit) {
            //每次初始化都要停止自动播放
            this.resetAutoPlay();
            App.sound.isCloseBgm = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_BGM + uid + "_" + this.gameId) ? true : false;
            App.sound.isCloseSound = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_EFFECT + uid + "_" + this.gameId) ? true : false;
            App.sound.isCloseVoice = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_ROLESOUND + uid + "_" + this.gameId) ? true : false;
        }
        else {
            var autoPlay: string = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_AUTOPLAY + uid + "_" + this.gameId);
            this.isAutoPlay = autoPlay ? true : false;
        }
        /**语音速度 */
        var speed: string = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_WORDSPEED + uid + "_" + this.gameId);
        if (!speed)
            speed = "2";
        this.typingSpeed = EnumTypingSpeed.LIST[parseInt(speed)];
    }

    /**
     * 重置自动播放
     */
    public resetAutoPlay(auto: boolean = false): void {
        App.global.storage.setItem(EnumStorageType.HERONIES_SETTING_AUTOPLAY + App.global.userInfo.uid + "_" + this.gameId, auto ? "1" : "");
        this.isAutoPlay = auto;
    }

    /**
     * 解析反馈数据
     */
    public parse(data: any): void {
        this.lastType = this.type;
        this.type = data.type;
        var chapters: string[];
        if (data.chapter_name && data.chapter_name.indexOf("-")) {
            chapters = data.chapter_name.split("-");
            let tChapter: number = Number(chapters[0]);
            if (((data.hasOwnProperty(data.info_id) && data.id == data.info_id) || (this.currentChapter != tChapter && this.currentChapter != 0)) && !data.in_log) {
                App.nativeBridge.sendUMengData(EnumUMengEventID.GAME_CHAPTER + this.gameId + "_" + this.dlcID, { chapter: "第" + tChapter + "章" });
            }
            this.currentChapter = tChapter;
            this.currentSection = Number(chapters[1]);
        }
        if (data.next_chapter_name && data.next_chapter_name.indexOf("-")) {
            chapters = data.next_chapter_name.split("-");
            this.nextChapter = Number(chapters[0]);
            this.nextSection = Number(chapters[1]);
        }
        if (data.hasOwnProperty("balance")) {
            var coin: number = Number(data.balance);
            if (coin != App.global.userInfo.xdCoin) {
                App.global.userInfo.xdCoin = coin;
                App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
            }
        }
        if (this.type == EnumGameStepType.SHOP) {
            this.costMoney = Number(data.money);
            this.originalMoney = Number(data.original_money);
            this.gift_package = data.gift_package;
            this.start_time = Number(data.start_time);
            this.stop_time = Number(data.stop_time);
            if (data.interface)
                this.bgmInfo.setBgmData(data.interface.looping_audio);
        }
        else if (this.type == EnumGameStepType.SUBSCRIPTION) {
            this.costMoney = Number(data.balance_money);
            this.gift_package = {
                id: this.gameId,
                dlcID: this.dlcID,
                price: this.costMoney
            }
            if (data.gift_package) {
                this.gift_package.gift_package = data.gift_package;
            }
            if (data.actual_money) {
                this.gift_package.actual = { actual_title: data.title, actual_money: data.actual_money, actual_discount: data.discount, actual_id: this.gameId };
            }
        }
        else if (this.type == EnumGameStepType.END) {
            this.getNewMemory = Number(data.is_new_memories);
        }
        else if (this.type = EnumGameStepType.CHAT) {
            this.parsechatData(data);
        }
    }

    /**
     * 快进
     */
    public set fastSpeedPlay(value: boolean) {
        this._fastSpeedPlay = value;
        //快进优化级最高,快进时会重置自动播放
        if (this._fastSpeedPlay && this.isAutoPlay) {
            this.resetAutoPlay();
        }
    }

    /**
     * 快进
     */
    public get fastSpeedPlay(): boolean {
        return this._fastSpeedPlay;
    }

    /**
     * 解析聊天类型数据
     */
    private parsechatData(data: any): void {
        this.chatType = Number(data.chat_type);
        this.id = data.id;
        this.in_shop_chat = data.in_shop_chat;
        this.getNewMemory = Number(data.is_new_memories);
        this.hasGetMemoryNum = data.obtained;
        this.memoryTotal = data.total;
        this._hasRead = data.in_log;
        this.conditions = data.condition;
        this.options = data.options;
        this.relationshipStatus = data.relationship_status;
        this.isShowGmBtn = data.hasOwnProperty("condition");

        if (this.isShowGmBtn) {
            if (this.conditions["f.好感度"]) {
                var hgd: number = Number(this.conditions["f.好感度"].value);//总分
                var changeScore: string = "";
                if (this._lastHaoGanDu != undefined && this._lastOptions && this._lastOptions.length > 0) {
                    changeScore = " , 选项分数： (" + (hgd - this._lastHaoGanDu) + ")";
                }
                GameLog.log('>>>>>>>>当前好感度 : ', hgd + changeScore);
                this._lastHaoGanDu = hgd;
                this._lastOptions = this.options;
            }
            if (this.conditions["f.结局分数"]) {
                var jjfs: number = Number(this.conditions["f.结局分数"].value);//总分
                // GameLog.log('>>>>>>>>结局分数：', jjfs);
            }
        }
        //强制显示时间
        if (data.interface.survival_time)
            this.survivalTime = Number(data.interface.survival_time);
        else
            this.survivalTime = 0;
        //解析背景和立绘数据
        this.survivalTime = this.imageEffectInfo.parse(data.interface, this.survivalTime);

        this.particleEffect = data.interface.particle_effect;

        /**
         * 声音解析
         */
        this.bgmInfo.setBgmData(data.interface.looping_audio);
        this.bgmInfo.setSoundData(data.interface.background_music);
        this.bgmInfo.setVoiceData(data.interface.voice);

        /**窗口数据解析 */
        // this.windowInfo.width = data.window.window_width;
        // this.windowInfo.height = data.window.window_height;
        // this.windowInfo.position = data.interface.dialog_position;
        this.endTitle = data.title;
        if (data.interface.text_dia && data.depict != "") {
            this.windowInfo.dialogType = data.interface.hasOwnProperty("text_dia_type") ? Number(data.interface.text_dia_type) : 1;
            this.windowInfo.url = data.interface.text_dia.background;
            // this.windowInfo.left = Number(data.interface.text_dia.dia_left);
            // this.windowInfo.top = Number(data.interface.text_dia.dia_top);
            this.windowInfo.labelLeft = Number(data.interface.text_dia.area_left);
            this.windowInfo.labelTop = Number(data.interface.text_dia.area_top);
            this.windowInfo.labelWidth = Number(data.interface.text_dia.text_width);
            this.windowInfo.labelHeight = Number(data.interface.text_dia.text_height);
            this.windowInfo.labelRight = Number(data.interface.text_dia.area_right);
            this.windowInfo.labelBottom = Number(data.interface.text_dia.area_bottom);
            this.windowInfo.labelColor = parseInt("0x" + data.interface.text_dia.color.slice(1));
            this.windowInfo.label = data.depict;
            this.windowInfo.hasDialog = true;
        }
        else {
            this.windowInfo.hasDialog = false;
        }
        //对话框样式解析
        if (data.interface.name_dia && this.windowInfo.hasDialog) {
            this.windowInfo.hasName = true;
            this.windowInfo.name = data.interface.name_dia.name;
            this.windowInfo.nameColor = parseInt("0x" + data.interface.name_dia.color.slice(1));
            this.windowInfo.nameURL = data.interface.name_dia.background;
            this.windowInfo.nameX = Number(data.interface.name_dia.background_left);
            this.windowInfo.nameY = Number(data.interface.name_dia.background_top);
        }
        else {
            this.windowInfo.hasName = false;
        }
        this.windowInfo.autoChange = data.interface.auto_reading
        this.windowInfo.labelSpeed = data.interface.speed;
        //特殊类型解析
        if (this.chatType == EnumChatType.VIDEO) {
            this.videoURL = data.interface.video;
            this.bgmInfo.bgMusicChanged = true;
        }
        else if (this.chatType == EnumChatType.BENAME) {
            this.windowInfo.hasDialog = true;
            this.windowInfo.label = "还有，我不是“那谁”，我叫";
            this.windowInfo.url = EnumGameRes1.DIALOG0;
            this.windowInfo.labelSpeed = 0;
        }
    }

    /**
     * 是否有选项
     */
    public get hasSelectOptions(): boolean {
        return this.options && this.options.length > 0;
    }

    public get isDLC(): boolean {
        return this.dlcID != 0;
    }

    public get hasRead(): boolean {
        return this._hasRead || Config.skipVideo;
    }
}