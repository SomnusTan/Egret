class SoundInfo {
    /**背景音乐(仅当前场景有效) */
    public bgMusicURL: string;
    /**背景音乐是否改变 */
    public bgMusicChanged: boolean = false;
    /**背景音量 */
    public bgMusicVolume: number = 1;
    /**背景音量是否改变 */
    public bgMusicVolumeChanged: boolean = false;

    /**音效 */
    public soundEffectURL: string;
    /**音效类型(0:正常流程播放 1:跟转场同时播放) */
    public soundEffectType: number;
    /**语音 */
    public voiceURL: string;


    /**
     * 重置数据
     */
    public reset(): void {
        this.bgMusicVolume = 1;
        this.bgMusicVolumeChanged = false;
        this.bgMusicURL = null;
        this.bgMusicChanged = false
        this.soundEffectURL = null;
        this.voiceURL = null;
    }

    /**
     * 设置音乐数据
     */
    public setBgmData(data: any): void {
        if (data) {
            if (this.bgMusicURL != data.music) {
                this.bgMusicURL = data.music;
                this.bgMusicChanged = true;
            }
        }
        else {
            this.bgMusicURL = null;
            this.bgMusicChanged = true;
        }
        if (data && data.music && data.volume != this.bgMusicVolume) {
            this.bgMusicVolume = data.volume;
            this.bgMusicVolumeChanged = true;
        }
    }

    /**
     * 设置音效数据
     */
    public setSoundData(data: any): void {
        if (data && data.music) {
            this.soundEffectType = data.hasOwnProperty("type") ? data.type : "0";
            this.soundEffectURL = data.music;
        }
        else {
            this.soundEffectType = -1;
            this.soundEffectURL = null;
        }
    }

    /**
     * 设置语音数据
     */
    public setVoiceData(data: any): void {
        if (data)
            this.voiceURL = data;
        else
            this.voiceURL = null;
    }

}