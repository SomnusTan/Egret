class Game2Center {

    /**逻辑中心 */
    private _mediatorCnter: Game2MediatorCenter;
    
    private _gameSceneCenter: GameSceneCenter;

    private _loadingLock:LoadingLock;

    public init(): void {
        // this.StageUtils.stage = stage;                       //保存全局Stage
        // App.data.game2Center.StageUtils.fitScreen();                         //适配手机屏幕
        // App.data.game2Center.SoundManager.windowFocusHandler();              //失去或获得窗口焦点时，背景音乐控制
        // LogICT.getInstance();                               //console拦截器
        // egret.registerFontMapping("fzyc","font/fzyc.TTF");  //加载外部字体
        // App.nativeBridge.customLoadingFlag();               //通知runtime加载页面已就绪,可以关闭runtime loading

        //注册Controller
        // this.registerMediator(AppMediator.NAME, new AppMediator());
        // this.registerMediator(LoadMediator.NAME, new LoadMediator());
        // this.registerMediator(LoginMediator.NAME, new LoginMediator());
        // this.registerMediator(GameMediator.NAME, new GameMediator());
        this.mediatorCenter.gameMediator;
    }

    /**
     * 逻辑中心
     */
    public get mediatorCenter(): Game2MediatorCenter {
        if (this._mediatorCnter == null)
            this._mediatorCnter = new Game2MediatorCenter();
        return this._mediatorCnter;
    }
    /**
     * 游戏主界面
     */
    public get gameSceneCenter(): GameSceneCenter {
        if (this._gameSceneCenter == null)
            this._gameSceneCenter = new GameSceneCenter();
        return this._gameSceneCenter;
    }

    /**数据中心*/
    public get DataCenter(): DataCenter {
        return DataCenter.getInstance();
    }

    /**舞台工具类*/
    public get StageUtils(): StageUtils {
        return StageUtils.getInstance();
    }

    /**声音管理*/
    public get SoundManager(): SoundManager {
        return SoundManager.getInstance();
    }

    /**
     * 语音播放管理类
     */
    public get TalkManager(): TalkManager {
        return TalkManager.getInstance();
    }

    /**
     * 加载等待动画 新
     */
    public get LoadingLock(): LoadingLock {
        if(this._loadingLock==null)
            this._loadingLock = new LoadingLock();
        return this._loadingLock;
    }
}