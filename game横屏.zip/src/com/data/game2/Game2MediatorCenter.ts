class Game2MediatorCenter {

    private _loginMediator: LoginMediator;
    private _gameMediator: GameMediator;

    /**
     * 登录逻辑
     */
    public get loginMediator(): LoginMediator {
        if (this._loginMediator == null) {
            this._loginMediator = new LoginMediator();
        }
        if (this._loginMediator.hasRegister == false) {
            this._loginMediator.onRegister();
        }
        return this._loginMediator;
    }

    public get gameMediator(): GameMediator {
        if (this._gameMediator == null) {
            this._gameMediator = new GameMediator();
        }
        if (this._gameMediator.hasRegister == false) {
            this._gameMediator.onRegister();
        }
        return this._gameMediator;
    }
}