class LogCenter {

	private logHashMap: HashMap = new HashMap();

	/**
	 * 日志的总数
	 */
	public logTotalNum: number = 0;

	/**
	 * 日志的字符数大小
	 */
	public logTotalCharLength: number = 0;

	/**
	 * 根据类型存入日志信息
	 * @param type      日志类型(EnumLogType枚举)
	 * @param args      日志内容
	 *
	 */
	public inputMsgByType(type: number, ...args): void {
		let arr: Array<any> = this.logHashMap.get(type);
		if (arr == null) {
			arr = [];
			this.logHashMap.put(type, arr);
		}

		EnumLogType.indexArr[type]++;
		let msg: string = EnumLogType.indexArr[type] + "、[" + EnumLogType.typeArr[type] + "] " + args.join(" ") + "\n\n";
		arr.push(msg);

		this.logTotalNum++;
		this.logTotalCharLength += msg.length;

		if (arr.length >= EnumLogType.maxArr[type]) {
			arr.splice(10); //保留最早的10条
		}
	}

	/**
	 * 通过日志的类型获取日志数组数据
	 * @param type		日志类型 EnumLogType
	 * @return
	 *
	 */
	public getMsgsByType(type: number): Array<any> {
		let arr: Array<any> = [];
		if (this.logHashMap.get(type) != null) {
			arr = this.logHashMap.get(type);
		}
		return arr;
	}

	/**
	 * 根据字符串匹配日志信息字典
	 * @param field		需要检索的字符串
	 * @param type		需要检索的日志类型
	 * @return
	 *
	 */
	public getMsgsByRegExp(type: number, field: string): Array<any> {
		let arr: Array<any> = [];
		let regExp: RegExp = new RegExp(field);
		let msgs: Array<any> = this.getMsgsByType(type);
		for (let i: number = 0; i < msgs.length; i++) {
			if (regExp.test(msgs[i])) {
				arr.push(msgs[i]);
			}
		}

		return arr;
	}

}