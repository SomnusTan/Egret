/**
 * 账号的基础信息
 */
class BaseCenter
{
    /**等级 */
    public level:number;
}