class ChargeVo {
    /**商品ID */
    public id: number;
    /**商品名称 */
    public name: string;
    /**商品金额 */
    public money: number;
    /**商品描述 */
    public depict: string;
    /**商品个数 */
    public num: number;
    /**商品类型 1:心动币 */
    public type: number;
    /**显示索引 */
    public index: number;

    public constructor(data: any) {
        this.id = Number(data.id);
        this.name = data.name;
        this.money = Number(data.money);
        this.depict = data.depict;
        this.num = Number(data.number);
        this.type = Number(data.type);
        this.index = Number(data.index) - 1;
    }
}