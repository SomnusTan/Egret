class ActivityVo {

    /**活动ID */
    public id: number;
    /**活动标题 */
    public title: string;
    /**开始时间 */
    public startTime: number;
    /**结束时间 */
    public stopTime: number;
    /**显示类型 0:不可用(变灰) 1:正常 */
    public type: number;

    public constructor(data: any) {
        this.parse(data);
    }

    public parse(data: any): void {
        this.id = data.id;
        this.title = data.title;
        this.type = data.type;
        this.startTime = data.start_time;
        this.stopTime = data.stop_time;
    }

    /**
     * 活动是否开启
     */
    public isOpen(): boolean {
        var time: number = ServerTime.serverTime;
        return time >= this.startTime && time < this.stopTime;
    }


}