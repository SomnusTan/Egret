class GameResourceCenter {
    /**配置路径 */
    private _configURL: string = "";
    /**资源路径头 */
    private _baseURL: string = "";
    /**游戏女主ID */
    private _gameId: number = 0;
    /**dlc ID */
    private _dlcID: number = 0;
    /**版本号 */
    private _version: string = "";

    /**章节资源组名 0:ui资源*/
    private _chapterResGroupNameList: string[] = [];
    /**组资源名 0:ui资源*/
    private _chapterResourceKeyList: any[][] = [];
    /**已经加载过的章节组 0:ui资源*/
    private _hasLoadedChapterList: boolean[] = [];

    /**资源配置 */
    private _configJson: any;
    /**资源组头 */
    private start_name: string = "heroine_";
    /**dlc资源组头 */
    private start_dlc_name: string = "s_dlc_";
    /**最多同时存在的资源章节数 */
    private MAX_RES_CHAPTER: number = 2;

    public SOUND_SUFFIX: string = "_sound";

    public IMAGE_SUFFIX: string = "_image";

    private _activateSoundList: string[];

    public constructor() {

    }

    /**
     * 资源版本配置数据
     */
    public parseData(data: any, saveId: number): void {
        var dlcID: number = data.hasOwnProperty("dlc_id") ? Number(data.dlc_id) : 0;
        if (Config.isLocalApp && data.oss.indexOf("//") == 0) {
            data.oss = "https:" + data.oss;
        }
        if (this.hasResource()) {
            if (this._gameId == Number(data.heroine_id)) {
                if (this._dlcID == dlcID) {
                    if (this._configURL == data.oss && this._version == data.version) {
                        this.closeOtherPanel();
                        GameManager.startGame(Number(data.heroine_id), dlcID, { saveId: saveId, id: Number(data.heroine_id), dlcID: dlcID });
                        return;
                    } else {
                        this.dispose(false);
                    }
                }
                else {
                    this.dispose(false);
                }
            }
            else {
                PanelManager.disposePanelyByGameId(this._gameId);
                GameManager.disposeGame(this._gameId, this._dlcID);
                this.dispose();
            }
        }
        else if (GameManager.lasetGameId == EnumGameID.GAME2) {
            if ((DeviceUtil.isMobile && DeviceUtil.IsWeb) || DeviceUtil.IsNative) {
                PanelManager.disposePanelyByGameId(EnumGameID.GAME2);
                App.res.destoryGroup([AssetConst.LoadPanel]);
                App.res.destoryGroup(DeviceUtil.isWebIOS ? AssetConst.SOUND_RES_LIST : AssetConst.ONLY_IMAGE_RES_LIST);
            }
        }
        var resName: string = this.start_name + data.heroine_id;
        var resItemInfo: RES.ResourceItem = (RES["configInstance"] as RES.ResourceConfig).getResourceItem(resName);
        if (resItemInfo) {
            resItemInfo.url = data.oss + (DeviceUtil.IsNative ? "" : "?v=" + data.version);
            if (RES.hasRes(resName)) {
                RES.destroyRes(resName);
            }
        }
        else {
            RES["configInstance"].addItemToKeyMap({
                name: this.start_name + Number(data.heroine_id),
                type: RES.ResourceItem.TYPE_JSON,
                url: data.oss + (DeviceUtil.IsNative ? "" : "?v=" + data.version)
            });
        }
        App.nativeBridge.log("start load resource config:" + data.oss);
        GameLog.log('开始加载资源配置文件:' + data.oss);
        // RES.getResByUrl(data.oss + (DeviceUtil.IsNative ? "" : "?v=" + data.version), (json: any) => {
        //     GameLog.log('加载资源配置文件成功:' + data.oss);
        //     this.parseJsonData(Number(data.heroine_id), data.version, data.oss, json);
        //     GameManager.startGame(this._gameId, { id: this._gameId, saveId: saveId });
        // }, this, RES.ResourceItem.TYPE_JSON);
        RES.getResAsync(resName, (json: any) => {
            if (json) {
                GameLog.log('加载资源配置文件成功:' + data.oss);
                this.parseJsonData(Number(data.heroine_id), dlcID, data.version, data.oss, json);
                this.closeOtherPanel();
                GameManager.startGame(this._gameId, this._dlcID, { id: this._gameId, dlcID: this._dlcID, saveId: saveId });
            }
            else {
                Notice.showBottomCenterMessage("加载配置文件失败,请重试");
            }
        }, this);
    }

    private closeOtherPanel(): void {
        PanelOpenManager.removePanel(EnumPanelID.HEROINES_DETAIL);// 关闭女主详情
        PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_BUY);
        PanelOpenManager.removePanel(EnumPanelID.RECORD);
        PanelOpenManager.removePanel(EnumPanelID.OTHER_STORY);
    }


    /**
     * 解析配置,生成资源配置组
     */
    public parseJsonData(gameId: number, dlcID: number, version: string, configURL: string, json: any): void {
        this._gameId = gameId;
        this._dlcID = dlcID;
        this._version = version;
        this._configURL = configURL;
        var index: number = configURL.lastIndexOf("/");
        this._baseURL = configURL.substr(0, index + 1);
        var chapter: number;
        var group: any;
        var startGroupName: string = this.start_name + this._gameId + "_";
        var startDlcName: string = this.start_dlc_name + this._gameId + "_" + dlcID + "_";
        //高版本资源解析
        var tempList: any[] = json.resources;
        var resourceData: any;
        for (var i: number = 0, len: number = tempList.length; i < len; i++) {
            resourceData = tempList[i];
            // resourceData.url = Config.RESOURCE_PATH + "game/" + this._groupName + "/" + resourceData.url;
            resourceData.url = this._baseURL + resourceData.url + "?v=" + version;
            resourceData.extra = 1;
            resourceData.root = "";
            RES["configInstance"].addItemToKeyMap(resourceData);
        }
        var groupName: string;
        for (var i: number = 0, len: number = json.groups.length; i < len; i++) {
            group = json.groups[i];
            chapter = -1;
            groupName = group.name;
            if (groupName == startGroupName + "ui") {
                chapter = 0;
            }
            else {
                if (dlcID == 0 && groupName.indexOf(this.start_name) != -1) {
                    chapter = Number(groupName.substr(startGroupName.length));
                }
                else if (dlcID != 0 && groupName.indexOf(this.start_dlc_name) != -1) {
                    chapter = Number(groupName.substr(startDlcName.length));
                }
            }
            if (chapter >= 0) {
                this._chapterResGroupNameList[chapter] = groupName;
                this._chapterResourceKeyList[chapter] = this.parseKeys(group.keys.split(","));
                if (chapter != 0) {//章节资源分图片和声音
                    RES.createGroup(groupName + this.IMAGE_SUFFIX, this._chapterResourceKeyList[chapter][0], false);
                    RES.createGroup(groupName + this.SOUND_SUFFIX, this._chapterResourceKeyList[chapter][1], false);
                }
                else {
                    RES.createGroup(groupName, this._chapterResourceKeyList[chapter][0], false);
                }
            }
        }
    }

    /**
     * 把图片和声音分两组
     */
    private parseKeys(keys: string[]): any[] {
        for (var i: number = 0, len: number = keys.length; i < len; i++) {
            if (keys[i].indexOf("_mp3") != -1) {
                break;
            }
        }
        return [keys.slice(0, i), keys.slice(i)];
    }

    /**
     * 是否有章节资源
     * @param chapter 章节
     */
    public hasChapterResource(chapter: number): boolean {
        if (this._chapterResGroupNameList == null)
            return false;
        return this._hasLoadedChapterList[chapter] == true;
    }

    /**
     * 通过原生方法获取章节资源是否加载
     */
    public hasChapterResourceByNative(chapter: number): boolean {
        if (this._chapterResGroupNameList == null)
            return false;
        if (chapter == 0)
            return App.res.isGroupLoaded(this._chapterResGroupNameList[chapter]);
        else {
            var bool: boolean = App.res.isGroupLoaded(this._chapterResGroupNameList[chapter] + this.IMAGE_SUFFIX);
            if (Config.soundAsyncLoad)
                bool = bool && App.res.isGroupLoaded(this._chapterResGroupNameList[chapter] + this.SOUND_SUFFIX);
            return bool
        }
    }

    /**
     * 设置加载过的章节
     * @param chapter 章节 如果设置了,则表示UI也加载完了
     */
    public setLoadedResourceChapter(chapter: number): void {
        if (this._chapterResGroupNameList && this._hasLoadedChapterList) {
            this._hasLoadedChapterList[0] = true;
            this._hasLoadedChapterList[chapter] = true;
            if (chapter != 0 && this.needActivateSound) {
                this.createActivateSound(chapter);
            }
        }
    }

    /**
     * 释放空闲的资源
     * @param chapter 当前章节
     */
    public disposeFreeChapter(currentChapter: number): void {
        if (this.getChapterResLoadedCount() > this.MAX_RES_CHAPTER) {
            var tempList: { chapter, dis }[] = [];
            for (var i: number = 1, len: number = this._hasLoadedChapterList.length; i < len; i++) {
                if (this._hasLoadedChapterList[i] == true)
                    tempList.push({ chapter: i, dis: Math.abs(currentChapter - i) });
            }
            tempList.sort((a: { chapter, dis }, b: { chapter, dis }) => {
                if (a.dis < b.dis)
                    return -1;
                else if (a.dis > b.dis)
                    return 1;
                else
                    return 0;
            });
            tempList = tempList.slice(2);
            for (i = 0, len = tempList.length; i < len; i++) {
                this.disposeChapter(tempList[i].chapter);
            }
        }
    }

    /**
     * 创建声音激活列表
     */
    public createActivateSound(chapter: number): void {
        if (this._chapterResGroupNameList) {
            var groupName: string = this._chapterResGroupNameList[chapter] + this.SOUND_SUFFIX;
            this._activateSoundList = this._chapterResourceKeyList[chapter][1].concat([]);
        }
    }

    /**
     * 激活声音
     */
    public activateSound(): void {
        if (this.needActivateSound && this._activateSoundList && this._activateSoundList.length > 0) {
            var sound: egret.Sound;
            var channel: egret.SoundChannel;
            for (var i: number = 0, len: number = this._activateSoundList.length; i < len; i++) {
                sound = RES.getRes(this._activateSoundList[i]);
                channel = sound.play();
                channel.stop();
            }
            this._activateSoundList.length = 0;
            this._activateSoundList = null;
        }
    }

    /**
     * 是否需要激活声音
     */
    public get needActivateSound(): boolean {
        return DeviceUtil.isWebIOS;
    }

    /**
     * 通过章节获取组名(已经加载过UI了,直接返回组名,未加载过UI,则添加UI组拼出一个新数组返回)
     * @param chapter
     */
    public getChapterGroupName(chapter: number): string[] {
        if (this._chapterResGroupNameList) {
            if (chapter == 0)
                return this._hasLoadedChapterList[0] ? [] : [this._chapterResGroupNameList[0]];
            if (this._hasLoadedChapterList[0]) {
                if (Config.soundAsyncLoad)
                    return [this._chapterResGroupNameList[chapter] + this.SOUND_SUFFIX, this._chapterResGroupNameList[chapter] + this.IMAGE_SUFFIX];
                else
                    return [this._chapterResGroupNameList[chapter] + this.IMAGE_SUFFIX];
            }
            else {
                if (Config.soundAsyncLoad)
                    return [this._chapterResGroupNameList[chapter] + this.SOUND_SUFFIX, this._chapterResGroupNameList[chapter] + this.IMAGE_SUFFIX, this._chapterResGroupNameList[0], EnumResGroupName.EFFECT_FILTER];
                else
                    return [this._chapterResGroupNameList[chapter] + this.IMAGE_SUFFIX, this._chapterResGroupNameList[0], EnumResGroupName.EFFECT_FILTER];
            }
        }
        return null;
    }

    /**
     * 释放章节资源
     */
    public disposeChapter(chapter: number, force: boolean = false): void {
        if (DeviceUtil.IsWeb && !DeviceUtil.isMobile && force == false) {
            GameLog.log('PC端网页不做资源释放');
            return;
        }
        if (this._chapterResGroupNameList) {
            var chapterName: string = this._chapterResGroupNameList[chapter];
            var bool: boolean;
            if (chapterName) {
                if (chapter == 0) {
                    bool = RES.destroyRes(chapterName);
                }
                else {
                    bool = RES.destroyRes(chapterName + this.IMAGE_SUFFIX);
                    if (Config.soundAsyncLoad)
                        bool = bool && RES.destroyRes(chapterName + this.SOUND_SUFFIX);
                }
            }
            GameLog.log('释放资源章节:' + chapter + "[" + bool + "]");
            this._hasLoadedChapterList[chapter] = false;
        }
    }

    /**
     * 获取已经加载资源的章节数
     */
    public getChapterResLoadedCount(): number {
        var count: number = 0;
        if (this._hasLoadedChapterList) {
            for (var i: number = 0, len: number = this._hasLoadedChapterList.length; i < len; i++) {
                if (this._hasLoadedChapterList[i] == true) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * 释放资源
     */
    public dispose(disposeUI: boolean = true): void {
        if (this._chapterResGroupNameList) {
            for (var i: number = disposeUI ? 0 : 1, len: number = this._chapterResGroupNameList.length; i < len; i++) {
                if (this._hasLoadedChapterList[i] && this._chapterResGroupNameList[i]) {
                    this.disposeChapter(i, true);
                }
            }
            if (disposeUI) {
                this._chapterResGroupNameList.length = 0;
                this._chapterResourceKeyList.length = 0;
                this._hasLoadedChapterList.length = 0;
            }
            else {
                this._chapterResGroupNameList.length = 1;
                this._chapterResourceKeyList.length = 1;
                this._hasLoadedChapterList.length = 1;
            }
        }
        if (this._configURL) {
            this._configURL = "";
            this._configJson = "";
            this._baseURL = "";
            this._gameId = 0;
            this._dlcID = 0;
            this._version = ""
        }
    }

    /**
     * 播放背景音乐
     */
    public playBgmSound(key: string): void {
        if (Config.soundAsyncLoad) {
            App.sound.playBgm(key, 2000, true, true);
        }
        else {
            var info: RES.ResourceItem = (RES["configInstance"] as RES.ResourceConfig).getResourceItem(key);
            if (info) {
                App.sound.playBgm(info.url, 2000, false, true);
            }
        }
    }

    /**
     * 播放语音
     */
    public playVoice(key: string, callback: FunctionVO): boolean {
        if (Config.soundAsyncLoad) {
            return App.sound.playVoiceByKey(key, callback);
        }
        else {
            var info: RES.ResourceItem = (RES["configInstance"] as RES.ResourceConfig).getResourceItem(key);
            if (info) {
                return App.sound.playVoice(info.url, callback);
            }
            return false;
        }
    }

    /**
     * 播放音效
     */
    public playSound(key: string, callback: FunctionVO = null): void {
        if (Config.soundAsyncLoad) {
            App.sound.playSoundByKey(key, false, 0, 1, callback);
        }
        else {
            var info: RES.ResourceItem = (RES["configInstance"] as RES.ResourceConfig).getResourceItem(key);
            if (info) {
                App.sound.playSound(info.url, false, 0, 1, callback);
            }
        }
    }

    public stopSound(key: string): void {
        if (Config.soundAsyncLoad) {
            App.sound.stopSound(key);
        }
        else {
            var info: RES.ResourceItem = (RES["configInstance"] as RES.ResourceConfig).getResourceItem(key);
            if (info) {
                App.sound.stopSound(info.url);
            }
        }
    }

    /**
     * 获取资源
     * @param key 资源名
     */
    public getRes(key: string): any {
        return RES.getRes(key);
    }

    /**
     * 验证资源是否匹配
     * @param gameId 游戏ID
     * @param configURL 配置路径
     * @param version 版本号
     */
    public checkResource(gameId: number, configURL: string, version: string): boolean {
        return this._gameId == gameId && this._configURL == configURL && this._version == version;
    }

    /**
     * 是存有管理资源
     */
    public hasResource(): boolean {
        return this._configURL != "" && this._gameId != 0 && this._version != "";
    }

    /**
     * 游戏女主ID
     */
    public get gameId(): number {
        return this._gameId;
    }

    /**
     * DLC ID
     */
    public get dlcID(): number {
        return this._dlcID;
    }

    /**
     * 配置路径
     */
    public get configURL(): string {
        return this._configURL;
    }

    /**
     * 资源路径头
     */
    public get baseURL(): string {
        return this._baseURL;
    }

    /**
     * 版本号
     */
    public get version(): string {
        return this._version;
    }
}