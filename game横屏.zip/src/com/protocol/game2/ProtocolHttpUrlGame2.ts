/**
 * Http协议
 * @author xiongjian
 * @date 2016/11/17
 */
class ProtocolHttpUrlGame2 {
    /**获取链接 */
    public static get url() {
        if (Config.isRelease) {
            if (Config.isHttps) {
                return "https://www.dmgame.com";    //https 正式地址
            } else {
                if(DeviceUtil.IsNative)
                    return "http://www.dmgame.com:80";       //http 正式地址
                else
                    return "http://47.104.85.224:3000";
            }
        } else {
            if (Config.isHttps) {
                // return "https://xdh5.aqgame.cn:3443";   //https 测试地址
                return "http://192.168.0.121:8087";        //测试 https
            } else {
                // return "http://47.104.85.224:3000";       //http 测试地址
                return "http://192.168.0.121:8087";       //http 测试地址
            }
        }
    }
    /************************vivo接口 *-***********************/
    /**vivo登陆 */
    public static loginVivo = "/user/login/vivo/";

    /************************小米接口 *-***********************/
    /**小米登陆 */
    public static loginXiaoMi = "/user/login/xiaomi/";

    /*************************玩吧接口****************** */
    /**玩吧登陆 */
    public static loginWanBa = "/user/login/wanba/";
    /**
     * 发货
     */
    public static paymentWanbaDo = "/payment/wanba/do/";
    /**
     * 玩吧礼包数据接口
     */
    public static userInviteGain = "/user/invite/gain/";
    /*******************************神秘商店 */
    /***商品列表 */
    public static userSpecialGoods = "/user/special/goods/";
    /**商品列表 刷新 */
    public static userSGR = "/user/special/goods/refresh/";
    /**商品列表购买 */
    public static userSGB = "/user/special/goods/buy/";
    /************************************* */
    /**注册 */
    public static register = "/user/register/";
    /**登录 */
    public static login = "/user/login/";
    /**7k7k登录 */
    public static k7k7_login = "/user/login/7k7k/";
    /**游客登录 */
    public static guest = "/user/guest/";
    /**登出 */
    public static logout = "/user/logout/";
    /**游戏信息 */
    public static gameinfo = "/game/info/";
    /**微信聊天 */
    public static chat = "/chat/finish/";
    /**恋爱列表 */
    public static loves = "/user/loves/";
    /**恋爱开始 */
    public static loveStart = "/love/start/";
    /**恋爱结束 */
    public static loveFinish = "/love/finish/";
    /**恋爱立即结束 */
    public static loveFinishNow = "/love/finish/immediate/";

    /**工作列表 */
    public static works = "/user/works/";
    /**工作开始 */
    public static workStart = "/work/start/";
    /**工作结束 */
    public static workFinish = "/work/finish/";
    /**工作立即结束 */
    public static workFinishNow = "/work/finish/immediate/";
    /**升职 */
    public static workPromotion = "/work/promotion/";

    /**请求电话微信 */
    public static userChats = "/user/chats/";

    /**道具购买 */
    public static toolsBuy = "/shop/tool/buy/";
    /**礼包购买 */
    public static giftBuy = "/shop/gift/buy/";
    /**最近的订单 */
    public static shop_end_order = "/shop/end_order";
    /**背包列表 */
    public static bags = "/user/bags/";

    /**能否升级判断接口 */
    public static prepare = "/game/prepare/";
    /**用户升级 */
    public static upgrade = "/game/level/upgrade/";
    /**购买视频 */
    public static videoBuy = "/user/video/buy/";
    /**视频播放接口 */
    public static videoPlay = "/video/play/";
    /**微博评论 */
    public static weiboComment = "/weibo/comment/";
    /**微博赞 */
    public static weiboApprove = "/weibo/approve/";

    /**使用道具 */
    public static useTool = "/shop/tool/use/";
    /**礼品下方 */
    public static giftForUser = "/shop/ios/gift/to/user/";
    /**领取体力 */
    public static powerGain = "/power/gain/";
    /**邮件列表 */
    public static mailList = "/mail/list/";
    /**领取邮件 */
    public static mailLingqu = "/mail/gain/";
    /**新手引导接口 */
    public static guide = "/guide/will_do_guide/";
    /**新手引导接口完成 */
    public static guideDone = "/guide/step_done/";
    /**随机用户名 */
    public static randomName = "/user/name/random/";
    /**用户昵称绑定 */
    public static nameBind = "/user/name/bind/";
    /**协议图片 */
    public static protocalImg = "/user/princeple/";
    /**体力状态 */
    public static tiliStatus = "/user/power/status/";
    /**获取视频url  浏览器使用*/
    public static videoUrl = "/video/url/";

    public static payStatusH5 = "/user/pay/status/";
    /**请求分享奖励 */
    public static shareGain = "/share/gain/";
    /**登录奖励详情 */
    public static loginReward = "/user/login/reward/";
    /**领取登录奖励 */
    public static gainLoginReward = "/user/login/reward/gain/";
    /**首付礼包详情 */
    public static fpayReward = "/user/fpay/reward/";
    /**访问邀请码 */
    public static inviteGain = "/user/invite/gain/";
    /**请求首冲礼包奖励 */
    public static rewardGin = "/user/fpay/reward/gain/";
    /**视频列表 */
    public static videoList = "/user/videos/";
    /** 视频列表*/
    public static userCollections = "/user/collections/";
    /** 解锁背景图片*/
    public static userBgiUnlock = "/user/bgi/unlock/";
    /** 设置背景图片*/
    public static userBgiSet = "/user/bgi/set/";
    /**公告 */
    public static attention = "/game/attention/";
    /**u8 登录 */
    public static u8_login = "/user/login/u8/";
    /**版本信息 */
    public static authorInfo = "/game/author/info/";
    /**后台开关配置读取 */
    public static upgradeStatus = "/client/upgrade/status/";
    /**累计充值*/
    public static getTotal_pay = "/user/tpay/reward/gain/";
    //dlc模块
    /**获取章节列表 */
    public static dlc_getChapters = "/extra/chapters/";
    /**获取章节详情 */
    public static dlc_getChaptersDetail = "/extra/chapters/detail/";
    /**对话请求 */
    public static dlc_storyNex = "/extra/story/next/";
    /**跳过 */
    public static dlc_skip = "/extra/story/skip/";
    /**结算接口 */
    public static dlc_storyFinish = "/extra/story/finish/";
    /**月卡领取 */
    public static lingqumonthly = "/shop/gift/monthly/";
    /**soeasy 屏蔽公告列表 */
    public static fitlerList = "/game/attention/fitler/list/";
    /**360渠道接口 */
    public static h5_360 = "/user/login/360/";
    /**设备情况统计 */
    public static fd_start_info = "/fd/start/info/";
    /**渠道最新优惠 */
    public static channel_new_offer = "/channel/new/offer/";
    /**心动之旅心动碎片兑换 */
    public static extra_chapters_fragment_exchange = "/extra/chapters/fragment/exchange/";
}
