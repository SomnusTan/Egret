/**
 * 赵小野通讯
 */
class ProtocolGame2 extends ProtocolBase {
    private static _instance: ProtocolGame2;

    public static instance(): ProtocolGame2 {
        if (this._instance == null) {
            this._instance = new ProtocolGame2();
        }
        return this._instance;
    }

    /**
     * 微信支付
     */
    public send_shop_gift_buy(callBack: FunctionVO): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, {}, callBack);
    }

    /**
     * 心动之旅心动碎片兑换
     */
    public send_extra_chapters_fragment_exchange(callBack: FunctionVO): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.extra_chapters_fragment_exchange, {}, callBack);
    }

    /**
     * 请求渠道优惠活动
     */
    public send_channel_offer(channelId: string, callBack: FunctionVO): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.channel_new_offer, { channel_id: channelId }, callBack);
    }

    /**
     * 请求开关配置
     */
    public send_upgrade_status(callBack: FunctionVO): void {
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.upgradeStatus, {}, callBack);
    }

    /**
     * 请求绑定心动1用户名
     */
    public sendGame2NameBind(account: string, callBack: FunctionVO): void {
        ProtocolBase.sendBack(ProtocolHttpUrl.user_bind_name, { name: account }, callBack, true, ProtocolHttpUrl.ip)
    }

    /**
     * 赵小野版本通用请求
     */
    public static sendCommom(url: string, data: any, callBack: FunctionVO, notice: boolean = false, needTimeOut: boolean = true): void {
        data = this.extendObj(ProtocolHttp.httpHead, data);
        ProtocolBase.sendBack(url, data, callBack, notice, null, false, needTimeOut);
    }

    /**
	 * 合并请求头和参数
	 * @param obj1 请求头
	 * @param obj2  参数
	 */
    private static extendObj(obj1: Object, obj2: Object) {
        var obj3: any = {};
        for (let key in obj2) {
            if (obj3.hasOwnProperty(key)) continue;
            obj3[key] = obj2[key];
        }
        for (let key in obj1) {
            if (obj3.hasOwnProperty(key))
                continue;
            if (key == "Authorization")
                obj3[key] = App.data.game2Center.DataCenter.skey;
            else
                obj3[key] = obj1[key];
            // if (App.data.game2Center.DataCenter.skey) {
            //     GameLog.log("sky:::", App.data.game2Center.DataCenter.skey)
            // }
        }
        obj3.AuthorizationID = App.global.userInfo.uid;
        return obj3;
    }

}