class ProtocolBase {

    public static send(url: string, data: any, onComplete: Function, thisObj: any, notice: boolean = true, needAddToken: boolean = true, needTimeOut: boolean = true): void {
        this.sendBack(url, data, new FunctionVO(onComplete, thisObj), notice, null, needAddToken, needTimeOut);
    }

    public static sendBack(url: string, data: any, callBack: FunctionVO, notice: boolean = true, baseURL?: string, needAddToken: boolean = true, needTimeOut: boolean = true): void {
        let skey: string = App.global.userInfo.skey;
        // if (DeviceUtil.IsWeb && skey != null && skey != "null" && skey != "") {
        //     document.cookie = "Authorization=" + skey;
        // }
        if (needAddToken && skey != null && skey != "null" && skey != "") {
            data.Authorization = skey;
        }
        let userId: number = App.global.userInfo.uid;
        if (needAddToken && userId) {
            data.AuthorizationID = userId;
        }
        var http: HttpRequest = new HttpRequest();
        http.requestCompleteFun = callBack;
        http.needTimeOut = needTimeOut;
        http.noticeError = notice;
        if (baseURL) {
            http.baseURL = baseURL;
        }
        http.needAddToken = needAddToken;
        http.send(url, JSON.stringify(data));
    }
}