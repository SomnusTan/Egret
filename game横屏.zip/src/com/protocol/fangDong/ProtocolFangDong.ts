/**
 * 房东通讯
 */
class ProtocolFangDong extends ProtocolBase {
    private static _instance: ProtocolFangDong;

    public static instance(): ProtocolFangDong {
        if (this._instance == null) {
            this._instance = new ProtocolFangDong();
        }
        return this._instance;
    }

    /**
     * 请求随机名
     */
    public send_random_name(): void {
        ProtocolBase.sendBack(ProtocolHttpUrl.random_role_name, {}, new FunctionVO(this.receive_random_name, this));
    }

    /**
     * 随机名字反馈
     */
    public receive_random_name(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.dispatcher.dispatchEvent(GameEvent.GAME_RANDOM_NAME, response.data);
        }
    }

    /**
     * 取名
     */
    public send_bename(name: string, gameId: number): void {
        ProtocolBase.sendBack(ProtocolHttpUrl.bename, { user_name: name, heroine_id: gameId }, new FunctionVO(this.receive_bename, this));
    }

    /**
     * 取名反馈
     */
    public receive_bename(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.dispatcher.dispatchEvent(GameEvent.GAME_BENAME, response.data);
        }
    }

    /**
     * 聊天初始化
     * @param gameId 女主ID
     * @param dlcID
     * @param saveId 存档ID (非dlc(0:自动存档 1-6:存档序号 7:重新开始),dlc(0:重新开始 1:自动存档))
     * @description method:1:原来的买断付费 2:分章购买(会弹提示) 3:分章自动解锁
     */
    public send_chat_init(gameId: number, dlcID: number, saveId: number = 0): void {

        if (dlcID == 0) {
            ProtocolBase.sendBack(ProtocolHttpUrl.chat_init, {
                heroine_id: gameId,
                schedule_id: saveId,
                channel_id: App.global.userInfo.channelId,
                method: App.global.avgAutoPay ? 3 : 2
            }, new FunctionVO(this.receive_chat_init, this));
        }
        else {
            ProtocolBase.sendBack(ProtocolHttpUrl.dlc_info, {
                dlc_id: dlcID,
                schedule_id: saveId,
                channel_id: App.global.userInfo.channelId,
                method: App.global.avgAutoPay ? 3 : 2
            }, new FunctionVO(this.receive_chat_init, this));
        }
    }

    /**
     * 聊天初始化反馈
     */
    private receive_chat_init(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.data.gameFangDongCenter.parse(response.data);
            App.dispatcher.dispatchEvent(GameEvent.GAME_INIT);
        }
    }

    /**
     * 聊天下一步
     * @param gameId
     * @param dlcID
     * @param options 选项 0:无选项 1之后:选项
     * @param autoBuy 0:走默认设置 1:原买断制 2:章节购买 3:自动解锁
     */
    public send_chat_select(gameId: number, dlcID: number, options: number = 0, autoBuy: number = 0): void {
        if (dlcID == 0) {
            ProtocolBase.sendBack(ProtocolHttpUrl.chat_select, {
                heroine_id: gameId,
                options: options,
                channel_id: App.global.userInfo.channelId,
                method: autoBuy != 0 ? autoBuy : App.global.avgAutoPay ? EnumPayType.AVG_BUY_TYPE_3 : EnumPayType.AVG_BUY_TYPE_2
            }, new FunctionVO(this.receive_chat_select, this));
        }
        else {
            ProtocolBase.sendBack(ProtocolHttpUrl.dlc_select, {
                dlc_id: dlcID,
                options: options,
                channel_id: App.global.userInfo.channelId,
                method: App.global.avgAutoPay ? 3 : 2
            }, new FunctionVO(this.receive_chat_select, this));
        }
    }

    private receive_chat_select(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.data.gameFangDongCenter.parse(response.data);
            App.dispatcher.dispatchEvent(GameEvent.GAME_NEXT);
        }
        else {
            if (response.code == 234) {
                PanelOpenManager.openPanel(EnumPanelID.GAME_CHARGE,{ type: 0, minCoin: 200, successClose: true });
            }
        }
    }

    /**
     * 请求回放数据
     */
    public send_chat_review(gameId: number, page: number = 1): void {
        ProtocolBase.sendBack(ProtocolHttpUrl.chat_review, { heroine_id: gameId, limit: page }, new FunctionVO(this.receive_chat_review, this));
    }

    /**
     * 回放数据返回
     */
    private receive_chat_review(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.dispatcher.dispatchEvent(GameEvent.GAME_REVIEW_DATA, response.data);
        }
    }
}