/**
 * Http协议
 * @author xiongjian
 * @date 2016/11/17
 */
class ProtocolHttpUrl {


    private static _ip: string = null;

    public static set ip(value: string) {
        this._ip = value;
    }

    public static get ip(): string {
        if (!this._ip) {
            if (Config.isRelease) {
                if (Config.isHttps) {
                    // https 正式地址
                    // return "https://xdh5.aqgame.cn:3443";
                    return "https://avg.dmgame.com";
                } else {
                    // http 正式地址
                    // return "http://www.dmgame.com:80";
                    return "http://csserver.kdfa.cn";
                }
            } else {
                if (Config.isHttps) {
                    // https 测试
                    return "https://xdcs.aqgame.cn:3333";
                } else {
                    // http 测试服
                    return "http://192.168.0.121:8888";
                }
            }
        }
        else {
            return this._ip;
        }
    }

    /**soeasy登陆 */
    public static loginSoeasy = "/user/soeasy/login";
    /**vivo登陆 */
    public static loginVivo = "/user/login/vivo/";
    /**小米登陆 */
    public static loginXiaoMi = "/user/login/xiaomi/";
    /**玩吧登陆 */
    public static loginWanBa = "/user/login/wanba/";
    /**注册 */
    public static register = "/user/register/";

    //==========================================================登录相关=============================
    /** 登录注册验证码发送 */
    public static tel_code_send_handler = "/user/tel/send/code";
    /** 获取用户token对应的用户ID */
    public static user_token = "/user/token";
    /**登录 */
    public static login = "/user/login/";
    /**安卓官方登录 */
    public static android_login = "/user/login/android/";
    /**ios官方登录 */
    public static ios_login = "/user/login/iphone/";
    /**7k7k登录 */
    public static k7k7_login = "/user/login/7k7k/";
    /**u8 登录 */
    public static u8_login = "/user/login/u8/";
    /**steam 登录 */
    public static steam_login = "/user/steam/login";
    /** 手机号登录 */
    public static tel_login = "/user/tel/login";
    /**ios游戏登录 */
    public static tourist_login_ios = "/user/tourist/iphone/";
    /**ios游戏登录 */
    public static ice_snow_ios_login = "/user/ice_snow/login";
    //==========================================================登录相关=============================


    /**soeasy 屏蔽公告列表 */
    public static fitlerList = "/game/attention/fitler/list/";
    /**360渠道接口 */
    public static h5_360 = "/user/login/360/";
    /** 获取指定女主详情版本 */
    public static heroine_version = "/heroine/version/number";
    /** 获取女主列表 */
    public static user_list = "/heroine/list";
    /** 获取女主详情 */
    public static heroine_info = "/heroine/info";
    /** 用户详情 */
    public static user_info = "/user/info";
    /** 退出登录 */
    public static user_out = "/user/logout";
    /**游戏登录 */
    public static tourist_login = "/user/tourist";
    /**购买 */
    public static shop_please_pay = "/shop/please/pay";
    /**  (验证)解除绑定手机号*/
    public static Untied_old_phone: string = "/user/unbind/tel/code";
    /**  解除绑定手机号后绑定新的手机*/
    public static Untied_old_Newphone: string = "/user/unbind/newtel";
    /**  解除绑定手机号后请求新手机验证码*/
    public static Untied_new_code: string = "/user/unbind/new/tel/code";
    /** 立即绑定--获取验证码 */
    public static user_tel_bind_code: string = "/user/tel/bind/code";
    /** 立即绑定 */
    public static user_tel_bind_user: string = "/user/tel/bind/user";
    /**关闭收藏面板 */
    public static user_close_favorite = "/user/close/favorite";
    /**收藏列表 */
    public static user_favorite_list = "/user/favorite/list";
    /**移除收藏 */
    public static user_collect_kill = "/user/collect/kill";
    /**收藏详情 */
    public static user_collect_info = "/user/collect/info";
    /**使用指定壁纸 */
    public static user_use_wallpaper = "/user/use/wallpaper";
    /**取消使用指定壁纸 */
    public static user_cancel_wallpaper = "/user/cancel/wallpaper";
    /** 存档列表 */
    public static heroine_archive_list = "/heroine/archive/list";
    /** 选择女主 */
    public static char_love_one_click = "/char/love_one/click";
    /** 是否已支付 */
    public static shop_is_shop = "/shop/is_shop";
    /**IOS订单是否已经支付 */
    public static ios_is_bought = "/payment/apple/notify/";
    /**steam订单是否已经支付 */
    public static steam_is_bought = "/payment/steam/notify/"
    /**绑定游戏用户名 */
    public static user_bind_name = "/user/bind/name";
    /**获取 */
    public static get_avg_system_init = "/Avg/System/Init"
    /**分享链接 */
    public static share_link = "/share/link";
    /**游戏版本号 */
    public static game_version = "/user/info";
    /**兑换女主心动碎片 */
    public static heroine_heart_fragment_convert = "/heroine/heart/fragment/convert";
    /**请求dlc列表 */
    public static heroine_dlc_list = "/dlc/list";
    /**请求某位置的公告 */
    public static get_place_bulletin = "/get/place/bulletin";
    //=====================================支付接口===================================
    /**获取货币和充值数据 */
    public static user_currency_info = "/user/currency/info";

    //=====================================支付接口===================================

    //=====================================活动相关===================================
    /**获取邀请相关数据 */
    public static user_invite_info = "/user/invite/info";
    /**绑定邀请 */
    public static user_bind_invite = "/user/bind/invite";
    //=====================================活动相关===================================


    //-------------------------------------游戏内消息----------------------------------
    /**主角随机名 */
    public static random_role_name: string = "/user/name/random";
    /**聊天初始化 */
    public static chat_init: string = "/chat/info";
    /**聊天选项 */
    public static chat_select: string = "/chat/select";
    /**取名 */
    public static bename: string = "/chat/save/name";
    /**回放 */
    public static chat_review: string = "/chat/history/dialogue";
    /**存档:进度保存 */
    public static chat_save_schedule: string = "/chat/save/schedule";

    /**dlc聊天初始化 */
    public static dlc_info: string = "/dlc/info";
    /**dlc聊天选项 */
    public static dlc_select: string = "/dlc/select";
}
