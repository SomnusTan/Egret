class ProtocolCommon extends ProtocolBase {
    private static _instance: ProtocolCommon;

    public static instance(): ProtocolCommon {
        if (this._instance == null) {
            this._instance = new ProtocolCommon();
        }
        return this._instance;
    }
    /**
     * Soeasy登录
     */
    public sendLoginSoeasy(params: any, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.loginSoeasy, params, callBack);
    }

    /**
     * 兑换女主心动碎片
     * @param id 女主ID
     */
    public send_heroine_heart_fragment_convert(id: number): void {
        ProtocolGame2.sendBack(ProtocolHttpUrl.heroine_heart_fragment_convert, { heroine_id: id }, null);
    }

    /**
     * 请求分享链接内容
     * @param id 女主ID
     * @param dlcId DLCId
     * @param chatId avg的id或者壁纸中的keep_id
     */
    public send_share_link(id: number, dlcId: number, chatId: number, callBack: FunctionVO): void {
        if (dlcId == 0) {
            ProtocolGame2.sendBack(ProtocolHttpUrl.share_link, { heroine_id: id, chat_id: chatId }, callBack);
        }
        else {
            ProtocolGame2.sendBack(ProtocolHttpUrl.share_link, { dlc_id: dlcId, chat_id: chatId }, callBack);
        }
    }

    public send_get_avg_system_init(): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.get_avg_system_init, {}, new FunctionVO(this.receive_get_avg_system_init, this), false);
    }

    private receive_get_avg_system_init(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.global.userInfo.loginVideo = response.data.login_animation;
            App.global.userInfo.startVideo = response.data.splash_screen;
            App.dispatcher.dispatchEvent(LoginEvent.GET_AVG_SYSTEM_INIT);
        }
    }

    /**
     * 请求U8登录
     */
    public send_u8_login(data: any, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.u8_login, data, callBack);
    }

    /**
     * 请求安卓官方登录
     */
    public send_android_login(data: any, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.android_login, data, callBack);
    }

    public send_ios_login(data: any, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.ios_login, data, callBack);
    }

    /**
     * 请求steam登录
     */
    public send_steam_login(data: any, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.steam_login, data, callBack);
    }

    /**
     * 请求广州冰雪登录
     */
    public send_snow_ios_login(data: any, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.ice_snow_ios_login, data, callBack);
    }

    /**
     * 查询token是否正确
     */
    public send_user_token(): void {
        ProtocolCommon.send(ProtocolHttpUrl.user_token, {}, this.receive_user_token, this, false);
    }

    private receive_user_token(response: any): void {
        if (ResponseUtil.checkResponseData(response))//已经登录
        {
            App.global.userInfo.uid = Number(response.data);
            App.dispatcher.dispatchEvent(LoginEvent.CHECK_LOGIN_BACK, true)
        }
        else {
            App.dispatcher.dispatchEvent(LoginEvent.CHECK_LOGIN_BACK, false)
        }
    }

    /**
     * 请求手机验证码
     * @param phoneNum 手机号码
     */
    public send_tel_code(phoneNum: string, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.tel_code_send_handler, { tel: phoneNum }, callBack);
    }

    /**
     * 请求手机登录
     * @param phoneNum 手机号码
     * @param verifCode 验证码
     * @param channelId 渠道号
     */
    public send_tel_login(phoneNum: string, verifCode: string, channelId: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.tel_login, { tel: phoneNum, code: verifCode, channel_id: channelId }, callBack);
    }

    /**
     * 游客登录
     * @param channelId 渠道号
     */
    public send_tourist_login(channelId: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.tourist_login, { channel_id: channelId }, callBack);
    }

    /**
     * IOS游客登录
     */
    public send_tourist_login_ios(channelId: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.tourist_login_ios, { channel_id: channelId, user_name: IOSConfig.iosID }, callBack);
    }

    /**
     * 退出登录
     */
    public send_login_out(callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_out, {}, callBack);
    }

    /**
     * 请求列表,自动进入第一个女主
     */
    public send_heroineslist_single(callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_list, { version_id: Config.version }, new FunctionVO(this.send_heroineslist_singleBack, this, callBack));
    }

    /**
     * 请求列表数据返回
     */
    private send_heroineslist_singleBack(response: any, callBack: FunctionVO): void {
        if (!ResponseUtil.checkResponseData(response))
            return;
        var list: Array<any> = response.data;
        var uid = App.global.userInfo.uid;
        var versionStr: string = App.global.storage.getItem(EnumStorageType.HERONIES_VERSION + uid);
        var versions: any;
        if (versionStr)
            versions = JSON.parse(versionStr);
        else
            versions = {};
        App.data.gameHallCenter.heroinesDataList = new HashMap();
        var hd: HeroinesData;
        for (var i: number = 0; i < list.length; i++) {
            // 提取女主状态
            hd = App.data.gameHallCenter.getHeroniesData(Number(list[i]['id']));
            if (hd == null)
                hd = new HeroinesData();
            hd.type = Number(list[i]['type']);
            hd.name = list[i]['name'];
            hd.title = list[i]['title'];
            hd.depict = list[i]['depict'];
            hd.id = Number(list[i]['id']);
            // hd.list = list[i]['poster_list'];
            hd.version = list[i]['version'];
            hd.heart_fragment = list[i]['heart_fragment'];
            hd.if_new_plot = list[i]['if_new_plot'];
            //版本对比,如果有版本号且版本号不一致,则是新内容(规则暂定这样)//屏蔽
            hd.is_new = false;//versions[hd.id] && versions[hd.id] != hd.version;
            versions[hd.id] = hd.version;
            // 插入角色列表
            App.data.gameHallCenter.setHeroniesData(hd);
        }
        App.global.storage.setItem(EnumStorageType.HERONIES_VERSION + uid, JSON.stringify(versions));
        if (callBack) {
            callBack.exec(response);
        }
    }

    /**
     * 请求女主列表
     */
    public send_heroineslist(callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_list, { version_id: Config.version }, callBack);
    }

    /**
     * 请求女主详情信息
     * @param id 女主ID
     */
    public send_heroinesDetail(id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.heroine_info, { heroine_id: id }, callBack);
    }

    /**
     * 请求DLC列表
     */
    public send_heroinesDlcList(id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.heroine_dlc_list, { heroine_id: id }, callBack);
    }


    /**
     * 请求支付 
     * @ type        支付类型 1:购买女主, 2:女主限时礼包
     * @ good_id     商品ID
     * @ payType     支付类型 1:心动币 2:现金
     * @ callBack    回调
     * @ cashPayType 现金支付类型
     */
    public send_shop_please_pay(type: number, good_id: number, payType: number, callBack: FunctionVO, cashPayType: number = 0): void {
        var setting: number = DeviceUtil.currentSetting;
        var channel: string = DeviceUtil.getPayType(cashPayType);
        //channel_id 渠道ID
        ProtocolCommon.sendBack(ProtocolHttpUrl.shop_please_pay, {
            channel: channel,
            type: type,
            good_id: good_id,
            setting: setting,
            channel_id: App.global.userInfo.channelId,
            method: payType
        }, callBack, true, ProtocolHttpUrl.ip);
    }

    /**
     * 请求跳转支付宝
     * @param url
     */
    public send_alipay_switch(url: string, win: Window): void {
        var req: string = "/shop/alipay/switch?" + url;
        WebParams.openWindow(req, win);
    }

    /**
     * 请求女主版本信息
     * @param id 女主ID
     */
    public send_heroine_version(id: number, dlcId: number = 0, saveId: number = -1): void {
        var data: any = {
            heroine_id: id,
            channel_id: App.global.userInfo.channelId ? App.global.userInfo.channelId : "1"
        }
        if (dlcId != 0)
            data.dlc_id = dlcId;
        ProtocolCommon.sendBack(ProtocolHttpUrl.heroine_version, data, new FunctionVO(this.onHttpVersionBack, this, saveId));
    }

    private onHttpVersionBack(data: any, saveId: number): void {
        App.data.gameResourceCenter.parseData(data.data, saveId);
    }

    /**
     * (验证)解除绑定手机号
     * @param _code 验证码
     */
    public send_Untied_old_phone(_code: string, callBack: FunctionVO): void {
        GameLog.log("_code", _code);
        if (_code == null) {
            ProtocolCommon.sendBack(ProtocolHttpUrl.Untied_old_phone, {}, callBack);
        } else {
            ProtocolCommon.sendBack(ProtocolHttpUrl.Untied_old_phone, { code: _code }, callBack);
        }
    }
    /**
     * 解除绑定手机号后绑定新的手机
     */
    public send_Untied_old_Newphone(_phone: string, _code: string, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.Untied_old_Newphone, { phone: _phone, code: _code }, callBack);
    }
    /**
     * 解除绑定手机号后请求新手机验证码
     */
    public send_Untied_new_code(_phone: string, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.Untied_new_code, { phone: _phone }, callBack);
    }
    /*
     * 游客登录绑定手机
     */
    public send_tourist_bindphone(_phone: string, _code: string, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_tel_bind_user, { tel: _phone, code: _code }, callBack);
    }
    /*
     * 游客登录获取手机验证码
     */
    public send_tourist_bindphone_code(_code: string, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_tel_bind_code, { tel: _code }, callBack);
    }
    /**
     * 关闭收藏列表
     * @param heroine_id    女主ID
     */
    public send_user_close_favorite(heroine_id: number, callBack?: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_close_favorite, { heroine_id: heroine_id }, callBack);
    }
    /**
     * 收藏列表
     * @param type          收藏类型 (1:手动收藏, 2:视频收藏, 3:结局收藏)
     * @param heroine_id    女主ID
     * @param limit         页码
     * 返回成功
        page": "页码", "data": [{ "id": "收藏ID", "time": "时间戳", "type": "收藏列表: 1:对白, 2:电话, 3:微信, 4:视频, 5:条件分歧节点",
        "title": "收藏标题", "collect_image": "收藏展示图URL", }]
     */
    public send_user_favorite_list(type: number, heroine_id: number, limit: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_favorite_list, { type: type, heroine_id: heroine_id, limit: limit }, callBack);
    }
    /**
     * 收藏详情
     * @param type                 收藏类型 (1:手动收藏, 2:视频收藏, 3:结局收藏)
     * @param heroine_id           女主ID
     * @param keep_id              收藏ID
     * 返回成功
        "type": "状态: 1:对白, 2:电话, 3:微信, 4:视频, 5:条件分歧节点",
        "url": "缩略图或视频链接",
     */
    public send_user_collect_info(type: number, heroine_id: number, keep_id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_collect_info, { type: type, heroine_id: heroine_id, keep_id: keep_id }, callBack);
    }
    /**
     * 移除收藏
     * @param heroine_id           女主ID
     * @param keep_id              收藏ID
     */
    public send_user_collect_kill(heroine_id: number, keep_id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_collect_kill, { heroine_id: heroine_id, keep_id: keep_id }, callBack);
    }
    /**
     * 使用指定壁纸
     * @param heroine_id           女主ID
     * @param keep_id              收藏ID
     */
    public send_user_use_wallpaper(heroine_id: number, keep_id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_use_wallpaper, { heroine_id: heroine_id, keep_id: keep_id }, callBack);
    }
    /**
     * 取消使用指定壁纸
     * @param heroine_id           女主ID
     * @param keep_id              收藏ID
     */
    public send_user_cancel_wallpaper(heroine_id: number, keep_id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_cancel_wallpaper, { heroine_id: heroine_id, keep_id: keep_id }, callBack);
    }
    /**
     * 存档列表
     * @param heroine_id    女主ID
     * 返回成功 0自动存档 1~6存档
        [{ "id": "聊天节点ID",
            "time": "聊天保存时间",
            "thumbnail": "缩略图",
        }]
     */
    public send_heroine_archive_list(heroine_id: number): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.heroine_archive_list, { heroine_id: heroine_id }, new FunctionVO(this.onRecordList, this));
    }
    private onRecordList(data: any): void {
        App.dispatcher.dispatchEvent(RecordEvent.RECORD_LIST, data);
    }
    /**
     * 存档:进度保存
     * @param heroine_id    女主ID
     * @param schedule_id   收藏ID
     * 返回成功
     * {'code': 200, 'data': ""}
     */
    public send_chat_save_schedule(heroine_id: number, schedule_id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.chat_save_schedule, { heroine_id: heroine_id, schedule_id: schedule_id }, callBack);
    }

    /**
     * 请求女主聊天信息--读档
     * @param id 女主ID
     * @param schedule_id 存档ID 0:自动存档, 1~6存档, 7:重新玩
     */
    public send_ChatInfo(id: number, schedule_id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.chat_init, { heroine_id: id, schedule_id: schedule_id }, callBack);
    }

    /*
     * 请求某位置的公告信息
     * @param place_id 位置 0:大厅
     */
    public send_game_notice(place_id: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.get_place_bulletin, {
            channel_id: App.global.userInfo.channelId,
            version_id: Config.version,
            place_id: place_id
        }, callBack);
    }

    /**
     * 请求订单验证
     */
    public send_check_order_status(data: any, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.shop_is_shop, data, callBack, true, ProtocolHttpUrl.ip);
    }
    /**
     * 请求玩家货币信息和充值数据
     */
    public send_user_currency_info(callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_currency_info, {}, callBack);
    }

    /**
     * 获取邀请数据
     */
    public send_user_invite_info(callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_invite_info, {}, callBack);
    }

    /**
     * 绑定邀请码
     */
    public send_user_bind_invite(inviteCode: number, callBack: FunctionVO): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.user_bind_invite, { user_id: inviteCode }, callBack);
    }
}