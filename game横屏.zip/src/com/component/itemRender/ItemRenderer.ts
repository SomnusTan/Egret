class ItemRenderer extends eui.ItemRenderer {
	public constructor() {
		super();
		this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddStage, this);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveStage, this);
		this.addEventListener(eui.UIEvent.COMPLETE, this.onInitComplete, this);
		this._dispatcher = new DispatcherRegister();
	}

	/***初始化操作 */
	protected createChildren() {

	}

	/**添加到舞台 */
	protected onAddStage(e?: egret.Event): void {
		
	}

	/**移除舞台 */
	protected onRemoveStage(e?: egret.Event): void {
		this._dispatcher.removeAllListeners();
	}

	protected onInitComplete(e?: eui.UIEvent): void {
		this.removeEventListener(eui.UIEvent.COMPLETE, this.onInitComplete, this);
	}

	/**数据改变 */
	protected dataChanged(): void {

	}

	public dispose(): void {

	}
	/**是否选中 */
	public showSelected(value: boolean = false): void {

	}
	protected _dispatcher: DispatcherRegister;
}