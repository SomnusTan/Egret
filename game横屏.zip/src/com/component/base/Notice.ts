class Notice {
	/*** 主菜单上方的指引提示 */
	public static GUIDE: number = 0;
	/** 聊天框中的系统提示消息 */
	public static LEFT: number = 1;
	/** 右下角的消息 */
	public static RIGHT: number = 2;
	/** 顶部广播的消息 */
	public static TOP: number = 4;
	/** 频幕中间的消息 */
	public static MIDDLE: number = 8;
	/** 鼠标位置的消息 */
	public static MOUSE: number = 16;
	/** 频幕底部的消息 */
	public static BOTTOM: number = 32;
	/** 频幕底部BUFF的消息 */
	public static BUFF: number = 64;
	/** gm命令返回的信息（显示到聊天框-喇叭） */
	public static GMCMD: number = 128;
	/** 帮会 */
	public static GUILD: number = 0x100;
	/** 组队 */
	public static TEAM: number = 0x200;
	/** 弹窗提示 */
	public static ALERT: number = 0x400;

	/*** 顶部、系统公告广播颜色 */
	public static TOP_COLOR: number = 0xF5C84D;
	/*** 中上部、系统提示广播颜色 */
	public static MIDDLE_COLOR: number = 0xF1C600;
	/*** 底部、个人操作广播颜色 */
	public static BOTTOM_COLOR: number = 0xFFFFFF;
	/*** 鼠标位置的提示颜色 */
	public static MOUSE_COLOR: number = 0xFF3300;
	/*** 左下角的提示颜色 */
	public static CORNER_COLOR: number = 0xDED0B4;
	/*** BUFF提示颜色 */
	public static BUFF_COLOR: number = 0x00FF00;

	public static MONEY_COLORS: string[] = ["#009400"];
	/** 失去货币提示id */
	public static LOSE_MONEY_IDS: number[] = [86, 93, 158, 162, 259];

	/**
	 *
	 * @param type		提示类型
	 * @param text		提示内容
	 * @param count		（type=TOP）提示次数（大于1次，提示间隔是10秒左右）
	 * @param inPanel	（type=RIGHT）是否在信息面板中提示
	 *
	 */
	public static showNoticeTypeMsg(type: number, text: string, count: number = 1, inPanel: boolean = true, parent: egret.DisplayObjectContainer = null, bottomIcon: number = 0): void {
		if ((type & this.TOP) != 0) {
			this.showTopMessage(text, Notice.TOP_COLOR, count);
		} else if ((type & this.MIDDLE) != 0) {
			this.showMiddleMessage(text);
		} else
			if ((type & this.MOUSE) != 0) {
				this.showMousePosMessage(text, Notice.MOUSE_COLOR, parent);
			} else
				if ((type & this.BOTTOM) != 0) {
					this.showBottomMessage(text, Notice.BOTTOM_COLOR, 0, bottomIcon);
				} else if ((type & this.RIGHT) != 0) {
					this.showCornerMessage(text);
				}
		// if ((type & this.BUFF) != 0) {
		// 	this.showBuffMessage(text);
		// }
	}

	/**
	 * 客户端提示语言
	 * @param id
	 * @param args 	动态参数
	 *
	 */
	public static show(id: number, ...args): void {
		var tip: string = "";
		if (tip == null || tip == "") {
			tip = "";
		}
		var bottomIcon: number = 0; //默认0，蓝色icon

		if (args != null && args.length > 0) {
			tip = StringUtil.substitute(tip, args);
		}
		// Notice.showTip(tip, bean.q_type, bean.q_color, bottomIcon);
	}

	private static showTip(str: string, type: number, color: number, bottomIcon: number = 0): void {
		var c: number = Notice.getContentColor(color);
		switch (type) {
			case Notice.TOP: {
				Notice.showTopMessage(str, c);
				break;
			}
			case Notice.MIDDLE: {
				Notice.showMiddleMessage(str, c);
				break;
			}
			case Notice.BOTTOM: {
				Notice.showBottomMessage(str, c, 0, bottomIcon);
				break;
			}
			case Notice.MOUSE: {
				Notice.showMousePosMessage(str, c);
				break;
			}
		}
	}

	/**
	 * 获取颜色值
	 * @param color	（0红色，1绿色，2蓝色，3白色，4灰色）
	 * @return
	 */
	private static getContentColor(color: number = 0): number {
		if (Notice.ColorJsonAry == null) {
			var colorJson: string = ""
			Notice.ColorJsonAry = JSON.parse(colorJson) as Array<any>;
		}
		if (Notice.ColorHash.has(color)) {
			return Notice.ColorHash.get(color);
		} else {
			for (var i: number = 0; i < Notice.ColorJsonAry.length; i++) {
				if (color == Notice.ColorJsonAry[i].type) {
					var c: string = Notice.ColorJsonAry[i].color;
					Notice.ColorHash.put(color, parseInt("0x" + c.substr(1)));
					break;
				}
			}
		}
		return Notice.ColorHash.get(color) as number;
	}

	private static ColorJsonAry: Array<any>;
	private static ColorHash: HashMap = new HashMap();

	/**
	 * 顶部、系统公告广播
	 * @param str
	 * @param color
	 * @param count	提示次数,间隔10秒提示
	 *
	 */
	public static showTopMessage(str: string, color: number = Notice.TOP_COLOR, count: number = 1): void {
		if (this._topMessage == null) {
			this._topMessage = new TopMessageView();
		}
		if (count == 1) {
			this._topMessage.showTopMessage(str, color);
		} else {
			let crt: number = egret.getTimer();
			let id: any = App.timer.doTimeLoop(this, 6000, this.showTop, [crt, str, color], false); //30秒,这是个大概的时间，要改.
			this._topCountHash.put(crt, count);
			this._clearIdHash.put(crt, id);
			this.showTop(crt, str, color);
		}
	}

	public static showTop(crt: number, str: string, color: number): void {
		let count: number = this._topCountHash.get(crt);
		if (count == 0) {
			App.timer.clearTimer(this, this._clearIdHash.get(crt));
			this._clearIdHash.del(crt);
		} else {
			this._topMessage.showTopMessage(str, color);
			this._topCountHash.put(crt, count - 1);
			count = this._topCountHash.get(crt);
		}
	}

	/**
	 * 中上部、系统提示广播(未使用)
	 * @param str
	 * @param color
	 */
	public static showMiddleMessage(str: string, color: number = Notice.MIDDLE_COLOR): void {
		if (this._middleMessage == null) {
			this._middleMessage = new MiddleMessageView();
		}
		this._middleMessage.showMiddleMessage(str, color);
	}

	/**
	 * 中底部提示(使用中)
	 */
	public static showBottomCenterMessage(str: string, color: number = Notice.BOTTOM_COLOR, gap: number = 0, playSound: boolean = true): void {
		if (gap > 0) {
			let lastT: number = Number(this._tempHash.get(str));
			let ct: number = egret.getTimer();
			if (lastT > 0) {
				let gapT: number = ct - lastT;
				if (gapT < gap) {
					return;
				}
			}
			this._tempHash.put(str, ct);
		}

		if (this._bottomMessage == null) {
			this._bottomMessage = new BottomMessageView();
			App.layer.messageLayer.addChild(this._bottomMessage);
		}
		this._bottomMessage.show(str, color, playSound);
	}

	/**
	 * 底部、个人操作广播(未使用)
	 * @param str
	 * @param color
	 * @param gap 	单位ms
	 * @param bottomIcon 	icon，默认0,蓝色icon
	 */
	public static showBottomMessage(str: string, color: number = Notice.BOTTOM_COLOR, gap: number = 0, bottomIcon: number = 0): void {
		this.showCornerMessage(str, color);
		// if (gap > 0) {
		// 	let lastT: number = Number(this._tempHash.get(str));
		// 	let ct: number = egret.getTimer();
		// 	if (lastT > 0) {
		// 		let gapT: number = ct - lastT;
		// 		if (gapT < gap) {
		// 			return;
		// 		}
		// 	}
		// 	this._tempHash.put(str, ct);
		// }

		// if (this._bottomMessage == null) {
		// 	this._bottomMessage = new BottomMessageView();
		// 	App.layer.messageLayer.addChild(this._bottomMessage);
		// }
		// this._bottomMessage.show(str, color, bottomIcon);
	}

	/**
	 * 右下角、资源获取广播
	 * @param str
	 * @param color
	 * @param inPanel	是否在信息面板里面显示
	 */
	public static showCornerMessage(str: String, color: number = Notice.CORNER_COLOR): void {
		this._cornerAry.push(str);
		// GameLog.log("showCornerMessage ---  " + this._cornerAry.length + " -------   " + egret.getTimer());
		if (!Notice.cornerTimeId) {
			Notice.cornerTimeId = App.timer.doTimeOnce(this, 100, this.showCornerMsg);
		}
	}

	private static showCornerMsg(): void {
		Notice.cornerTimeId = null;
		var leng: number = this._cornerAry.length;
		if (this._cornerMessage == null) {
			this._cornerMessage = new CornerMessageView(new FunctionVO(this.removeCornerView, this));
			App.layer.messageLayer.addChildAt(this._cornerMessage, 0);
		}
		this._cornerMessage.showCornerMessage();
	}

	public static get cornerAry(): Array<any> {
		return this._cornerAry;
	}

	private static removeCornerView(): void {
		App.log.echo("cornerMessage已回收" + this._cornerMessage);
		if (this._cornerMessage) {
			this._cornerMessage.dispose();
			this._cornerMessage = null;
		}
	}

	/**
	 * 鼠标位置的提示
	 * @param str
	 * @param color
	 * @param parent		提示消息的父容器
	 * @param continuous	是否不断的提示，默认true
	 */
	public static showMousePosMessage(str: string, color: number = Notice.MOUSE_COLOR, parent: egret.DisplayObjectContainer = null, continuous: boolean = true): void {
		if (continuous) {
			this._mouseMsgAry.push([str, color]);
			if (this._loopId == null) {
				this.loopShowMouseMsg(parent);
				this._loopId = App.timer.doTimeLoop(this, 500, this.loopShowMouseMsg, [parent]);
			}
		} else {
			if (this._mousePosMessage == null) {
				this._mousePosMessage = new MousePosMessageView();
			}
			this._mousePosMessage.showMousePosMessage(str, color);
		}
	}
	/**
	 * 鼠标位置的提示
	 * @param str
	 * @param color
	 */
	public static showMouseMessage(str: string, e: egret.TouchEvent, color: number = Notice.MOUSE_COLOR): void {
		let mousePosMessage: MousePosMessageView = this.getMousePosMessage();
		mousePosMessage.showMousePosMessage(str, color, e.stageX, e.stageY);
	}
	public static loopShowMouseMsg(parent: egret.DisplayObjectContainer, e?: egret.TouchEvent): void {
		if (this._mouseMsgAry.length == 0) {
			if (this._loopId) {
				App.timer.clearTimer(this, this._loopId);
				this._loopId = null;
			}
		} else {
			let ary: Array<any> = this._mouseMsgAry.shift();
			let str: string = ary[0], color: number = ary[1];
			let mousePosMessage: MousePosMessageView = this.getMousePosMessage();
			if (e) {
				mousePosMessage.showMousePosMessage(str, color, e.stageX, e.stageY);
			} else {
				mousePosMessage.showMousePosMessage(str, color);
			}
		}
	}

	private static _logView: LogView;

	public static showLog(...str): void {
		if (Config.skipVideo) {
			if (this._logView == null) {
				this._logView = new LogView();
				App.layer.tipLayer.addChild(this._logView);
			}
			this._logView.addLog(str.join(","));
		}
	}


	private static getMousePosMessage(): MousePosMessageView {
		if (this._mousePosMessagePool.length > 0) {
			return this._mousePosMessagePool.pop();
		}
		return new MousePosMessageView();
	}

	public static setMousePosMessagePool(view: MousePosMessageView): void {
		this._mousePosMessagePool.push(view);
	}

	private static _mousePosMessagePool: Array<MousePosMessageView> = [];
	private static _mousePosMessage: MousePosMessageView;

	private static _loopId: any;
	private static _mouseMsgAry: Array<any> = [];

	private static _topMessage: TopMessageView;
	private static _clearIdHash: HashMap = new HashMap();
	private static _topCountHash: HashMap = new HashMap();
	private static _middleMessage: MiddleMessageView;
	private static _tempHash: HashMap = new HashMap();
	private static _bottomMessage: BottomMessageView;
	// private static _leftMessageView: LeftMessageView;

	private static cornerTimeId: any;
	private static _cornerAry: Array<any> = [];
	private static _cornerMessage: CornerMessageView;
	private static attributeTimeId: any;
	private static _attributeAry: Array<any> = [];
}