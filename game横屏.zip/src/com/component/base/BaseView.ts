class BaseView extends BaseUI {
    protected _dispatcher: DispatcherRegister;

    public constructor(euiSkinName?: string) {
        super(euiSkinName);
    }

	protected createComplete() {
        this._dispatcher = new DispatcherRegister();
		super.createComplete();
		this.show();
    }

	/**
    * 显示
    * @param data
    */
    public show(data?: any): void { };

    /**
     * 隐藏
     */
    public hide(): void {
        this._dispatcher.removeAllListeners();
    }

    public dispose(): void {
        this.hide();
        this._dispatcher = undefined;
        super.dispose();
    }
}