/**
 * 视频基类
 */
class Video {

    private static _instance: Video;
    /**底部 */
    public static BOTTOM: string = "bottom";
    /**顶部 */
    public static TOP: string = "top";

    protected _src: string = null;
    protected _muted: boolean;
    protected _loop: boolean;
    protected _completeHandler: FunctionVO;
    protected _loadCompleteHandler: FunctionVO;
    protected _isPaused: boolean;
    protected _resumeContine: boolean;

    /**遮罩 */
    protected _maskSp: h5_engine.GShape;

    protected _loadingEffect: VideoLoadingEffect;

    /**是否视频初始化好 */
    protected _isInit: boolean;

    /**
     * 初始化
     * @param src 视频路径
     * @param muted 是否静音
     * @param loop 是否循环
     * @param completeHandler 视频播放完成回调
     * @param src layerType 视频播放层级
     */
    public init(src: string, muted?: boolean, loop?: boolean, completeHandler?: FunctionVO, layerType?: string, loadCompleteHandler?: FunctionVO, ...arg): void {
        this._src = src;
        this._muted = muted;
        this._loop = loop;
        this._completeHandler = completeHandler;
        this._loadCompleteHandler = loadCompleteHandler;
        this._resumeContine = false;

        this._isInit = false;
        GameLog.log('播放视频:' + src);
        if (layerType == Video.TOP) {
            App.layer.showVideoLayer(true);
        }
        if (this._maskSp == null) {
            this._maskSp = new h5_engine.GShape();
        }
        this._maskSp.alpha = 1;
        App.layer.videoLoadingLayer.addChild(this._maskSp);

        if (this._loadingEffect == null) {
            this._loadingEffect = new VideoLoadingEffect();
        }
        this._loadingEffect.play(-1);
        App.layer.videoLoadingLayer.addChild(this._loadingEffect);

        this.onResize();
        App.stage.addEventListener(egret.Event.RESIZE, this.onResize, this);
    }

    /**
     * 视频流是否初始化好,可播放
     */
    public get isInit(): boolean {
        return this._isInit;
    }

    /**
     * 视频流是否初始化好,可播放
     */
    public set isInit(value: boolean) {
        this._isInit = value;;
    }

    /**
     * 播放
     */
    public play(): void {

    }

    /**
     * 暂停
     */
    public pause(): void {

    }

    /**
     * 恢复则继续播放
     */
    public set resumeContine(value: boolean) {
        this._resumeContine = value;
    }

    /**
     * 恢复则继续播放
     */
    public get resumeContine(): boolean {
        return this._resumeContine;
    }

    protected onResize(e: egret.Event = null): void {
        var w: number = App.layer.rotation == 0 ? Config.SCREEN_WIDTH : Config.SCREEN_HEIGHT;
        var h: number = App.layer.rotation == 0 ? Config.SCREEN_HEIGHT : Config.SCREEN_WIDTH;
        if (this._maskSp.parent && (this._maskSp.width != w || this._maskSp.height != h)) {
            this._maskSp.graphics.clear();
            this._maskSp.graphics.beginFill(0);
            this._maskSp.graphics.drawRect(0, 0, w, h);
            this._maskSp.graphics.endFill();
        }
        this._loadingEffect.x = w >> 1;
        this._loadingEffect.y = h >> 1;
    }

    /**
     * 释放
     */
    public dispose(data?): void {
        GameLog.log('释放video');
        if (this._maskSp)
            this._maskSp.remove();
        if (this._loadingEffect && this._loadingEffect.parent) {
            this._loadingEffect.stop();
            this._loadingEffect.remove();
        }
        this._isInit = false;
        this._loop = false;
        this._muted = false;
        this._resumeContine = false;
        this._completeHandler = null;
        this._loadCompleteHandler = null;
        App.layer.showVideoLayer(false);
        PanelOpenManager.removePanel(EnumPanelID.VIDEO_BUTTON);
    }

    /**
     * 是否停止播放了
     */
    public get paused(): boolean {
        return this._isPaused;
    }

    /**
     * 获取完成回调方法
     */
    public get completeHandler(): FunctionVO {
        return this._completeHandler;
    }

    public execCompleteHandler(): void {
        if (this._completeHandler) {
            this._completeHandler.exec();
        }
    }

    /**视频路径 */
    public get src(): string {
        return this._src;
    }

    public hideMaskSp(): void {
        this._loadingEffect.stop();
        this._loadingEffect.remove();
        egret.Tween.get(this._maskSp).to({ alpha: 0 }, 500).call(() => {
            this._maskSp.remove();
        });
        this._isInit = true;
        if (this._loadCompleteHandler) {
            this._loadCompleteHandler.exec();
        }
    }

    public static instance(): Video {
        if (this._instance == null) {
            if (DeviceUtil.IsWeb)
                this._instance = new H5Video();
            else
                this._instance = new NativeVideo();
        }
        return this._instance;
    }
}


class NativeVideo extends Video {

    public init(src: string, muted: boolean, loop: boolean, completeHandler: FunctionVO = null, layerType: string = Video.BOTTOM, loadCompleteHandler?: FunctionVO, isLandscapePlay: boolean = false): void {
        super.init(src, muted, loop, completeHandler, layerType, loadCompleteHandler);
        App.nativeBridge.sendPlayVideo(src, muted, loop, isLandscapePlay);
        this._isPaused = false;
    }

    public play(): void {
        App.nativeBridge.sendVideoResume();
        this._isPaused = false;
    }

    public pause(): void {
        App.nativeBridge.sendVideoPause();
        this._isPaused = true;
    }

    /**
     * 释放
     */
    public dispose(data?): void {
        super.dispose();
        if (this._src) {
            if (data)
                App.nativeBridge.sendVideoStop();
            this._isPaused = true;
            this._src = null;
        }
    }
}

/**
 * H5版本视频播放
 */
class H5Video extends Video {
    private _video: HTMLElement;

    public constructor() {
        super();
        this._video = document.getElementById("myVideo");
        this._video.style.visibility = "hidden";
    }

    public init(src: string, muted: boolean, loop: boolean, completeHandler: FunctionVO = null, layerType: string = Video.BOTTOM, loadCompleteHandler?: FunctionVO): void {
        if (this._src)
            this.pause();
        if (Config.isLocalApp && src.indexOf("//") == 0) {
            src = "https:" + src;
        }
        super.init(src, muted, loop, completeHandler, layerType, loadCompleteHandler);

        this._video.style.visibility = "visible";

        this.muted = muted;
        this.loop = loop;
        this._video["src"] = src;
        this._video.addEventListener("canplay", this.onCanPlayVideo);
        if (completeHandler) {
            this._video.addEventListener("ended", this.onPlayerComplete);
        }
    }

    public play(): void {
        if (this.paused == true) {
            this._video["play"]();
        }
    }

    public pause(): void {
        if (this.paused == false) {
            this._video["pause"]();
        }
    }

    public dispose(data?): void {
        super.dispose();
        this._video.style.visibility = "hidden";

        this._video.removeEventListener("ended", this.onPlayerComplete);
        this._video.removeEventListener("canplaythrough", this.onCanPlayVideo);
        this.pause();
        this._video["src"] = "";
        this._src = null;
        App.stage.removeEventListener(egret.Event.RESIZE, this.onResize, this);
    }

    public set loop(value: boolean) {
        this._video["loop"] = value;
    }

    public set muted(value: boolean) {
        this._video["muted"] = value;
    }

    public get paused(): boolean {
        return this._video["paused"];
    }

    protected onResize(e: egret.Event = null): void {
        var clientW: number = document.body.clientWidth;
        var clientH: number = document.body.clientHeight;
        if (DeviceUtil.isMobile) {
            if ((App.stage.orientation == egret.OrientationMode.LANDSCAPE && (window.orientation == 0 || window.orientation == 180)) ||
                (App.stage.orientation == egret.OrientationMode.PORTRAIT && (window.orientation == 90 || window.orientation == -90))) {
                if (App.stage.orientation == egret.OrientationMode.PORTRAIT) {
                    this._video.style.transform = "rotate(270deg) translate(" + ((clientW - clientH) / 2) + "px," + ((clientW - clientH) / 2) + "px)";
                    this._video.style.webkitTransform = "rotate(270deg) translate(" + ((clientW - clientH) / 2) + "px," + ((clientW - clientH) / 2) + "px)";
                }
                else if (App.stage.orientation == egret.OrientationMode.LANDSCAPE) {
                    this._video.style.transform = "rotate(90deg) translate(" + ((clientH - clientW) / 2) + "px," + ((clientH - clientW) / 2) + "px)";
                    this._video.style.webkitTransform = "rotate(90deg) translate(" + ((clientH - clientW) / 2) + "px," + ((clientH - clientW) / 2) + "px)";
                }
                this._video.style.width = clientH + "px";
                this._video.style.height = clientW + "px";
                this._video.style.transformOrigin = "center center";
                this._video.style.webkitTransformOrigin = "center center";
            }
            else {
                this._video.style.transform = "";
                this._video.style.webkitTransform = "";
                this._video.style.transformOrigin = "";
                this._video.style.webkitTransformOrigin = "";
                this._video.style.width = clientW + "px";
                this._video.style.height = clientH + "px";
            }
        }
        else {
            this._video.style.width = clientW + "px";
            this._video.style.height = clientH + "px";
        }
        super.onResize();
    }

    private onCanPlayVideo(): void {
        Video.instance().play();
        Video.instance().isInit = true;
        Video.instance().hideMaskSp();
    }

    /**
    * 播放完成
    */
    private onPlayerComplete(): void {
        Video.instance().execCompleteHandler();
    }
}