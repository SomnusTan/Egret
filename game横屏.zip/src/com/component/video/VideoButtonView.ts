class VideoButtonView extends BasePanel {
	private _view: VideoButtonUI;

	private _videoType: number;
	private _uid: number;
	private _collectId: number;
	private _isWallPaper: boolean;
	private _canSkip: boolean;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new VideoButtonUI();
		this.addChild(this._view);
	}

	/** { type: this.collectType, uid: this.uid, collectId: this._collectId, using: this._isWallPaper canSkip:this.canSkip } */
	public show(data?: any): void {
		super.show(data);
		this._view.width = this.width;
		this._view.height = this.height;
		this._videoType = data.type;
		this._uid = data.uid;
		this._collectId = data.collectId;
		this._isWallPaper = data.using;
		if (this._videoType != EnumVideoType.DONGTAI_BIZHI && this._videoType != EnumVideoType.AVG_SHIPIN) {
			App.sound.isCloseBgm = true;
		}
		this._canSkip = data.canSkip;

		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBg, this, this._view.bgRect);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBack, this, this._view.btnBack);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickUse, this, this._view.btnUse);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickShare, this, this._view.btnShare);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClicpSkip, this, this._view.groupSkip);
		this._dispatcher.addEventListener(egret.Event.RESIZE, this.onResize, this);
		this.showVideoButton(true);
	}
	/** Video操作按钮显示规则
	 * @param init 是否初始化
	 */
	private showVideoButton(init: boolean = false): void {
		var isPlay: boolean = Video.instance().paused == false || init;
		switch (this._videoType) {
			case EnumVideoType.DONGTAI_BIZHI://动态壁纸
				this._view.btnBack.visible = false;
				this._view.btnPlay.visible = false;
				this._view.btnUse.visible = true;
				// (this._view.btnUse.getChildAt(0) as eui.Image).source = this._isWallPaper ? "common_json.common_using_png" : "common_json.common_anniu1_png";
				this._view.btnUse.label = this._isWallPaper ? "使用中" : "使用";
				this._view.btnShare.visible = App.global.canShare;
				if (this._view.btnShare.visible) {
					this._view.btnUse.horizontalCenter = -130;
				} else {
					this._view.btnUse.horizontalCenter = 0;
				}
				this._view.groupSkip.visible = false;
				break;
			case EnumVideoType.HUIYI_SHIPIN://回忆视频
			case EnumVideoType.XIN_DONG1_VIDEO:
				this._view.btnBack.visible = !isPlay;
				this._view.btnPlay.visible = !isPlay;
				this._view.btnUse.visible = false;
				this._view.btnShare.visible = false;
				this._view.groupSkip.visible = false;
				break;
			case EnumVideoType.XIN_DONG1:
				this._view.btnBack.visible = false;
				this._view.btnPlay.visible = !isPlay;
				this._view.btnUse.visible = false;
				this._view.btnShare.visible = false;
				this._view.groupSkip.visible = Config.skipVideo;
				break;
			case EnumVideoType.XINTIAO_JIEJU://心跳结局
				this._view.btnBack.visible = !isPlay;
				this._view.btnPlay.visible = !isPlay;
				this._view.btnUse.visible = false;
				this._view.btnShare.visible = false;
				this._view.groupSkip.visible = false;
				break;
			case EnumVideoType.AVG_SHIPIN://AVG视频
				this._view.btnBack.visible = false;
				this._view.btnPlay.visible = !isPlay;
				this._view.btnUse.visible = false;
				this._view.btnShare.visible = false;
				this._view.groupSkip.visible = this._canSkip || Config.skipVideo;
				break;
		}
	}
	/** 跳过 */
	private onClicpSkip(e: egret.TouchEvent): void {
		// if (Video.instance().isInit) {
		if (Video.instance().completeHandler) {
			Video.instance().completeHandler.exec();
		}
		Video.instance().dispose(true);
		// }
	}

	/** 使用壁纸 */
	private onClickUse(e: egret.TouchEvent): void {
		if (this._isWallPaper) return;
		ProtocolCommon.instance().send_user_use_wallpaper(this._uid, this._collectId, new FunctionVO(this.onUseBack, this));
	}
	/** 使用后返回 */
	private onUseBack(data: any): void {
		if (data.code == "200") {
			this._isWallPaper = true;
			this.showVideoButton();
			App.dispatcher.dispatchEvent(MemoryEvent.CHANGE_BIZHI, this._collectId);
			//更新当前的壁纸
			App.data.gameHallCenter.updateHeroniesProps(this._uid, { videoUrl: Video.instance().src });
		}
	}
	/** 分享 */
	private onClickShare(e: egret.TouchEvent): void {
		ProtocolCommon.instance().send_share_link(this._uid, 0, this._collectId, new FunctionVO(this.onCallBack, this));
	}

	private onCallBack(data: any): void {
		if (data.code == "200") {
			PanelOpenManager.openPanel(EnumPanelID.GAME_SHARE2, { url: data.data.collect_image });
		}
	}

	private onClickBack(e: egret.TouchEvent): void {
		if (this._videoType == EnumVideoType.HUIYI_SHIPIN || this._videoType == EnumVideoType.XINTIAO_JIEJU) {
			App.sound.playSoundSwitchClient(EnumSoundId.PANEL_CLOSE);
		} else if (this._videoType == EnumVideoType.XIN_DONG1) {
			if (Video.instance().completeHandler) {
				Video.instance().completeHandler.exec();
				return;
			}
		}
		// else if (this._videoType == EnumVideoType.AVG_SHIPIN) {
		// 	Video.instance().dispose(true);
		// 	App.dispatcher.dispatchEvent(EventType.VIDEO_BACK)
		// 	return;
		// }
		Video.instance().dispose(true);
	}

	private onClickBg(e: egret.TouchEvent): void {
		if (this._videoType == EnumVideoType.DONGTAI_BIZHI) {
			this.onClickBack(e);
			App.sound.playSoundSwitchClient(EnumSoundId.PANEL_CLOSE);
			return;
		}
		this.showPlayBtnState();
	}
	/** 按钮状态 */
	private showPlayBtnState(): void {
		// if (Video.instance().isInit == false) return;
		if (Video.instance().paused == false) {
			Video.instance().pause();
			if (this._videoType == EnumVideoType.HUIYI_SHIPIN) {//回忆视频暂停播放时时播放按键音
				App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
			}
		} else {
			Video.instance().play();
		}
		this.showVideoButton();
	}
	//视频返回执行
	public hide(): void {
		super.hide();
		if (this._videoType == EnumVideoType.HUIYI_SHIPIN || this._videoType == EnumVideoType.XINTIAO_JIEJU) {
			var isPlay: string = App.global.storage.getItem(EnumStorageType.HALL_MUSIC_SETTING);
			App.sound.isCloseBgm = isPlay == "0";
		}
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	private onResize(e: egret.Event): void {
		this.x = 0;
		this.y = 0;
	}

	public get width(): number {
		return App.layer.rotation == 0 ? Config.SCREEN_WIDTH : Config.SCREEN_HEIGHT;
	}

	public get height(): number {
		return App.layer.rotation == 0 ? Config.SCREEN_HEIGHT : Config.SCREEN_WIDTH;
	}

	public needDispose(): boolean {
		return false;
	}


}