class EffectImage extends eui.Group {

    private _image: eui.Image;

    private _spImageMask: egret.Shape;
    /**上一次的效果 */
    private _lastEffectType: string;

    /**是否抖动中 */
    private _isShake: Boolean = false;
    /**抖动次数 */
    private _shakeNum: number = 0;
    /**抖动偏移 */
    private _offsetXYArray: number[];

    private _rect: egret.Rectangle = new egret.Rectangle();

    private _tempImage0: eui.Image;

    private _tempTexture0: egret.RenderTexture;

    private _tempImage1: eui.Image;

    private _tempTexture1: egret.RenderTexture;

    private _matrix: egret.Matrix;
    /**是否显示 */
    private _isShow: boolean = false;

    private _tempObj: any;

    private _addStaticEffect: boolean = false;

    private _staticMaskSp: egret.Shape;

    /**基础数据 */
    private _baseScale: number = 1;
    private _baseX: number = 0;
    private _baseY: number = 0;

    public constructor() {
        super();
        this.init();
    }

    private init(): void {
        this._image = new eui.Image();
        this.addChild(this._image);
    }

    public dispose(): void {
        if (this._image) {
            this._image.source = null;
            if (this._image.parent)
                this._image.parent.removeChild(this._image);
            this._image = null;
        }
        if (this._spImageMask) {
            this._spImageMask.graphics.clear();
            if (this._spImageMask.parent)
                this._spImageMask.parent.removeChild(this._spImageMask);
            this._spImageMask = null;
        }
        if (this._tempImage0) {
            this._tempImage0.source = null;
            if (this._tempImage0.parent)
                this._tempImage0.parent.removeChild(this._tempImage0);
            this._tempImage0 = null;
        }
        if (this._tempTexture0) {
            this._tempTexture0.dispose();
            this._tempTexture0 = null;
        }
        if (this._tempTexture1) {
            this._tempTexture1.dispose();
            this._tempTexture1 = null;
        }
        if (this._tempImage1) {
            if (this._tempImage1.texture) {
                this._tempImage1.texture.dispose();
                this._tempImage1.texture = null;
            }
            if (this._tempImage1.parent)
                this._tempImage1.parent.removeChild(this._tempImage0);
            this._tempImage1 = null;
        }
        this._offsetXYArray = null;
        this._rect = null;
        this._matrix = null;
        this.remove();
    }

    public remove(): void {
        if (this.parent) {
            this.parent.removeChild(this);
        }
    }

    /**
     * 显示效果
     */
    public showEffect(effectType: string, time: number = 1000, delay: number = 0, params?: any): void {
        if (this._lastEffectType == EnumImageEffect.REMOVE_APART_SHAKE) {
            this._addStaticEffect = false;
            this.resetEffect()
        }
        this._lastEffectType = effectType;
        this._addStaticEffect = false;
        var targetObj: any;
        var sw: number = Config.MAIN_WIDTH;
        var sh: number = Config.MAIN_HEIGHT;
        switch (effectType) {
            case EnumImageEffect.FADE_IN:
                this._image.alpha = 0;
                egret.Tween.get(this._image).wait(delay).to({ alpha: 1 }, time).call(this.onTweenFinish, this, [this._image]);
                break;
            case EnumImageEffect.FADE_OUT:
                this._image.alpha = 1;
                egret.Tween.get(this._image).wait(delay).to({ alpha: 0 }, time).call(this.onTweenFinish, this, [this._image]);
                break;
            case EnumImageEffect.FADE_IN_BLACK:
                this._image.alpha = 1;
                this.initMask();
                egret.Tween.get(this._spImageMask).wait(delay).to({ alpha: 0 }, time).call(this.onTweenFinish, this, [this._spImageMask]);
                break;
            case EnumImageEffect.CHANGE_SCALE:
                this._image.alpha = 1;
                targetObj = {};
                if (params.hasOwnProperty("to_scale"))
                    targetObj.scaleY = targetObj.scaleX = Number(params.to_scale);
                if (params.hasOwnProperty("to_x"))
                    targetObj.x = Number(params.to_x);
                if (params.hasOwnProperty("to_y"))
                    targetObj.y = Number(params.to_y);
                if (params.hasOwnProperty("x"))
                    this._image.x = Number(params.x);
                if (params.hasOwnProperty("y"))
                    this._image.y = Number(params.y);
                if (params.hasOwnProperty("scale"))
                    this._image.scaleY = this._image.scaleX = Number(params.scale);
                egret.Tween.get(this._image).wait(delay).to(targetObj, time).call(this.onTweenFinish, this, [this._image]);
                break;
            case EnumImageEffect.MOVE:
                this._image.alpha = 1;
                this._image.scaleX = this._image.scaleY = this._baseScale;
                targetObj = {};
                if (params.hasOwnProperty("x"))
                    this._image.x = Number(params.x);
                if (params.hasOwnProperty("y"))
                    this._image.y = Number(params.y);
                if (params.hasOwnProperty("to_x"))
                    targetObj.x = Number(params.to_x);
                if (params.hasOwnProperty("to_y"))
                    targetObj.y = Number(params.to_y);
                egret.Tween.get(this._image).wait(delay).to(targetObj, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this._image]);
                break;
            case EnumImageEffect.LOOP_MOVE:
                this._image.alpha = 1;
                var num: number = params.num ? Number(params.num) : 1;
                var end: string = params.end ? params.end : EnumMoveEnd.MIDDLE;
                if (end == EnumMoveEnd.MIDDLE)
                    time = time / (num * 2 - 0.5 + (num * 2 - 1) * 0.25);
                else if (end == EnumMoveEnd.RIGHT)
                    time = time / (num * 2 - 1 + (num * 2 - 2) * 0.25);
                else
                    time = time / (num * 2 + (num * 2 - 1) * 0.25);
                this.onCheckLoop(time, num, end);
                break;
            case EnumImageEffect.MOVE_IN:
                this._image.alpha = 1;
                targetObj = {};
                if (params == null || params.dir == "0") {
                    this._image.y = -sh;
                    targetObj = { y: this._baseY };
                }
                else if (params.dir == "1") {
                    this._image.x = sw;
                    targetObj = { x: this._baseX };
                }
                else if (params.dir == "2") {
                    this._image.y = sh;
                    targetObj = { y: this._baseY };
                }
                else {
                    this._image.x = -sw;
                    targetObj = { x: -this._baseX };
                }
                egret.Tween.get(this._image).wait(delay).to(targetObj, time).call(this.onTweenFinish, this, [this._image]);
                break;
            case EnumImageEffect.MOVE_OUT:
                this._image.alpha = 1;
                targetObj = {};
                if (params == null || params.dir == "0") {
                    targetObj = { y: -sh };
                }
                else if (params.dir == "1") {
                    targetObj = { x: sw };
                }
                else if (params.dir == "2") {
                    targetObj = { y: sh };
                }
                else {
                    targetObj = { x: -sw };
                }
                egret.Tween.get(this._image).wait(delay).to(targetObj, time).call(this.onTweenFinish, this, [this._image]);
                break;
            case EnumImageEffect.MOVE_BLACK_MASK_IN:
                this._image.alpha = 1;
                this.initMask(0, false, 1);
                targetObj = {};
                if (params == null || params.dir == "0") {
                    this._spImageMask.y = 0;
                    targetObj.y = -sh;
                }
                else if (params.dir == "1") {
                    this._spImageMask.x = 0;
                    targetObj.x = sw;
                }
                else if (params.dir == "2") {
                    this._spImageMask.y = 0;
                    targetObj.y = sh;
                }
                else {
                    this._spImageMask.x = 0;
                    targetObj.x = -sw;
                }
                egret.Tween.get(this._spImageMask).wait(delay).to(targetObj, time).call(this.onTweenFinish, this, [this._spImageMask]);
                break;
            case EnumImageEffect.MOVE_BLACK_MASK_OUT:
                this._image.alpha = 1;
                this.initMask(0, false, 1);
                targetObj = {};
                if (params == null || params.dir == "0") {
                    this._spImageMask.y = sh;
                    targetObj.y = 0;
                }
                else if (params.dir == "1") {
                    this._spImageMask.x = -sw;
                    targetObj.x = 0;
                }
                else if (params.dir == "2") {
                    this._spImageMask.y = -sh;
                    targetObj.y = 0;
                }
                else {
                    this._spImageMask.x = sw;
                    targetObj.x = 0;
                }
                egret.Tween.get(this._spImageMask).wait(delay).to(targetObj, time).call(this.onTweenFinish, this, [this._spImageMask]);
                break;
            case EnumImageEffect.FLASH_OUT:
                this.initMask(0xffffff);
                this._spImageMask.alpha = 0;
                egret.Tween.get(this._spImageMask).wait(delay).to({ alpha: 1 }, time).call(this.onTweenFinish, this, [this._spImageMask]);
                break;
            case EnumImageEffect.FLASH_IN:
                this.initMask(0xffffff);
                this._image.alpha = 1;
                egret.Tween.get(this._spImageMask).wait(delay).to({ alpha: 0 }, time).call(this.onTweenFinish, this, [this._spImageMask]);
                break;
            case EnumImageEffect.CUT_TWO_IMAGE_OUT:
                this._rect.setTo(0, 0, sw, sh >> 1);
                (this.tempRenderImage0.texture as egret.RenderTexture).drawToTexture(this._image, this._rect);
                this.addChild(this.tempImage0);
                this._rect.setTo(0, sh >> 1, sw, sh >> 1);
                (this.tempRenderImage1.texture as egret.RenderTexture).drawToTexture(this._image, this._rect);
                this.addChild(this.tempImage1);
                this.tempImage0.y = 0;
                this.tempImage1.y = sh >> 1;
                this._image.alpha = 0;
                egret.Tween.get(this.tempImage0).wait(delay).to({ y: -sh >> 1 }, time).call(this.onTweenFinish, this, [this.tempImage0]);
                egret.Tween.get(this.tempImage1).wait(delay).to({ y: sh }, time).call(this.onTweenFinish, this, [this.tempImage1, false]);
                break;
            case EnumImageEffect.CUT_TWO_IMAGE_IN:
                App.timer.doTimeOnce(this, 10, () => {
                    this._rect.setTo(0, 0, sw, sh >> 1);
                    (this.tempRenderImage0.texture as egret.RenderTexture).drawToTexture(this._image, this._rect);
                    this.addChild(this.tempImage0);
                    this._rect.setTo(0, sh >> 1, sw, sh >> 1);
                    (this.tempRenderImage1.texture as egret.RenderTexture).drawToTexture(this._image, this._rect);
                    this.addChild(this.tempImage1);
                });
                this.tempImage0.y = -sh >> 1;
                this.tempImage1.y = sh;
                this._image.alpha = 0;
                egret.Tween.get(this.tempImage0).wait(delay).to({ y: 0 }, time).call(this.onTweenFinish, this, [this.tempImage0]);
                egret.Tween.get(this.tempImage1).wait(delay).to({ y: sh >> 1 }, time).call(this.onTweenFinish, this, [this.tempImage1, false]);
                break;
            case EnumImageEffect.CUT_IMAGE_OUT:
                targetObj = {};
                this._image.alpha = 1;
                this.initMask(0, true, 1);
                //上下 0
                if (params == null || params.dir == "0") {
                    targetObj.scaleY = 0//1 / sh;
                    targetObj.y = sh >> 1;
                } else {//左右 1
                    targetObj.scaleX = 0//1 / sh;
                    targetObj.x = sw >> 1;
                }
                egret.Tween.get(this._spImageMask).wait(delay).to(targetObj, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this._spImageMask]);
                break;
            case EnumImageEffect.CUT_IMAGE_IN:
                targetObj = {};
                this._image.alpha = 1;
                this.initMask(0, true, 1);
                //上下 0
                if (params == null || params.dir == "0") {
                    this._spImageMask.scaleY = 0;
                    this._spImageMask.y = sh >> 1;
                    targetObj.y = 0;
                    targetObj.scaleY = 1;
                } else {//左右 1
                    this._spImageMask.scaleX = 0;
                    this._spImageMask.x = sw >> 1;
                    targetObj.x = 0;
                    targetObj.scaleX = 1;
                }
                egret.Tween.get(this._spImageMask).wait(delay).to(targetObj, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this._spImageMask]);
                break;
            case EnumImageEffect.SHAKE:
                this._image.alpha = 1;
                this.shakeTween(this, params && params.times ? Number(params.times) : 2, params && params.offset ? Number(params.offset) : 4, params && params.speed ? Number(params.speed) : 32);
                break;
            case EnumImageEffect.BLACK_MOVE_OUT:
                this._image.alpha = 1;
                this.tempImage0.source = "img_black_mask_png";
                this.addChild(this.tempImage0);
                if (params == null || params.dir == null || params.dir == "0") {
                    this.tempImage0.scaleY = 1.5;
                    this.tempImage0.y = sh;
                    egret.Tween.get(this.tempImage0).wait(delay).to({ y: -sh >> 1 }, time).call(this.onTweenFinish, this, [this.tempImage0]);
                }
                else {
                    this.tempImage0.scaleY = -1.5;
                    this.tempImage0.y = 0;
                    egret.Tween.get(this.tempImage0).wait(delay).to({ y: sh + (sh >> 1) }, time).call(this.onTweenFinish, this, [this.tempImage0]);
                }
                break;
            case EnumImageEffect.BLACK_MOVE_IN:
                this._image.alpha = 1;
                this.tempImage0.source = "img_black_mask_png";
                this.addChild(this.tempImage0);
                if (params == null || params.dir == null || params.dir == "0") {
                    this.tempImage0.scaleY = 1.5;
                    this.tempImage0.y = -sh >> 1;
                    egret.Tween.get(this.tempImage0).wait(delay).to({ y: sh }, time).call(this.onTweenFinish, this, [this.tempImage0]);
                }
                else {
                    this.tempImage0.scaleY = 1.5;
                    this.tempImage0.y = sh + (sh >> 1);
                    egret.Tween.get(this.tempImage0).wait(delay).to({ y: 0 }, time).call(this.onTweenFinish, this, [this.tempImage0]);
                }
                break;
            case EnumImageEffect.CLOCK_IN:
                this._image.alpha = 1;
                if (this._tempObj == null)
                    this._tempObj = {};
                this.initMask(-1, false, 1);
                this._spImageMask.x = sw >> 1;
                this._spImageMask.y = sh >> 1;
                this._tempObj.angle = 359;
                this._tempObj.isRightDir = false;
                this._tempObj.radius = Math.ceil(Math.sqrt(sw * sw + sh * sh)) >> 1;
                egret.Tween.get(this._tempObj, { onChange: this.onChangeClock, onChangeObj: this }).wait(delay).to({ angle: 1 }, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this._tempObj]);
                break;
            case EnumImageEffect.CLOCK_OUT:
                this._image.alpha = 1;
                if (this._tempObj == null) {
                    this._tempObj = {};
                }
                this.initMask(-1, false, 1);
                this._spImageMask.x = sw >> 1;
                this._spImageMask.y = sh >> 1;
                this._tempObj.angle = 0;
                this._tempObj.isRightDir = true;
                this._tempObj.radius = Math.ceil(Math.sqrt(sw * sw + sh * sh)) >> 1;
                egret.Tween.get(this._tempObj, { onChange: this.onChangeClock, onChangeObj: this }).wait(delay).to({ angle: 359 }, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this._tempObj]);
                break;
            case EnumImageEffect.CLOCK_IN_OUT://遮住上面的图,下面的图直接出现
                this._image.alpha = 1;
                if (this._tempObj == null) {
                    this._tempObj = {};
                }
                this.initMask(-1, true, 1);
                this._spImageMask.x = sw >> 1;
                this._spImageMask.y = sh >> 1;
                this._tempObj.angle = 359;
                this._tempObj.isRightDir = false;
                this._tempObj.radius = Math.ceil(Math.sqrt(this._image.width * this._image.width + this._image.height * this._image.height)) >> 1;
                egret.Tween.get(this._tempObj, { onChange: this.onChangeClock, onChangeObj: this }).wait(delay).to({ angle: 1 }, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this._tempObj]);
                break;
            case EnumImageEffect.CLOCK_IN_MASK://遮住上面的图,下面的图直接出现
                this._image.alpha = 1;
                if (this._tempObj == null) {
                    this._tempObj = {};
                }
                this.initMask(-1, true, 1);
                this._spImageMask.x = sw >> 1;
                this._spImageMask.y = sh >> 1;
                this._tempObj.angle = 1;
                this._tempObj.isRightDir = true;
                this._tempObj.radius = Math.ceil(Math.sqrt(this._image.width * this._image.width + this._image.height * this._image.height)) >> 1;
                egret.Tween.get(this._tempObj, { onChange: this.onChangeClock, onChangeObj: this }).wait(delay).to({ angle: 359 }, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this._tempObj]);
                break;
            case EnumImageEffect.BRUSH_IN:
                this._image.alpha = 1;
                this.tempImage0.source = "brush_mask_tex_png";
                this.addChild(this.tempImage0);
                this.tempImage0.width = sw;
                this.tempImage0.height = sh;
                this.tempImage0.scaleX = -2;
                this.tempImage0.scaleY = -2;
                this.tempImage0.x = sw;//-sw * 2;
                this.tempImage0.y = sh * 2;
                egret.Tween.get(this.tempImage0).wait(delay).to({ y: sh, x: sw * 3 }, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this.tempImage0]);
                break;
            case EnumImageEffect.BRUSH_OUT:
                this._image.alpha = 1;
                this.tempImage0.source = "brush_mask_tex_png";
                this.addChild(this.tempImage0);
                this.tempImage0.width = sw;
                this.tempImage0.height = sh;
                this.tempImage0.scaleX = this.tempImage0.scaleY = 2;
                this.tempImage0.x = -sw * 2;
                this.tempImage0.y = 0;
                egret.Tween.get(this.tempImage0).wait(delay).to({ y: -sh, x: 0 }, time, egret.Ease.sineIn).call(this.onTweenFinish, this, [this.tempImage0]);
                break;
            case EnumImageEffect.SPREAD_OUT:
                this._image.alpha = 1;
                if (params && params.isblur == "1") {
                    this.tempImage0.source = "img_circle_blur_mask_png";
                    this.tempImage0.width = 1700;
                    this.tempImage0.height = 1700;
                    this.tempImage0.x = (sw - 1700) >> 1;
                    this.tempImage0.y = (sh - 1700) >> 1;
                }
                else {
                    this.tempImage0.source = "img_circle_mask_png";
                    this.tempImage0.width = 1470;
                    this.tempImage0.height = 1470;
                    this.tempImage0.x = (sw - 1470) >> 1;
                    this.tempImage0.y = (sh - 1470) >> 1;
                }
                this.addChild(this.tempImage0);
                this._image.mask = this.tempImage0;
                egret.Tween.get(this.tempImage0).wait(delay).to({ width: 10, height: 10, x: sw - 10 >> 1, y: sh - 10 >> 1 }, time).
                    call(this.onTweenFinish, this, [this.tempImage0]);
                break;
            case EnumImageEffect.SPREAD_IN:
                this._image.alpha = 1;
                if (params && params.isblur == "1") {
                    this.tempImage0.source = "img_circle_blur_mask_png";
                    targetObj = { width: 1700, height: 1700, x: sw - 1700 >> 1, y: sh - 1700 >> 1 };
                }
                else {
                    this.tempImage0.source = "img_circle_mask_png";
                    targetObj = { width: 1470, height: 1470, x: sw - 1470 >> 1, y: sh - 1470 >> 1 };
                }
                this.tempImage0.width = this.tempImage0.height = 10;
                this.tempImage0.x = sw - 10 >> 1;
                this.tempImage0.y = sh - 10 >> 1;
                this._image.mask = this.tempImage0;
                this.addChild(this.tempImage0);
                egret.Tween.get(this.tempImage0).wait(delay).to(targetObj, time).
                    call(this.onTweenFinish, this, [this.tempImage0]);
                break;
            case EnumImageEffect.SHADE_OUT:
                this._image.alpha = 1;
                this.tempImage0.source = "img_shade_mask_png";
                this.addChild(this.tempImage0);
                this._image.mask = this._tempImage0;
                if (params == null || params.dir == null || params.dir == "0") { //0:左上->右下
                    this.tempImage0.scaleX = 2;
                    this.tempImage0.scaleY = 2;
                    this.tempImage0.x = -sw;
                    this.tempImage0.y = -sh;
                    targetObj = { x: 0, y: 0 };
                } else if (params.dir == "1") { //1:右上->左下
                    this.tempImage0.scaleX = -2;
                    this.tempImage0.scaleY = 2;
                    this.tempImage0.x = sw * 2;
                    this.tempImage0.y = -sh;
                    targetObj = { x: sw, y: 0 };
                } else if (params.dir == "2") { //2:右下->左上
                    this.tempImage0.scaleX = -2;
                    this.tempImage0.scaleY = -2;
                    this.tempImage0.x = sw * 2;
                    this.tempImage0.y = sh * 2;
                    targetObj = { x: sw, y: sh };
                } else if (params.dir == "3") { //3:左下->右上
                    this.tempImage0.scaleX = 2;
                    this.tempImage0.scaleY = -2;
                    this.tempImage0.x = -sw;
                    this.tempImage0.y = sh * 2;
                    targetObj = { x: 0, y: sh };
                }
                egret.Tween.get(this.tempImage0).to(targetObj, time).call(this.onTweenFinish, this, [this.tempImage0]);
                break;
            case EnumImageEffect.SHADE_IN:
                this._image.alpha = 1;
                this.tempImage0.source = "img_shade_mask_png";
                this.addChild(this.tempImage0);
                if (params == null || params.dir == null || params.dir == "0") { //0:左上->右下
                    this.tempImage0.scaleX = 2;
                    this.tempImage0.scaleY = 2;
                    this.tempImage0.x = -sw;
                    this.tempImage0.y = -sh;
                    targetObj = { x: 0, y: 0 };
                } else if (params.dir == "1") { //1:右上->左下
                    this.tempImage0.scaleX = -2;
                    this.tempImage0.scaleY = 2;
                    this.tempImage0.x = sw * 2;
                    this.tempImage0.y = -sh;
                    targetObj = { x: sw, y: 0 };
                } else if (params.dir == "2") { //2:右下->左上
                    this.tempImage0.scaleX = -2;
                    this.tempImage0.scaleY = -2;
                    this.tempImage0.x = sw * 2;
                    this.tempImage0.y = sh * 2;
                    targetObj = { x: sw, y: sh };
                } else if (params.dir == "3") { //3:左下->右上
                    this.tempImage0.scaleX = 2;
                    this.tempImage0.scaleY = -2;
                    this.tempImage0.x = -sw;
                    this.tempImage0.y = sh * 2;
                    targetObj = { x: 0, y: sh };
                }
                egret.Tween.get(this.tempImage0).to(targetObj, time).call(this.onTweenFinish, this, [this.tempImage0]);
                break;
            case EnumImageEffect.NONE_IN:
                this._image.alpha = 1;
                break;
            case EnumImageEffect.NONE_OUT:
                this._image.alpha = 0;
                this._image.source = null;
                break;
            case EnumImageEffect.FLASH_WHITE_LIGHT:
                this._image.alpha = 1;
                this.initMask(0xffffff, false, 1);
                this._spImageMask.alpha = 0;
                this.onLoopFlashWhite(params && params.num ? Number(params.num) : 1);
                break;
            case EnumImageEffect.FLASH_BLACK_LIGHT:
                this._image.alpha = 1;
                this.initMask(0, false, 1);
                this._spImageMask.alpha = 0;
                this.onLoopFlashBlack(params && params.num ? Number(params.num) : 1, params && params.time ? Number(params.time) : 200, 250);
                break;
            case EnumImageEffect.APART_SHAKE:
                this._image.alpha = 1;
                var scale: number = this._image.scaleX;
                this.tempImage0.source = this._image.source;
                this.addChild(this.tempImage0);
                this.tempImage1.source = this._image.source;
                this.addChild(this.tempImage1);
                this.tempImage0.alpha = this.tempImage1.alpha = 0.5;
                this.tempImage0.x = this.tempImage1.x = this._image.x;
                this.tempImage0.y = this.tempImage1.y = this._image.y;
                this.tempImage0.scaleX = this.tempImage0.scaleY = this.tempImage1.scaleX = this.tempImage1.scaleY = scale;
                this.shakeTween(this, 8, 4, 16);
                // egret.Tween.get(this.tempImage0, { loop: true }).wait(50).to({ x: this._image.x - 30 * scale }, 1500).wait(50).
                //     to({ x: this._image.x }, 1200);
                // egret.Tween.get(this.tempImage1, { loop: true }).wait(50).to({ x: this._image.x + 30 * scale }, 1500).wait(50).
                //     to({ x: this._image.x }, 1200);
                this.resetApartShake(8, this._image.x, this._image.y, scale, 500);
                break;
            case EnumImageEffect.MEMORY:
            case EnumImageEffect.WHITE_IMAGINATION:
            case EnumImageEffect.DARK:
            case EnumImageEffect.SHAKE_BLUR:
            case EnumImageEffect.REMOVE_APART_SHAKE:
                break;
            case EnumImageEffect.CLEAR:
                this._image.alpha = 1;
                this._isShow = true;
                this.removeStaticEffect();
                break;
        }
        this._isShow = EnumImageEffect.HIDE_EFFECT_LIST.indexOf(effectType) == -1;
    }

    public addStaticEffect(effectType: string, params: any = null): void {
        this._lastEffectType = effectType;
        this._addStaticEffect = true;
        var sw: number = Config.MAIN_WIDTH;
        var sh: number = Config.MAIN_HEIGHT;
        switch (effectType) {
            case EnumImageEffect.MEMORY:
                this._image.alpha = 1;
                this.tempImage0.source = "memory_mask_tex_png";
                this.addChild(this.tempImage0);
                break;
            case EnumImageEffect.WHITE_IMAGINATION:
                this._image.alpha = 1;
                this.tempImage0.source = "memory_mask_tex_png";
                this.addChild(this.tempImage0);
                this.tempImage1.source = "memory_mask_tex_png";
                this.addChild(this.tempImage1);
                break;
            case EnumImageEffect.DARK:
                this._image.alpha = 1;
                if (this._staticMaskSp == null) {
                    this._staticMaskSp = new egret.Shape();
                }
                this._staticMaskSp.x = 0;
                this._staticMaskSp.y = 0;
                this.drawRectMask(this._staticMaskSp, 0);
                this._staticMaskSp.alpha = 0;
                this.addChild(this._staticMaskSp);
                egret.Tween.get(this._staticMaskSp).to({ alpha: 0.6 }, 400).call(this.onTweenFinish, this, [this._staticMaskSp, false]);
                // this._image.alpha = 1;
                // this._image.filters = [FilterUtil.getConfigAdjustColorMatrixFilter(-80, 0, 0, 0)];
                break;
            case EnumImageEffect.SHAKE_BLUR:
                this._image.alpha = 1;
                this._image.filters = [FilterUtil.getBlurFilterByQuality(params && params.quality ? Number(params.quality) : 0)];
                egret.Tween.get(this._image, { loop: true }).
                    to({ scaleX: 1.1, scaleY: 1.1, x: -this._image.texture.textureWidth * 0.1 >> 1, y: -this._image.texture.textureHeight * 0.1 >> 1 }, 2400, egret.Ease.sineIn).
                    to({ scaleX: 1, scaleY: 1, x: 0, y: 0 }, 1200, egret.Ease.sineIn);
                break;
            case EnumImageEffect.REMOVE_APART_SHAKE:
                this._image.alpha = 1;
                var scale: number = this._image.scaleX;
                this.tempImage0.source = this._image.source;
                this.addChild(this.tempImage0);
                this.tempImage1.source = this._image.source;
                this.addChild(this.tempImage1);
                this.tempImage0.alpha = this.tempImage1.alpha = 0.5;
                this.tempImage0.x = this.tempImage1.x = this._image.x;
                this.tempImage0.y = this.tempImage1.y = this._image.y;
                this.tempImage0.scaleX = this.tempImage0.scaleY = this.tempImage1.scaleX = this.tempImage1.scaleY = scale;
                egret.Tween.removeTweens(this.tempImage0);
                egret.Tween.removeTweens(this.tempImage1);
                this.resetApartShake(3, this._image.x, this._image.y, scale);
                break;
        }
    }

    public removeStaticEffect(): void {
        this._addStaticEffect = false;
        this.resetEffect();
    }

    private resetApartShake(times: number, x: number, y: number, scale: number, delay: number = 0): void {
        if (times >= 1) {
            egret.Tween.get(this.tempImage0).wait(delay).to({ x: x - 40 * times / 8 * scale }, 1550).wait(50).
                to({ x: x }, 1550).wait(50).call(this.resetApartShake, this, [times * 0.5, x, y, scale]);
            egret.Tween.get(this.tempImage1).wait(delay).to({ x: x + 40 * times / 8 * scale }, 1550).wait(50).
                to({ x: x }, 1550).wait(50);
        }
        else {
            egret.Tween.removeTweens(this.tempImage0);
            egret.Tween.removeTweens(this.tempImage1);
            if (scale != 1)
                this._lastEffectType = EnumImageEffect.CHANGE_SCALE;
            this.removeStaticEffect();
        }
    }

    private onLoopFlashBlack(leftNum: number, time: number = 200, showTime: number): void {
        egret.Tween.removeTweens(this._spImageMask);
        if (leftNum >= 1) {
            egret.Tween.get(this._spImageMask).to({ alpha: 1 }, 100, egret.Ease.quartOut).wait(showTime).to({ alpha: 0 }, 100, egret.Ease.quadOut).wait(time).
                call(this.onLoopFlashBlack, this, [leftNum - 1, time, showTime]);
        }
        else if (leftNum == 0) {
            egret.Tween.get(this._spImageMask).to({ alpha: 1 }, 100, egret.Ease.quartOut).wait(showTime + 1000).to({ alpha: 0 }, 1000).
                call(this.onLoopFlashBlack, this, [leftNum - 1, time, showTime]);
        }
        else {
            this.resetEffect();
        }
    }

    private onLoopFlashWhite(leftNum: number): void {
        egret.Tween.removeTweens(this._spImageMask);
        if (leftNum >= 1) {
            egret.Tween.get(this._spImageMask).to({ alpha: 1 }, 100, egret.Ease.quartOut).wait(50).to({ alpha: 0 }, 100, egret.Ease.quadOut).wait(200).
                call(this.onLoopFlashWhite, this, [leftNum - 1]);
        }
        else {
            this.resetEffect();
        }
    }

    /**
     * 时钟切入切出更新
     */
    private onChangeClock(): void {
        this.drawSectorMask(this._tempObj.radius, this._tempObj.isRightDir, this._tempObj.angle ? Math.floor(this._tempObj.angle) : 0);
    }

    /**执行下一个tween */
    private onTweenNext(oldTarget: any, newTarget: any, props: any, time: number): void {
        egret.Tween.removeTweens(oldTarget);
        egret.Tween.get(newTarget).to(props, time).call(this.onTweenFinish, this, [newTarget]);
    }

    /**
     * 抖动
     */
    public shakeTween(target: egret.DisplayObject, times: number = 2, offset: number = 4, speed: number = 32): void {
        if (this._isShake) {
            return;
        }
        this._isShake = true;
        if (this._offsetXYArray == null) {
            this._offsetXYArray = [0, 0];
        }
        App.timer.doTimeLoop(this, speed, this.onUpdateShake, [target, target.x, target.y, offset, times]);
    }

    private onUpdateShake(target: egret.DisplayObject, x: number, y: number, offset: number, times: number): void {
        this._offsetXYArray[this._shakeNum % 2] = (this._shakeNum++) % 4 < 2 ? 0 : offset;
        if (this._shakeNum > (times * 4 + 1)) {
            App.timer.clearTimer(this, this.onUpdateShake);
            this._shakeNum = 0;
            this._isShake = false;
            this._offsetXYArray[0] = 0;
            this._offsetXYArray[1] = 0;
        }
        target.x = this._offsetXYArray[0] + x;
        target.y = this._offsetXYArray[1] + y;
    }

    /**
     * 初始化遮罩
     */
    private initMask(color: number = 0, isMask: boolean = false, depth: number = 1): void {
        if (this._spImageMask == null) {
            this._spImageMask = new egret.Shape();
        }
        this._spImageMask.x = 0;
        this._spImageMask.y = 0;
        this._spImageMask.alpha = 1;
        if (color >= 0)
            this.drawRectMask(this._spImageMask, color);
        if (depth >= 1)
            this.addChild(this._spImageMask);
        else
            this.addChildAt(this._spImageMask, 0);
        if (isMask)
            this._image.mask = this._spImageMask;
    }

    /**
     * 绘制遮罩
     */
    private drawRectMask(target: egret.Shape, color: number = 0): void {
        target.graphics.clear();
        target.graphics.beginFill(color);
        target.graphics.drawRect(0, 0, Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
        target.graphics.endFill();
    }

    /**
     * 创建渐变区域
     */
    private createGradientMatrix(width: number, height: number, rotation?: number, tx?: number, ty?: number): void {
        if (this._matrix == null) {
            this._matrix = new egret.Matrix();
        }
        this._matrix.createGradientBox(width, height, rotation, tx, ty);
    }

    /**
     * 绘制扇形
     */
    private drawSectorMask(radius: number, isRightDir: boolean, angle: number, x: number = 0, y: number = 0, startFrom: number = 270, color = 0): void {
        this._spImageMask.graphics.clear();
        this._spImageMask.graphics.lineStyle(0, color);
        this._spImageMask.graphics.beginFill(color);
        this._spImageMask.graphics.moveTo(x, y);
        angle = (Math.abs(angle) > 360) ? 360 : angle;
        var n: number = Math.ceil(Math.abs(angle) / 45);
        var angleA: number = angle / n;
        angleA = angleA * Math.PI / 180;
        startFrom = startFrom * Math.PI / 180;
        this._spImageMask.graphics.lineTo(x + radius * Math.cos(startFrom), y + radius * Math.sin(startFrom));
        var angleMid: number, bx: number, by: number, cx: number, cy: number;
        for (var i = 1; i <= n; i++) {
            startFrom = isRightDir ? startFrom + angleA : startFrom - angleA;
            angleMid = isRightDir ? startFrom - angleA / 2 : startFrom + angleA / 2;
            bx = x + radius / Math.cos(angleA / 2) * Math.cos(angleMid);
            by = y + radius / Math.cos(angleA / 2) * Math.sin(angleMid);
            cx = x + radius * Math.cos(startFrom);
            cy = y + radius * Math.sin(startFrom);
            this._spImageMask.graphics.curveTo(bx, by, cx, cy);
        }
        if (angle != 360) {
            this._spImageMask.graphics.lineTo(x, y);
        }
        this._spImageMask.graphics.endFill();
    }

    private onCheckLoop(time: number, leftNum: number, end: string): void {
        var sw: number = Config.MAIN_WIDTH;
        var sh: number = Config.MAIN_HEIGHT;
        if (leftNum == 0) {
            egret.Tween.removeTweens(this._image);
        }
        else if (leftNum == 1) {
            if (end == EnumMoveEnd.MIDDLE) {
                egret.Tween.get(this._image).to({ x: sw - this._image.width }, time).wait(time * 0.25).to({ x: (sw - this._image.width) >> 1 }, time >> 1).call(this.onCheckLoop, this, [time, leftNum - 1, end]);
            }
            else if (end == EnumMoveEnd.RIGHT) {
                egret.Tween.get(this._image).to({ x: sw - this._image.width }, time).call(this.onCheckLoop, this, [time, leftNum - 1, end]);
            }
            else {
                egret.Tween.get(this._image).to({ x: sw - this._image.width }, time).wait(time * 0.25).to({ x: 0 }, time).call(this.onCheckLoop, this, [time, leftNum - 1, end]);
            }
        }
        else {
            egret.Tween.get(this._image).to({ x: sw - this._image.width }, time).wait(time * 0.25).to({ x: 0 }, time).wait(time * 0.25).call(this.onCheckLoop, this, [time, leftNum - 1, end]);
        }
    }

    private onTweenFinish(target, needReset: boolean = true): void {
        egret.Tween.removeTweens(target);
        if (needReset)
            this.resetEffect();
    }

    /**
     * 重置所有效果
     */
    public resetEffect(): void {
        if (this._lastEffectType != EnumImageEffect.LOOP_MOVE && this._lastEffectType != EnumImageEffect.MOVE && this._lastEffectType != EnumImageEffect.CHANGE_SCALE) {
            this._image.x = this._baseX;
            this._image.y = this._baseY;
        }
        if (this._lastEffectType != EnumImageEffect.CHANGE_SCALE) {
            this._image.scaleX = this._baseScale;
            this._image.scaleY = this._baseScale;
        }
        if (this._lastEffectType != EnumImageEffect.SHAKE_BLUR)
            egret.Tween.removeTweens(this._image);
        if (this._spImageMask) {
            egret.Tween.removeTweens(this._spImageMask);
            if (this._spImageMask.parent)
                this._spImageMask.parent.removeChild(this._spImageMask);
            this._spImageMask.graphics.clear();
            this._spImageMask.alpha = 1;
            this._spImageMask.scaleX = this._spImageMask.scaleY = 1;
        }
        if (this._tempObj && this._tempObj.hasOwnProperty("angle")) {
            egret.Tween.removeTweens(this._tempObj);
            delete this._tempObj.angle;
        }
        if (this._addStaticEffect == false) {
            if (this._tempImage0 && this._tempImage0.parent) {
                this._tempImage0.parent.removeChild(this._tempImage0);
                this._tempImage0.source = this._tempTexture0;
                this._tempImage0.x = this._tempImage0.y = 0;
                this._tempImage0.scaleX = 1;
                this._tempImage0.scaleY = 1;
                this._tempImage0.alpha = 1;
                egret.Tween.removeTweens(this._tempImage0);
            }
            if (this._tempImage1 && this._tempImage1.parent) {
                this._tempImage1.parent.removeChild(this._tempImage1);
                this._tempImage1.source = this._tempTexture1;
                this._tempImage1.x = this._tempImage1.y = 0;
                this._tempImage1.scaleX = 1;
                this._tempImage1.scaleY = 1;
                this._tempImage1.alpha = 1;
                egret.Tween.removeTweens(this._tempImage1);
            }
            if (this._image.filters) {
                this._image.filters = null;
            }
            this.removeStaticMaskSp();
        }
        this._image.mask = null;
        this._image.alpha = this._isShow ? 1 : 0;
        if (!this._isShow)
            this._image.source = null;
        if (this._isShake) {
            this._isShake = false;
            App.timer.clearTimer(this, this.onUpdateShake);
        }
    }

    /**
     * 移除静态效果对象
     */
    private removeStaticMaskSp(): void {
        if (this._staticMaskSp && this._staticMaskSp.parent) {
            egret.Tween.get(this._staticMaskSp).to({ alpha: 0 }, 400).call(() => {
                if (this._staticMaskSp.parent) {
                    this._staticMaskSp.parent.removeChild(this._staticMaskSp);
                    this._staticMaskSp.graphics.clear();
                    this._staticMaskSp.alpha = 1;
                    egret.Tween.removeTweens(this._staticMaskSp);
                }
            }, this);
        }
    }

    public set source(value: egret.Texture | string) {
        this._image.source = value;
    }

    public get source(): egret.Texture | string {
        return this._image.source;
    }

    public resetBaseData(): void {
        this._baseX = 0;
        this._baseY = 0;
        this._baseScale = 1;
        this._image.x = 0;
        this._image.y = 0;
        this._image.scaleX = 1;
        this._image.scaleY = 1;
    }

    public setBaseX(value: number, changeSrc: boolean = false) {
        this._baseX = value;
        if (changeSrc)
            this._image.x = value;
    }

    public setBaseY(value: number, changeSrc: boolean = false) {
        this._baseY = value;
        if (changeSrc)
            this._image.y = value;
    }

    public setBaseScale(value: number, changeSrc: boolean = false) {
        this._baseScale = value;
        if (changeSrc)
            this._image.scaleX = this._image.scaleY = value;
    }

    private get tempRenderImage0(): eui.Image {
        if (this._tempImage0 == null) {
            this._tempImage0 = new eui.Image();
            this._tempTexture0 = new egret.RenderTexture();
        }
        this._tempImage0.texture = this._tempTexture0;
        return this._tempImage0;
    }

    private get tempRenderImage1(): eui.Image {
        if (this._tempImage1 == null) {
            this._tempImage1 = new eui.Image();
            this._tempTexture1 = new egret.RenderTexture();
        }
        this._tempImage1.texture = this._tempTexture1;
        return this._tempImage1;
    }

    private get tempImage0(): eui.Image {
        if (this._tempImage0 == null) {
            this._tempImage0 = new eui.Image();
            this._tempTexture0 = new egret.RenderTexture();
            this._tempImage0.texture = this._tempTexture0;
        }
        return this._tempImage0;
    }

    private get tempImage1(): eui.Image {
        if (this._tempImage1 == null) {
            this._tempImage1 = new eui.Image;
            this._tempTexture1 = new egret.RenderTexture();
            this._tempImage1.texture = this._tempTexture1;
        }
        return this._tempImage1;
    }

    public get image(): eui.Image {
        return this._image;
    }

    public set lastEffectType(value: string) {
        this._lastEffectType = value;
    }

}