class BaseButton extends eui.Button {
    /**额外数据 */
    public data: any;

    protected createChildren(): void {
        super.createChildren();
    }

    public dispose(): void {
        this.data = null;
    }

}