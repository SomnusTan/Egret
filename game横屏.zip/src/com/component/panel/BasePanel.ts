/**
 * 面板基类
 */
class BasePanel extends h5_engine.GSprite implements IPanelDispose {
    protected _dispatcher: DispatcherRegister;

    protected _touchEffectBinder: TouchEffectBinder;
    /**面板名字 */
    public panelName: string = "";
    /**是否显示中 */
    public isShowing: boolean = false;

    public constructor() {
        super();
        this._dispatcher = new DispatcherRegister();
        this.init();
    }

    protected init(): void {

    }

    /**
     * 显示面板
     */
    public show(data?: any): void {
        if (this.needSendUMeng) {
            var panelInfo: PanelInfo = PanelManager.getPanelInfo(this.panelName);
            if (panelInfo && panelInfo.hasGetNameData == false && (App.global.userInfo.isNewUser || App.global.userInfo.isFistStart)) {
                App.nativeBridge.sendUMengData(EnumUMengEventID.GAME_PAGE_COUNT, panelInfo.nameData);
            }
        }
    }

    /**
     * 隐藏面板
     */
    public hide(): void {
        this._dispatcher.removeAllListeners();
        if (this._touchEffectBinder)
            this._touchEffectBinder.unBindAll();
    }

    public resize(): void {
    }

    public needDispose(): boolean {
        return true;
    }

    /**
     * 释放
     */
    public dispose(): void {
        this._dispatcher = null;
        this._touchEffectBinder = null;
        super.dispose();
    }

    /**
     * 关闭自身面板
     */
    public closePanel(): void {
        PanelManager.removePanelByName(this.panelName);
    }

    /**
     * 绑定点击特效
     */
    protected bindEffect(target: egret.DisplayObject, effectType: string): void {
        if (target == null)
            return;
        if (this._touchEffectBinder == null)
            this._touchEffectBinder = new TouchEffectBinder();
        if (this._touchEffectBinder)
            this._touchEffectBinder.bind(target, effectType);
    }

    /**
     * 解绑点击特效
     */
    protected unbindEffect(target: egret.DisplayObject, effectType: string): void {
        if (this._touchEffectBinder)
            this._touchEffectBinder.unbind(target);
    }

    /**
     * 是否需要发送数据
     */
    public get needSendUMeng(): boolean {
        return false;
    }

}