class GameTipsPanel extends BasePanel {
	private _view: GameTipsUI;
	private _pos: any;
	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new GameTipsUI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		this._view.txtContent.text = data ? String(data.content) : "";
		this._view.imgBg.height = Math.max(this._view.txtContent.textHeight + 40, 200);
		if (data && data.pos) {
			this._pos = data.pos;
		} else {
			var w: number = App.layer.rotation == 0 ? Config.SCREEN_WIDTH : Config.SCREEN_HEIGHT;
			var h: number = App.layer.rotation == 0 ? Config.SCREEN_HEIGHT : Config.SCREEN_WIDTH;
			this._pos = { x: w - this.width >> 1, y: h - this.height >> 1 };
		}
		this.resize();
	}

	public resize(): void {
		this.x = this._pos.x;
		this.y = this._pos.y;
	}

	public hide(): void {
		super.hide();
	}
}