class Alert extends h5_engine.GDisplayObjectContainer {
    /** 确定 */
    public static OK: number = 0;
    /** 取消 */
    public static CANCEL: number = 1;

    /** 
     * 弹框提示
     * @param txt :"",                  提示内容
     * @param btnLabels:"确定|取消",     按钮文本
     * @param closeHandler:FunctionVO   返回函数
     * @param title:""                  标题
     */
    public static show(txt: string = "", btnLabels: string = "确定|取消", closeHandler: FunctionVO = null, title: string = "提示"): void {
        PanelOpenManager.openPanel(EnumPanelID.ALERT,
            {
                txt: txt,
                title: title,
                btnLabels: btnLabels,
                closeHandler: closeHandler
            }, false);
    }

    /** 
     * (赵小野)弹框提示
     * @param txt :"",                  提示内容
     * @param btnLabels:"确定|取消",     按钮文本
     * @param closeHandler:FunctionVO   返回函数
     * @param title:""                  标题
     */
    public static show2(txt: string = "", btnLabels: string = "确 定|取 消", closeHandler: FunctionVO = null, title: string = "提示", isHtml: boolean = false): void {
        PanelOpenManager.openPanel(EnumPanelID.ALERT2,
            {
                isHtml: isHtml,
                txt: txt,
                title: title || "提示",
                btnLabels: btnLabels || "确 定|取 消",
                closeHandler: closeHandler
            }, false);
    }

    /**
     * 支付选择弹窗提示{price: string, closeHandler: FunctionVO}
     * @param price:价格
     * @param closeHandler:FunctionVO   返回函数
     */
    public static choosePay(data: any): void {
        PanelOpenManager.openPanel(EnumPanelID.CHOOSE_PAY, data, false);
    }

    /**
     * TIPS弹窗提示{content: string, pos?: any}
     * @param content:tips内容
     * @param pos:弹框的绝对位置，不填则上下左右居中
     */
    public static showTips(data: any): void {
        PanelOpenManager.openPanel(EnumPanelID.GAME_TIPS, data);
    }

}