class Combox extends BaseView {
	public groupItems: eui.Group;
	public itemBg: eui.Image;
	public groupBox: eui.Group;
	public imgBg: eui.Image;
	public btnDown: eui.Button;
	public txtSelected: eui.Label;

	private static _pool: eui.Label[] = [];
	private _items: eui.Label[];
	private _type: number;
	private _mask: egret.Shape;
	public selectNum: number;
	/** 下拉框状态，0：收起，1：展开 */
	private _state: number;

	public constructor() {
		super("ComboxSkin");
	}
	/**
	 * @param data = {data:数据列表， type:0:章，1:节}
	 */
	public show(data?: any): void {
		super.show(data);
		if (!data) return;

		this._type = data.type;

		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this.groupBox);
		this._dispatcher.addEventListener(egret.FocusEvent.FOCUS_OUT, this.onFocusOut, this, this);

		this.clearItems();
		this._items = [];
		var datas: number[] = data.data;
		var item: eui.Label;
		var lh: number = 30;
		for (var i: number = 0; i < datas.length; i++) {
			item = Combox.getLabel();
			item.text = datas[i] + "";
			item.y = lh * i;
			item.name = datas[i] + "";
			item.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onSelectItem, this);
			this.groupItems.addChild(item);
			this._items.push(item);
		}
		this.groupItems.y = 40 - this.groupItems.height;
		this.itemBg.height = datas.length * lh;
		if (this._mask == null) {
			this._mask = new egret.Shape();
			this._mask.y = 40;
			this.addChildAt(this._mask, 0);
			this.groupItems.mask = this._mask;
		}
		this._mask.graphics.clear();
		this._mask.graphics.beginFill(0);
		this._mask.graphics.drawRect(0, 0, this.groupItems.width, this.groupItems.height);
		this._mask.graphics.endFill();
		this.txtSelected.text = "请选择";
		this.selectNum = -1;
		this._state = 0;
	}

	private onSelectItem(e: egret.TouchEvent): void {
		this.txtSelected.text = e.target.name;
		this.selectNum = Number(e.target.name);
		this.onClick();
		if (this._type == 0) {
			App.dispatcher.dispatchEvent(GmCenter.SELECT_CHAPTER, this.selectNum);
		}
	}

	private onFocusOut(e?: egret.TouchEvent): void {
		if (this._state == 1) {
			this._state = 0;
			egret.Tween.get(this.groupItems).to({ y: 40 - this.groupItems.height }, 500);
		}
	}

	private onClick(e?: egret.TouchEvent): void {
		if (this._state == 0) {
			this._state = 1;
			egret.Tween.get(this.groupItems).to({ y: 40 }, 200);
		} else {
			this._state = 0;
			egret.Tween.get(this.groupItems).to({ y: 40 - this.groupItems.height }, 200);
		}
	}

	public hide(): void {
		super.hide();
		this.txtSelected.text = "请选择";
		this.clearItems();
	}

	private clearItems(): void {
		if (this._items) {
			for (var i: number = 0; i < this._items.length; i++) {
				this._items[i] && this._items[i].parent.removeChild(this._items[i]);
				this._items[i] && this._items[i].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onSelectItem, this);
				Combox._pool.push(this._items[i]);
			}
			this._items = undefined;
		}
	}

	private static getLabel(): eui.Label {
		if (this._pool.length > 0) {
			return this._pool.pop();
		}
		var label: eui.Label = new eui.Label();
		label.width = 100;
		label.textColor = 0;
		label.size = 30;
		return label;
	}

}