class ScrollerCenter {
	public constructor() {
	}
	/** 隐藏滚动条 */
	public static hideVerticalScrollBar(scroller: eui.Scroller): void {
		App.timer.doFrameOnce(this, 1, this.delayToHideScrollBar, [scroller]);
	}

	private static delayToHideScrollBar(scroller: eui.Scroller): void {
		App.timer.clearTimer(this, this.delayToHideScrollBar);
		if (scroller && scroller.verticalScrollBar) {
			scroller.verticalScrollBar.autoVisibility = false;
			scroller.verticalScrollBar.visible = false;
		}
		if (scroller && scroller.horizontalScrollBar) {
			scroller.horizontalScrollBar.autoVisibility = false;
			scroller.horizontalScrollBar.visible = false;
		}
	}
}