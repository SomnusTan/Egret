/**
 * 垂直列表组件（含滚动，对象复用）
 */
class VScrollPanel extends eui.Scroller {
	/**
	 * $width 可视区域宽
	 * $height 可视区域高
	 * $itemRender 渲染ItemRender
	 * $gap 间距
	 * $viewport 自定义渲染区域
	 */
	public constructor($width?: number, $height?: number, $itemRender?: any, $gap?: number, $viewPort?: eui.IViewport) {
		super()
		this.listSelectedIndex = -1;
		this.configUI($viewPort);
		this.width = $width ? $width : 0;
		this.height = $height ? $height : 0;
		this.itemRender = $itemRender ? $itemRender : undefined;
		this.gap = $gap ? $gap : 0;
		// this.scrollPolicyH = eui.ScrollPolicy.OFF;//屏蔽水平滚动条
		// this.scrollPolicyV.replace
	}

	private configUI($viewPort: eui.IViewport): void {
		this.skinName = "ScrollerSkin";
		if ($viewPort) {
			this.viewport = $viewPort;
		} else {
			this._list = new eui.List();
			this._list.addEventListener(eui.ItemTapEvent.ITEM_TAP, this.onListItemTab, this);
			// this._list.addEventListener(egret.Event.CHANGE, this.listChange, this);
			this.viewport = this._list;
		}
	}

	/**设置数据源 */
	public set dataProvider(value: any) {
		// this.removeAll();
		if (!this._dataProvider) {
			this._dataProvider = new eui.ArrayCollection(value);
			this._list.dataProvider = this._dataProvider;
		} else {
			this._dataProvider.source = value;
			this._dataProvider.refresh();
		}
		if (this.listSelectedIndex != -1) {
			App.timer.doFrameOnce(this, 1, this.onFrameSelecedItem);
		}
	}
	/**
	* 设置选中索引item
	*/
	public setSelectedIndex(index: number) {
		if (this.listSelectedIndex != index) {
			this.listSelectedIndex = index;
			App.timer.doFrameOnce(this, 1, this.onFrameSelecedItem);
		}
	}
	private onFrameSelecedItem(): void {
		if(!this._list) return;
		if(this.listSelectedIndex >= this._list.numChildren) return;
		this.onSelecedItem(this._list.getChildAt(this.listSelectedIndex) as eui.IItemRenderer);

	}
	/** 选中子页签 */
	private onListItemTab(evt: eui.ItemTapEvent): void {
		this.listSelectedIndex = this._list.selectedIndex;
		this.onSelecedItem(evt.itemRenderer);
	}
	private onSelecedItem(itemRenderer: eui.IItemRenderer) {
		if (this._clickItem) {
			this._clickItem.exec(itemRenderer);
		}
	}
	/**获取数据源 */
	public getDataProvider(): eui.ArrayCollection {
		return this._dataProvider;
	}

	/**定位 */
	public move($x: number, $y: number): void {
		this.x = $x;
		this.y = $y;
	}

	/**间距 */
	public set gap(value: number) {
		if (this._list && this._gap != value) {
			this._gap = value;
			let verLay: eui.VerticalLayout = new eui.VerticalLayout();
			verLay.gap = this.gap;
			this._list.layout = verLay;
		}
	}

	public get gap(): number {
		return this._gap;
	}

	/**移除所有项 */
	public removeAll(): void {
		if (this._list) {
			let len: number = this._list.numChildren;
			let render: ItemRenderer;
			for (let i: number = 0; i < len; i++) {
				render = this._list.getChildAt(i) as ItemRenderer;
				if (render) {
					// if(render.parent){
					// 	render.parent.removeChild(render);
					// }
					// this.list.removeChildAt(i)
					render.dispose();
				}
			}
			// this.list.removeItemAt(render);
		}
		if (this._dataProvider) {
			this._dataProvider.removeAll();
			// this._dataProvider.refresh();
			// this._dataProvider = null;
		}
	}

	/**销毁 */
	public dispose(): void {
		this.stopAnimation();
		this.removeAll();
		if (this._list) {
			this._list.removeEventListener(eui.ItemTapEvent.ITEM_TAP, this.onListItemTab, this);
			// this._list.removeEventListener(egret.Event.CHANGE, this.listChange, this);
			this._list = null;
		}
		this.viewport = null;
		this._itemRender = null;
		this._dataProvider = null;
		this.listSelectedIndex = -1;
	}

	public set itemRender(value: any) {
		if (value) {
			this._itemRender = value;
			this._list.itemRenderer = this._itemRender;
		}
	}

	public get itemRender(): any {
		return this._itemRender;
	}

	public get list(): eui.List {
		return this._list;
	}

	public set clickItem(vo: FunctionVO) {
		this._clickItem = vo;
	}
	private _clickItem: FunctionVO;
	private _dataProvider: eui.ArrayCollection;

	private _list: eui.List;

	private _itemRender: any;

	/**条目间距 */
	private _gap: number = 0;
	/** 选中列表 */
	private listSelectedIndex: number;
}