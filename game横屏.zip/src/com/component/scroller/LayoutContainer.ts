/***
 * 自动布局类<不含滚动>
 */
class LayoutContainer extends eui.Group {
	public static LEFT:string = "left";	
	
	public static CENTER:string = "center";

	public static RIGHT:string = "right";
	/**
	 * 布局
	 * sourse  源类<类型>
	 * verSpan  列间距 
	 * horSpan  行间距
	 * cols     列数
	 * itemCellFunction  对象关联函数
	 */
	public constructor(source: any, verSpan: number = 80, horSpan: number = 80, cols: number = 1, itemCellFunction?: FunctionVO) {
		super();
		this._sourse = source;
		this._cellFunction = itemCellFunction;
		this._verSpan = verSpan;
		this._horSpan = horSpan;
		this._cols = cols;
		this.touchEnabled = true;
		this.touchChildren = true;
	}

	/**
	 * 填充数据，自动布局
	 */
	public set dataProvider(list: any[]) {
		this.clear();
		this._dataProvider = list;
		if (!this._dataProvider) return;
		let length: number = list.length;
		if (this._align == LayoutContainer.CENTER) {
			this._alignStartX = -(this._cols * this._verSpan - this._vGap) / 2;
		} else if (this._align == LayoutContainer.RIGHT) {
			this._alignStartX = -(this._cols * this._verSpan - this._vGap);
		} else {
			this._alignStartX = 0;
		}
		this._sourseArr = [];
		let tempItem: egret.DisplayObject;
		for (let i: number = 0; i < length; i++) {
			tempItem = this.getItemTarget();
			if (this._cols != -1) {
				tempItem.x = (i % this._cols) * this._verSpan + this._alignStartX;
				tempItem.y = Math.floor(i / this._cols) * this._horSpan;
			} else {
				tempItem.x = i * this._verSpan;
				tempItem.y = 0;
			}
			this.addChild(tempItem);
			this._sourseArr.push(tempItem);
			if (this._cellFunction) {
				this._cellFunction.param = [tempItem, list[i], i];
				this._cellFunction.exec();
			}
		}
	}

	/**
	 * 强制刷新数据
	 */
	public refreshData(): void {
		if (!this._cellFunction) return;
		let len: number = this.dataProvider.length;
		let tempItem: h5_engine.GDisplayObject;
		for (let i: number = 0; i < len; i++) {
			tempItem = this.dataGroup[i];
			this._cellFunction.param = [tempItem, this.dataProvider[i]];
			this._cellFunction.exec();
		}
	}

	public get dataProvider(): any[] {
		return this._dataProvider;
	}

	public get dataGroup(): any[] {
		return this._sourseArr;
	}

	public set vGap(value: number) {
		this._vGap = value;
	}

	public set hGap(value: number) {
		this._hGap = value;
	}

	public set align(value: string) {
		this._align = value;
	}

	private getItemTarget(): egret.DisplayObject {
		// let clsName: string = egret.getQualifiedClassName(this._sourse);
		let itemTarget: egret.DisplayObject = new this._sourse();
		// switch (clsName) {
		// 	case "ItemGrid":
		// 		break;
		// 	default:
		// 		break;
		// }
		return itemTarget;
	}

	public clear(): void {
		while (this.numChildren > 0) {
			let dis: egret.DisplayObject = this.removeChildAt(0);
			if (egret.is(dis, "IDispose")) {
				dis['dispose']();
			} else {
				throw Error("使用LayoutContainer必须实现 IDispose接口");
			}
		}
	}

	private _dataProvider: any[];
	private _sourseArr: any[] = [];
	private _alignStartX: number = 0;
	// private _itemsPool:any[] = [];
	private _cols: number = -1;
	protected _sourse: any;
	private _vGap: number = 0;
	private _hGap: number = 0;
	private _verSpan: number = 50;
	private _horSpan: number = 50;
	private _cellFunction: FunctionVO;
	private _align: string = "left";
}