/**
 * 界面层级管理
 */
class MainLayer extends h5_engine.GDisplayObjectContainer {
    /**Video Loading*/
    public videoLoadingLayer: LayerBase;
    /**地图场景层*/
    public sceneLayer: LayerBase;
    /**主界面*/
    public mainLayer: LayerBase;
    /**特殊菜单层 */
    public specialMenuLayer: LayerBase;
    /**模块层*/
    public moduleLayer: LayerModule;
    /**通用显示层*/
    public commonLayer: LayerBase;
    /**video操作层 */
    public videoLayer: LayerBase;
    /**弹出层*/
    public popLayer: LayerBase;
    /**tip层*/
    public tipLayer: LayerBase;
    /**特效层 */
    public effectLayer: LayerBase;
    /**消息层*/
    public messageLayer: LayerBase;

    private _bgModal: h5_engine.GShape;

    private _lockMask: h5_engine.GShape;

    private _bgModalAlpha: number;

    private _httpLoading: HttpLoading;

    constructor() {
        super();
        this.init();
        this.createChildren();
    }
    /** 视频操作层 */
    public showVideoLayer(show: boolean): void {
        this.videoLayer.visible = show;
        this.sceneLayer.visible = !show;
        this.mainLayer.visible = !show;
        this.specialMenuLayer.visible = !show;
        this.moduleLayer.visible = !show;
        this.commonLayer.visible = !show;
    }

    private init(): void {
        this.videoLoadingLayer = new LayerBase();
        this.sceneLayer = new LayerBase();
        this.sceneLayer.touchEnabled = false;
        this.sceneLayer.touchChildren = true;
        this.mainLayer = new LayerBase();
        this.mainLayer.touchEnabled = false;
        this.mainLayer.touchChildren = true;
        this.specialMenuLayer = new LayerBase();
        this.specialMenuLayer.touchEnabled = false;
        this.specialMenuLayer.touchChildren = true;
        this.moduleLayer = new LayerModule();
        this.moduleLayer.touchEnabled = false;
        this.moduleLayer.touchChildren = true;
        this.commonLayer = new LayerBase();
        this.commonLayer.touchEnabled = false;
        this.commonLayer.touchChildren = true;
        this.videoLayer = new LayerBase();
        this.videoLayer.touchEnabled = false;
        this.videoLayer.touchChildren = true;
        this.videoLayer.visible = false;
        this.popLayer = new LayerBase();
        this.popLayer.touchEnabled = false;
        this.popLayer.touchChildren = true;
        this.tipLayer = new LayerBase();
        this.tipLayer.touchEnabled = false;
        this.tipLayer.touchChildren = true;
        this.effectLayer = new LayerBase();
        this.messageLayer = new LayerBase();
        this.messageLayer.touchEnabled = false;
        this.messageLayer.touchChildren = false;
    }

    private createChildren(): void {
        this.addChild(this.videoLoadingLayer);
        this.addChild(this.sceneLayer);
        this.addChild(this.mainLayer);
        this.addChild(this.specialMenuLayer);
        this.addChild(this.moduleLayer);
        this.addChild(this.commonLayer);
        this.addChild(this.videoLayer);
        this.addChild(this.popLayer);
        this.addChild(this.tipLayer);
        this.addChild(this.effectLayer);
        this.addChild(this.messageLayer);
    }

    /**
     * 显示模态面板
     * @param pc 父容器
     * @param isAdd 是否是添加面板操作
     */
    public showModal(pc: egret.DisplayObjectContainer, modalAlpha: number, isAdd: boolean): void {
        if (this._bgModal == null) {
            this._bgModal = new h5_engine.GShape();
            this._bgModal.touchEnabled = true;
            this._bgModalAlpha = 0;
            this._bgModal.graphics.beginFill(0, 1);
            this._bgModal.graphics.drawRect(0, 0, 100, 100);
            this._bgModal.graphics.endFill();
            this._bgModal.alpha = this._bgModalAlpha;
        }
        this._bgModal.remove();
        if (isAdd)
            pc.addChild(this._bgModal);
        else
            pc.addChildAt(this._bgModal, pc.numChildren - 1);
        this.updateModal(modalAlpha);
        if (this._bgModal.hasEventListener(egret.TouchEvent.TOUCH_TAP) == false) {
            App.stage.addEventListener(egret.Event.RESIZE, this.onResize, this);
            this._bgModal.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchModal, this);
        }
    }
    private updateModal(modalAlpha: number = 0): void {
        if (this._bgModal && this._bgModal.parent) {
            if (modalAlpha == 0)
                modalAlpha = this._bgModalAlpha;
            this._bgModalAlpha = modalAlpha;
            this._bgModal.alpha = this._bgModalAlpha;
            if (App.layer.rotation != 0) {
                this._bgModal.scaleX = Config.SCREEN_HEIGHT * 0.01;
                this._bgModal.scaleY = Config.SCREEN_WIDTH * 0.01;
            }
            else {
                this._bgModal.scaleX = Config.SCREEN_WIDTH * 0.01;
                this._bgModal.scaleY = Config.SCREEN_HEIGHT * 0.01;
            }

        }
    }

    public showLockMask(): void {
        if (this._lockMask == null) {
            this._lockMask = new h5_engine.GShape();
            this._lockMask.graphics.beginFill(0, 0);
            this._lockMask.graphics.drawRect(0, 0, 100, 100);
            this._lockMask.graphics.endFill();
            this._lockMask.touchEnabled = true;
        }
        if (App.layer.rotation == 0) {
            this._lockMask.scaleX = Config.SCREEN_WIDTH * 0.01;
            this._lockMask.scaleY = Config.SCREEN_HEIGHT * 0.01;
        } else {
            this._lockMask.scaleX = Config.SCREEN_HEIGHT * 0.01;
            this._lockMask.scaleY = Config.SCREEN_WIDTH * 0.01;
        }
        this.commonLayer.addChild(this._lockMask);
    }

    public hideLockMask(): void {
        if (this._lockMask) {
            this._lockMask.remove();
        }
    }

    public hideModal(): void {
        if (this._bgModal && this._bgModal.parent) {
            this._bgModal.parent.removeChild(this._bgModal);
            App.stage.removeEventListener(egret.Event.RESIZE, this.onResize, this);
            this._bgModal.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchModal, this);
        }
    }

    private onTouchModal(e: egret.TouchEvent): void {
        PanelManager.removeModalPanel();
    }


    public showLoading(): void {
        if (this._httpLoading == null)
            this._httpLoading = new HttpLoading();
        this.popLayer.addChild(this._httpLoading);
        this._httpLoading.show();
    }

    public hideLoading(): void {
        if (this._httpLoading) {
            this._httpLoading.hide();
        }
    }

    private onResize(e: egret.Event): void {
        this.updateModal();
    }
}