class LayerModule extends LayerBase
{
    public _bgModal:h5_engine.GShape;

    public constructor()
    {
        super();
    }


    public showModal():void
    {
        if(this._bgModal==null)
        {
            this._bgModal=new h5_engine.GShape();
            this._bgModal.touchEnabled=true;
        }
        if(this._bgModal.parent==null)
        {
            this.addChild(this._bgModal);
            this.updateModal();
            App.stage.addEventListener(egret.Event.RESIZE,this.onResize,this);
            this._bgModal.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onTouchModal,this);
        }
    }
    private updateModal():void
    {
        if(this._bgModal&&this._bgModal.parent)
        {
            this._bgModal.graphics.clear();
            this._bgModal.graphics.beginFill(0,0.5);
            this._bgModal.graphics.drawRect(0,0,Config.SCREEN_WIDTH,Config.SCREEN_HEIGHT);
            this._bgModal.graphics.endFill();
        }
    }

    public hideModal():void
    {
        if(this._bgModal&&this._bgModal.parent)
        {
            this._bgModal.parent.removeChild(this._bgModal);
            App.stage.removeEventListener(egret.Event.RESIZE,this.onResize,this);
            this._bgModal.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onTouchModal,this);
        }
    }

    private onTouchModal(e:egret.TouchEvent):void
    {
        PanelManager.removeModalPanel();
    }

    private onResize(e:egret.Event):void
    {
        this.updateModal();
    }

}