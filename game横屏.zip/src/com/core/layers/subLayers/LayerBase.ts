class LayerBase extends h5_engine.GDisplayObjectContainer{
    constructor()
    {
        super();
    }
    
}