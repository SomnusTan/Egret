class LogicInterface extends h5_engine.LogicInterface{
	public constructor() {
		super();
		h5_engine.LogicInterface.instance = this;
		this.init();
	}

	private init():void
	{
		this._isCloseLog = WebParams.closeLog;
	}

	public log(... args):void 
	{
		if(this._isCloseLog) 
		{
			var str:string = this.getFormatLog(args);
			App.log.echo(str);
		}
	}

	public logError(... args):void {
		if(this._isCloseLog == false) {
			var info:string = args[0] + ">>: " + args[1];
			var str:string = this.getFormatLog(args);
			if(!this._errorHash[info]) 
			{
				this._errorHash[info] = info;
				// LogCommandSender.sendClientLogMessage(LogType.TYPE_GAME_ERROR, str);
				App.log.error(str);
			}
			// EventManager.dispatchEvent(LoginEvent.SHOW_INIT_GAME_PROGRESS, str);
			// if(Config.isDebug || Config.isRelease == false) {
			// 	Notice.showBottomMessage(str, 0xFFFF00);
			// }
		}
	}

	public logInfo(... args):void {
	}

	public logDebug(... args):void {
	}

	public logWarn(... args):void {
	}

	public logStack(... args):void {
	}

	public logXingneng(... args):void {
	}

	private getFormatLog(ary:any[]):string 
	{
		var str:string =  ary.join(' ');
		let da:Date = new Date();
		da.setTime(ServerTime.serverTime);
		var time:string = DateUtil.format(da);
		return "[" + time + "]>>: \r	" + str;
	}

	public static getLogStr(str:string):string 
	{
		// let msg:String = App.global.characterData ? App.global.characterData.name : "";
		let msg:String = "";
		let date:Date = new Date();
		date.setTime(ServerTime.serverTime);
		return "[" + ServerTime.serverTime + "," + DateUtil.format(date) + "]" + msg + ": " + str;
	}
		

	private _errorHash:Object = new Object();
	private _isCloseLog:boolean = false;
}