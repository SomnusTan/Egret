class LogType {
	public constructor() 
	{
	}

	/**
	 * 网络淤积包
	 */
	public static TYPE_NET_RESLOVE_MAX:number = 7;

	/**
	 * 网络包发送太多
	 */
	public static TYPE_NET_SEND_MAX:number = 15;

	/**
	 * 网络错误：
	 */
	public static TYPE_NET_ERROR:number = 16;

	/**
	 * 性能日志
	 */
	public static TYPE_XING_NENG:number = 13;

	/**
	 * 堆栈调用日志
	 */
	public static TYPE_STACK:number = 14;

	/**
	 * 游戏错误
	 */
	public static TYPE_GAME_ERROR:number = 3;
	/**
	 * 游戏登录部分错误
	 */
	public static TYPE_GAME_LOGIN_ERROR:number = 4;

	/**
	 * 面板加载错误
	 */
	public static TYPE_UI_LOAD_ERROR:number = 5;

	/**
	 * 游戏未知的不确定错误
	 */
	public static TYPE_UNKNOW_ERROR:number = 3;

	/**
	 * 登录部分的步骤跟错误
	 */
	public static TYPE_LOGIN_STEP:number = 50;
	/**
	 * 登录部分的创建显示
	 */
	public static TYPE_LOGIN_CREATE_SHOW:number = 51;
	/**
	 * 登录部分的创建进入
	 */
	public static TYPE_LOGIN_CREATE_START:number = 52;

	/**
	 * 切换地图加载耗时
	 */
	public static CHANGE_MAP_LOAD_USE_TIME:number = 6;

	/**
	 * 加载
	 */
	public static TYPE_LOAD_:number = 8;

	/**
	 * 使用技能
	 */
	public static TYPE_USE_SKILL:number = 9;
}