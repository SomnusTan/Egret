class FilterUtil {
    /**
	 * 变灰滤镜
	 */
	public static FILTER_GRAY: egret.Filter[] = [new egret.ColorMatrixFilter([
		0.3, 0.59, 0.11, 0, 0,
		0.3, 0.59, 0.11, 0, 0,
		0.3, 0.59, 0.11, 0, 0,
		0, 0, 0, 1, 0])];
    /**
	 * 变暗滤镜
	 */
	public static FILTER_DARK: egret.Filter[] = [new egret.ColorMatrixFilter([
		0.6, 0.3, 0.11, 0, 0,
		0.6, 0.3, 0.11, 0, 0,
		0.6, 0.3, 0.11, 0, 0,
		0, 0, 0, 1, 0])];
	/**
	 * 高亮滤镜 
	 */
	public static FILTER_HighLight: egret.Filter[] = [new egret.ColorMatrixFilter([
		1, 0, 0, 0, 50,
		0, 1, 0, 0, 50,
		0, 0, 1, 0, 50,
		0, 0, 0, 1, 0])];
	/**
	 * 反相滤镜 
	 */
	public static FILTER_RP: egret.Filter[] = [new egret.ColorMatrixFilter([-1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0])];
	/**
	 * 绿色中毒滤镜 
	 */
	public static FILTER_GREEN: egret.Filter[] = [new egret.ColorMatrixFilter([
		0, 0, 0, 0, 0,
		0, 1, 0, 0, 0,
		0, 0, 0, 0, 0,
		0, 0, 0, 1, 0
	])];

	// public static blur_filter: egret.BlurFilter = new egret.BlurFilter(8, 8, 1);

	/**
	* 通用描边滤镜
	*/
	public static GF_COMMON: egret.Filter[] = [new egret.GlowFilter(0xF9F609, 1, 6, 6, 20, 10, false, false)];
	/***
	 * 红色滤镜
	 */
	public static FILTER_RED: egret.Filter[] = [new egret.ColorMatrixFilter([
		1, 0, 0, 0, 0,
		0, 0, 0, 0, 0,
		0, 0, 0, 0, 0,
		0, 0, 0, 1, 0
	])];
	/***
	 * 蓝色滤镜 <冰冻>
	 */
	public static FILTER_BLUE: egret.Filter[] = [new egret.ColorMatrixFilter([
		0.01, 0.01, 0.01, 0, 0,
		0.24, 0.24, 0.24, 0, 0,
		0.3333, 0.3333, 0.3333, 0, 0,
		0, 0, 0, 1, 0,
	])];
	/***
* 紫色滤镜
*/
	public static FILTER_PURPLE: egret.Filter[] = [new egret.ColorMatrixFilter([
		0.4, 0.4, 0.4, 0, 0,
		0.2, 0.2, 0.2, 0, 0,
		0.4, 0.4, 0.4, 0, 0,
		0, 0, 0, 1, 0,
	])];

	/**
	 * 高亮滤镜
	 */
	public static HIGH_LIGHT_FILTER: egret.ColorMatrixFilter = new egret.ColorMatrixFilter(
		[
			1.6, 0, 0, 0, 0,
			0, 1.6, 0, 0, 0,
			0, 0, 1.6, 0, 0,
			0, 0, 0, 1, 0
		]);

	/**
	 * 模糊
	 */
	public static BLUR_FILTER: egret.BlurFilter = new egret.BlurFilter(4, 4, 1);
	public static blur_filter: egret.BlurFilter = new egret.BlurFilter(8, 8, 1);
	/**发光滤镜 */
	public static YELLOW_GLOW_FILTER: egret.GlowFilter[] = [new egret.GlowFilter(0xffff00, 1, 4, 4,2)];

	/**
	 * 通过品质获取模糊效果滤镜
	 */
	public static getBlurFilterByQuality(quality: number = 0): egret.BlurFilter {
		var blur: number = (quality + 1) * 4;
		if (this.BLUR_FILTER.blurX != blur) {
			this.BLUR_FILTER.blurX = this.BLUR_FILTER.blurY = blur;
		}
		return this.BLUR_FILTER;
	}

	/**
	* 获取一个颜色素质
	*  color
	*/
	public static getConfigColorMatrixFilter(color: number): egret.ColorMatrixFilter {
		let cmat: egret.ColorMatrixFilter = FilterUtil.configColorMatrixDict.get(color);
		if (!cmat) {
			cmat = ColorFilter.getColorMatrixFilterArrByColorUint(color);
			this.configColorMatrixDict.put(color, cmat);
		}
		return cmat;
	}

	public static getConfigAdjustColorMatrixFilter(brightness: number, contrast: number, hue: number, saturation: number): egret.ColorMatrixFilter {
		var adjust: String = brightness + "_" + contrast + "_" + hue + "_" + saturation;
		var adjustMat: egret.ColorMatrixFilter = FilterUtil.adjustColorMatrixDict.get(adjust) as egret.ColorMatrixFilter;
		if (adjustMat == null) {
			var adjustColor: h5_engine.AdjustColor = new h5_engine.AdjustColor();
			adjustColor.brightness = brightness;
			adjustColor.contrast = contrast;
			adjustColor.hue = hue;
			adjustColor.saturation = saturation;
			if (adjustColor.AllValuesAreSet()) {
				adjustMat = new egret.ColorMatrixFilter(adjustColor.CalculateFinalFlatArray());
				FilterUtil.adjustColorMatrixDict.put(adjust, adjustMat);
			}
		}
		return adjustMat;
	}

	/**
	 * 添加唯一颜色滤镜
	 * @param	target
	 * @param	filter
	 */
	public static addColorMatrixFilter(target: egret.DisplayObject, filter: egret.ColorMatrixFilter): void {
		var filters: any[] = target.filters || [];
		var tempFilter: egret.ColorMatrixFilter;
		for (var i: number = 0, len: number = filters.length; i < len; i++) {
			if (filters[i] instanceof egret.ColorMatrixFilter) {
				tempFilter = filters[i];
				if (tempFilter && tempFilter.matrix.toString() == filter.matrix.toString()) {
					return;
				}
			}
		}
		filters.push(filter);
		target.filters = filters;
	}

	/**
	 * 移除颜色滤镜
	 * @param	target
	 * @param	filter
	 */
	public static removeColorMatrixFilter(target: egret.DisplayObject, filter: egret.ColorMatrixFilter): void {
		var filters: any = target.filters || [];
		var tempFilter: egret.ColorMatrixFilter;
		for (var i: number = 0, len: number = filters.length; i < len; i++) {
			if (filters[i] instanceof egret.ColorMatrixFilter) {
				tempFilter = filters[i];
				if (tempFilter && tempFilter.matrix.toString() == filter.matrix.toString()) {
					filters.splice(i, 1);
					i--;
					len--;
				}
			}
		}
		target.filters = filters;
	}

	/**让显示对象变成灰色*/
	public static gray(traget: egret.DisplayObject, isGray: boolean = true): void {
		if (isGray) {
			this.addColorMatrixFilter(traget, this.grayFilter);
		} else {
			this.removeColorMatrixFilter(traget, this.grayFilter);
		}
	}
	private static grayFilter: egret.ColorMatrixFilter = new egret.ColorMatrixFilter([0.3086, 0.6094, 0.082, 0, 0, 0.3086, 0.6094, 0.082, 0, 0, 0.3086, 0.6094, 0.082, 0, 0, 0, 0, 0, 1, 0]);
	private static adjustColorMatrixDict: HashMap = new HashMap();
	private static configColorMatrixDict: HashMap = new HashMap();
}