/**
 * 呼吸灯效果
 */
class BreathEffect {
    /**目标对象 */
    private _target: egret.DisplayObject;
    /**关联的滤镜 */
    private _filter: egret.GlowFilter;
    /**滤镜颜色 */
    private _color: number = 0xFFFFFF;
    /**模糊量 */
    private _blur: number = 2;
    /**呼吸次数 */
    private _count: number;
    /**呼或吸 */
    private _toggle: boolean;

    public constructor() {

    }

    public init(target: egret.DisplayObject): void {
        if (this._target) {
            App.timer.clearTimer(this, this.onUpdate);
        }
        this._target = target;
    }

    /**
     * 开始呼吸
     * @param count 次数小于0为循环
     */
    public start(count: number = 0, color: number = 0xFFFFFF): void {
        this._count = count;
        this._color = color;
        this._blur = 2;
        if (this._filter == null)
            this._filter = new egret.GlowFilter(this._color, 1, this._blur, this._blur, 2, 2);
        else {
            this._filter.color = color;
            this._filter.blurX = this._filter.blurY = this._blur;
        }
        this._toggle = true;
        App.timer.doTimeLoop(this, 60, this.onUpdate);
    }

    /**
     * 停止呼吸
     */
    public stop(): void {
        App.timer.clearTimer(this, this.onUpdate);
    }

    /**
     * 释放
     */
    public dispose(): void {
        this.stop();
        if (this._target) {

            this._target.filters = null;
            this._target = null;
        }
        this._filter = null;
        ObjectPool.getPool(EnumEffectName.BreathEffect).push(this);
    }

    private onUpdate(): void {
        if (this._toggle)
            this._blur++;
        else
            this._blur--;
        if (this._blur >= 20) {
            this._toggle = false;
        }
        else if (this._blur <= 0) {
            this._toggle = true;
            this._count--;
        }
        this._filter.blurX = this._filter.blurY = this._blur;
        this._target.filters = [this._filter];
        if (this._count == 0) {
            this.stop();
        }
    }

    public get target(): egret.DisplayObject {
        return this._target;
    }
}