class ArrayUtils {
	public constructor() {
	}

	/**
	 * @ByteConversion          字节换算
	 * ================================
	 * @Byte                    字节
	 */
	public static arrayBufferToBase64(name, buffer) {
		// 初始化
		var binary = '';
		var mime_list = {
			gif: "image/gif", jpeg: "image/jpeg", jpg: "image/jpeg", png: "image/png",
			mp3: "audio/mpeg", ogg: "audio/ogg", m4a: "audio/x-m4a", mp4: "video/mp4"
		}
		// 后缀匹配
		var prg_name = /^.*[_\.](\w+)$/.exec(name);
		// 判断是否有后缀
		if (prg_name != null && mime_list.hasOwnProperty(prg_name[1])) {

			var bytes = new Uint8Array(buffer);
			var len = bytes.byteLength;
			for (var i = 0; i < len; i++) {
				binary += String.fromCharCode(bytes[i]);
			}
			// 返回bash64
			return "data:" + mime_list[prg_name[1]] + ";base64," + window.btoa(binary);
		} else {
			return false;
		}
	}




	/**
	 * @setCookie           设置Cookie
	 * ===============================
	 * @cname               Cookie键
	 * @cvalue              Cookie值
	 * @exdays              过期时间
	 */
	public static setCookie(cname, cvalue, exdays) {
		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		var expires = "expires=" + d.toUTCString();
		document.cookie = cname + "=" + cvalue + "; " + expires;
	}

	/**
	 * @PrefixInteger       字符串前填充
	 * ================================
	 * @num                 字符串
	 * @n                   填充到多少位
	 * @text                填充字符
	 */
	public static PrefixInteger(num, n, text = "0") {
		if (num.length < n) {
			return (Array(n).join(text) + num).slice(-n);
		} else {
			return num;
		}
	}

	/**
	 * @ByteConversion          字节换算
	 * ================================
	 * @Byte                    字节
	 */
	public static byteConversion(Byte) {
		// 初始化
		var size = "";
		// 小于0.1KB，则转化成B
		if (Byte < 0.1 * 1024) {
			size = Byte.toFixed(2) + "B"
			//小于0.1MB，则转化成KB
		} else if (Byte < 0.1 * 1024 * 1024) {
			size = (Byte / 1024).toFixed(2) + "KB"
			//小于0.1GB，则转化成MB
		} else if (Byte < 0.1 * 1024 * 1024 * 1024) {
			size = (Byte / (1024 * 1024)).toFixed(2) + "MB"
			//其他转化成GB
		} else {
			size = (Byte / (1024 * 1024 * 1024)).toFixed(2) + "GB"
		}
		// 转成字符串
		var sizeStr = size + "";
		// 获取小数点处的索引
		var index = sizeStr.indexOf(".");
		// 获取小数点后两位的值
		var dou = sizeStr.substr(index + 1, 2);
		//判断后两位是否为00，如果是则删除00
		if (dou == "00") {
			return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
		}
		return size;
	}

}