class ResponseUtil {

    /**
     * 验证返回的数据是否正常
     */
    public static checkResponseData(data: any, check202: boolean = false): boolean {
        if (data && Number(data["code"]) == 200) {
            return true;
        }
        if (check202 && data && Number(data["code"]) == 202) {//异地登录，回到登录界面
            App.global.clearRoleData();
            App.dispatcher.dispatchEvent(LoginEvent.RELOGIN);
        }
        return false;
    }
}