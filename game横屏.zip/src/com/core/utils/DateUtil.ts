class DateUtil {
	public constructor() {

	}

	/**
	 * 将一个整数的时间值格式化为00:00:00格式的时间值
	 *  time 秒数
	 */
	public static formatToTime(time: number): string {
		let second: number = Math.floor(time % 60);
		let minute: number = Math.floor(((time - second) / 60) % 60);
		let hour: number = Math.floor((time - 60 * minute - second) / 3600);
		let strSecond: string = second < 10 ? "0" + second.toString() : second.toString();
		let strMinute: string = minute < 10 ? "0" + minute.toString() : minute.toString();
		let strHour: string = hour < 10 ? "0" + hour.toString() : hour.toString();
		return strHour + ":" + strMinute + ":" + strSecond;
	}

	/**
	 * 将一个整数的时间值格式化为 00小时00分00秒 格式的时间值
	 * @param time 秒数
	 */
	public static formatToTime_V2(time: number, showHour: boolean = true): string {
		let second: number = Math.floor(time % 60);
		let minute: number = Math.floor(((time - second) / 60) % 60);
		let hour: number = Math.floor((time - 60 * minute - second) / 3600);
		let strMinute: string = minute == 0 ? "" : minute.toString() + "分";
		let strHour: string = hour == 0 ? "" : hour.toString() + "小时";
		if (showHour) {
			return strHour + strMinute + second + "秒";
		}
		return strMinute + second + "秒";
	}

	/**
	 * 将一个整数的时间值格式化为 00小时00分 格式的时间值
	 * time 秒数
	 */
	public static formatToTime_V3(time: number): string {
		let second: number = time % 60;
		let minute: number = ((time - second) / 60) % 60;
		let hour: number = (time - 60 * minute - second) / 3600;
		let strMinute: string = minute == 0 ? "" : minute.toString() + "分";
		let strHour: string = hour == 0 ? "" : hour.toString() + "小时";
		return strHour + strMinute;
	}

	/**
	 * 将一个整数的时间值格式化为 0天0小时0分 格式的时间值
	 * time 秒数
	 */
	public static formatToTime_V4(time: number): string {
		let tian: number = Math.floor(time / (24 * 3600));
		let hour: number = Math.floor(time % (24 * 3600) / 3600);
		let min: number = Math.floor(time % 3600 / 60);
		return tian + "天" + hour + "小时" + min + "分";
	}

	/**
	 * 将一个整数的时间值格式化为		大于1天：  xx天；	小于一天：  NN小时；	小于1小时：MM分钟；	小于1分钟：1分钟；
	 * time 秒数
	 */
	public static formatToTime_V5(time: number): string {
		let tian: number = Math.floor(time / (24 * 3600));
		let hour: number = Math.floor(time / 3600);
		let min: number = Math.floor(time % 3600 / 60);
		if (tian > 0) {
			return tian + "天"
		} else if (hour > 0) {
			return hour + "小时"
		} else if (min > 0) {
			return min + "分钟"
		} else {
			return "1分钟";
		}
	}

	/**
	 * 将一个整数的时间值格式化为 00分00秒 格式的时间值
	 * time 秒数
	 */
	public static formatToTime_V6(time: number): string {
		let second: number = time % 60;
		let minute: number = ((time - second) / 60) % 60;
		let hour: number = (time - 60 * minute - second) / 3600;
		let strSecond: string = second == 0 ? "" : second.toString() + "分";
		let strMinute: string = minute == 0 ? "" : minute.toString() + "分";
		return strMinute + strSecond;
	}

		/**
		 * 将一个UTC格式化为 00:00 格式的时间值
		 * @param time utc时间
		 * @return
		 */
	public static formatToTime_V7(utc:number):string {
			var date:Date = new Date(utc * 1000);
			var minute:number = date.getMinutes();
			var hour:number = date.getHours();
			var strMinute:string = minute == 0 ? "00" : minute.toString();
			var strHour:string = hour == 0 ? "00" : hour.toString();
			return strHour + ':' + strMinute;
		}

	/**
	 * 将一个整数的时间值格式化为 00:00 格式的时间值
	 * time 秒数
	 */
	public static formatToTime_V8(time: number): string {
		let second: number = Math.floor(time % 60);
		let minute: number = Math.floor(((time - second) / 60) % 60);
		let strSecond: string = second < 10 ? "0" + second.toString() : second.toString();
		let strMinute: string = minute < 10 ? "0" + minute.toString() : minute.toString();
		return strMinute + ":" + strSecond;
	}

	/**
	 * 获取当天最大的UTC时间
	 * @return  utc
	 */
	public static getTodayMaxUtc(): number {
		let date: Date = new Date(ServerTime.serverTime);
		date.setHours(23, 59, 59, 999);
		return Math.floor(date.getTime() * 0.001);
	}

	/**
	 * 格式化日期
	 * date	 日期，默认为当前日期
	 * formatStr 自定义样式，由 年-月-日 时:分:秒 组成，不需要显示哪个，就去掉哪个字母
	 */
	public static format(date: Date = undefined, formatStr: string = "年-月-日 时:分:秒"): string {
		if (!date)
			date = new Date();
		let year: string = date.getFullYear().toString();
		let month: string = (date.getMonth() + 1).toString();
		let day: string = date.getDate().toString();
		let hours: string = ((date.getHours() > 9) ? "" : "0") + date.getHours();
		let minutes: string = ((date.getMinutes() > 9) ? "" : "0") + date.getMinutes();
		let seconds: string = ((date.getSeconds() > 9) ? "" : "0") + date.getSeconds();
		return formatStr.replace("年", year).replace("月", month).replace("日", day).replace("时", hours).replace("分", minutes).replace("秒", seconds);
	}

	/**
		 * 解析时间(年月日时分)
		 * 1970年1月1日10:20
		 * @param time
		 * @return
		 *
		 */
	public static formatTimeToMin2(time: number): string {
		//发过来的时间是距离1970年1月1日的秒数，因此用DATE的格式化需要乘上1000
		let t: string = "";
		let d: Date = new Date(time * 1000);
		t = d.getFullYear() + "年" + (d.getMonth() + 1) + "月" + d.getDate() + "日" + (d.getHours() < 10 ? "0"
			+ d.getHours() : "" + d.getHours()) + ":" + (d.getMinutes() < 10 ? "0" + d.getMinutes() : "" + d.getMinutes());
		return t;
	}
}