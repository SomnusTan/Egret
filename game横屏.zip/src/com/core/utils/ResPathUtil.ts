class ResPathUtil {
	public constructor() {
	}

	public static getCommonImageRes(name: string, suffix: string = ".png"): string {
		return ResPathUtil.getVersionUrl("assets/base/image/" + name + suffix);
	}

	/**
	 * 获取通用资源
	 */
	public static getCommonRes(pack: string, name: string, suffix: string = ".png"): string {
		return ResPathUtil.getVersionUrl("assets/base/" + (pack ? pack + "/" : "") + name + suffix);
	}

	/**
	 * 本地视频路径
	 */
	public static getCommonVideoRes(name: string): string {
		return ResPathUtil.getVersionUrl("assets/base/video/" + name);
	}

	/**
	 * 游戏女主资源
	 */
	public static getGameRes(pack: string, base: string): string {
		return Config.RESOURCE_PATH + "game/" + pack + "/" + base;
	}

	/**
	 * 游戏女主资源(不加版本号)
	 */
	public static getGameResNoVer(version: string, base: string): string {
		return ResPathUtil.getVersionUrl(version + "/" + base);
	}

	/**
	 * 开始游戏动画资源
	 */
	public static getOpeningVideoRes(): string {
		return ResPathUtil.getCommonVideoRes("z6_1.mp4");
	}

	/**
	 * 获取通用资源res路径
	 * @param pack
	 * @param name
	 * @param suffix
	 * @return
	 *
	 */
	public static getCommonIconRes(pack: string, name: string): string {
		var url: string = "assets/common/" + pack + "/" + name;
		return ResPathUtil.getVersionUrl(url);
	}

	/**
	 * 获取心动一音效
	 */
	public static getSoundPath1(id: string): string {
		var path: string = "assets/game2/assets/xindong/music/" + id + ".mp3";
		return ResPathUtil.getVersionUrl(path);
	}

	/**
	 * 获取音效
	 */
	public static getSoundPath(id: string, pack: string = "base"): string {
		var path: string = "assets/" + pack + "/music/sound/" + id + ".mp3";
		return ResPathUtil.getVersionUrl(path);
	}

	/**
	 * 获取背景音乐
	 */
	public static getBgmPath(id: string, pack: string = "base"): string {
		var path: string = "assets/" + pack + "/music/bgm/" + id + ".mp3";
		return ResPathUtil.getVersionUrl(path);
	}

	/**
	 * 获得版本号处理后的资源
	 * @param url
	 * @return
	 */
	public static getVersionUrl(url: string): string {
		// if (DeviceUtil.IsWeb) {
		// 	return RES.getVersionController().getVirtualUrl(Config.RESOURCE_PATH + url) + "?v=" + Config.version
		// }
		// else {
			return RES.getVersionController().getVirtualUrl(Config.RESOURCE_PATH + url);
		// }
	}

}