class DeviceUtil {
    /**
     * 环境 1:安卓, 2:苹果, 3:web, 4:wap手机网页, 5: 测试 6:PC
     */
    public static get currentSetting(): number {
        if (Config.isRelease == false) return 5;
        if (DeviceUtil.IsAndroid && DeviceUtil.IsWeb) return 4;
        if (DeviceUtil.IsIos && DeviceUtil.IsWeb) return 4;
        if (DeviceUtil.IsAndroid) return 1;
        if (DeviceUtil.IsIos) return 2;
        if (Config.isLocalApp) return 6;
        if (DeviceUtil.IsWeb) return 3;
        return 5;
    }
    /**
     * 支付渠道 alipay:支付宝, soeasy: SoEasy, wechat: 微信, 360: "360"
     * <font color="#FF0000">type 1:微信, 2:支付宝</font>
     */
    public static getPayType(type: number = 0): string {
        // if (Config.isRelease == false) return "1";
        if (this.IsAndroid && Config.U8Login) return "u8";
        if (Config.isGZSnow) return "ice_snow";
        if (this.IsIos && this.IsNative) return "ios";
        if (Config.isLocalApp) return "steam";
        if (Config.soEasy) return "soeasy";
        if (H5_360_Sdk.getInstance().config360) return "360";
        if (type == 1) return "wechat";
        return "alipay";
    }

    /**
     * 是否在IOS移动网页端
     */
    public static get isWebIOS(): boolean {
        return this.IsWeb && this.IsIos;
    }

    /**
     * runtimeType 运行在web上
     */
    public static get IsWeb() {
        return (egret.Capabilities.runtimeType == egret.RuntimeType.WEB);
    }

    /**runtimeType 运行在native上*/
    public static get IsNative() {
        return (egret.Capabilities.runtimeType == egret.RuntimeType.RUNTIME2 ||
            egret.Capabilities.runtimeType == egret.RuntimeType.NATIVE);
    }

    /**是否移动端 */
    public static get isMobile() {
        return egret.Capabilities.isMobile;
    }

    /**是否ios系统 */
    public static get IsIos() {
        return (egret.Capabilities.os == "iOS" || egret.Capabilities.os == "Mac OS")
    }

    /**是否android系统 */
    public static get IsAndroid() {
        return (egret.Capabilities.os == "Android")
    }

    /**是否ipad */
    public static get IsIpad() {
        if (navigator.userAgent.indexOf("iPad") != -1) {
            return true;
        }
        return false;
    }

    //是否iphoneX
    public static get isIPhoneX() {
        let rate = egret.Capabilities.boundingClientWidth / egret.Capabilities.boundingClientHeight;
        if (rate >= 2) {
            return true;
        }
        return false;
    }

    /**
     * 是否微信浏览器
     */
    public static get isWeiXinBrowser(): boolean {
        if (this.IsWeb) {
            var ua = navigator.userAgent.toLowerCase();
            return /micromessenger/.test(ua);
        }
        return false;
    }

    /**
     * 是否微博浏览器
     */
    public static get isWeiBoBrowser(): boolean {
        if (this.IsWeb) {
            var ua = navigator.userAgent.toLowerCase();
            return /weibo/.test(ua);
        }
        return false;
    }

    /**
     * 是否手机QQ内置浏览器
     */
    public static get isQQInBrowser(): boolean {
        if (this.IsWeb) {
            var ua = navigator.userAgent.toLowerCase();
            return (DeviceUtil.IsIos && / qq/.test(ua) && /mqqbrowser/.test(ua) == false) || (DeviceUtil.IsAndroid && /mqqbrowser/.test(ua) && /qq/i.test(ua.split("mqqbrowser")[1]));
        }
        return false;
    }

    /**是否QQ浏览器 */
    public static get ISQQBrower() {
        if (this.IsWeb) {
            var ua = navigator.userAgent.toLowerCase();
            return (DeviceUtil.IsIos && / qq/.test(ua) == false && /mqqbrowser/.test(ua)) || (DeviceUtil.IsAndroid && /mqqbrowser/.test(ua) && /qq/i.test(ua.split("mqqbrowser")[1]) == false);
        }
        return false;
    }

    /**是否UC浏览器 */
    public static get IsUCBrowser() {
        if (this.IsWeb && navigator.userAgent.indexOf('UCBrowser') > -1) {
            return true;
        }
        return false;
    }

    public static get isSogouBrowser() {
        var ua = navigator.userAgent.toLowerCase();
        if (this.IsWeb && /sogoumobilebrowser/.test(ua)) {
            return true;
        }
    }

    /**
     * 是否IE浏览器
     */
    public static get isIEBrowser(): boolean {
        if (this.IsWeb && (!!window["ActiveXObject"] || "ActiveXObject" in window)) {
            return true;
        }
        return false;
    }

    /**
     * 是否百度浏览器
     */
    public static get isBaiduBrowser(): boolean {
        var ua = navigator.userAgent.toLowerCase();
        if (this.IsWeb && /baidubrowser/.test(ua)) {
            return true;
        }
        return false;
    }

    /**
     * 是否微信小游戏
     */
    public static get isWxGame(): boolean {
        return egret.Capabilities.runtimeType == egret.RuntimeType.WXGAME;
    }
}