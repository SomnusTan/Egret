class ItemFlyEffect {
	public constructor() {
	}
	/** 
	 * 碎片飞的动效
	 */
	public static flySuiPian(len: number, startP: egret.Point, endP: egret.Point): void {
		let sx: number = startP.x;
		let sy: number = startP.y;
		let tx: number = endP.x;
		let ty: number = endP.y;
		var icon: eui.Image;
		let delay: number = 0;
		for (var i: number = 0; i < len; i++) {
			icon = new eui.Image();
			icon.source = "gamehall_json.gamehall_suipian";
			icon.anchorOffsetX = icon.anchorOffsetY = 33;
			App.layer.commonLayer.addChildAt(icon, 0);
			delay += 300;
			egret.Tween.get(icon).set({ x: sx + icon.anchorOffsetX, y: sy + icon.anchorOffsetY }).to({ x: tx, y: ty }, delay, egret.Ease.sineOut).call(this.onTweenOver, this, [icon]);
		}
	}

	private static onTweenOver(icon: eui.Image) {
		egret.Tween.removeTweens(icon);
		if (icon instanceof eui.Image) {
			(icon as eui.Image).source = null;
		}
		if (icon.parent) {
			icon.parent.removeChild(icon);
		}
	}

	public static fly(target: eui.Image, startP: egret.Point, endP: egret.Point): void {
		App.layer.commonLayer.addChildAt(target, 0);
		egret.Tween.get(target).set({ x: startP.x, y: startP.y }).to({ x: endP.x, y: endP.y }, 1000, egret.Ease.sineOut).call(this.onTweenOver, this, [target]);
	}

}