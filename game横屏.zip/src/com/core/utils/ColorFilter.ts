class ColorFilter {
	public constructor() {
	}

	public static getColorMatrixFilterArrByColorUint(color:number) : egret.ColorMatrixFilter
	{
		let tag:number = 255;
		let b:number = (color & tag) / 255;
		let g:number = (color >> 8 & tag) / 255;
		let r:number = (color >> 16 & tag) / 255;
		let a:number = (color >> 24 & tag) / 255;
		return new egret.ColorMatrixFilter([r,0,0,0,0,0,g,0,0,0,0,0,b,0,0,0,0,0,a,0]);
	}
      
	public static getColorMatrixFilterArrByColorString(color:string) : egret.ColorMatrixFilter
	{
		let colorUint:number = parseInt(color,16);
		return this.getColorMatrixFilterArrByColorUint(colorUint);
	}
      
	public static getColorMatrix(arr:any[]) : egret.Filter[]
	{
		let lightness:egret.ColorMatrixFilter = null;
		let val2:number = NaN;
		let contrast:egret.ColorMatrixFilter = null;
		let red:number = NaN;
		let green:number = NaN;
		let blue:number = NaN;
		let saturation:egret.ColorMatrixFilter = null;
		let cosVal:number = NaN;
		let sinVal:number = NaN;
		let lumR:number = NaN;
		let lumG:number = NaN;
		let lumB:number = NaN;
		let hue:egret.ColorMatrixFilter = null;
		let filterArr:egret.Filter[] = [];
		let val:number = arr[0];
		if(val != 0)
		{
			val = val * 2.55;
			lightness = new egret.ColorMatrixFilter([1,0,0,0,val,0,1,0,0,val,0,0,1,0,val,0,0,0,1,0]);
			filterArr.push(lightness);
		}
		val = arr[1];
		if(val != 1)
		{
			val = (val + 100) / 100;
			val2 = 128 * (1 - val);
			contrast = new egret.ColorMatrixFilter([val,0,0,0,val2,0,val,0,0,val2,0,0,val,0,val2,0,0,0,1,0]);
			filterArr.push(contrast);
		}
		val = arr[2];
		if(val != 1)
		{
			val = (val + 100) / 100;
			red = 0.3086 * (1 - val);
			green = 0.6094 * (1 - val);
			blue = 0.082 * (1 - val);
			saturation = new egret.ColorMatrixFilter([red + val,green,blue,0,0,red,green + val,blue,0,0,red,green,blue + val,0,0,0,0,0,1,0]);
			filterArr.push(saturation);
		}
		val = arr[3];
		if(val != 0)
		{
			val = val * 1.8;
			val = Math.min(180,Math.max(-180,val)) / 180 * Math.PI;
			cosVal = Math.cos(val);
			sinVal = Math.sin(val);
			lumR = 0.213;
			lumG = 0.715;
			lumB = 0.072;
			hue = new egret.ColorMatrixFilter([lumR + cosVal * (1 - lumR) + sinVal * -lumR,lumG + cosVal * -lumG + sinVal * -lumG,lumB + cosVal * -lumB + sinVal * (1 - lumB),0,0,lumR + cosVal * -lumR + sinVal * 0.143,lumG + cosVal * (1 - lumG) + sinVal * 0.14,lumB + cosVal * -lumB + sinVal * -0.283,0,0,lumR + cosVal * -lumR + sinVal * -(1 - lumR),lumG + cosVal * -lumG + sinVal * lumG,lumB + cosVal * (1 - lumB) + sinVal * lumB,0,0,0,0,0,1,0]);
			filterArr.push(hue);
		}
		return filterArr;
	}
}