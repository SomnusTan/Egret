/**点击效果绑定 */
class TouchEffectBinder {

    private _bindHash: HashMap;

    private _target: egret.DisplayObject;

    public constructor() {
        this.init();
    }

    private init(): void {
        this._bindHash = new HashMap();

    }

    private onTouchBegin(e: egret.TouchEvent): void {
        App.stage.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this);
        this._target = e.currentTarget;
        var effectType: string = this._bindHash.get(this._target);
        switch (effectType) {
            case EnumTouchEffect.ADD_SCALE:
                this._target.scaleX = this._target.scaleY = 1.1;
                break;
            case EnumTouchEffect.MIN_SCALE:
                // this._target.anchorOffsetX = this._target.width >> 1;
                // this._target.anchorOffsetY = this._target.height >> 1;
                this._target.scaleX = this._target.scaleY = 0.8;
                break;
            case EnumTouchEffect.ALPHA:
                this._target.alpha = 0.8;
                break;
        }
    }

    private onTouchEnd(e: egret.TouchEvent): void {
        App.stage.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this);
        if (this._target) {
            var effectType: string = this._bindHash.get(this._target);
            this.resetTarget(effectType);
            this._target = null;
        }
    }

    private resetTarget(effectType: string) {
        if (this._target == null)
            return;
        switch (effectType) {
            case EnumTouchEffect.ADD_SCALE:
            case EnumTouchEffect.MIN_SCALE:
                this._target.scaleX = this._target.scaleY = 1;
                break;
            case EnumTouchEffect.ALPHA:
                this._target.alpha = 1;
                break;
        }
    }


    /**
     * 动效绑定
     */
    public bind(target: egret.DisplayObject, effectType: string): void {
        if (target) {
            if (this._bindHash.has(target) == false)
                target.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this);
            this._bindHash.put(target, effectType);
        }
    }

    /**
     * 动效解绑
     */
    public unbind(target: egret.DisplayObject): void {
        if (target && this._bindHash.has(target)) {
            if (this._target == target) {
                var effectType: string = this._bindHash.get(target)
                App.stage.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this);
                this.resetTarget(effectType);
                this._target = null;
            }
            this._bindHash.remove(target);
            target.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this);
        }
    }

    public unBindAll(): void {
        if (this._bindHash) {

            var targetList: any[] = this._bindHash.keys;
            var target: egret.DisplayObject;
            var effectType: string;
            for (var i: number = 0, len: number = targetList.length; i < len; i++) {
                target = targetList[i];
                if (target == this._target) {
                    effectType = this._bindHash.get(target);
                    this.resetTarget(effectType);
                }
                target.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this);
            }
            App.stage.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this);
            this._bindHash.clear();
        }
        this._target = null;
    }

    public dispose() {
        this.unBindAll();
        this._bindHash = null;
    }
}