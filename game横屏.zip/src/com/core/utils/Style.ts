class Style {
    
	// public static FONT:string = "fzyc";
	public static FONT:string = "fzyc";

	public static SIZE:number = 20;

	public static stroke:number = 1;

	public static strokeColor:number = 0x0;
}