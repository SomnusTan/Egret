class InputTextUtil {

    private static _target: eui.TextInput;

    private static _lastText: string;

    /**
     * 增加文本侦听
     */
    public static addNativeInputTextListener(txt: eui.TextInput): void {
        if (/*DeviceUtil.IsIos && */DeviceUtil.IsNative) {
            txt.textDisplay.addEventListener(egret.FocusEvent.FOCUS_IN, this.onFocusIn, this);
            txt.textDisplay.addEventListener(egret.FocusEvent.FOCUS_OUT, this.onFocusOut, this);
        }
    }

    /**
     * 移除文本侦听
     */
    public static removeNativeInputTextListener(txt: eui.TextInput): void {
        if (/*DeviceUtil.IsIos && */DeviceUtil.IsNative) {
            txt.textDisplay.removeEventListener(egret.FocusEvent.FOCUS_IN, this.onFocusIn, this);
            txt.textDisplay.removeEventListener(egret.FocusEvent.FOCUS_OUT, this.onFocusOut, this);
        }
    }

    /**
     * 改变输入文本
     */
    public static updateNativeText(text: string): void {
        if (InputTextUtil._target && InputTextUtil._target["textTemp"]) {
            if (text != "") {
                InputTextUtil._target["textTemp"].text = text;
                InputTextUtil._lastText = text;
            }
            else {
                InputTextUtil._target["textTemp"].text = " ";
                InputTextUtil._lastText = text;
                App.timer.doFrameOnce(InputTextUtil, 1, InputTextUtil.resetText, [InputTextUtil._target["textTemp"], ""]);
            }
        }
    }

    private static onFocusIn(e: egret.FocusEvent): void {
        if (e.currentTarget.parent instanceof eui.TextInput) {
            this._target = e.currentTarget.parent;
            this._target["textTemp"].visible = true;
            this._target.textDisplay.alpha = 0;
            if (DeviceUtil.IsIos) {
                if (this._target.textDisplay.text == "　") {
                    this._target.textDisplay.text = "";
                    App.timer.clearTimer(this, this.resetText);
                }
            }
        }
    }

    private static onFocusOut(e: egret.FocusEvent): void {
        if (e.currentTarget.parent == this._target && this._target["textTemp"]) {
            this._target["textTemp"].visible = false;
            this._target.textDisplay.alpha = 1;
            if (DeviceUtil.IsIos) {
                if (this._target.textDisplay.text == "") {
                    this._target.textDisplay.text = "　";//　这里有个空格
                    App.timer.doFrameOnce(this, 1, this.resetText, [this._target, ""]);
                }
            }
            else {
                if (this._lastText == "") {
                    this._target.text = " ";
                    App.timer.doFrameOnce(this, 1, this.resetText, [this._target, ""]);
                }
                else if (this._lastText != this._target.text) {
                    App.timer.doFrameOnce(this, 1, this.resetText, [this._target, this._lastText]);
                    this._target.text = this._lastText;
                }
            }
            this._lastText = null;
            this._target = null;
        }
    }

    public static resetText(txt: eui.TextInput | eui.Label, text: string): void {
        if (txt instanceof eui.TextInput) {
            txt.textDisplay.text = text;
            txt.invalidateState();
        }
        else {
            txt.text = text;
        }
    }
}