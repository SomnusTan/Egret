class ImageEffectUtil {

    /**
     * 停止所有效果
     */
    public static stopAllEffect(target?:egret.DisplayObject):void{
        this.stopClock();
    }

    /**
     * 两张图片交换显示
     * @param 当前图片
     * @param 下一张图片
     */
    public static changeImage(curImage: eui.Image, nextImage: eui.Image, time: number = 1000): void {
        egret.Tween.removeTweens(curImage);
        egret.Tween.removeTweens(nextImage);
        egret.Tween.get(curImage).set({ alpha: 1 }).to({ alpha: 0 }, time);
        egret.Tween.get(nextImage).set({ alpha: 0 }).to({ alpha: 0 }, time);
    }

    /**
     * 淡出
     * @param target 目标
     * @param time 时间
     * @param endRemove 结束是否移除显示列表
     */
    public static fadeOut(target: egret.DisplayObject, time: number = 1000, endRemove: boolean = false): void {
        egret.Tween.removeTweens(target);
        // egret.Tween.get(target).set({ alpha: 1 }).to({ alpha: 0 }, time);
        egret.Tween.get(target).to({ alpha: 0 }, time);
        if (endRemove)
            egret.Tween.get(target).call(() => {
                if (target.parent)
                    target.parent.removeChild(target);
            }, this)
    }

    /**
     * 淡入
     */
    public static fadeIn(target: egret.DisplayObject, time: number = 1000, waitTime: number = 0): void {
        egret.Tween.removeTweens(target);
        // egret.Tween.get(target).set({ alpha: 0 }).to({ alpha: 1 }, time);
        egret.Tween.get(target).wait(waitTime).to({ alpha: 1 }, time);
    }

    /**
     * 移动
     * @param target
     * @param x
     * @param y
     * @param type 移动类型 0:匀速 1:加速 2:减速
     * @param time
     */
    public static move(target: egret.DisplayObject, x: number, y: number = undefined, type: number = 0, time: number = 1000): void {
        egret.Tween.removeTweens(target);
        var targetObj: any = {};
        if (x != undefined)
            targetObj.x = x;
        if (y != undefined)
            targetObj.y = y;
        var ease: Function = undefined;
        if (type == 1)
            ease = egret.Ease.cubicIn;
        else if (type == 2)
            ease = egret.Ease.cubicOut;
        egret.Tween.get(target).to(targetObj, time);
    }

    /**
     * 旋转
     * @param target 对象
     * @param count 总圈数
     * @param isPlus 是否正旋转
     * @param speed 每圈耗时
     */
    public static rotate(target: egret.DisplayObject, count: number = 1, isPlus: boolean = true, speed: number = 500): void {
        if (count <= 0)
            count = 1;
        if (speed <= 100)
            speed = 100;
        egret.Tween.get(target).set({ rotation: 0 }).to({ rotation: count * 360 * (isPlus ? 1 : -1) })
    }

    private static _clockMask: egret.Shape;
    private static _clockInObj: any;
    private static _clockOutObj: any;

    /**
     * 时钟切出
     * @param target
     * @param speed
     * @param isRightDir 是否顺时针方向
     * @param showInTarget 播放完切出后播放切入的对象,无则不播放
     */
    public static clockOut(target: egret.DisplayObject, speed: number = 600, isRightDir: boolean = true, showInTarget: egret.DisplayObject = null): void {
        if (this._clockMask == null) {
            this._clockMask = new egret.Shape();
        }
        if (this._clockOutObj == null) {
            this._clockOutObj = {};
        }
        var radius: number = Math.ceil(Math.sqrt(target.width * target.width + target.height * target.height)) >> 1;
        target.parent.addChild(this._clockMask);
        // this._clockMask.x = target.x + (target.width >> 1);
        // this._clockMask.y = target.y + (target.height >> 1);
        this._clockMask.x = Config.SCREEN_WIDTH >> 1
        this._clockMask.y = Config.SCREEN_HEIGHT >> 1;
        this._clockOutObj.angle = 0;
        this._clockOutObj.radius = radius;
        this._clockOutObj.target = target;
        this._clockOutObj.showInTarget = showInTarget;
        this._clockOutObj.showInTime = speed;
        egret.Tween.get(this._clockOutObj, { onChange: this.onChangeClockOut, onChangeObj: this }).to({ angle: 360 }, speed, egret.Ease.sineIn).call(this.onCompleteClock, this, [this._clockOutObj]);
        this.updateClockMask(radius, true, 0);
    }

    /**
     * 时钟切入
     * @param target
     * @param speed
     * @param waitTime 等待时间
     * @param isRightDir 是否顺时针方向
     */
    public static clockIn(target: egret.DisplayObject, speed: number = 600, waitTime: number = 0, isRightDir: boolean = true): void {
        if (this._clockMask == null) {
            this._clockMask = new egret.Shape();
        }
        if (this._clockInObj == null) {
            this._clockInObj = {};
        }
        var radius: number = Math.ceil(Math.sqrt(target.width * target.width + target.height * target.height)) >> 1;
        target.parent.addChild(this._clockMask);
        // this._clockMask.x = target.x + (target.width >> 1);
        // this._clockMask.y = target.y + (target.height >> 1);
        this._clockMask.x = Config.SCREEN_WIDTH >> 1
        this._clockMask.y = Config.SCREEN_HEIGHT >> 1;
        this._clockInObj.angle = 359;
        this._clockInObj.radius = radius;
        this._clockInObj.target = target;
        egret.Tween.get(this._clockInObj, { onChange: this.onChangeClockIn, onChangeObj: this }).to({ angle: 1 }, speed, egret.Ease.sineIn).call(this.onCompleteClock, this, [this._clockInObj]);
        this.updateClockMask(radius, true, 359);
    }

    /**
     * 停止时钟动画
     */
    public static stopClock(clockObj?: any): void {
        if (clockObj) {
            if (clockObj && clockObj.target) {
                egret.Tween.removeTweens(clockObj);
                clockObj.target = null;
                if (this._clockMask && this._clockMask.parent) {
                    this._clockMask.parent.removeChild(this._clockMask);
                }
                if (clockObj.showInTarget) {
                    this.clockIn(clockObj.showInTarget, clockObj.showInTime);
                    clockObj.showInTarget = null;
                }
            }
        } else {
            if (this._clockInObj && this._clockInObj.target) {
                egret.Tween.removeTweens(this._clockInObj);
                this._clockInObj.target.alpha = 0;
                this._clockInObj.target = null;
                if (this._clockMask && this._clockMask.parent) {
                    this._clockMask.parent.removeChild(this._clockMask);
                }
            }
            if (this._clockOutObj && this._clockOutObj.target) {
                egret.Tween.removeTweens(this._clockOutObj);
                this._clockOutObj.target = null;
                if (this._clockMask && this._clockMask.parent) {
                    this._clockMask.parent.removeChild(this._clockMask);
                }
            }
        }
    }

    private static onChangeClockOut(): void {
        this.updateClockMask(this._clockOutObj.radius, true, Math.floor(this._clockOutObj.angle));
    }

    private static onChangeClockIn(): void {
        this.updateClockMask(this._clockInObj.radius, true, Math.floor(this._clockInObj.angle));
    }

    private static onCompleteClock(clockObj: any): void {
        this.stopClock(clockObj);
    }

    /**
     * 
     */
    private static updateClockMask(radius: number, isRightDir: boolean, angle: number, x: number = 0, y: number = 0, startFrom: number = 270, color = 0): void {
        GameLog.log('==>', angle, startFrom);
        this._clockMask.graphics.clear();
        this._clockMask.graphics.lineStyle(0, color);
        this._clockMask.graphics.beginFill(color);
        this._clockMask.graphics.moveTo(x, y);
        angle = (Math.abs(angle) > 360) ? 360 : angle;
        var n: number = Math.ceil(Math.abs(angle) / 45);
        var angleA: number = angle / n;
        angleA = angleA * Math.PI / 180;
        startFrom = startFrom * Math.PI / 180;
        this._clockMask.graphics.lineTo(x + radius * Math.cos(startFrom), y + radius * Math.sin(startFrom));
        var angleMid: number, bx: number, by: number, cx: number, cy: number;
        for (var i = 1; i <= n; i++) {
            startFrom += angleA;
            angleMid = startFrom - angleA / 2;
            bx = x + radius / Math.cos(angleA / 2) * Math.cos(angleMid);
            by = y + radius / Math.cos(angleA / 2) * Math.sin(angleMid);
            cx = x + radius * Math.cos(startFrom);
            cy = y + radius * Math.sin(startFrom);
            this._clockMask.graphics.curveTo(bx, by, cx, cy);
        }
        if (angle != 360) {
            this._clockMask.graphics.lineTo(x, y);
        }
        this._clockMask.graphics.endFill();// if you want a sector without filling color , please remove this line.
    }

    /**
     * 抖动
     */
    // public static shake(target: egret.DisplayObject): void {
    //     egret.Tween.get(target).to({ x: target.x + 20, y: target.y + 20 }, 100, egret.Ease.bounceOut)
    //         .to({ x: target.x - 20, y: target.y - 20 }, 100, egret.Ease.bounceIn)
    //         .to({ x: target.x + 20, y: target.y + 20 }, 100, egret.Ease.bounceOut)
    //         .to({ x: target.x - 20, y: target.y - 20 }, 100, egret.Ease.bounceIn)
    //         .to({ x: target.x + 20, y: target.y + 20 }, 100, egret.Ease.bounceOut)
    //         .to({ x: target.x - 20, y: target.y - 20 }, 100, egret.Ease.bounceIn);
    // }

    /**是否抖动中 */
    private static isShake: Boolean = false;
    /**抖动次数 */
    private static shakeNum: number = 0;

    /**
     * 抖动
     */
    public static shakeTween(target: egret.DisplayObject, times: number = 2, offset: number = 4, speed: number = 32): void {
        if (this.isShake) {
            return;
        }
        this.isShake = true;
        var offsetXYArray: any[] = [0, 0];
        App.timer.doTimeLoop(this, speed, this.onUpdateShake, [target, target.x, target.y, offsetXYArray, offset, times]);
    }

    private static onUpdateShake(target: egret.DisplayObject, x: number, y: number, offsetXYArray: any[], offset: number, times: number): void {
        offsetXYArray[this.shakeNum % 2] = (this.shakeNum++) % 4 < 2 ? 0 : offset;
        if (this.shakeNum > (times * 4 + 1)) {
            App.timer.clearTimer(this, this.onUpdateShake);
            this.shakeNum = 0;
            this.isShake = false;
        }
        target.x = offsetXYArray[0] + x;
        target.y = offsetXYArray[1] + y;
    }

    /**呼吸灯列表 */
    private static _breathHash: HashMap = new HashMap();

    /**
     * 开始呼吸灯效果(注意,使用滤镜实现,会把对象原滤镜替换掉)
     * @param target
     * @param count 呼吸次数 小于0循环播放
     */
    public static startBreath(target: egret.DisplayObject, count: number = -1, color: number = 0xFFFFFF): void {
        if (target == null)
            return;
        var breathEffect: BreathEffect;
        if (this._breathHash.has(target)) {
            breathEffect = this._breathHash.get(target);
        }
        else {
            breathEffect = ObjectPool.getObject(EnumEffectName.BreathEffect);
            this._breathHash.put(target, breathEffect);
        }
        breathEffect.init(target);
        breathEffect.start(count, color);
    }

    /**
     * 停止呼吸灯效果
     */
    public static stopBreath(target: egret.DisplayObject, dispose: boolean = true): void {
        if (target == null)
            return;
        if (this._breathHash.has(target)) {
            var breathEffect: BreathEffect = this._breathHash.get(target);
            if (dispose)
                breathEffect.dispose();
            else
                breathEffect.stop();
        }
    }

}