class StringUtil {
	public constructor() {
	}
	// /** 数值，保留小数位数，万分比填100 */
	// public formatNumToFixNum(value: number, fix: number, rate: number = 100): number {
	// 	var bit: number = rate.toString().length - 1;
	// 	var hasFix: number = 0;
	// 	for (var i: number = bit; i > 0; i--) {
	// 		if (value % Math.pow(10, i) == 0) {
	// 			hasFix = bit - i;
	// 			break;
	// 		}
	// 	}
	// 	if(hasFix > fix) {
	// 		hasFix = fix;
	// 	}
	// 	value = Number(Number(value / rate).toFixed(hasFix));
	// 	return value;
	// }

	/**
	 * 获取当天最大的UTC时间
	 * @return  utc
	 */
	public static getTodayMaxUtc(): number {
		var date: Date = new Date(ServerTime.serverTime);
		date.setHours(23, 59, 59, 999);
		return date.getTime() * 0.001 >> 0;
	}

	/**
	 * 解析1970年开始时间，格式：00:00:00
	 * @param time 距离1970年1月1日的秒数
	 * @return
	 *
	 */
	public static resloveFormatHMS(time: number): string {
		//发过来的时间是距离1970年1月1日的秒数，因此用DATE的格式化需要乘上1000
		var d: Date = new Date(time * 1000);
		var hour: number = d.getHours();
		var min: number = d.getMinutes();
		var sec: number = d.getSeconds();
		return (hour < 10 ? "0" + hour : "" + hour)
			+ ":" + (min < 10 ? "0" + min : "" + min)
			+ ":" + (sec < 10 ? "0" + sec : "" + sec);
	}

	/**用字符串填充数组，并返回数组副本*/
	public static fillArray(arr: any[], str: string, type: any = null): any[] {

		var temp: any[] = [];
		var a: any[] = str.split(",");
		let len: number = Math.min(arr.length, a.length);
		if (str && str != "") {
			for (var i: number = 0; i < len; i++) {
				var value: string = a[i];
				temp[i] = (value == "true" ? true : (value == "false" ? false : value));
			}
		}
		return temp;
	}


	/**
	 * 将秒数转化为01:18:56格式
	 * @param        time 秒数
	 * @return  返回格式：01:08:56
	 * @example
	 * <listing>
	 *                 convertTime(4136); // 01:08:56
	 * </listing>
	 */
	public static convertTime(time: number, separator: string = ":"): string {
		var hour: number = (time / 3600) >> 0;
		var min: number = (time % 3600 / 60) >> 0;
		var sec: number = (time % 60) >> 0;

		return (hour < 10 ? "0" + hour : "" + hour)
			+ separator + (min < 10 ? "0" + min : "" + min)
			+ separator + (sec < 10 ? "0" + sec : "" + sec);
	}

	/**
	 * 将秒数转化为18:56格式(分钟：秒)
	 * @param value 秒
	 * return 00：00
	 */
	public static formatTimeToMinSec(value: number): string {
		var min: number = Math.ceil(value / 60);
		var sec: number = value % 60;
		var t: string = (min >= 10 ? min : "0" + min) + ":" + (sec >= 10 ? sec : "0" + sec);
		return t;
	}

	/**
	 * 将秒数转化为18分56秒格式(分钟：秒)
	 * @param value 秒
	 * return 00分00秒
	 */
	public static formatTimeToMinSecWord(value: number): string {
		var min: number = Math.floor(value / 60);
		var sec: number = value % 60;
		var t: string = (min >= 10 ? min : "0" + min) + "分" + (sec >= 10 ? sec : "0" + sec) + "秒";
		return t;
	}

	/**
	 * 将秒数转化为X天X时X分：剩余时间
	 * @param value 秒
	 * return X天X时X分
	 */
	public static formatLeftTimeDHM(value: number): string {
		var day: number = value / (3600 * 24) >> 0;
		var hour: number = ((value % (3600 * 24)) / 3600) >> 0;
		if (day == 0 && hour == 0) {
			return StringUtil.formatTimeToMinSecWord(value);
		}
		var min: number = ((value % (3600 * 24)) % 3600 / 60) >> 0;
		var t: string = (day > 0 ? day + "天" : "") + (hour > 0 ? hour + "时" : "") + (min > 0 ? min + "分" : "");
		return t;
	}

	/**
	 * 替换{0}格式字符串
	 */
	public static substitute(str: string, ...rest): string {
		if (str == undefined || str == null) {
			return '';
		}
		let len: number = rest.length;
		let args: string[];
		let bool: boolean = TypeUtil.isArray(rest[0]);
		if (len == 1 && bool) {
			args = rest[0];
			len = args.length;
		} else {
			args = rest;
		}
		for (let i: number = 0; i < len; i++) {
			str = str.replace(new RegExp("\\{" + i + "\\}", "g"), args[i]);
		}
		return str;
	}

	/**换行符转换 */
	public static getLineBreakStr(des: string): string {
		des = des.replace(new RegExp("\\\\n", "g"), 'br');
		return des;
	}

	public static replacJosnStr(str: string): string {
		let myPattern: RegExp = /\'/g;
		str = str.replace(myPattern, "\"");
		return str;
	}

	/**
	 * 格式化钱币， 超过万的 都用  X万 显示
	 * @param value		钱币数
	 * @param str		钱币单位
	 * @param rate		格式化单位比例
	 * @return
	 *
	 */
	public static formatMoney(value: number, str: string = "万", rate: number = 10000): string {
		if (value >= 10 * rate) {
			if (value % rate == 0) {
				return (value / rate) + str;
			}
			return Number(value / rate).toFixed(1) + str;
		}
		return value + "";
	}

	/**
	 * 格式化钱币， 把数字转成  1000->1,000
	 * @param 	value
	 * @param	useFormat	是否超过百万用  X万 显示，超过10亿用 X亿 显示
	 * @return
	 *
	 */
	public static formatNum(value: number, useFormat: boolean = true, asInt: boolean = false): string {
		let pix: string = "";
		if (useFormat && value >= 1000000000) {
			if (value % 100000000 == 0) {
				value = value / 100000000;
			} else {
				value = Number((value / 100000000).toFixed(1));
			}
			pix = "亿";
		} else if (useFormat && value >= 100000) {
			if (value % 10000 == 0) {
				value = value / 10000;
			} else {
				value = Number((value / 10000).toFixed(1));
			}
			pix = "万";
		}
		if (asInt) {
			value = Math.floor(value);
		}
		let strNum: string = value.toString();
		if (strNum.length > 3) {
			let arr: Array<string> = [];
			let start: number = 0;
			let end: number = strNum.length;
			while (end > 0) {
				start = Math.max(end - 3, 0);
				arr.unshift(strNum.slice(start, end));
				end = start;
			}
			strNum = arr.join(",");
		}
		return strNum + pix;
	}

	/**
	 * 格式化钱币 过万用万做单位，过亿用亿做单位
	 */
	public static formatNum1(value: number): string {
		if (value >= 100000000) {
			return (value / 100000000 >> 0) + "亿";
		} else if (value >= 10000) {
			return Number(value / 10000 >> 0) + "万";
		}
		return value.toString();
	}

	/**
	 * 解析时间(月日(周六)时分)
	 * 1970年1月1日10:20
	 * @param time
	 * @return
	 *
	 */
	public static formatTimeToMDWHM(time: number): string {
		//发过来的时间是距离1970年1月1日的秒数，因此用DATE的格式化需要乘上1000
		var t: string = "";
		var d: Date = new Date(time * 1000);
		t = (d.getMonth() + 1) + "月" + d.getDate() + "日(周" + StringUtil.getWeekDay(d.getDay()) + ")" + (d.getHours() < 10 ? "0"
			+ d.getHours() : "" + d.getHours()) + ":" + (d.getMinutes() < 10 ? "0" + d.getMinutes() : "" + d.getMinutes());
		return t;
	}

	/**
	 * 获得中文周几
	 * @param $num
	 *
	 */
	public static getWeekDay($num: number): string {
		let arr: string[] = ["日", "一", "二", "三", "四", "五", "六"];
		return arr[$num];
	}

	/**
	 * 获得中文数字（0~10）
	 * @param $num
	 */
	public static getChieseNum($num: number): string {
		let arr: string[] = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"];
		return arr[$num];
	}

	/**
	 * 阿拉伯数字转中文大写数字(支持亿)
	 * @param num
	 */
	public static getChieseNums(num: number): string {
		let unit: string[] = ["", "十", "百", "千", "万", "十", "百", "千", "亿"];
		let strArr: string[] = num.toString().split("").reverse();
		let newNum: string = "";
		let value: number;
		for (var i = 0; i < strArr.length; i++) {
			value = Number(strArr[i]);
			newNum = (i == 0 && value == 0 ? "" : (i > 0 && value == 0 && Number(strArr[i - 1]) == 0 ? "" : this.getChieseNum(value) + (value == 0 ? unit[0] : unit[i]))) + newNum;
		}

		//替换以“一十”开头的，为“十”
		if (newNum.indexOf("一十") == 0) {
			newNum = newNum.substr(1);
		}

		return newNum;
	}

	/**
	 * 获取字串长度
	 * @param str	字符串
	 * @param ChineseLen	单个中文的长度
	 * @return 
	 * 
	 */
	static getstringLen(str: string, ChineseLen: number = 2): number {
		let len: number = 0;
		if (str) {
			let tmp: string = '';
			for (let i: number = 0; i < ChineseLen; i++) {
				tmp += 'x';
			}
			len = str.replace(/[^\x00-\xff]/g, tmp).length;
		}
		return len;
	}

	/**
	 * 返回按符号截断后的第几个字符串；长度可被定义
	 * @param str	原字符串
	 * @param index	第几个，从1开始
	 * @param sign	截断符号
	 * @param start	从第几个开始截取
	 * @param end	截取到倒数第几个
	 * @return
	 */
	public static getIndexStr(str: string, index: number, sign: string = ';', start: number = 0, end: number = 0): string {
		if (str == null || str == "" || index <= 0) {
			return "";
		}
		var arr: Array<any> = str.split(sign);
		if (arr != null) {
			var tempStr: string = arr[index - 1];
			return tempStr
		}
		return "";
	}

	/**
	 * 格式化日期
	 * @param	date		日期，默认为当前日期
	 * @param	formatStr	格式化样板，由YMDhms组成，不需要显示哪个，就去掉哪个字母
	 * @return	返回格式：2010-10-12 01:08:56
	 */
	public static format(date: Date = null, formatStr: string = "Y-M-D h:m:s"): string {
		if (date == null)
			date = new Date();
		var year: any = date.getFullYear();
		var month: any = date.getMonth() + 1;
		var day: any = date.getDate();
		var hours: any = ((date.getHours() > 9) ? "" : "0") + date.getHours();
		var minutes: any = ((date.getMinutes() > 9) ? "" : "0") + date.getMinutes();
		var seconds: any = ((date.getSeconds() > 9) ? "" : "0") + date.getSeconds();
		return formatStr.replace(new RegExp("Y"), year).replace(new RegExp("M"), month).replace(new RegExp("D"), day).replace(new RegExp("h"), hours).replace(new RegExp("m"), minutes).replace(new RegExp("s"), seconds);
	}

	/**
	 * 将一个time格式化为		xx月xx日 xx:xx:xx；
	 * @param time
	 * @return String
	 */
	public static formatToTime_V10(time: number): string {
		var date: Date = new Date(time * 1000);
		var hour: string = date.getHours() < 10 ? '0' + date.getHours() : '' + date.getHours();
		var minute: String = date.getMinutes() < 10 ? '0' + date.getMinutes() : '' + date.getMinutes();
		var second: String = date.getSeconds() < 10 ? '0' + date.getSeconds() : '' + date.getSeconds();
		return date.getMonth() + 1 + '月' + date.getDate() + '日 ' + hour + ':' + minute + ':' + second;
	}

	/**
	 * 将一个time格式化为		xx月xx日
	 * @param time
	 * @return String
	 */
	public static formatToTime_MD(time: number): string {
		var date: Date = new Date(time * 1000);
		return date.getMonth() + 1 + '月' + date.getDate() + '日 ';
	}

	/**
	 * 获得一个富文本
	 * @param 	texts
	 * @param 	textColors
	 * @param 	sizes
	 * @param	bolds
	 * @return 多个富文本的数组
	 */
	public static getTextFlow(texts: any[], textColors: number[], sizes?: number[], bolds?: boolean[]): Array<egret.ITextElement> {
		var verticalAligns: Array<egret.ITextElement> = [];
		var size: number = Style.SIZE;
		var bold: boolean = false;
		for (let i: number = 0; i < texts.length; i++) {
			if (sizes && sizes.length != 0) {
				size = sizes[i];
			}
			if (bolds && bolds.length != 0) {
				bold = bolds[i];
			}
			let e: egret.ITextElement = this.getTextElement(texts[i], textColors[i], size, bold);
			verticalAligns.push(e);
		}
		return verticalAligns;
	}

	/**
	 * 获得一个富文本
	 * @param 	text
	 * @param 	textColor
	 * @param 	size 可不填
	 * @param	bold 可不填
	 * @return 单个富文本的数组
	 */
	public static getTextFlow2(text: any, textColor: number, size?: number, bold?: boolean): Array<egret.ITextElement> {
		var verticalAligns: Array<egret.ITextElement> = [];
		if (!size) {
			size = Style.SIZE;
		}
		if (!bold) {
			bold = false;
		}
		let e: egret.ITextElement = this.getTextElement(text, textColor, size, bold);
		verticalAligns.push(e);
		return verticalAligns;
	}

	/**
	 * 获得单个富文本
	 * @param 	text
	 * @param 	textColor
	 * @param 	size 可不填
	 * @param	bold 可不填
	 * @return 单个富文本
	 */
	public static getTextElement(text: any, textColor: number, size: number = Style.SIZE, bold?: boolean): egret.ITextElement {
		if (bold)
			return { text: text + "", style: { "size": size, "textColor": textColor, "bold": bold } };
		else
			return { text: text + "", style: { "size": size, "textColor": textColor } };
	}

}