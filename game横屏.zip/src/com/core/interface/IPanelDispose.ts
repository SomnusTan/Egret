interface IPanelDispose 
{
    show(any):void;
    hide():void;
	dispose():void;
    needDispose():boolean;
}