/**
 * 游戏控制接口
 */
interface IGame extends IDispose
{   
    /**游戏ID */
    gameId:number;

    show(data?:any):void;
    hide():void;
	dispose():void;
    getView():h5_engine.GDisplayObjectContainer;
}