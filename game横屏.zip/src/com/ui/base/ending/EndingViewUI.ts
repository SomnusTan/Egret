class EndingViewUI extends BaseUI {
	public bg: eui.Image;
	public groupEndWord: eui.Group;
	public imgWordBg: eui.Image;
	public txtEndZw: eui.Label;
	public txtEndYw: eui.Label;
	public groupBtns: eui.Group;
	public groupHome: eui.Group;
	public btnHome: eui.Button;
	public groupMore: eui.Group;
	public btnMore: eui.Button;
	public groupShare: eui.Group;
	public btnShare: eui.Button;

	public constructor() {
		super("EndingViewSkin");
	}
}