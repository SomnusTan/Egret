class GmUI extends BaseUI {
	public imgBg: eui.Image;
	public txtChatId: eui.TextInput;
	public txtCenterTitle: eui.Label;
	public btnClose: eui.Button;
	public btnGo: eui.Button;
	public groupAttri: eui.Group;
	public comboxChapter: Combox;
	public comboxSection: Combox;

	public constructor() {
		super("GmSkin");
	}
}