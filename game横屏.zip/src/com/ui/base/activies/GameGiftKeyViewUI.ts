class GameGiftKeyViewUI extends BaseUI {
    public imgShareBg: eui.Image;
    public txtKey: eui.TextInput;
    public btnOK: eui.Button;

    public constructor() {
        super("GameGiftKeyViewSkin");
    }
}