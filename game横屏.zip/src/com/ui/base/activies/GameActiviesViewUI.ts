class GameActiviesViewUI extends BaseUI {
    public boxItem: eui.Group;

    public constructor() {
        super("GameActivitiesViewSkin");
    }
}