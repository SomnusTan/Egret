class GameInviteViewUI extends BaseUI {
    public txtTotalCoin: eui.Label;
    public txtPeopleCount: eui.Label;
    public txtMyInviteCode: eui.Label;
    public btnCopy: eui.Button;
    public boxInputInvite: eui.Group;
    public boxInvite: eui.Group;
    public txtInviteCode: eui.TextInput;
    public btnBind: eui.Button;
    public boxHasBinded: eui.Group;
    public txtCoin0: eui.Label;
    public txtCoin1: eui.Label;
    public txtCoin2: eui.Label;
    public btnOK: eui.Button;

    public constructor() {
        super("GameInviteViewSkin");
    }
}