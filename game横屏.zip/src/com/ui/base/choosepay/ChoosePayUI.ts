class ChoosePayUI extends BaseUI {
	public txtTitle: eui.Label;
	public txt_money: eui.Label;
	public btn_wx: eui.Button;
	public btn_zfb: eui.Button;
	public btn_close: eui.Button;

	public constructor() {
		super("ChoosePaySkin");
	}
}