class MemoryViewUI extends BaseUI {
	public txtTitle: eui.Label;
	public txtNumber: eui.Label;
	public txtNew: eui.Label;
	public btnBack: eui.Image;
	public viewStack: eui.ViewStack;
	public btnBizhi: eui.Button;
	public btnShipin: eui.Button;
	public btnJieju: eui.Button;
	public btnChange: eui.Button;

	public constructor() {
		super("MemoryViewSkin");
	}
}