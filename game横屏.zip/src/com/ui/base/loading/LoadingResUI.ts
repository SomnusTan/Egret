class LoadingResUI extends BaseUI {
	public loading_bg: eui.Image;
	public boxProgress: eui.Group;
	public imgProgress: eui.Image;
	public txtLabel: eui.Label;

	public constructor() {
		super("LoadingResSkin");
	}
}