class GameChargeViewUI extends BaseUI {
    public boxItem: eui.Group;
    public imgSelected: eui.Image;
    public btnBuy: eui.Button;

    public constructor() {
        super("GameChargeViewSkin");
    }
}