class LoginUI extends BaseUI {
    public panelLogin: eui.Group;
    public boxCheckBox: eui.Group;
    public checkBoxUserAgreement: eui.CheckBox;
    public txtUserAgreement: eui.Label;
    public txtPhoneNum: eui.TextInput;
    public txtCode: eui.TextInput;
    public btnGetCode: eui.Button;
    public btnLogin: eui.Button;
    public groupYk: eui.Group;
    public txtTouristlogin: eui.Label;

    public constructor() {
        super("LoginSkin");
    }
}