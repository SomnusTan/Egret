class TouristloginUI extends BaseUI {
	public btn_BindingPhone: eui.Button;
	public txt_Notlogging: eui.Label;

	public constructor() {
		super("TouristloginSkin");
	}
}