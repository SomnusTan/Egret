class UserAgreementUI extends BaseUI {
	public scroller: eui.Scroller;
	public dataList: eui.List;
	public userAgreement_btn: eui.Button;

	public constructor() {
		super("UserAgreementSkin");
	}
}