class GameOtherLoginUI extends BaseUI {
    public imgBg: eui.Image;
    public btnLogin: eui.Button;

    public constructor() {
        super("OtherLoginSkin");

    }
}