class WeChatQRCodeUI extends BaseUI {
	public txtTitle: eui.Label;
	public txt_money: eui.Label;
	public txtTishi: eui.Label;
	public imgPayType: eui.Image;
	public btn_close: eui.Button;

	public constructor() {
		super("WeChatQRCodeSkin");
	}
}