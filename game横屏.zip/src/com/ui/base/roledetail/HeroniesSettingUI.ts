class HeroniesSettingUI extends BaseUI {
	public btn_bgm: eui.ToggleButton;
	public btn_effect: eui.ToggleButton;
	public btn_rolesound: eui.ToggleButton;
	public btn_autoplay: eui.ToggleButton;
	public groupSlider: eui.Group;
	public txtSpeed1: eui.Label;
	public txtSpeed2: eui.Label;
	public txtSpeed3: eui.Label;
	public imgSlideBg: eui.Image;
	public imgSlide: eui.Image;
	public btn_sure: eui.Button;

	public constructor() {
		super("HeroniesSettingSkin");
	}
}