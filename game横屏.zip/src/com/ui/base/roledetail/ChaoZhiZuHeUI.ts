class ChaoZhiZuHeUI extends BaseUI {
	public rectBg: eui.Rect;
	public bg: eui.Image;
	public txtPrice: eui.Label;
	public txtTime: eui.Label;
	public btnBuy: eui.Button;
	public btn_quit: eui.Button;

	public constructor() {
		super("ChaoZhiZuHeSkin");
	}
}