class HeroinesDetailUI extends BaseUI {
	public groupVideo: eui.Group;
	public btnBack: eui.Image;
	public boxSet: eui.Group;
	public img_shezhi: eui.Button;
	public boxStory: eui.Group;
	public btnOtherStory: eui.Button;
	public groupNew: eui.Group;
	public imgStory: eui.Button;
	public txtStory: eui.Label;
	public groupDuqu: eui.Group;
	public btnDuqu: eui.Button;
	public groupHuiyi: eui.Group;
	public btnHuiyi: eui.Button;
	public txtDesc: eui.Label;
	public txtHeroniesName: eui.Label;
	public txtHeroniesLabel: eui.Label;

	public constructor() {
		super("HeroniesDetailSkin");
	}
}