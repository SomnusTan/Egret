class HeroinesOtherStoryUI extends BaseUI {
	public imgBg: eui.Image;
	public txtDetail: eui.Label;
	public btnStart: eui.Button;

	public constructor() {
		super("HeroniesOtherStorySkin");
	}
}