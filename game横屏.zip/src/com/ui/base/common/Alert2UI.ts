class Alert2UI extends BaseUI {
	public txtDesc: eui.Label;
	public btnCancel: eui.Button;
	public btnConfirm: eui.Button;
	public txtTitle: eui.Label;

	public constructor() {
		super("Alert2Skin");
	}
}