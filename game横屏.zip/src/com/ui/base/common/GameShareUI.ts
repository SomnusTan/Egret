class GameShareUI extends BaseUI {
	public groupShareWx: eui.Group;
	public groupShareWxquan: eui.Group;
	public groupShareWb: eui.Group;
	public groupShareQQ: eui.Group;
	public groupShareQZone: eui.Group;

	public constructor() {
		super("GameShareSkin");
	}
}