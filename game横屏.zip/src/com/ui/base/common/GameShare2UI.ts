class GameShare2UI extends BaseUI {
	public bg: eui.Image;
	public groupShare: eui.Group;
	public groupShareQQ: eui.Group;
	public groupShareQZone: eui.Group;
	public groupShareWx: eui.Group;
	public groupShareWxquan: eui.Group;
	public groupShareWb: eui.Group;
	public imgWhite: eui.Rect;

	public constructor() {
		super("GameShare2Skin");
	}
}