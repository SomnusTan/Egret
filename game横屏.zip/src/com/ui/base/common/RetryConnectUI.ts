class RetryConnectUI extends BaseUI {
    public txtTitle: eui.Label;
    public txtDesc: eui.Label;
    public btnRetry: eui.Button;

    public constructor() {
        super("RetryConnectSkin");
    }
}