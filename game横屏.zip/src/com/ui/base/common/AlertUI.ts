class AlertUI extends BaseUI {
	public txtDesc: eui.Label;
	public btnConfirm: eui.Button;
	public btnCancel: eui.Button;

	public constructor() {
		super("AlertSkin");
	}
}