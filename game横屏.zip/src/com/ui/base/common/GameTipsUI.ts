class GameTipsUI extends BaseUI {
	public imgBg: eui.Image;
	public txtContent: eui.Label;

	public constructor() {
		super("GameTipsSkin");
	}
}