class GameNoticeViewUI extends BaseUI {
    public scrollBar: eui.Scroller;
    public txtNotice: eui.Label;
    public btnOK: eui.Button;

    public constructor() {
        super("GameNoticeViewSkin");
    }
}