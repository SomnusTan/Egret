class WindowView2UI extends BaseView {
	public imgBg: eui.Image;
	public groupView: eui.Group;

	public constructor() {
		super("WindowView2Skin");
	}
}