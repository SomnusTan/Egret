class WindowViewUI extends BaseView {
	public imgBg0: eui.Image;
	public imgBg: eui.Image;
	public groupRightTitle: eui.Group;
	public txtRightTitle: eui.Label;
	public groupCenterTitle: eui.Group;
	public txtCenterTitle: eui.Label;
	public groupTopTitle: eui.Group;
	public txtTopTitle: eui.Label;
	public groupView: eui.Group;

	public constructor() {
		super("WindowViewSkin");
	}
}