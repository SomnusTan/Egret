class WindowView3UI extends BaseUI {
    
    public imgBg: eui.Image;
    public txtTitle: eui.Label;
    public container: eui.Group;

    public constructor() {
        super("WindowView3Skin");
    }
}