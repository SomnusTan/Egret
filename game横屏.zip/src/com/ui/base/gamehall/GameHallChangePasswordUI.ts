class GameHallChangePasswordUI extends BaseUI {
	public telephoneNumber: eui.TextInput;
	public getVerificationCode: eui.Button;
	public verificationCode: eui.TextInput;
	public bindNewNumber: eui.Button;
	public cancelEdit: eui.Label;

	public constructor() {
		super("GameHallChangePasswordSkin");
	}
}