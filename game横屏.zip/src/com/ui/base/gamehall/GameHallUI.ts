class GameHallUI extends BaseUI {
	public imgBg: eui.Image;
	public img_shezhi: eui.Button;
	public boxCoin: GameCoinComponentUI;
	public btnActivies: eui.Button;

	public constructor() {
		super("GameHallSkin");
	}
}