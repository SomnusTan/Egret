class GameHallSettingUI extends BaseUI {
	public TouristAccount: eui.Label;
	public modifyPhone: eui.Button;
	public UserId: eui.Label;
	public btnGiftKey: eui.Button;
	public Music_btn: eui.ToggleButton;
	public SoundEffect: eui.ToggleButton;
	public signOut: eui.Button;
	public UserAgreement_btn: eui.Button;
	public txtVersion: eui.Label;
	public rectVersion: eui.Rect;

	public constructor() {
		super("GameHallSettingSkin");
	}
}