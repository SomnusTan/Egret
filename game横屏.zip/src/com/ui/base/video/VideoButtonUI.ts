class VideoButtonUI extends BaseUI {
	public bgRect: eui.Rect;
	public btnBack: eui.Image;
	public btnPlay: eui.Image;
	public btnUse: eui.Button;
	public btnShare: eui.Button;
	public groupSkip: eui.Group;
	public imgMark: eui.Image;

	public constructor() {
		super("VideoButtonSkin");
		this.btnBack.visible = false;
		this.btnPlay.visible = false;
		this.btnUse.visible = false;
		this.btnShare.visible = false;
	}

}