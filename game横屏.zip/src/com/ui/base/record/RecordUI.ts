class RecordUI extends BaseUI {
	public btnBack: eui.Image;
	public btnReplay: eui.Button;
	public groupItem: eui.Group;

	public constructor() {
		super("RecordSkin");
	}
}