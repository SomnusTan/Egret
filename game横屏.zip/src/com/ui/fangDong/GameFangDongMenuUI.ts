class GameFangDongMenuUI extends BaseUI {

    public boxButton: eui.Group;
    public btnSave: eui.Button;
    public btnRead: eui.Button;
    public btnContinue: eui.Button;
    public btnSetting: eui.Button;
    public btnBack: eui.Button;
    public btnGm: eui.Button;

    public constructor() {
        super("GameFangDongMenuSkin");
    }
}