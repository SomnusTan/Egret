class GameFangDongUnlockUI extends BaseUI {
    public imgShareBg: eui.Image;
    public btnOK: eui.Button;
    public txtDesc: eui.Label;
    public btnExit: eui.Rect;

    public constructor() {
        super("GameFangDongUnlockSkin");
    }
}