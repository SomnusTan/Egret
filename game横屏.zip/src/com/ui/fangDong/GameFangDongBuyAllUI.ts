class GameFangDongBuyAllUI extends BaseUI {
    public boxSingle: eui.Group;
    public txtSingleDiscount: eui.Label;
    public txtSinglePrice: eui.Label;
    public btnBuySingle: eui.Button;
    public boxAll: eui.Group;
    public txtAllOldPrice: eui.Label;
    public txtAllPrice: eui.Label;
    public btnBuyAll: eui.Button;
    public rectLine: eui.Rect;

    public constructor() {
        super("GameFangDongBuyAllSkin");

    }
}