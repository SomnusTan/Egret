class GameFangDongUI extends BaseUI {
    public boxBg: eui.Group;
    public boxRole: eui.Group;
    public boxButton: eui.Group;
    public btnReview: eui.Button;
    public btnMenu: eui.Button;
    public groupShare: eui.Group;
    public btnShare: eui.Button;
    public imgGuang: eui.Image;
    public boxWeChat: eui.Group;
    public boxDialog: eui.Group;
    public imgDialogBox: eui.Image;
    public txtDialog: eui.Label;
    public boxName: eui.Group;
    public imgName: eui.Image;
    public txtName: eui.Label;
    public boxNext: eui.Group;
    public imgNext: eui.Image;
    public boxEffect: eui.Group;
    public boxCoin: GameCoinComponentUI;

    public constructor() {
        super("GameFangDongSkin");
    }
}