class GameFangDongBeNameUI extends BaseUI {
    public btnName: eui.Button;
    public imgBg: eui.Image;
    public txtName: eui.TextInput;
    public btnRandom: eui.Button;

    public constructor() {
        super("BenameSkin");
    }
}