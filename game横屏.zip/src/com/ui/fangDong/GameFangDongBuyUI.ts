class GameFangDongBuyUI extends BaseUI {
    public imgLight: eui.Image;
    public btn_quit: eui.Button;
    public img_payword: eui.Image;
    public boxButton: eui.Group;
    public btn_unlock: eui.Button;
    public groupBtnLabel: eui.Group;
    public group_old: eui.Group;
    public txt_oldprice: eui.Label;
    public txt_btnLabel: eui.Label;
    public txt_price: eui.Label;
    public groupTime: eui.Group;
    public txt_actTime: eui.Label;

    public constructor() {
        super("GameFangDongBuySkin");

    }
}