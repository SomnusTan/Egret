class GameStatusViewUI extends BaseUI {

	public imgBg: eui.Image;
	public boxCoin: GameCoinComponentUI;
	public imgRole: eui.Image;
	public imgStatus: eui.Image;
	public imgFlag: eui.Image;
	public txtInfo: eui.Label;

	public constructor() {
		super("GameStatusViewSkin");
	}
}