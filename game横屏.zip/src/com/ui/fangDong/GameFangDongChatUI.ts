class GameFangDongChatUI extends BaseUI {
    public imgBg: eui.Image;
    public scrollBar: eui.Scroller;
    public boxChat: eui.Group;
    public btnBack: eui.Rect;
    public btnSend: eui.Rect;
    public txtSend: eui.Label;

    public constructor() {
        super("GameFangDongChatSkin");
    }
}