class GameFangDongSelectViewUI extends BaseUI {

    public imgBg: eui.Image;
    public boxBtn: eui.Group;

    public constructor() {
        super("GameFangDongSelectViewSkin");

    }
}