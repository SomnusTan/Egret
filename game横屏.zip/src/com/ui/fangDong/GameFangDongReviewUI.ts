class GameFangDongReviewUI extends BaseUI {
    public boxTxt:eui.Group;

    public constructor() {
        super("GameFangDongReviewSkin");

    }
}