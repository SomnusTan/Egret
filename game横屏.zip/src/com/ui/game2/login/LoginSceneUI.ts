class LoginSceneUI extends BaseUI {
    public bgImg: eui.Image;
    public titleLabel: eui.Label;
    public componeyLabel: eui.Label;
    public statusLabel: eui.Label;
    public startBtn: eui.Button;
    public nameLabel: eui.Label;
    public leftGroup: eui.Group;

    public constructor() {
        super("LoginSceneSkin");

    }
}