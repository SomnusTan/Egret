class LoadSceneUI extends BaseUI {
    public bgImg: eui.Image;
    public probg: eui.Image;
    public proImg: eui.Image;
    public percentLab: eui.Label;

    public constructor() {
        super("LoadSceneSkin");
    }
}