class InputNameViewUI extends BaseUI {

    public bgImg: eui.Image;
    public startBtn: eui.Button;
    public zhanghaoEdit: eui.TextInput;
    public shaiziBtn: eui.Button;

    public constructor() {
        super("InputNamePanelSkin");

    }
}