class ActPanelUI extends BaseUI {
	public bg: eui.Image;
	public titleBg: eui.Image;
	public title: eui.Label;
	public menuBg: eui.Image;
	public radioScroller: eui.Scroller;
	public radioBtn8: eui.RadioButton;
	public radioBtn7: eui.RadioButton;
	public radioBtn6: eui.RadioButton;
	public radioBtn5: eui.RadioButton;
	public radioBtn0: eui.RadioButton;
	public radioBtn1: eui.RadioButton;
	public radioBtn2: eui.RadioButton;
	public radioBtn3: eui.RadioButton;
	public radioBtn4: eui.RadioButton;
	public viewStack: eui.ViewStack;
	public page0: ActPage0UI;
	public page1: ActPage1UI;
	public page2: ActPage2UI;
	public page3: ActPage3UI;
	public page4: ActPage4UI;
	public page5: ActPage5UI;
	public page6: ActPage6UI;
	public page7: ActPage7UI;
	public page8: ActPage8UI;
	public closeBtn: eui.Image;

	public constructor() {
		super("ActPanelSkin");
	}
}