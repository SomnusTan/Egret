class WeixinPanelUI extends BaseUI {

    /**回答选择 */
    public selectList: MessageList;
    /**选择背景 用于点击关闭*/
    public selectBg: eui.Rect;
    /**回答选择容器 */
    public selectGroup: eui.Group;
    /**返回按钮 */
    public backBtn: eui.Button;
    public messageScroller: eui.Scroller;
    public messageList: eui.List;
    /**发送消息控件 */
    public sendMessage: SendMessage;
    public grilImg: eui.Image;
    public maskImg: eui.Image;
    public grilname: eui.Label;
    public heartPlugin: HeartsPlugins;
    public goldGroup: eui.Group;
    public goldLabel: eui.Label;
    /**引导 */
    public yindaoGroup: eui.Group;
    public yd_weixinImg: eui.Image;
    public weixinHand: eui.Image;
    public ydsend: eui.Button;
    public yindaoHeart: eui.Group;
    public yd_dianhuaImg0: eui.Image;
    public dianhuaHand0: eui.Image;
    public yindaoBack: eui.Group;
    public backCircle: eui.Image;
    public backHand: eui.Image;
    /**提示购买无等待 */
    public cdBtn: eui.Button;
    public jinbiImg: eui.Image;
    public btnBG: eui.Image;
    public leftGroup: eui.Group;

    public constructor() {
        super("WeixinPanelSkin");

    }
}