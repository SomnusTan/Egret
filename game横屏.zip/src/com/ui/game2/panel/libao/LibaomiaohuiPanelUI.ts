class LibaomiaohuiPanelUI extends BaseUI {

    public contentGroup: eui.Group;
    public buyBtn: eui.Button;
    public closeBtn: eui.Button;

    public constructor() {
        super("LibaomiaohuiPanelSkin");

    }
}