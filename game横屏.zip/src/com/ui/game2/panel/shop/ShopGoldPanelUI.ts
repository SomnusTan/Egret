class ShopGoldPanelUI extends BaseUI {
	public heartPlugin: HeartsPlugins;
	public goldGroup: eui.Group;
	public jinbiImg: eui.Image;
	public goldLabel: eui.BitmapLabel;
	public diamondGroup: eui.Group;
	public zhuanshiImg: eui.Image;
	public diamondLabel: eui.BitmapLabel;
	public goldGrp: eui.Group;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;

	public constructor() {
		super("ShopGoldPanelSkin");
	}
}