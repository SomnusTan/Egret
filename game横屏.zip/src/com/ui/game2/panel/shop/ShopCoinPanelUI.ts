class ShopCoinPanelUI extends BaseUI {
    public heartPlugin: HeartsPlugins;
    public coinGroup: eui.Group;
    public fontCoin: eui.BitmapLabel;
    public diamondGroup1: eui.Group;
    public zhuanshiImg: eui.Image;
    public fontDiamond: eui.BitmapLabel;
    public boxItem: eui.Group;
    public leftGroup: eui.Group;
    public backBtn: eui.Button;
    public imgSelected: eui.Image;

    public constructor() {
        super("ShopCoinPanelSkin");
    }
}