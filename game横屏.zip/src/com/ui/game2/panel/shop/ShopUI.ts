class ShopUI extends BaseUI {
	public shopViewStack: eui.ViewStack;
	public xiangouScroller: eui.Scroller;
	public xiangouGroup: eui.Group;
	public chaozhiScroller: eui.Scroller;
	public chaozhiGroup: eui.Group;
	public zhuanshiScroller: eui.Scroller;
	public zhuanshiGroup: eui.Group;
	public goldScroller: eui.Scroller;
	public goldGroup: eui.Group;
	public daojuScroller: eui.Scroller;
	public daojuGroup: eui.Group;
	public btnGroup: eui.Group;
	public xiangouRadioBtn: eui.RadioButton;
	public goumaiRadioBtn: eui.RadioButton;
	public diamontRadioBtn: eui.RadioButton;
	public goldRadioBtn: eui.RadioButton;
	public daojuRadioBtn: eui.RadioButton;
	public heartPlugin: HeartsPlugins;
	public goldGroup1: eui.Group;
	public jinbiImg: eui.Image;
	public goldLabel: eui.BitmapLabel;
	public diamondGroup1: eui.Group;
	public zhuanshiImg: eui.Image;
	public diamendLabel: eui.BitmapLabel;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;

	public constructor() {
		super("ShopPanelSkin");
	}
}