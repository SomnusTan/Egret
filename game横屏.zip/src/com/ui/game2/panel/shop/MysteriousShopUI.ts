class MysteriousShopUI extends BaseUI {
	public bg: eui.Image;
	public refresh_time: eui.Label;
	public titleBg: eui.Image;
	public title: eui.Label;
	public closeBtn: eui.Image;
	public scroller: eui.Scroller;
	public showListGrp: eui.Group;
	public refresh_text: eui.BitmapLabel;
	public iconImg: eui.Image;
	public gotoShop: eui.Button;

	public constructor() {
		super("MysteriousShopSkin");
	}
}