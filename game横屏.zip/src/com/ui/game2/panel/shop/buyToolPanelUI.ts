class buyToolPanelUI extends BaseUI {
	public contentGroup: eui.Group;
	public canelBtn: eui.Button;
	public okBtn: eui.Button;
	public titleLabel: eui.Label;
	public contentLabel: eui.Label;
	public goldLabel: eui.BitmapLabel;
	public xiangouGroup: eui.Group;
	public maxcountLabel: eui.Label;
	public giftImg: eui.Image;
	public jianBtn: eui.Button;
	public jiaBtn: eui.Button;
	public countLabel: eui.Label;
	public nojianBtn: eui.Button;
	public nojiaBtn: eui.Button;

	public constructor() {
		super("buyToolPanelSkin");
	}
}