class ShopDiamondPanelUI extends BaseUI {
	public heartPlugin: HeartsPlugins;
	public coinGroup: eui.Group;
	public coinLabel: eui.BitmapLabel;
	public diamondGroup1: eui.Group;
	public zhuanshiImg: eui.Image;
	public diamondLabel: eui.BitmapLabel;
	public scroller: eui.Scroller;
	public diamondGrp: eui.Group;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;
	public imgSelected: eui.Image;

	public constructor() {
		super("ShopDiamondPanelSkin");
	}
}