class ShopGiftToolPanelUI extends BaseUI {
	public contentGroup: eui.Group;
	public radioGrp: eui.Group;
	public radioBtn0: eui.RadioButton;
	public radioBtn1: eui.RadioButton;
	public goldGroup: eui.Group;
	public jinbiImg: eui.Image;
	public goldLabel: eui.BitmapLabel;
	public diamondGroup: eui.Group;
	public zhuanshiImg: eui.Image;
	public diamondLabel: eui.BitmapLabel;
	public viewStack: eui.ViewStack;
	public shopToolPart: ShopToolPart;
	public shopGiftPart: ShopGiftPart;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;
	public coinGroup: CoinUI;

	public constructor() {
		super("ShopGiftToolPanelSkin");
	}
}