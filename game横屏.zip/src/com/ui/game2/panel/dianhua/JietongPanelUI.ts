class JietongPanelUI extends BaseUI {
    
    public btnBG: eui.Image;
    public yindaoHeart: eui.Group;
    public yd_dianhuaImg0: eui.Image;
    public dianhuaHand0: eui.Image;
    /**选择回答列表 */
    public selectList: MessageList;
    /**选择答案Group */
    public selectGroup: eui.Group;
    /**聊天显示List */
    public messageList: eui.List;
    /**昵称文本 */
    public girlName: eui.Label;
    /**挂断按钮 */
    public guaduanBtn: eui.Button;
    /**通话时间 */
    public timeLabel: eui.Label;
    /**消息滚动容器 */
    public msgScroller: eui.Scroller;
    /**亲密度 */
    public heartPlugin: HeartsPlugins;
    /**头像遮罩 */
    public maskImg: eui.Image;
    /**头像 */
    public grilImg: eui.Image;
    /**引导相关 */
    public yindaoGroup: eui.Group;
    public yindaoSGro: eui.Group;
    public yd_dianhuaImg: eui.Image;
    public dianhuaHand: eui.Image;

    public constructor() {
        super("JietongPanelSkin");

    }
}