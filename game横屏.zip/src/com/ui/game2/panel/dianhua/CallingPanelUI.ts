class CallingPanelUI extends BaseUI {
    public btnBG: eui.Image;
    public heartPlugin: HeartsPlugins;
    public maskImg: eui.Image;
    public grilImg: eui.Image;

    public constructor() {
        super("CallingPanelSkin");
    }
}