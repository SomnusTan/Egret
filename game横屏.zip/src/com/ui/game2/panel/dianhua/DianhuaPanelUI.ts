class DianhuaPanelUI extends BaseUI {

    public btnBG: eui.Image;
    public leftGroup: eui.Group;
    public maskImg: eui.Image;
    public grilImg: eui.Image;
    public girlName: eui.Label;
    public callBtn: eui.Button;
    public backBtn: eui.Button;
    public dianhuaScroller: eui.Scroller;
    public dianhuaList: eui.List;
    public yindaoGroup: eui.Group;
    public yd_dianhuaImg: eui.Image;
    public dianhuaHand: eui.Image;

    public constructor() {
        super("DianhuaPanelSKin");

    }
}