class CallHistoryPanelUI extends BaseUI {

    public btnBG: eui.Image;
    public maskImg: eui.Image;
    public grilImg: eui.Image;
    public dataScroller: eui.Scroller;
    public dataList: eui.List;
    public leftGroup: eui.Group;
    public backBtn: eui.Button;

    public constructor() {
        super("CallHistoryPanelSkin");

    }
}