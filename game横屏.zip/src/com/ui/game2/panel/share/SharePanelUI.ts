class SharePanelUI extends BaseUI {

    public closeBtn: eui.Button;
    public weiboBtn: eui.Image;
    public weixinBtn: eui.Image;
    public qqBtn: eui.Image;
    public friendBtn: eui.Image;
    public zoneBtn: eui.Image;
    public okBtn: eui.Button;

    public constructor() {
        super("SharePanelSkin");

    }
}