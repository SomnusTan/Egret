class BagsPanelUI extends BaseUI {

    public bgImg: eui.Image;
    public giftScroller: eui.Scroller;
    public giftGroup: eui.Group;
    public heartPlugin: HeartsPlugins;
    public nothingGroup: eui.Group;
    public gotoShop: eui.Button;
    public leftGoup: eui.Group;
    public backBtn: eui.Button;
    public yindaoTip: eui.Group;
    public yindaoBack: eui.Group;
    public backCircle: eui.Image;
    public backHand: eui.Image;

    public constructor() {
        super("BagsPanelSkin");

    }
}