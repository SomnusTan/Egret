class UseToolPanelUI extends BaseUI {
    public bgImg: eui.Rect;
    public contentGroup: eui.Group;
    public titleLabel: eui.Label;
    public contentLabel: eui.Label;
    public giftImg: eui.Image;
    public countGroup: eui.Group;
    public jianBtn: eui.Button;
    public jiaBtn: eui.Button;
    public countLabel: eui.Label;
    public nojianBtn: eui.Button;
    public nojiaBtn: eui.Button;
    public canelBtn: eui.Button;
    public canelMidBtn: eui.Button;
    public okBtn: eui.Button;
    public myCount: eui.Label;

    public constructor() {
        super("useToolPanelSkin");
    }
}