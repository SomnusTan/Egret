class SetPanelUI extends BaseUI {

    public setGroup: eui.Group;
    public zhuName: eui.Label;
    public zhuId: eui.Label;
    public versionLabel: eui.Label;
    public quitGameBtn: eui.Button;
    public kaiguanGroup: eui.Group;
    public sndLine: eui.Image;
    public kaiguan: eui.ToggleButton;
    public jianyiGroup: eui.Group;
    public youjianGroup: eui.Group;
    public xin: eui.Image;
    public leftGroup: eui.Group;
    public guanbiBtn: eui.Button;

    public constructor() {
        super("SetPanelSkin");
    }
}