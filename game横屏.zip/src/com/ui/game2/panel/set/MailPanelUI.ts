class MailPanelUI extends BaseUI {
    public contentGroup: eui.Group;
    public maillScroller: eui.Scroller;
    public mailList: eui.List;
    public noText: eui.Label;
    public leftGroup: eui.Group;
    public backBtn: eui.Button;

    public constructor() {
        super("MailPanelSkin");

    }
}