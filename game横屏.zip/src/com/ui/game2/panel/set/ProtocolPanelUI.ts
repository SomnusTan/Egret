class ProtocolPanelUI extends BaseUI {
    public contentGroup: eui.Group;
    public protocalScroller: eui.Scroller;
    public dataList: eui.List;
    public okBtn: eui.Button;
    public leftGroup: eui.Group;
    public guanbiBtn: eui.Button;

    public constructor() {
        super("ProtocalPanelSkin");

    }
}