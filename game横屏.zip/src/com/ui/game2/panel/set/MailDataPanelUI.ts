class MailDataPanelUI extends BaseUI {

    public contentGroup: eui.Group;
    public linquBtn: eui.Button;
    public mailGroup: eui.Group;
    public content: eui.Label;
    public giftGroup: eui.Group;
    public text: eui.Label;
    public leftGroup: eui.Group;
    public backBtn: eui.Button;

    public constructor() {
        super("MailDataPanelSkin");

    }
}