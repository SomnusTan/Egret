class WorkProPanelUI extends BaseUI {
	public TypeImg: eui.Image;
	public finishBtn: eui.Button;
	public typeLabel: eui.Label;
	public probg: eui.Image;
	public proImg: eui.Image;
	public ProLabel: eui.Label;
	public tipLabel: eui.Label;
	public cdBtn: eui.Button;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;

	public constructor() {
		super("WorkProPanelSkin");
	}
}