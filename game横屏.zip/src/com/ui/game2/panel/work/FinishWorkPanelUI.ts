class FinishWorkPanelUI extends BaseUI {
	public contentGroup: eui.Group;
	public xinLabel: eui.Label;
	public okBtn: eui.Button;

	public constructor() {
		super("FinishWorkPanelSkin");
	}
}