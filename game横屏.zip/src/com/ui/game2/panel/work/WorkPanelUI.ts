class WorkPanelUI extends BaseUI {
	public workBoxScroller: eui.Scroller;
	public itemGroup: eui.Group;
	public heartPlugin: HeartsPlugins;
	public goldGroup: eui.Group;
	public jinbiImg: eui.Image;
	public goldLabel: eui.BitmapLabel;
	public diamondGroup: eui.Group;
	public zhuanshiImg: eui.Image;
	public diamendLabel: eui.BitmapLabel;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;
	public yindaoGroup: eui.Group;
	public yd_workImg: eui.Image;
	public workHand: eui.Image;
	public startBtn: eui.Button;
	public yindaoGroup0: eui.Group;
	public yd_loveImg0: eui.Image;
	public loveHand0: eui.Image;
	public yindaoGroup1: eui.Group;
	public yd_loveImg1: eui.Image;
	public loveHand1: eui.Image;
	public yindaoBack: eui.Group;
	public backCircle: eui.Image;
	public backHand: eui.Image;

	public constructor() {
		super("WorkPanelSkin");
	}
}