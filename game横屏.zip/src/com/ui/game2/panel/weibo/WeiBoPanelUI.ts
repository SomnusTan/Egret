class WeiBoPanelUI extends BaseUI {
    /**选择回答列表 */
    public selectList: MessageList;
    /**选择背景 */
    public selectBg: eui.Rect;
    /**选择回答容器 */
    public selectGroup: eui.Group;
    public heartPlugin: HeartsPlugins;
    public backBtn: eui.Button;
    public headImg: eui.Image;
    public girlNeme: eui.Label;
    public weiboScoller: eui.Scroller;
    public weiboList: eui.List;
    public maskImg: eui.Image;
    public yindaoZan: eui.Group;
    public zanCricle: eui.Image;
    public zanHand: eui.Image;
    public yindaoPin: eui.Group;
    public pinCricle: eui.Image;
    public pinHand: eui.Image;

    public constructor() {
        super("WeiBoPanelSkin");

    }
}