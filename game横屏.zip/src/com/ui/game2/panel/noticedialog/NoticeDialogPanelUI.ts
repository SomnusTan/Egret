class NoticeDialogPanelUI extends BaseUI {
	public bg: eui.Image;
	public titleBg: eui.Image;
	public title: eui.Label;
	public menuBg: eui.Image;
	public viewStack: eui.ViewStack;
	public gameContent: eui.Label;
	public systemLabel: eui.Label;
	public QQgift: eui.Button;
	public weixigift: eui.Button;
	public wxLabel: eui.Label;
	public qqLabel0: eui.Label;
	public qqLabel1: eui.Label;
	public closeBtn: eui.Image;
	public radioGrp: eui.Group;
	public radioBtn0: eui.RadioButton;
	public radioBtn1: eui.RadioButton;
	public radioBtn2: eui.RadioButton;

	public constructor() {
		super("NoticeDialogPanelSkin");
	}
}