class DlcMainDocUI extends BaseUI {

    public showScroller: eui.Scroller;
    public finditemGrp: eui.Group;
    public showIndexGrp: eui.Group;
    public dlc_title: eui.Label;
    public dlc_doc: eui.Label;
    public dlc_doc0: eui.Label;
    public dlc_doc1: eui.Label;
    public dlc_doc2: eui.Label;
    public dlc_doc3: eui.Label;
    public backBtn: eui.Button;
    public gotoShop: eui.Button;

    public constructor() {
        super("DlcMainDocSkin");

    }
}