class DlcMainGameUI extends BaseUI {

    public contentGroup: eui.Group;
    public otherImg: eui.Image;
    public meGrp: eui.Group;
    public nextImg1: eui.Image;
    public textInfoMe: eui.Label;
    public nameMe: eui.Label;
    public otherGrp: eui.Group;
    public nextImg0: eui.Image;
    public nameOther: eui.Label;
    public textInfoOther: eui.Label;
    public selectGrp: eui.Group;
    public titleSelect: eui.Label;
    public startGrp: eui.Group;
    public showSelectGrp: eui.Group;
    public select_0: eui.RadioButton;
    public select_1: eui.RadioButton;
    public select_2: eui.RadioButton;
    public pangGrp: eui.Group;
    public nextImg2: eui.Image;
    public namePang: eui.Label;
    public textInfoPang: eui.Label;
    public upBtn: eui.Button;

    public constructor() {
        super("DlcMainGameSkin");

    }
}