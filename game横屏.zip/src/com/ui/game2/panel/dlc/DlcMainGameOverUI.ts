class DlcMainGameOverUI extends BaseUI {
    public bg: eui.Image;
    public startGrp: eui.Group;
    public backBtn: eui.Button;
    public nextBtn: eui.Button;

    public constructor() {
        super("DlcMainGameOverSkin");
    }
}
