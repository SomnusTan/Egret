class DlcMainPanelUI extends BaseUI {

    public bg: eui.Image;
    public titleBg: eui.Image;
    public title: eui.Label;
    public panelChapterList: eui.List;
    public showGrpImgInfos: eui.Group;
    public startBtn: eui.Button;
    public closeBtn: eui.Image;
    public showImggrp: eui.Group;
    public showImgInfo: eui.Image;
    public showLoading: eui.Group;
    public showLabel: eui.Label;

    public constructor() {
        super("DlcMainPanelSkin");

    }
}