class RedPacketPanelUI extends BaseUI {
	public closeBtn: eui.Image;
	public remindBtn: eui.Image;
	public redPacketImage: eui.Image;
	public minLabel: eui.Label;
	public maxLabel: eui.Label;
	public continuityGrp0: eui.Group;
	public circleImage0: eui.Image;
	public rect0: eui.Rect;
	public continuityGrp1: eui.Group;
	public circleImage1: eui.Image;
	public rect1: eui.Rect;
	public continuityGrp2: eui.Group;
	public circleImage2: eui.Image;
	public rect2: eui.Rect;

	public constructor() {
		super("RedPacketPanelSkin");
	}
}