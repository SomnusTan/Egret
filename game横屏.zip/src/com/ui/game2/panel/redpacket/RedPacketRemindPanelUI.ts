class RedPacketRemindPanelUI extends BaseUI {
	public exitImage: eui.Image;

	public constructor() {
		super("RedPacketRemindPanelSkin");
	}
}