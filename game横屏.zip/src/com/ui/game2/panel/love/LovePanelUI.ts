class LovePanelUI extends BaseUI {
	public powerGroup: eui.Group;
	public tiliImg: eui.Image;
	public powerLabel: eui.BitmapLabel;
	public goldGroup: eui.Group;
	public jinbiImg: eui.Image;
	public goldLabel: eui.BitmapLabel;
	public loveBoxScroller: eui.Scroller;
	public itemGroup: eui.Group;
	public heartPlugin: HeartsPlugins;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;
	public yindaoGroup: eui.Group;
	public yd_loveImg: eui.Image;
	public loveHand: eui.Image;
	public startBtn: eui.Button;
	public yindaoGroup0: eui.Group;
	public yd_loveImg0: eui.Image;
	public loveHand0: eui.Image;
	public yindaoBack: eui.Group;
	public backCircle: eui.Image;
	public backHand: eui.Image;

	public constructor() {
		super("LovePanelSkin");
	}
}