class LoveProPanelUI extends BaseUI {
	public TypeImg: eui.Image;
	public probg: eui.Image;
	public proImg: eui.Image;
	public ProLabel: eui.Label;
	public typeLabel: eui.Label;
	public finishBtn: eui.Button;
	public tipLabel: eui.Label;
	public cdBtn: eui.Button;
	public leftGroup: eui.Group;
	public backBtn: eui.Button;

	public constructor() {
		super("LoveProPanelSkin");
	}
}