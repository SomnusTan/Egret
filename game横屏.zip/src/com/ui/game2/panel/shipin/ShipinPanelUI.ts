class ShipinPanelUI extends BaseUI {

    public goldGroup: eui.Group;
    public jinbiImg: eui.Image;
    public goldLabel: eui.BitmapLabel;
    public rag: eui.Group;
    public shoucangScroller: eui.Scroller;
    public itemGroup: eui.Group;
    public huiyiScroller: eui.Scroller;
    public item2Group: eui.Group;
    public bgScroller: eui.Scroller;
    public item3Group: eui.Group;
    public kaiguan: eui.ToggleSwitch;
    public leftGroup: eui.Group;
    public backBtn: eui.Button;
    public yindaoGroup: eui.Group;
    public yd_shipinImg: eui.Image;
    public shipinHand: eui.Image;
    public yindaoBack: eui.Group;
    public backCircle: eui.Image;
    public backHand: eui.Image;

    public constructor() {
        super("ShipinPanelSkin");

    }
}