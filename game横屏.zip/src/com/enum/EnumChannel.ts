class EnumChannel {
    /**官方U8 */
    public static C_DEFAULT: string = "1773";
    /**360 */
    public static C_360: string = "1741";
    /**oppo */
    public static C_OPPO: string = "1745";
    /**vivo */
    public static C_VIVO: string = "1746"
    /**九游UC */
    public static C_UC: string = "1744";
    /**UC 豌豆荚 */
    public static C_UC1: string = "1780";
    /**搜狗 */
    public static C_SOUGOU: string = "1786";
    public static C_SOUGOU1: string = "1788";
    public static C_SOUGOU2: string = "1790";
    public static C_SOUGOU3: string = "1791";

    /**官方H5 */
    public static C_DEFAULT_H5: string = "1";
    /**IOS */
    public static C_IOS: string = "2";
    /**成都h5 */
    public static C_CD_H5: string = "3";
    /**Steam */
    public static C_STEAM: string = "6";
    /**广州冰雪IOS */
    public static C_GZ_SNOW: string = "7";


    public static CAN_INVITE_LIST: string[] = [EnumChannel.C_DEFAULT_H5, EnumChannel.C_DEFAULT, EnumChannel.C_IOS, EnumChannel.C_CD_H5, EnumChannel.C_STEAM];
}