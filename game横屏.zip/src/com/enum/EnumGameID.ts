class EnumGameID {
    /**非DLC */
    public static NO_DLC: number = 0

    /**房东 */
    public static FANG_DONG: number = 1;

    /**房东 前男友DLC */
    public static FANG_DONG_DLC_1: number = 1;

    /**赵小野 */
    public static GAME2: number = 2;

}