class EnumTypingSpeed {
    /**快速 */
    public static FAST: number = 75;
    /**中速 */
    public static NORMAL: number = 100//143;
    /**慢速 */
    public static SLOW: number = 130//250;

    public static LIST: number[] = [EnumTypingSpeed.NORMAL, EnumTypingSpeed.SLOW, EnumTypingSpeed.NORMAL, EnumTypingSpeed.FAST];

    /**标点符号时间间隔 */
    public static SYMBOL_TIME: number = 400;
    /**需要停顿的标点符号 */
    public static SYMBOL: string = "，。？！、;";
}