class EnumVideoType {
	public constructor() {
	}
	/** 动态壁纸 1-- 不可修改值 */
	public static DONGTAI_BIZHI: number = 1;

	/** 回忆视频 2-- 不可修改值 */
	public static HUIYI_SHIPIN: number = 2;

	/** 心跳结局 3-- 不可修改值 */
	public static XINTIAO_JIEJU: number = 3;

	/** avg视频 */
	public static AVG_SHIPIN: number = 4;
	/**心动1故事 */
	public static XIN_DONG1: number = 5;
	/**心动1视频 */
	public static XIN_DONG1_VIDEO: number = 6;

}