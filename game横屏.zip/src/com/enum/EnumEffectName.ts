class EnumEffectName {
    /**点击效果 */
    public static TouchEffect: string = "TouchEffect";
    /**呼吸灯效果 */
    public static BreathEffect: string = "BreathEffect";
}