class EnumRecordType {
	public constructor() {
	}

	/**
	 * 0 SAVE，存档
	 */
	public static SAVE: number = 0;

	/**
	 * 1 READ，读档
	 */
	public static READ: number = 1;
}