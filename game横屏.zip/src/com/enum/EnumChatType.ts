/**
 * 对话类型
 */
class EnumChatType {
    /**对白 */
    public static CHAT: number = 1;
    /**微信有对白 */
    public static WECHAT_DIALOG: number = 2;
    /**微信 */
    public static WECHAT: number = 3;
    /**视频 */
    public static VIDEO: number = 4;
    /**选项 (后端使用)*/
    public static OPTION: number = 5;
    /**角色取名 */
    public static BENAME: number = 6;
    /**结局视频 */
    public static END_VIDEO: number = 7;
    /**结局对白 */
    public static END_IMAGE: number = 8;
    /**显示状态机 */
    public static SHOW_STATUS: number = 9;
}