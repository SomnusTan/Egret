class EnumWindowType {
	public constructor() {
	}
	/** 类型0--不用底 */
	public static TYPE_0: number = 0;

	/** 类型1--红底 */
	public static TYPE_1: number = 1;

	/** 类型2--蓝底 */
	public static TYPE_2: number = 2;

	/** 类型3--绑定手机 */
	public static TYPE_3: number = 3;

	/** 类型4--分享界面 */
	public static TYPE_4: number = 4;
}