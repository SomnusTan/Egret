class EnumLanguageId {
	public constructor() {
	}
	/**0	零*/
	public static KEY_0: number = 0;
	/**1	一*/
	public static KEY_1: number = 1;
	/**2	二*/
	public static KEY_2: number = 2;
	/**3	三*/
	public static KEY_3: number = 3;
	/**4	四*/
	public static KEY_4: number = 4;
	/**5	五*/
	public static KEY_5: number = 5;
	/**6	六*/
	public static KEY_6: number = 6;
	/**7	七*/
	public static KEY_7: number = 7;
	/**8	八*/
	public static KEY_8: number = 8;
	/**9	九*/
	public static KEY_9: number = 9;
	/**10	十*/
	public static KEY_10: number = 10;
	/**11	十一*/
	public static KEY_11: number = 11;
	/**12	十二*/
	public static KEY_12: number = 12;
	/**13	十三*/
	public static KEY_13: number = 13;
	/**14	十四*/
	public static KEY_14: number = 14;
	/**15	十五*/
	public static KEY_15: number = 15;
	/**16	百*/
	public static KEY_16: number = 16;
	/**17	千*/
	public static KEY_17: number = 17;
	/**18	万*/
	public static KEY_18: number = 18;
	/**19	亿*/
	public static KEY_19: number = 19;
	/**20	年*/
	public static KEY_20: number = 20;
	/**21	月*/
	public static KEY_21: number = 21;
	/**22	日*/
	public static KEY_22: number = 22;
	/**23	天*/
	public static KEY_23: number = 23;
	/**24	时*/
	public static KEY_24: number = 24;
	/**25	分*/
	public static KEY_25: number = 25;
	/**26	秒*/
	public static KEY_26: number = 26;
	/**27	周日*/
	public static KEY_27: number = 27;
	/**28	周一*/
	public static KEY_28: number = 28;
	/**29	周二*/
	public static KEY_29: number = 29;
	/**30	周三*/
	public static KEY_30: number = 30;
	/**31	周四*/
	public static KEY_31: number = 31;
	/**32	周五*/
	public static KEY_32: number = 32;
	/**33	周六*/
	public static KEY_33: number = 33;
	/**34	确定*/
	public static KEY_34: number = 34;
	/**35	取消*/
	public static KEY_35: number = 35;
	/**36	提示*/
	public static KEY_36: number = 36;
	/**37	重试*/
	public static KEY_37: number = 37;
	/**38	网络连接中断，请检查移动网络或WIFI设置*/
	public static KEY_38: number = 38;
	/**39	我已查看并同意*/
	public static KEY_39: number = 39;
	/**40	用户协议*/
	public static KEY_40: number = 40;
	/**41	手机号*/
	public static KEY_41: number = 41;
	/**42	请输入手机号*/
	public static KEY_42: number = 42;
	/**43	验证码*/
	public static KEY_43: number = 43;
	/**44	请输入验证码*/
	public static KEY_44: number = 44;
	/**45	获取验证码*/
	public static KEY_45: number = 45;
	/**46	快速登录*/
	public static KEY_46: number = 46;
	/**47	游客登录*/
	public static KEY_47: number = 47;
	/**48	开    始*/
	public static KEY_48: number = 48;
	/**49	跳过*/
	public static KEY_49: number = 49;
	/**50	不要去迎合女人的时间，让女人主动迎合你，因为不忙的男人在女人眼里都是低价值的。*/
	public static KEY_50: number = 50;
	/**51	互动的最高境界，就是瞎扯淡，看到什么东西，就乱编什么故事*/
	public static KEY_51: number = 51;
	/**52	太正经的老实男人很难泡到美女，正如人们常说：男人不坏，女人不爱*/
	public static KEY_52: number = 52;
	/**53	女人永远都觉得男人穿西装最帅了*/
	public static KEY_53: number = 53;
	/**54	穿着打扮上面，除了衣服鞋子要贵一点，其他的，干净得体就可以了*/
	public static KEY_54: number = 54;
	/**55	灰色和黑色是男人永不过时的颜色，要想有男人形象，最好就别穿的花花绿绿的*/
	public static KEY_55: number = 55;
	/**56	男人一定要学会锻炼，女人大部分都喜欢一个强壮的男人*/
	public static KEY_56: number = 56;
	/**57	一定要学会几招互动冷场时候补救的办法，比如魔术*/
	public static KEY_57: number = 57;
	/**58	男人没有什么行为比翻看女人的手袋更令她讨厌*/
	public static KEY_58: number = 58;
	/**59	与女人逛街的时候带一百元为她花完的效果，好过你带一万元为她花五千元的几倍*/
	public static KEY_59: number = 59;
	/**60	其实说什么不重要，重���的是你能否让她笑，这个是关键*/
	public static KEY_60: number = 60;
	/**61	你们关系没有好到无话不谈的时候，最好不要轻易向对方表白，失败率很高*/
	public static KEY_61: number = 61;
	/**62	做一个精致的男人，时时刻刻保持迷人的微笑，最佳着装以及口腔卫生等最好的状态*/
	public static KEY_62: number = 62;
	/**63	如果你从来没有让你的女人痛哭过，那就说明你在她心中根本不重要*/
	public static KEY_63: number = 63;
	/**64	跟女生表白可以这样说：我给你讲个爱情故事吧，有一天，我遇见了你*/
	public static KEY_64: number = 64;
	/**65	和女生聊天时，如果你一直长篇大论，自言自语，她一定会回你好吧，哦，呵呵，所以一定要留下让女生接话的谈资，给她留出回复空间*/
	public static KEY_65: number = 65;
	/**66	俗话说言多必失，聊天时废话太多也会暴露你的需求感让女生觉得你是一个低价值的人，��以不要用太多语气词和废话*/
	public static KEY_66: number = 66;
	/**67	女生善于转移话题，当话题的走向完全被对方引导并占据主动时，你的回复空间会越来越窄，所以尽可能用关键字去延伸话题*/
	public static KEY_67: number = 67;
	/**68	一味的幽默风趣只会让女生觉得你是个逗比，在有了一定的幽默风趣后，一定要在对话中穿插一些真实的东西*/
	public static KEY_68: number = 68;
	/**69	搭讪开场白：我想认识你，但我觉得没有好的方法，所以就直接过来跟你打个招呼，我叫……*/
	public static KEY_69: number = 69;
	/**70	让女生留电话：我觉得跟你聊天挺舒服的，说不定以后我们可以成为很好的朋友，我们可以交换个联系方式到时候再联系*/
	public static KEY_70: number = 70;
	/**71	当一个女生总是找你说话，说一些无关紧要的话的时候，往往是喜欢的一个暗示*/
	public static KEY_71: number = 71;
	/**72	大部分女生觉得厌烦的行为：给她打太多电话，太早告诉她你对她有感觉，为了满足她而不为自己考虑*/
	public static KEY_72: number = 72;
	/**73	大多女性喜欢直率的表达，她们会觉得这样的男性充满魅力，相反，她们讨厌那种说法拐弯抹角、吞吞吐吐、过分含蓄的男性*/
	public static KEY_73: number = 73;
	/**74	女人有一种心理防卫本能，经常用语言掩饰自己的本意，不喜欢别人一语道破天机，如果男人自作聪明说破女人的心事，往往会引起反感*/
	public static KEY_74: number = 74;
	/**75	女人不喜欢两类男人：一种是在女人面前呆若木鸡，少言寡语，另一种是在女人面前夸夸其谈，举止夸张*/
	public static KEY_75: number = 75;
	/**76	女人喜欢刚毅、果敢、热情、爽朗、勇于负责的男子汉，而对畏首畏尾、优柔寡断、迟疑不决的男人心存鄙弃*/
	public static KEY_76: number = 76;
	/**77	女生不回微信的原���：时间太久了不知道怎么回，故意装的很忙，发的问题太敏感，你还不够重要*/
	public static KEY_77: number = 77;
	/**78	有时候还是需要保持一点神秘感，对方猜不透你，对你的兴趣也就越来越浓，不会随着时间变淡*/
	public static KEY_78: number = 78;
	/**79	加载中…*/
	public static KEY_79: number = 79;
	/**80	解锁心动之旅需要50个碎片，当前数量{0}个。*/
	public static KEY_80: number = 80;
	/**81	获取碎片*/
	public static KEY_81: number = 81;
	/**82	神秘商店*/
	public static KEY_82: number = 82;
	/**83	恋爱场景：运动、逗猫、游乐园*/
	public static KEY_83: number = 83;
	/**84	解锁《纯情房东俏房客》任意结局*/
	public static KEY_84: number = 84;
	/**85	恋爱*/
	public static KEY_85: number = 85;
	/**86	亲爱的：*/
	public static KEY_86: number = 86;
	/**87	    故事到这里暂告一段落，与你甜蜜相恋的这些天里，是我最开心的日子。*/
	public static KEY_87: number = 87;
	/**88	最新剧情已开拍，详情请关注公众号:《心动女生手游》  玩家群:545937961*/
	public static KEY_88: number = 88;
	/**89	奖励*/
	public static KEY_89: number = 89;
	/**90	已开启心动之旅，将获得的心动碎片{0}  兑换为 钻石{1}*/
	public static KEY_90: number = 90;
	/**91	公告*/
	public static KEY_91: number = 91;
	/**92	获得5钻石*/
	public static KEY_92: number = 92;
	/**93	心动之旅*/
	public static KEY_93: number = 93;
	/**94	        在你向小野告白前，你们之间发生过哪些暧昧往事？        快用你的超能力集齐50个心动碎片，回味你与小野的心动之旅……*/
	public static KEY_94: number = 94;
	/**95	旁白*/
	public static KEY_95: number = 95;
	/**96	我*/
	public static KEY_96: number = 96;
	/**97	赵小野*/
	public static KEY_97: number = 97;
	/**98	额外剧情*/
	public static KEY_98: number = 98;
	/**99	可获得写真*/
	public static KEY_99: number = 99;
	/**100	去充值*/
	public static KEY_100: number = 100;
	/**101	活动时间*/
	public static KEY_101: number = 101;
	/**102	领取*/
	public static KEY_102: number = 102;
	/**103	奖励叠加（例如充值1288元可领取所有档位奖励）更有小野签名海报可领。*/
	public static KEY_103: number = 103;
	/**104	30 元*/
	public static KEY_104: number = 104;
	/**105	剩余30天*/
	public static KEY_105: number = 105;
	/**106	活动中心*/
	public static KEY_106: number = 106;
	/**107	联动活动*/
	public static KEY_107: number = 107;
	/**108	最新优惠*/
	public static KEY_108: number = 108;
	/**109	月 卡*/
	public static KEY_109: number = 109;
	/**110	累计充值*/
	public static KEY_110: number = 110;
	/**111	登录有奖*/
	public static KEY_111: number = 111;
	/**112	首充双倍*/
	public static KEY_112: number = 112;
	/**113	首充礼包*/
	public static KEY_113: number = 113;
	/**114	免费体力*/
	public static KEY_114: number = 114;
	/**115	礼包兑换*/
	public static KEY_115: number = 115;
	/**116	10元50钻石*/
	public static KEY_116: number = 116;
	/**117	可领取*/
	public static KEY_117: number = 117;
	/**118	第一天*/
	public static KEY_118: number = 118;
	/**119	第二天*/
	public static KEY_119: number = 119;
	/**120	第三天*/
	public static KEY_120: number = 120;
	/**121	第四天*/
	public static KEY_121: number = 121;
	/**122	第五天*/
	public static KEY_122: number = 122;
	/**123	第六天*/
	public static KEY_123: number = 123;
	/**124	第七天*/
	public static KEY_124: number = 124;
	/**125	背包中没有道具，请前往商城购买~*/
	public static KEY_125: number = 125;
	/**126	从商城和活动获得小礼物后别忘了在背包里使用送给女主增加好感度哦*/
	public static KEY_126: number = 126;
	/**127	返回大厅继续获得好感度解锁下一个视频吧，可以继续给女友打电话发微信了哦~*/
	public static KEY_127: number = 127;
	/**128	拥有数量*/
	public static KEY_128: number = 128;
	/**129	您游戏中的名字*/
	public static KEY_129: number = 129;
	/**130	获得{0}心动值*/
	public static KEY_130: number = 130;
	/**131	每次获得*/
	public static KEY_131: number = 131;
	/**132	冷却时长*/
	public static KEY_132: number = 132;
	/**133	发传单的*/
	public static KEY_133: number = 133;
	/**134	消耗体力*/
	public static KEY_134: number = 134;
	/**135	所需道具*/
	public static KEY_135: number = 135;
	/**136	宠物零食*/
	public static KEY_136: number = 136;
	/**137	游戏内时间第10天开放*/
	public static KEY_137: number = 137;
	/**138	点击开始按钮，完成和她的第一次恋爱时间吧！喵~*/
	public static KEY_138: number = 138;
	/**139	冷却时间结束后可以继续进行恋爱活动哦~喵~*/
	public static KEY_139: number = 139;
	/**140	点击返回大厅看看吧*/
	public static KEY_140: number = 140;
	/**141	做饭*/
	public static KEY_141: number = 141;
	/**142	恋爱秘籍*/
	public static KEY_142: number = 142;
	/**143	购买永久一键完成*/
	public static KEY_143: number = 143;
	/**144	已售罄*/
	public static KEY_144: number = 144;
	/**145	每日 00:00 自动刷新*/
	public static KEY_145: number = 145;
	/**146	立即刷新*/
	public static KEY_146: number = 146;
	/**147	游戏活动*/
	public static KEY_147: number = 147;
	/**148	系统公告*/
	public static KEY_148: number = 148;
	/**149	联系我们*/
	public static KEY_149: number = 149;
	/**150	加群领礼包*/
	public static KEY_150: number = 150;
	/**151	公众号领礼包*/
	public static KEY_151: number = 151;
	/**152	官方网址：http://girl.dmgame.com*/
	public static KEY_152: number = 152;
	/**153	微信公众号：xdnssy（关注公众号领福利）*/
	public static KEY_153: number = 153;
	/**154	QQ群一：545937961（已满）*/
	public static KEY_154: number = 154;
	/**155	QQ群二：547467858*/
	public static KEY_155: number = 155;
	/**156	点击这里拨号，快开始你们第一次通话吧！喵~*/
	public static KEY_156: number = 156;
	/**157	通话中…*/
	public static KEY_157: number = 157;
	/**158	选择回答回应女友吧，选择之前要三思而后行哦~喵~*/
	public static KEY_158: number = 158;
	/**159	做的不错哦，女友对你的好感度增加了~喵~*/
	public static KEY_159: number = 159;
	/**160	保底获得*/
	public static KEY_160: number = 160;
	/**161	最高获得*/
	public static KEY_161: number = 161;
	/**162	连续一天*/
	public static KEY_162: number = 162;
	/**163	连续二天*/
	public static KEY_163: number = 163;
	/**164	连续三天*/
	public static KEY_164: number = 164;
	/**165	说明*/
	public static KEY_165: number = 165;
	/**166	连续1天购买红包可随机获得90-500钻石。*/
	public static KEY_166: number = 166;
	/**167	连续2天购买红包可随机获得120-800钻石。*/
	public static KEY_167: number = 167;
	/**168	连续3天及3天以上购买红包可随机获得150-1000钻石。*/
	public static KEY_168: number = 168;
	/**169	中途若有一天中断将从第一天重新开始计算。*/
	public static KEY_169: number = 169;
	/**170	您当前没有邮件！*/
	public static KEY_170: number = 170;
	/**171	主人公*/
	public static KEY_171: number = 171;
	/**172	角色ID*/
	public static KEY_172: number = 172;
	/**173	版本：1.0.3*/
	public static KEY_173: number = 173;
	/**174	返回大厅*/
	public static KEY_174: number = 174;
	/**175	音乐*/
	public static KEY_175: number = 175;
	/**176	协议*/
	public static KEY_176: number = 176;
	/**177	邮件*/
	public static KEY_177: number = 177;
	/**178	回 忆*/
	public static KEY_178: number = 178;
	/**179	珍 藏*/
	public static KEY_179: number = 179;
	/**180	背 景*/
	public static KEY_180: number = 180;
	/**181	点击播放视频，属于心动女生的第一次回忆！喵~*/
	public static KEY_181: number = 181;
	/**182	有新功能解锁了~点击返回大厅看看吧~*/
	public static KEY_182: number = 182;
	/**183	购买数量*/
	public static KEY_183: number = 183;
	/**184	已购买*/
	public static KEY_184: number = 184;
	/**185	来自*/
	public static KEY_185: number = 185;
	/**186	点击这里给她点赞，可以增加好感度哦~喵~*/
	public static KEY_186: number = 186;
	/**187	点击这里评论微��，选择评论要三思后行哦~喵~*/
	public static KEY_187: number = 187;
	/**188	对方正在输入…*/
	public static KEY_188: number = 188;
	/**189	立即回复*/
	public static KEY_189: number = 189;
	/**190	购买永久微信秒回*/
	public static KEY_190: number = 190;
	/**191	点击这里，选择你想要发送的消息~喵~*/
	public static KEY_191: number = 191;
	/**192	好像有新的事件发生了，点击这里返回主界面，喵~*/
	public static KEY_192: number = 192;
	/**193	经验*/
	public static KEY_193: number = 193;
	/**194	获得经验*/
	public static KEY_194: number = 194;
	/**195	购买永久无冷却*/
	public static KEY_195: number = 195;
	/**196	点击工作按钮，快速赚取第一笔收入，可以开心的买买买啦~*/
	public static KEY_196: number = 196;
	/**197	冷却时间结束后可以继续进行工作了哦~喵~*/
	public static KEY_197: number = 197;
	/**198	工作获得经验累积后可以升职获得更多金币哦~喵~*/
	public static KEY_198: number = 198;
	/**199	新功能开放啦~女友在等你给她打电话哟~喵~*/
	public static KEY_199: number = 199;
	/**200	恭喜你解锁了恋爱功能，可以快速收集好感度了哦~*/
	public static KEY_200: number = 200;
	/**201	钱不是万能的，但是没有钱是万万不能的，工作是赚金币的重要途径哦！喵~*/
	public static KEY_201: number = 201;
	/**202	视频开放啦~点击右侧视频按钮观看视频！喵~*/
	public static KEY_202: number = 202;
	/**203	微信开放啦~快给她发个消息问候一下吧~喵~*/
	public static KEY_203: number = 203;
	/**204	恭喜你，女友现在对你好感满满，可以欣赏女友的视频了，*/
	public static KEY_204: number = 204;
	/**205	背包存放您获得的各种物品，点击打开背包~喵~*/
	public static KEY_205: number = 205;
	/**206	微博功能开放啦~可以查看和点赞评论女友发表的微博动态了哦~*/
	public static KEY_206: number = 206;
	/**207	资源加载中，请稍候…*/
	public static KEY_207: number = 207;
	/**208	本应用由 深圳市正易龙科技有限公司 提供*/
	public static KEY_208: number = 208;
	/**209	健康游戏忠告*/
	public static KEY_209: number = 209;
	/**210	抵制不良游戏    拒绝盗版游戏*/
	public static KEY_210: number = 210;
	/**211	注意自我保护    谨防受骗上当*/
	public static KEY_211: number = 211;
	/**212	适度游戏益脑    沉迷游戏伤身*/
	public static KEY_212: number = 212;
	/**213	合理安排时间    享受健康生活*/
	public static KEY_213: number = 213;
	/**214	请选择*/
	public static KEY_214: number = 214;
	/**215	使用*/
	public static KEY_215: number = 215;
	/**216	使用中*/
	public static KEY_216: number = 216;
	/**217	加载配置文件失败，请重试*/
	public static KEY_217: number = 217;
	/**218	用户未登录*/
	public static KEY_218: number = 218;
	/**219	用户登录已过期或未登录*/
	public static KEY_219: number = 219;
	/**220	手机号码格式有误*/
	public static KEY_220: number = 220;
	/**221	用户状态暂时禁用*/
	public static KEY_221: number = 221;
	/**222	用户状态封号*/
	public static KEY_222: number = 222;
	/**223	短信发送失败错误码*/
	public static KEY_223: number = 223;
	/**224	距上次短信发送时间未达60秒*/
	public static KEY_224: number = 224;
	/**225	验证码过期*/
	public static KEY_225: number = 225;
	/**226	验证码有误*/
	public static KEY_226: number = 226;
	/**227	要求用户重新获取验证码*/
	public static KEY_227: number = 227;
	/**228	女主已购买无需再次购买*/
	public static KEY_228: number = 228;
	/**229	7k7k支付拉取失败请重试*/
	public static KEY_229: number = 229;
	/**230	支付宝支付拉取失败请重试*/
	public static KEY_230: number = 230;
	/**231	微信支付拉取失败请重试*/
	public static KEY_231: number = 231;
	/**232	玩吧QQ支付拉取失败请重试*/
	public static KEY_232: number = 232;
	/**233	360支付拉取失败请重试*/
	public static KEY_233: number = 233;
	/**234	216支付拉取失败请重试*/
	public static KEY_234: number = 234;
	/**235	订单不存在*/
	public static KEY_235: number = 235;
	/**236	交易回调鉴权失败*/
	public static KEY_236: number = 236;
	/**237	交易服务器连接失败*/
	public static KEY_237: number = 237;
	/**238	传入值有误*/
	public static KEY_238: number = 238;
	/**239	登录账号格式有误*/
	public static KEY_239: number = 239;
	/**240	密码格式有误*/
	public static KEY_240: number = 240;
	/**241	昵称在黑名单中*/
	public static KEY_241: number = 241;
	/**242	昵称长度不符合*/
	public static KEY_242: number = 242;
	/**243	用户已经注册*/
	public static KEY_243: number = 243;
	/**244	用户不存在*/
	public static KEY_244: number = 244;
	/**245	用户状态不正常*/
	public static KEY_245: number = 245;
	/**246	目标账号不存在*/
	public static KEY_246: number = 246;
	/**247	已绑定手机号*/
	public static KEY_247: number = 247;
	/**248	手机号已被绑定*/
	public static KEY_248: number = 248;
	/**249	您传入的兑换码不存在*/
	public static KEY_249: number = 249;
	/**250	已被兑换*/
	public static KEY_250: number = 250;
	/**251	目标女主不存在*/
	public static KEY_251: number = 251;
	/**252	没有目标女主的进度*/
	public static KEY_252: number = 252;
	/**253	您已经收藏了目标节点请勿重新收藏*/
	public static KEY_253: number = 253;
	/**254	不可收藏当前节点*/
	public static KEY_254: number = 254;
	/**255	尚未收藏数据*/
	public static KEY_255: number = 255;
	/**256	您尚未收藏该��点*/
	public static KEY_256: number = 256;
	/**257	聊天节点数据不存在*/
	public static KEY_257: number = 257;
	/**258	服务端未接收到文件上传*/
	public static KEY_258: number = 258;
	/**259	OSS故障*/
	public static KEY_259: number = 259;
	/**260	是否退出游戏*/
	public static KEY_260: number = 260;
	/**261	是否返回游戏大厅*/
	public static KEY_261: number = 261;
	/**262	支付失败*/
	public static KEY_262: number = 262;
	/**263	支付取消*/
	public static KEY_263: number = 263;
	/**264	支付成功*/
	public static KEY_264: number = 264;
	/**265	"解锁{0}功能,加送{1}"*/
	public static KEY_265: number = 265;
	/**266	只需{0}元即可获得*/
	public static KEY_266: number = 266;
	/**267	请选择章、请选择节*/
	public static KEY_267: number = 267;
	/**268	资源加载中*/
	public static KEY_268: number = 268;
	/**269	资源加载完毕*/
	public static KEY_269: number = 269;
	/**270	正在偷瞄女孩*/
	public static KEY_270: number = 270;
	/**271	正在整理形象*/
	public static KEY_271: number = 271;
	/**272	正在翻看恋爱秘籍*/
	public static KEY_272: number = 272;
	/**273	立即绑定*/
	public static KEY_273: number = 273;
	/**274	暂不绑定*/
	public static KEY_274: number = 274;
	/**275	验证码格式有误*/
	public static KEY_275: number = 275;
	/**276	请输入正确的手机号码*/
	public static KEY_276: number = 276;
	/**277	请勾选同意用户协议*/
	public static KEY_277: number = 277;
	/**278	请稍候*/
	public static KEY_278: number = 278;
	/**279	验证码错误次数过多，请稍后再试*/
	public static KEY_279: number = 279;
	/**280	已发送*/
	public static KEY_280: number = 280;
	/**281	跳过视频*/
	public static KEY_281: number = 281;
	/**282	恋爱养成游戏，一段怦然心动的恋爱旅程等待着你。*/
	public static KEY_282: number = 282;
	/**283	声音加载失败，请检查您的网络后重试*/
	public static KEY_283: number = 283;
	/**284	授权失败!*/
	public static KEY_284: number = 284;
	/**285	其他错误*/
	public static KEY_285: number = 285;
	/**286	参数错误*/
	public static KEY_286: number = 286;
	/**287	支付结果请求超时*/
	public static KEY_287: number = 287;
	/**288	非足额支付（充值成功，未完成支付）*/
	public static KEY_288: number = 288;
	/**289	初始化失败*/
	public static KEY_289: number = 289;
	/**290	大家一起来玩吧*/
	public static KEY_290: number = 290;
	/**291	领取成功，奖励已放入背包中*/
	public static KEY_291: number = 291;
	/**292	确定要解锁视频吗?*/
	public static KEY_292: number = 292;
	/**293	确定要解锁背景吗?*/
	public static KEY_293: number = 293;
	/**294	确定设置当前为背景吗?*/
	public static KEY_294: number = 294;
	/**295	领取成功*/
	public static KEY_295: number = 295;
	/**296	请求超时，请稍候再试*/
	public static KEY_296: number = 296;
	/**297	返回数据有误*/
	public static KEY_297: number = 297;
	/**298	网络无法连接，请检查您的网络后重试*/
	public static KEY_298: number = 298;
	/**299	活动规则：活动期间，累计充值达到对应档位将获得额外奖励，奖励叠加（例如充值{0}元可领取所有累计充值奖励）*/
	public static KEY_299: number = 299;
	/**300	至亲爱的玩家*/
	public static KEY_300: number = 300;
	/**301	公众号*/
	public static KEY_301: number = 301;
	/**302	客服QQ*/
	public static KEY_302: number = 302;
	/**303	每日首次分享可获得钻石奖励哟!*/
	public static KEY_303: number = 303;
	/**304	比赛信息*/
	public static KEY_304: number = 304;
	/**305	《闲玩S》 诚招合作伙伴了！*/
	public static KEY_305: number = 305;
	/**306	公      告*/
	public static KEY_306: number = 306;
	/**307	分享朋友圈，免费参赛！*/
	public static KEY_307: number = 307;
	/**308	已开启心动之旅，将剩余的心动碎片 x {0} 兑换为*/
	public static KEY_308: number = 308;
	/**309	声音加载失败*/
	public static KEY_309: number = 309;
	/**310	网络请求异常*/
	public static KEY_310: number = 310;
	/**311	兑换成功，奖励已放入背包中*/
	public static KEY_311: number = 311;
	/**312	剩余{0}天*/
	public static KEY_312: number = 312;
	/**313	使用成功*/
	public static KEY_313: number = 313;
	/**314	恋爱宝典*/
	public static KEY_314: number = 314;
	/**315	增加10工作经验*/
	public static KEY_315: number = 315;
	/**316	（不能在背包中使用）*/
	public static KEY_316: number = 316;
	/**317	购买成功*/
	public static KEY_317: number = 317;
	/**318	游戏内时间第{0}天开放*/
	public static KEY_318: number = 318;
	/**319	1小时*/
	public static KEY_319: number = 319;
	/**320	2小时*/
	public static KEY_320: number = 320;
	/**321	1小时 {0} 分钟*/
	public static KEY_321: number = 321;
	/**322	2小时 {0} 分钟*/
	public static KEY_322: number = 322;
	/**323	数据错误*/
	public static KEY_323: number = 323;
	/**324	泡图书馆*/
	public static KEY_324: number = 324;
	/**325	约吃饭*/
	public static KEY_325: number = 325;
	/**326	看电影*/
	public static KEY_326: number = 326;
	/**327	逛街*/
	public static KEY_327: number = 327;
	/**328	唱歌*/
	public static KEY_328: number = 328;
	/**329	游公园*/
	public static KEY_329: number = 329;
	/**330	做运动*/
	public static KEY_330: number = 330;
	/**331	逗猫*/
	public static KEY_331: number = 331;
	/**332	游乐园*/
	public static KEY_332: number = 332;
	/**333	获得钻石*/
	public static KEY_333: number = 333;
	/**334	是否返回大厅？*/
	public static KEY_334: number = 334;
	/**335	第{0}天开放*/
	public static KEY_335: number = 335;
	/**336	观看视频*/
	public static KEY_336: number = 336;
	/**337	游戏第{0}天开放*/
	public static KEY_337: number = 337;
	/**338	珍藏*/
	public static KEY_338: number = 338;
	/**339	背景*/
	public static KEY_339: number = 339;
	/**340	设置成功*/
	public static KEY_340: number = 340;
	/**341	送给女生可获得*/
	public static KEY_341: number = 341;
	/**342	亲密度*/
	public static KEY_342: number = 342;
	/**343	今日可购买*/
	public static KEY_343: number = 343;
	/**344	钻石数量不足，是否充值钻石？*/
	public static KEY_344: number = 344;
	/**345	刷新成功*/
	public static KEY_345: number = 345;
	/**346	确定花费 {0} 钻石购买 {1} 吗？*/
	public static KEY_346: number = 346;
	/**347	确定花费 {0} 金币购买 {1} 吗？*/
	public static KEY_347: number = 347;
	/**348	购买*/
	public static KEY_348: number = 348;
	/**349	只需 {0} 元即可获得*/
	public static KEY_349: number = 349;
	/**350	今天*/
	public static KEY_350: number = 350;
	/**351	{0} 天前*/
	public static KEY_351: number = 351;
	/**352	点击左侧输入框，选择回复内容*/
	public static KEY_352: number = 352;
	/**353	剩余次数*/
	public static KEY_353: number = 353;
	/**354	工作次数*/
	public static KEY_354: number = 354;
	/**355	获得 {0} 金币*/
	public static KEY_355: number = 355;
	/**356	恭喜你获得*/
	public static KEY_356: number = 356;
	/**357	礼包*/
	public static KEY_357: number = 357;
	/**358	收到玩吧礼包*/
	public static KEY_358: number = 358;
	/**359	快去看看小野在干什么*/
	public static KEY_359: number = 359;
	/**360	快给小野发个微信吧~*/
	public static KEY_360: number = 360;
	/**361	快给小野打个电话吧~*/
	public static KEY_361: number = 361;
	/**362	如观看视频后无法正常游戏请更换其它浏览器重新进入游戏。\n推荐：Safari浏览器。*/
	public static KEY_362: number = 362;
	/**363	请输入昵称*/
	public static KEY_363: number = 363;
	/**364	我是一个普通的大学生，做梦也没想到校花竟然成为了我的女朋友，但是现实中的误会却让我们一次次伤害对方……*/
	public static KEY_364: number = 364;
	/**365	登录成功*/
	public static KEY_365: number = 365;
	/**366	登录失败*/
	public static KEY_366: number = 366;
	/**367	继续*/
	public static KEY_367: number = 367;
	/**368	转换协议*/
	public static KEY_368: number = 368;
	/**369	请求成功*/
	public static KEY_369: number = 369;
	/**370	创建*/
	public static KEY_370: number = 370;
	/**371	接受*/
	public static KEY_371: number = 371;
	/**372	非权威信息*/
	public static KEY_372: number = 372;
	/**373	无内容*/
	public static KEY_373: number = 373;
	/**374	重置内容*/
	public static KEY_374: number = 374;
	/**375	局部内容*/
	public static KEY_375: number = 375;
	/**376	多样选择*/
	public static KEY_376: number = 376;
	/**377	永久移动*/
	public static KEY_377: number = 377;
	/**378	创立*/
	public static KEY_378: number = 378;
	/**379	观察别的部分*/
	public static KEY_379: number = 379;
	/**380	只读*/
	public static KEY_380: number = 380;
	/**381	(没有用的)*/
	public static KEY_381: number = 381;
	/**382	临时重发*/
	public static KEY_382: number = 382;
	/**383	坏请求*/
	public static KEY_383: number = 383;
	/**384	未授权的*/
	public static KEY_384: number = 384;
	/**385	必需的支付*/
	public static KEY_385: number = 385;
	/**386	禁用*/
	public static KEY_386: number = 386;
	/**387	没有找到*/
	public static KEY_387: number = 387;
	/**388	不被允许的方法*/
	public static KEY_388: number = 388;
	/**389	不接受*/
	public static KEY_389: number = 389;
	/**390	代理服务器认证所必需*/
	public static KEY_390: number = 390;
	/**391	请求超时*/
	public static KEY_391: number = 391;
	/**392	冲突*/
	public static KEY_392: number = 392;
	/**393	停止*/
	public static KEY_393: number = 393;
	/**394	必需的长度*/
	public static KEY_394: number = 394;
	/**395	预处理失败*/
	public static KEY_395: number = 395;
	/**396	请求实体太大*/
	public static KEY_396: number = 396;
	/**397	请求的URI过长*/
	public static KEY_397: number = 397;
	/**398	不被支持的媒体类型*/
	public static KEY_398: number = 398;
	/**399	请求范围不满足*/
	public static KEY_399: number = 399;
	/**400	期望失败*/
	public static KEY_400: number = 400;
	/**401	服务器内部错误*/
	public static KEY_401: number = 401;
	/**402	不能实现*/
	public static KEY_402: number = 402;
	/**403	坏网关*/
	public static KEY_403: number = 403;
	/**404	难以获得的服务*/
	public static KEY_404: number = 404;
	/**405	网关超时*/
	public static KEY_405: number = 405;
	/**406	HTTP版本不支持*/
	public static KEY_406: number = 406;
	/**407	"为了您更流畅的游戏体验,请使用\n谷歌浏览器"*/
	public static KEY_407: number = 407;
	/**408	加载开始*/
	public static KEY_408: number = 408;
	/**409	加载结束*/
	public static KEY_409: number = 409;

	//"{"cn":{"0":"零","1":"一","2":"二","3":"三","4":"四","5":"五","6":"六","7":"七","8":"八","9":"九","10":"十","11":"十一","12":"十二","13":"十三","14":"十四","15":"十五","16":"百","17":"千","18":"万","19":"亿","20":"年","21":"月","22":"日","23":"天","24":"时","25":"分","26":"秒","27":"周日","28":"周一","29":"周二","30":"周三","31":"周四","32":"周五","33":"周六","34":"确定","35":"取消","36":"提示","37":"重试","38":"网络连接中断，请检查移动网络或WIFI设置","39":"我已查看并同意","40":"用户协议","41":"手机号","42":"请输入手机号","43":"验证码","44":"请输入验证码","45":"获取验证码","46":"快速登录","47":"游客登录","48":"开    始","49":"跳过","50":"不要去迎合女人的时间，让女人主动迎合你，因为不忙的男人在女人眼里都是低价值的。","51":"互动的最高境界，就是瞎扯淡，看到什么东西，就乱编什么故事","52":"太正经的老实男人很难泡到美女，正如人们常说：男人不坏，女人不爱","53":"女人永远都觉得男人穿西装最帅了","54":"穿着打扮上面，除了衣服鞋子要贵一点，其他的，干净得体就可以了","55":"灰色和黑色是男人永不过时的颜色，要想有男人形象，��好就别穿的花花绿绿的","56":"男人一定要学会锻炼，女人大部分都喜欢一个强壮的男人","57":"一定要学会几招互动冷场时候补救的办法，比如魔术","58":"男人没有什么行为比翻看女人的手袋更令她讨厌","59":"与女人逛街的时候带一百元为她花完的效果，好过你带一万元为她花五千元的几倍","60":"其实说什么不重要，重要的是你能否让她笑，这个是关键","61":"你们关系没有好到无话不谈的时候，最好不要轻易向对方表白，失败率很高","62":"做一个精致的男人，时时刻刻保持迷人的微笑，最佳着装以及口腔卫生等最好的状态","63":"如果你从来没有让你的女人痛哭过，那就说明你在她心中根本不重要","64":"跟女生表白可以这样说：我给你讲个爱情故事吧，有一天，我遇见了你","65":"和女生聊天时，如果你一直长篇大论，自言自语，她一定会回你好吧，哦，呵呵，所以一定要留下���女生接话的谈资，给她留出回复空间","66":"俗话说言多必失，聊天时废话太多也会暴露你的需求感让女生觉得你是一个低价值的人，所以不要用太多语气词和废话","67":"女生善于转移话题，当话题的走向完全被对方引导并占据主动时，你的回复空间会越来越窄，所以尽可能用关键字去延伸话题","68":"一味的幽默风趣只会让女生觉得你是个逗比，在有了一定的幽默风趣后，一定要在对话中穿插一些真实的东西","69":"搭讪开场白：我想认识你，但我觉得没有好的方法，所以就直接过来跟你打个招呼，我叫……","70":"让女生留电话：我觉得跟你聊天挺舒服的，说不定以后我们可以成为很好的朋友，我们可以交换个联系方式到时候再联系","71":"当一个女生总是找你说话，说一些无关紧要的话的时候，往往是喜欢的一个暗示","72":"大部分女生觉得厌烦的行为：给她打太多电话，太早告诉她你对她有感觉，为了满足她而不为自己考虑","73":"大多女性喜欢直率的表达，她们会觉得这样的男性充满魅力，相反，她们讨厌那种说法拐弯抹角、吞吞吐吐、过分含蓄的男性","74":"女人有一种心理防卫本能，经常用语言掩饰自己的本意，不喜欢别人一语道破天机，如果男人自作聪明说破女人的心事，往往会引起反感","75":"女人不喜欢两类男人：一种是在女人面前呆若木鸡，少言寡语，另一种是在女人面前夸夸其谈，举止夸张","76":"女人喜欢刚毅、果敢、热情、爽朗、勇于负责的男子汉，而对畏首畏尾、优柔寡断、迟疑不决的男人心存鄙弃","77":"女生不回微信的原因：时间太久了不知道怎么回，故意装的很忙，发的问题太敏感，你还不够重要","78":"有时候还是需要保持一点神秘感，对方猜不透你，对你的兴趣也就越来越浓，不会随着时间变淡","79":"加载中…","80":"解锁心动之旅需要50个碎片，当前数量{0}个。","81":"获取碎片","82":"神秘商店","83":"恋爱场景：运动、逗猫、游乐园","84":"解锁《纯情房东俏房客》任意结局","85":"恋爱","86":"亲爱的：","87":"    故事到这里暂告一段落，与你甜蜜相恋的这些天里，是我最开心的日子。","88":"最新剧情已开拍，详情请关注公众号:《心动女生手游》  玩家群:545937961","89":"奖励","90":"已开启心动之旅，将获得的心动碎片{0}  兑换为 钻石{1}","91":"公告","92":"获得5钻石","93":"心动之旅","94":"        在你向小野告白前，你们之间发生过哪些暧昧往事？        快用你的超能力集齐50个心动碎片，回味你与小野的心动之旅……","95":"旁白","96":"我","97":"赵小野","98":"额外剧情","99":"可获得写真","100":"去充值","101":"活动时间","102":"领取","103":"奖励叠加（例如充值1288元可领取所有档位奖励）更有小野签名海报可领。","104":"30 元","105":"剩余30天","106":"活动中心","107":"联动活动","108":"最新优惠","109":"月 卡","110":"累计充值","111":"登录有奖","112":"首充双倍","113":"首充礼包","114":"免费体力","115":"礼包兑换","116":"10元50钻石","117":"可领取","118":"第一天","119":"第二天","120":"第三天","121":"第四天","122":"第五天","123":"第六天","124":"第七天","125":"背包中没有道具，请前往商城购买~","126":"从商城和活动获得小礼物后别忘了在背包里使用送给女主增加好感度哦","127":"返回大厅继续获得好感度解锁下一个视频吧，可以继续给女友打电话发微信了哦~","128":"拥有数量","129":"您游戏中的名字","130":"获得{0}心动值","131":"每次获得","132":"冷却时长","133":"发传单的","134":"消耗体力","135":"所需道具","136":"宠物零食","137":"游戏内时间第10天开放","138":"点击开始按钮，完成和她的第一次恋爱时间吧！喵~","139":"冷却时间结束后可以继续进行恋爱活动哦~喵~","140":"点击返回大厅看看吧","141":"做饭","142":"恋爱秘籍","143":"购买永久一键完成","144":"已售罄","145":"每日 00:00 自动刷新","146":"立即刷新","147":"游戏活动","148":"系统公告","149":"联系我们","150":"加群领礼包","151":"公众号领礼包","152":"官方网址：http://girl.dmgame.com","153":"微信公众号：xdnssy（关注公众号领福利）","154":"QQ群一：545937961（已满）","155":"QQ群二：547467858","156":"点击这里拨号，快开始你们第一次通话吧！喵~","157":"通话中…","158":"选择回答回应女友吧，选择之前要三思而后行哦~喵~","159":"做的不错哦，女友对你的好感度增加了~喵~","160":"保底获得","161":"最高获得","162":"连续一天","163":"连续二天","164":"连续三天","165":"说明","166":"连续1天购买红包可随机获得90-500钻石。","167":"连续2天购买红包可随机获得120-800钻石。","168":"连续3天及3天以上购买���包可随机获得150-1000钻石。","169":"中途若有一天中断将从第一天重新开始计算。","170":"您当前没有邮件！","171":"主人公","172":"角色ID","173":"版本：1.0.3","174":"返回大厅","175":"音乐","176":"协议","177":"邮件","178":"回 忆","179":"珍 藏","180":"背 景","181":"点击播放视频，属于心动女生的第一次回忆！喵~","182":"有新功能解锁了~点击返回大厅看看吧~","183":"购买数量","184":"已购买","185":"来自","186":"点击这里给她点赞，可以增加好感度哦~喵~","187":"点击这里评论微博，选择评论要三思后行哦~喵~","188":"对方正在输入…","189":"立即回复","190":"购买永久微信秒回","191":"点击这里，选择你想要发送的消息~喵~","192":"好像有新的事件发生了，点击这里返回主界面，喵~","193":"经验","194":"获得经验","195":"购买永久无冷却","196":"点击工作按钮，快速赚取第一笔收入，可以开心的买买买啦~","197":"冷却时间结束后可以继续进行工作了哦~喵~","198":"工作获得经验累积后可以升职获得更多金币哦~喵~","199":"新功能开放啦~女友在等你给她打电话哟~喵~","200":"恭喜你解锁了恋爱功能，可以快速收集好感度了哦~","201":"钱不是万能的，但是没有钱是万万不能的，工作是赚金币的重要途径哦！喵~","202":"视频开放啦~点击右侧视频按钮观看视频！喵~","203":"微信开放啦~快给她发个消息问候一下吧~喵~","204":"恭喜你，女友现在对你好感满满，可以欣赏女友的视频了，","205":"背包存放您获得的各种物品，点击打开背包~喵~","206":"微博功能开放啦~可以查看和点赞评论女友发表的微博动态了哦~","207":"资源加载中，请稍候…","208":"本应用由 深圳市正易龙科技有限公司 提供","209":"健康游戏忠告","210":"抵制不良游戏    拒绝盗版游戏","211":"注意自我保护    谨防受骗上当","212":"适度游戏益脑    沉迷��戏伤身","213":"合理安排时间    享受健康生活","214":"请选择","215":"使用","216":"使用中","217":"加载配置文件失败，请重试","218":"用户未登录","219":"用户登录已过期或未登录","220":"手机号码格式有误","221":"用户状态暂时禁用","222":"用户状态封号","223":"短信发送失败错误码","224":"距上次短信发送时间未达60秒","225":"验证码过期","226":"验证码有误","227":"要求用户重新获取验证码","228":"女主已购买无需再次购买","229":"7k7k支付拉取失败请重试","230":"支付宝支付拉取失败请重试","231":"微信支付拉取失败请重试","232":"玩吧QQ支付拉取失败请重试","233":"360支付拉取失败请重试","234":"216支付拉取失败请重试","235":"订单不存在","236":"交易回调鉴权失败","237":"交易服务器连接失败","238":"传入值有误","239":"登录账号格式有误","240":"密码格式有误","241":"昵称在黑名单中","242":"昵称长度不符合","243":"用户已经注册","244":"用户不存在","245":"用户状态不正常","246":"目标账号不存在","247":"已绑定手机号","248":"手机号已被绑定","249":"您传入的兑换码不存在","250":"已被兑换","251":"目标女主不存在","252":"没有目标女主的进度","253":"您已经收藏了目标节点请勿重新收藏","254":"不可收藏当前节点","255":"尚未收藏数据","256":"您尚未收藏该节点","257":"聊天节点数据不存在","258":"服务端未接收到文件上传","259":"OSS故障","260":"是否退出游戏","261":"是否返回游戏大厅","262":"支付失败","263":"支付取消","264":"支付成功","265":"解锁{0}功能,加送{1}","266":"只需{0}元即可获得","267":"请选择章、请选择节","268":"资源加载中","269":"资源加载完毕","270":"正在偷瞄女孩","271":"正在整理形象","272":"正在翻看恋爱秘籍","273":"立即绑定","274":"暂不绑定","275":"验证码格式有误","276":"请输入正确的手机号码","277":"请勾选同意用户协议","278":"请稍候","279":"验证码错误次数过多，请稍后再试","280":"已发送","281":"跳过视频","282":"恋爱养成游戏，一段怦然心动的恋爱旅程等待着你。","283":"声音加载失败，请检查您的网络后重试","284":"授权失败!","285":"其他错误","286":"参数错误","287":"支付结果请求超时","288":"非足额支付（充值成功，未完成支付）","289":"初始化失败","290":"大家一起来玩吧","291":"领取成功，奖励已放入背包中","292":"确定要解锁视频吗?","293":"确定要解锁背景吗?","294":"确定设置当前为背景吗?","295":"领取成功","296":"请求超时，请稍候再试","297":"返回数据有误","298":"网络无法连接，请检查您的网络后重试","299":"活动规则：活动期间，累计充值达到对应档位将获得额外奖励，奖励叠加（例如充值{0}元可领取所有累计充值奖励）","300":"至亲爱的玩家","301":"公众号","302":"客服QQ","303":"每日首���分享可获得钻石奖励哟!","304":"比赛信息","305":"《闲玩S》 诚招合作伙伴了！","306":"公      告","307":"分享朋友圈，免费参赛！","308":"已开启心动之旅，将剩余的心动碎片 x {0} 兑换为","309":"声音加载失败","310":"网络请求异常","311":"兑换成功，奖励已放入背包中","312":"剩余{0}天","313":"使用成功","314":"恋爱宝典","315":"增加10工作经验","316":"（不能在背包中使用）","317":"购买成功","318":"游戏内时间第{0}天开放","319":"1小时","320":"2小时","321":"1小时 {0} 分钟","322":"2小时 {0} 分钟","323":"数据错误","324":"泡图书馆","325":"约吃饭","326":"看电影","327":"逛街","328":"唱歌","329":"游公园","330":"做运动","331":"逗猫","332":"游乐园","333":"获得钻石","334":"是否返回大厅？","335":"第{0}天开放","336":"观看视频","337":"游戏第{0}天开放","338":"珍藏","339":"背景","340":"设置成功","341":"送给女生可获得","342":"亲密度","343":"今日可购买","344":"钻石数量不足，是否充值钻石？","345":"刷新成功","346":"确定花费 {0} 钻石购买 {1} 吗？","347":"确定花费 {0} 金币购买 {1} 吗？","348":"购买","349":"只需 {0} 元即可获得","350":"今天","351":"{0} 天前","352":"点击左侧输入框，选择回复内容","353":"剩余次数","354":"工作次数","355":"获得 {0} 金币","356":"恭喜你获得","357":"礼包","358":"收到玩吧礼包","359":"快去看看小野在干什么","360":"快给小野发个微信吧~","361":"快给小野打个电话吧~","362":"如观看视频后无法正常游戏请更换其它浏览器重新进入游戏。\\n推荐：Safari浏览器。","363":"请输入昵称","364":"我是一个普通的大学生，做梦也没想到校花竟然成为了我的女朋友，但是现实中的误会却让我们一次次伤害对方……","365":"登录成功","366":"登录失败","367":"继续","368":"转换协议","369":"请求成功","370":"创建","371":"接受","372":"非权威���息","373":"无内容","374":"重置内容","375":"局部内容","376":"多样选择","377":"永久移动","378":"创立","379":"观察别的部分","380":"只读","381":"(没有用的)","382":"临时重发","383":"坏请求","384":"未授权的","385":"必需的支付","386":"禁用","387":"没有找到","388":"不被允许的方法","389":"不接受","390":"代理服务器认证所必需","391":"请求超时","392":"冲突","393":"停止","394":"必需的长度","395":"预处理失败","396":"请求实体太大","397":"请求的URI过长","398":"不被支持的媒体类型","399":"请求范围不满足","400":"期望失败","401":"服务器内部错误","402":"不能实现","403":"坏网关","404":"难以获得的服务","405":"网关超时","406":"HTTP版本不支持","407":"为了您更流畅的游戏体验,请使用\\n谷歌浏览器","408":"加载开始","409":"加载结束"}}"
}