class EnumEffectType {
    /**无特效 */
    public static NONE: string = "none";
    /**淡入同时淡出 */
    public static CROSS_FADE: string = "crossfade";
    /**淡出后再淡入 */
    public static CROSS_FADE_IN_THEN_OUT:string = "cross_fade_in_then_out"
    /**场景移动 */
    public static MOVE: string = "LayerNormalMoveModule";
    /**时钟切出切入 */
    public static CLOCK:string = "clock";
    /**上下振动 */
    public static SHAKE1: string = "LayerJumpActionModule";
    /**单次上下振动 */
    public static SHAKE2: string = "LayerJumpOnceActionModule";
    /**左右振动 */
    public static SHAKE3: string = "LayerWaveActionModule";
    /**振动动作 */
    public static SHAKE4: string = "LayerVibrateActionModule";

}