class EnumLogType {

	/**
	 * 日志类型名称
	 */
	public static typeArr: Array<string> = ["info", "error", "debug", "warn", "echo", "性能", "local"];

	/**
	 * 每种类型每页显示日志的最大长度数组
	 */
	public static showArr: Array<number> = [300, 100, 100, 100, 100, 10, 1];

	/**
	 * 每种类型日志存储的最大条目数
	 */
	public static maxArr: Array<number> = [10000, 10000, 1000, 1000, 2000, 2000, 1000];

	/**
	 * 记录每种类型日志的条目数（从0开始计数）
	 */
	public static indexArr: Array<number> = [0, 0, 0, 0, 0, 0, 0];

	/**
	 * 0 info
	 */
	public static INFO: number = 0;

	/**
	 * 1 error
	 */
	public static ERROR: number = 1;

	/**
	 * 2 debug
	 */
	public static DEBUG: number = 2;

	/**
	 * 3 warn
	 */
	public static WARN: number = 3;

	/**
	 * 4 echo
	 */
	public static ECHO: number = 4;

	/**
	 * 5 性能
	 */
	public static XINGNENG: number = 5;

	/**
	 * 6 localLog
	 */
	public static LOCAL_LOG: number = 6;
}