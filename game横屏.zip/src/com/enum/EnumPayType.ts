class EnumPayType {
	public constructor() {
	}
	/** 购买类型-寇雅：1 */
	public static BUY_KOUYA: number = 1;
	/** 购买类型-超值组合：2 */
	public static BUY_ZUHE: number = 2;
	/** 购买心动币 */
	public static BUY_COIN: number = 3;

	/** 支付类型-微信：1 */
	public static PAY_WECHAT: number = 1;
	/** 支付类型-支付宝：2 */
	public static PAY_ALIPAY: number = 2;

	/**购买方式-心动币 */
	public static BUY_TYPE_COIN: number = 1;
	/**购买方式-现金 */
	public static BUY_TYPE_CASH: number = 2;

	/**默认设置 */
	public static AVG_BUY_TYPE_0: number = 0;
	/**AVG原买断制 */
	public static AVG_BUY_TYPE_1: number = 1;
	/**章节付费 */
	public static AVG_BUY_TYPE_2: number = 2;
	/**自动解锁 */
	public static AVG_BUY_TYPE_3: number = 3;

}