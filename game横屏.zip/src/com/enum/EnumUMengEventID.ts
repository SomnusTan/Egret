class EnumUMengEventID {
    /**游戏章节 */
    public static GAME_CHAPTER: string = "chapter_";
    /**新玩家进入游戏界面 */
    public static GAME_PAGE_COUNT: string = "game_page";
    /** */
    public static GAME_PAY: string = "game_pay";
}