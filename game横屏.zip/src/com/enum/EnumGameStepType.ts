/**
 * 游戏步骤类型
 */
class EnumGameStepType {
    /**购买需求 */
    public static SHOP: string = "shop";
    /**章节购买 */
    public static SUBSCRIPTION: string = "subscription";
    /**对话聊天 */
    public static CHAT: string = "chat";
    /**结局 */
    public static END: string = "end";
}