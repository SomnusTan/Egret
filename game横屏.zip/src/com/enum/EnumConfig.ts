class EnumConfig {

    public static isRelease: number = 0;

    public static isDebug: number = 1;

    public static isHttps: number = 2;

    public static soEasy: number = 3;

    public static hasTouch: number = 4;

    public static skipVideo: number = 5;

    public static skipGuide: number = 6;

    public static CONFIG: string[] = ["isRelease", "isDebug", "isHttps",
        "soEasy", "hasTouch", "skipVideo", "skipGuide"];

    /**
     * 根据索引获取值
     */
    public static getValue(source: number, index: number): number {
        return source >> index & 1;
    }

}