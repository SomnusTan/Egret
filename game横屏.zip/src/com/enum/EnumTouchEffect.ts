class EnumTouchEffect {

    /**放大 */
    public static ADD_SCALE: string = "add_scale";
    /**缩小 */
    public static MIN_SCALE: string = "min_scale";
    /**半透明 */
    public static ALPHA: string = "alpha";
}