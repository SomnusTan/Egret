class EnumAlertContent {
	public constructor() {
	}

	/** 存档，存到某一个档位中 */
	public static SAVE_RECORD: string = "要放弃这段经历，保留新的经历吗？";

	/** 读档，从某一个存档中开始 */
	public static READ_RECORD: string = "当前你与寇雅之间发生的故事都会被覆盖，确定要从这段经历开始吗？";

	/** 与寇雅重新开始AVG */
	public static RESTART_AVG_KOUYA: string = "当前你与寇雅之间发生的故事都会被覆盖，确定要与寇雅<font color='#FF1616'>重新开始</font>吗？";

	/** 购买恋爱道具 */
	public static BUY_LOVE_ITEM: string = "<font color='#8d6b6a'>背包里缺少道具<font color='#f84d5d'>{0}</font>,是否花费<font color='#f84d5d'>{1}金币</font>直接购买？</font>";

	/** 用钻石购买 */
	public static BUY_USE_DIAMOND: string = "<font color='#8d6b6a'>您确定花费<font color='#f84d5d'>{0}钻石</font>购买？</font>";

	/** 用RMB购买 */
	public static BUY_USE_RMB: string = "<font color='#8d6b6a'>您确定花费<font color='#f84d5d'>¥{0}</font>购买？</font>";

	/**使用心动币购买 */
	public static BUY_CHAO_ZHI_GIFT: string = "<font color='#8d6b6a'>您确定花费<font color='#f84d5d'> {0} </font>个心动币购买<br><font color='#f84d5d'>{1}</font>？</font>";
	/**使用心动币购买整包 */
	public static BUY_CHAO_ZHI_GIFT_SINGLE: string = "<font color='#8d6b6a'>您确定花费<font color='#f84d5d'> {0} </font>个心动币购买<br><font color='#f84d5d'>{1}完整游戏内容</font>？</font>";

	/**使用心动币解锁 */
	public static UNLOCK_AVG_VIDEO: string = "<font color='#8d6b6a'>解锁下一部分内容并继续将消耗<br><font color='#f84d5d'>{0}</font>个心动币？</font>";
	/**使用心动币解锁最后一部分 */
	public static UNLOCK_AVG_VIDEO_LAST: string = "<font color='#8d6b6a'>解锁后续全部内容、结局及DLC-他的故事并继续游戏将消耗<br><font color='#f84d5d'>{0}</font>个心动币？</font>";

	/**赵小野中使用心动币购买 */
	public static BUY_GAME2_GIFT: string = "<font color='#8d6b6a'>您是否使用<font color='#f84d5d'>{0}</font>个心动币购买<br><font color='#f84d5d'>[{1}]{2}</font>？</font>";
	/**购买心动币描述 */
	public static BUY_DESC: string = "花费{0}元可以得到{1}心动币";
}