class EnumMoveEnd {
    
    public static LEFT: string = "left";

    public static RIGHT: string = "right";

    public static MIDDLE: string = "middle";
}