class EnumSoundId {

    /**背景音乐 */
    public static BGM: string = "Lovehome";
    /**点击 */
    public static CLICK: string = "click";
    /**哔哔提示 */
    public static NOTICE: string = "notice";
    /**泡泡 */
    public static BUBBLE: string = "bubble";
    /**关闭收起 */
    public static PANEL_CLOSE: string = "panelClose"
    /**写字 */
    public static WRITE: string = "write"
    /**卷起纸 */
    public static SCROLL_PAPER: string = "scrollPaper";
    /**短信提示 */
    public static MESSAGE: string = "message";
    /**心跳 */
    public static HEART: string = "heart";
    /**胶片 */
    public static FILM: string = "film";
    /**来消息 */
    public static RING_MESSAGE: string = "ringMessage";
    /**气泡爆炸 */
    public static BAOZHA: string = "baozha";
}