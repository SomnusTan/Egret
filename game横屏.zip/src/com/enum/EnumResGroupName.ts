class EnumResGroupName {
    /**预加载 */
    public static PRELOAD: string = "preload";
    /**预加载声音 */
    public static PRELOAD_SOUND: string = "proloadSound";
    /**loading动画 */
    public static LOADING: string = "loading";
    /**logo动画 */
    public static LOGO: string = "logo";
    /**logo横屏动画 */
    public static LOGO1: string = "logo1";
    /**气泡，碎片爆破动画 */
    public static SUIPIAN: string = "suipian";
    /**超值组合按钮动画 */
    public static CHAOZHIZUHE: string = "chaozhizuhe";
    /**转场效果滤镜图片 */
    public static EFFECT_FILTER: string = "effectFilter";
}