class EnumImageEffect {
    /**直接消失出现 */
    public static NONE: string = "none";
    /**直接出现 */
    public static NONE_IN: string = "none_in";
    /**直接消失 */
    public static NONE_OUT: string = "none_out";

    /**淡入淡出(交叠) */
    public static FADE_IN_OUT: string = "crossfade";
    /**淡入 */
    public static FADE_IN: string = "fade_in";
    /**淡出 */
    public static FADE_OUT: string = "fade_out";


    /**淡入淡出(替换) */
    public static FADE_IN_OUT_BLACK: string = "crossfade_black";
    /**黑屏淡入 */
    public static FADE_IN_BLACK: string = "fade_in_black";

    /**移动切入切出(替换) */
    public static MOVE_IN_OUT: string = "move_in_out";
    /**移动切出 */
    public static MOVE_OUT: string = "move_out";
    /**移动切入 */
    public static MOVE_IN: string = "move_in";

    /**黑屏切入切出(替换) */
    public static MOVE_BLACK_MASK_IN_OUT: string = "move_black_mask_in_out";
    /**黑屏移动切出 */
    public static MOVE_BLACK_MASK_OUT: string = "move_black_mask_out";
    /**黑屏移动切入 */
    public static MOVE_BLACK_MASK_IN: string = "move_black_mask_in";


    /**闪入闪出(替换) */
    public static FLASH_IN_OUT: string = "flash_in_out";
    /**闪入 */
    public static FLASH_IN: string = "flash_in";
    /**闪出 */
    public static FLASH_OUT: string = "flash_out";

    /**黑色遮罩中切图片,向上下或左右切出切入(替换) */
    public static CUT_IMAGE_IN_OUT: string = "cut_image_in_out";
    /**黑色遮罩中切图片,向上下或左右切入 */
    public static CUT_IMAGE_IN: string = "cut_image_in";
    /**黑色遮罩中切图片,向上下或左右切出 */
    public static CUT_IMAGE_OUT: string = "cut_image_out";


    /**切成两张图片,两张图片移出移入场景 */
    public static CUT_TWO_IMAGE_IN_OUT: string = "cut_two_image_in_out";
    /**切成两张图片,两张图片移入场景 */
    public static CUT_TWO_IMAGE_IN: string = "cut_two_image_in";
    /**切成两张图片,两张图片移出场景 */
    public static CUT_TWO_IMAGE_OUT: string = "cut_two_image_out";

    /**黑屏切入切出(替换)  */
    public static BLACK_MOVE_IN_OUT: string = "black_move_in_out";
    /**黑屏切出 */
    public static BLACK_MOVE_OUT: string = "black_move_out";
    /**黑屏切入 */
    public static BLACK_MOVE_IN: string = "black_move_in";

    /**笔刷切入切出(替换)  */
    public static BRUSH_IN_OUT: string = "brush_in_out";
    /**笔刷切出 */
    public static BRUSH_OUT: string = "brush_out";
    /**笔刷切入 */
    public static BRUSH_IN: string = "brush_in";

    /**中间圆切入切出(替换) */
    public static SPREAD_IN_OUT: string = "spread_in_out";
    /**中间圆切出 */
    public static SPREAD_OUT: string = "spread_out";
    /**中间圆切入 */
    public static SPREAD_IN: string = "spread_in";

    /**时钟切入切出(交叠) */
    public static CLOCK_IN_OUT: string = "clock_in_out";
    /**时间切入遮罩 */
    public static CLOCK_IN_MASK: string = "clock_in_mask";

    /**时钟切入切出(替换) */
    public static CLOCK_IN_OUT_BLACK: string = "clock_in_out_black";
    /**时钟切入 */
    public static CLOCK_IN: string = "clock_in";
    /**时钟切出 */
    public static CLOCK_OUT: string = "clock_out";

    /**合并切入切出(交叠) */
    public static MERGE_IN_OUT: string = "merge_in_out";
    /**合并切入 */
    public static MERGE_IN: string = "merge_in";
    /**合并切出 */
    public static MERGE_OUT: string = "merge_out";

    /**左上到右下渐变切入切出(交叠) */
    public static SHADE_IN_OUT: string = "shade_in_out";
    /**左上到右下渐变切入 */
    public static SHADE_IN: string = "shade_in";
    /**左上到右下渐变切出 */
    public static SHADE_OUT: string = "shade_out";


    /**放大缩小 */
    public static CHANGE_SCALE: string = "change_scale";

    /**移动 */
    public static MOVE: string = "move";

    /**来回移动 */
    public static LOOP_MOVE: string = "loop_move";

    /**抖动 */
    public static SHAKE: string = "shake";

    /**恢复静态效果 */
    public static CLEAR: string = "clear";
    /**回忆效果 */
    public static MEMORY: string = "memory";
    /**暗淡化 */
    public static DARK: string = "dark";
    /**模糊 */
    public static BLUR: string = "blur";
    /**泛白想象 */
    public static WHITE_IMAGINATION: string = "white_imagination";
    /**白光闪烁 */
    public static FLASH_WHITE_LIGHT: string = "flash_white_light";
    /**白屏闪烁 */
    public static FLASH_BLACK_LIGHT: string = "flash_black_light";
    /**摇晃模糊 */
    public static SHAKE_BLUR: string = "shake_blur";
    /**分离震颤 */
    public static APART_SHAKE: string = "apart_shake";
    /**移除分离震颤 */
    public static REMOVE_APART_SHAKE: string = "remove_apart_shake";

    /**
     * 会隐藏显示对象的效果列表
     */
    public static HIDE_EFFECT_LIST: string[] = [
        EnumImageEffect.FADE_OUT, EnumImageEffect.MOVE_OUT, EnumImageEffect.FLASH_OUT, EnumImageEffect.CUT_IMAGE_OUT,
        EnumImageEffect.BLACK_MOVE_OUT, EnumImageEffect.CLOCK_OUT, EnumImageEffect.CLOCK_IN_OUT, EnumImageEffect.NONE_OUT,
        EnumImageEffect.CUT_TWO_IMAGE_OUT, EnumImageEffect.SHADE_OUT, EnumImageEffect.MERGE_OUT, EnumImageEffect.SPREAD_OUT,
        EnumImageEffect.BRUSH_OUT, EnumImageEffect.SHADE_OUT, EnumImageEffect.MOVE_BLACK_MASK_OUT];

    /**
     * 不换底图能执行的效果
     */
    public static NO_CHANGE_EFFECT_LIST: string[] = [
        EnumImageEffect.CHANGE_SCALE, EnumImageEffect.MOVE, EnumImageEffect.LOOP_MOVE, EnumImageEffect.MEMORY,
        EnumImageEffect.DARK, EnumImageEffect.BLUR, EnumImageEffect.SHAKE_BLUR, EnumImageEffect.FLASH_WHITE_LIGHT,
        EnumImageEffect.WHITE_IMAGINATION, EnumImageEffect.CLEAR, EnumImageEffect.FLASH_BLACK_LIGHT, EnumImageEffect.APART_SHAKE,
        EnumImageEffect.SHAKE, EnumImageEffect.REMOVE_APART_SHAKE];

    /**
     * 静态效果
     */
    public static STATIC_EFFECT_LIST: string[] = [
        EnumImageEffect.MEMORY, EnumImageEffect.DARK, EnumImageEffect.BLUR, EnumImageEffect.WHITE_IMAGINATION, EnumImageEffect.SHAKE_BLUR,
        EnumImageEffect.APART_SHAKE, EnumImageEffect.SHAKE, EnumImageEffect.REMOVE_APART_SHAKE
    ];

    public static EFFECT_LIST: any;

    /**
     * 通过特效名或子特效名获取完整的特效名称
     */
    public static getEffect(name: string): EffectName {
        if (this.EFFECT_LIST == null) {
            this.initEffect();
        }
        return this.EFFECT_LIST[name];
    }

    private static initEffect(): void {
        this.EFFECT_LIST = {};
        this.addEffect(this.NONE, this.NONE_IN, this.NONE_OUT, this.NONE_IN);
        this.addEffect(this.FADE_IN_OUT, this.FADE_IN, this.FADE_OUT, this.FADE_IN, null, false);
        this.addEffect(this.FADE_IN_OUT_BLACK, this.FADE_IN_BLACK, this.FADE_OUT, this.FADE_IN_BLACK);
        this.addEffect(this.MOVE_IN_OUT, this.MOVE_IN, this.MOVE_OUT, this.MOVE_IN);
        this.addEffect(this.FLASH_IN_OUT, this.FLASH_IN, this.FLASH_OUT, this.FLASH_IN, this.FLASH_IN);
        this.addEffect(this.CUT_IMAGE_IN_OUT, this.CUT_IMAGE_IN, this.CUT_IMAGE_OUT, this.CUT_IMAGE_IN, this.CUT_IMAGE_IN);
        this.addEffect(this.CUT_TWO_IMAGE_IN_OUT, this.CUT_TWO_IMAGE_IN, this.CUT_TWO_IMAGE_OUT, this.CUT_TWO_IMAGE_IN, this.CUT_TWO_IMAGE_IN);
        this.addEffect(this.BLACK_MOVE_IN_OUT, this.BLACK_MOVE_IN, this.BLACK_MOVE_OUT, this.BLACK_MOVE_IN, this.BLACK_MOVE_IN);
        this.addEffect(this.BRUSH_IN_OUT, this.BRUSH_IN, this.BRUSH_OUT, this.BRUSH_IN, this.FADE_IN);
        this.addEffect(this.SPREAD_IN_OUT, this.SPREAD_IN, this.SPREAD_OUT, this.SPREAD_IN, this.SPREAD_IN);
        this.addEffect(this.CLOCK_IN_OUT, this.CLOCK_IN, this.CLOCK_OUT, this.NONE_IN, this.CLOCK_IN_MASK, false, this.CLOCK_IN_OUT);
        this.addEffect(this.CLOCK_IN_OUT_BLACK, this.CLOCK_IN, this.CLOCK_OUT, this.CLOCK_IN, this.CLOCK_IN);
        this.addEffect(this.MERGE_IN_OUT, this.MERGE_IN, this.MERGE_OUT, this.MERGE_IN, null, false);
        this.addEffect(this.SHADE_IN_OUT, this.SHADE_IN, this.SHADE_OUT, this.SHADE_IN, this.SHADE_IN, false);
        this.addEffect(this.MOVE_BLACK_MASK_IN_OUT, this.MOVE_BLACK_MASK_IN, this.MOVE_BLACK_MASK_OUT, this.MOVE_BLACK_MASK_IN, this.MOVE_BLACK_MASK_IN, false);
    }

    private static addEffect(baseName: string, inName: string, outName: string, showInName: string, defaultInName?: string, inWaitTime: boolean = true, showOutName?: string): void {
        var effectName: EffectName = new EffectName(baseName, showInName, outName, defaultInName, showOutName, inWaitTime);
        this.EFFECT_LIST[baseName] = this.EFFECT_LIST[inName] = this.EFFECT_LIST[outName] = effectName;
    }

    public static isInEffectName(name: string): boolean {
        var effectName: EffectName = this.getEffect(name);
        if (effectName && effectName.isInName(name)) {
            return true;
        }
        return false;
    }

    public static isOutEffectName(name: string): boolean {
        var effectName: EffectName = this.getEffect(name);
        if (effectName && effectName.isOutName(name)) {
            return true;
        }
        return false;
    }
}

class EffectName {
    /**特效完整名 */
    public name: string;
    /**特效切入名 */
    public inName: string;
    /**特效切出名 */
    public outName: string;
    /**首次切入时的效果 */
    public defaultInName: string;
    /**切入是否有等待时间 */
    public inWaitTime: boolean;

    public showOutName: string;

    public constructor(name: string, inName: string, outName: string, defaultInName?: string, showOutName?: string, inWaitTime: boolean = true) {
        this.name = name;
        this.inName = inName;
        this.outName = outName;
        this.defaultInName = defaultInName ? defaultInName : EnumImageEffect.FADE_IN;
        this.inWaitTime = inWaitTime;
        this.showOutName = showOutName;
    }

    public isInName(name: string): boolean {
        return this.inName == name;
    }

    public isOutName(name: string): boolean {
        return this.outName == name;
    }
}