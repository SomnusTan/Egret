module Enum {

    /**
     * 活动枚举
     */
    export enum ACTIVITIES {
        CheckIn = 1,//签到
        Invite = 2,//邀请码
    }
}