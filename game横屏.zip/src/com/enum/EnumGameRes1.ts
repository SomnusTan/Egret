class EnumGameRes1 {
    /**主角对话框 */
    public static DIALOG0: string = "s1_img_dialog0_png";
    /**菜单按钮 */
    public static MENU_BUTTON: string = "s1_btn_menu_png";
    /**回放按钮 */
    public static REVIEW_BUTTON: string = "s1_btn_review_png";

    /**继续游戏 */
    public static NEXT_WORD: string = "s1_img_next_png";
    /**自动中 */
    public static AUTO_PLAYING: string = "s1_auto_png";
    /**快进播放 */
    public static FAST_SPEED_PLAY: string = "s1_img_fast_png";

    /**继续游戏动画材质JSON */
    public static IMG_TEX_JSON: string = "PSWJ_tex_json";
    /**继续游戏动画动作JSON */
    public static IMG_SKE_JSON: string = "PSWJ_ske_json";
    /**继续游戏动画图片 */
    public static IMG_TEX_PNG: string = "PSWJ_tex_png";

    /**名字背景 */
    public static NAME_BG: string = "s1_img_name_bg_png";
    /**选择面板背景 */
    public static SELECT_BG: string = "s1_img_select_bg_png";
    /**选择按钮 */
    public static SELECT_BUTTON: string = "s1_btn_select_png"
    /**选择按钮选中状态 */
    public static SELECTED_BUTTON: string = "s1_btn_selected_png"

    /**存档图标 */
    public static SAVE_ICON: string = "s1_icon_save_png";
    /**读档图标 */
    public static READ_ICON: string = "s1_icon_read_png";
    /**继续图标 */
    public static CONTINUE_ICON: string = "s1_icon_continue_png";
    /**基本菜单按钮 */
    public static MENU_BASE_BUTTON: string = "s1_btn_menu_base_png";

    /**返回按钮 */
    public static BACK_BUTTON: string = "s1_btn_back_png"
    /**设置按钮 */
    public static SETTING_BUTTON: string = "s1_btn_setting_png";

    /**随机按钮 */
    public static RANDOM_BUTTON: string = "s1_btn_random_name_png";
    /**输入框背景 */
    public static INPUT_BG: string = "s1_img_input_bg_png";


}