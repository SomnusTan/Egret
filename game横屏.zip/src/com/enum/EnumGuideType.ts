class EnumGuideType {
	/** 打开菜单 */
	public static OPEN_MENU: number = 0;
	/** AVG保存进度 */
	public static AVG_MENU_SAVE: number = 1;
	/** 回放 */
	public static REVIEW: number = 2;
	/** 解锁了新的回忆 */
	public static DETAIL_MEMORY: number = 3;
	/** AVG求助 */
	public static AVG_HELP: number = 4;
	/** 开始自动播放 */
	public static START_AUTOPLAY: number = 5;
	/** 长按跳过已读内容 */
	public static PRESS_JUMPREAD: number = 6;
	/** 结局分享 */
	public static END_SHARE: number = 7;
	/** 读取存档 */
	public static DETAIL_READ: number = 8;
	/** 打开菜单 */
	public static OPEN_MENU2: number = 9;
	/** AVG读取存档 */
	public static AVG_MENU_READ: number = 10;

	/** ===引导总数量=== */
	public static MAX_NUM: number = 11;

	//==================引导的状态==================
	/** 未引导,可引导 */
	public static STATE_N: string = "n";
	/** 等待引导，不可引导 */
	public static STATE_0: string = "0";
	/** 已经引导，不可引导 */
	public static STATE_1: string = "1";

}