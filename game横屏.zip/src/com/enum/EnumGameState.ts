class EnumGameState {
    /**初始化中 */
    public static INIT: number = 0;
    /**播放开场视频中 */
    public static START_VIDEO: number = 1;
    /**可执行下一步 */
    public static CAN_DO_NEXT: number = 2;
    /**播放音频和文字中 */
    public static VOICE_TYPING_PLAYING: number = 3;
    /**播放视频中 */
    public static VIDEO_PLAYING: number = 4;
    /**取名中 */
    public static BENAME: number = 5;
    /**选项中 */
    public static SELECT: number = 6;
    /**自动时间跳转 */
    public static AUTO_TIME: number = 7;
    /**背景效果中 */
    public static BG_EFFECT_PLAYING: number = 8;
    /**立绘效果中 */
    public static ROLE_EFFECT_PLAYING: number = 9;
    /**音效播放中 */
    public static SOUND_PLAYING: number = 10;
    /**等待微信 */
    public static WAIT_WECHAT: number = 11;
    /**状态机界面 */
    public static SHOW_STATUS: number = 12;
}