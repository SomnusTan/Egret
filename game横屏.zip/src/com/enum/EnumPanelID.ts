class EnumPanelID {

    /**登录面板 */
    public static LOGIN: number = 1;

    /**游戏盒子 */
    public static GAME_HALL: number = 2;

    /**游戏开始视频 */
    public static START_VIDEO: number = 3;

    /**游戏大厅设置 */
    public static GAMEHALL_SETTING: number = 4;

    /**用户协议 */
    public static USER_AGREEMENT: number = 5;

    /**游客登录 */
    public static TOURISTLOGIN: number = 6;

    /**女主详细信息 */
    public static HEROINES_DETAIL: number = 7;

    // /**女主购买 */
    // public static HERONIES_BUY: number = 8;

    /**女主设置 */
    public static HERONIES_SETTING: number = 9;

    /**加载资源loading */
    public static LOADING_RESVIEW: number = 10;

    /**回忆 */
    public static MEMORY: number = 11;

    /**视频按钮面板 */
    public static VIDEO_BUTTON: number = 12;

    /**一个全屏的图片面板 */
    public static FULL_SCREEN_IMAGE: number = 13;

    /**分享面板 */
    public static GAME_SHARE: number = 14;

    /**读档存档面板,@param { uid: 女主id, type: EnumRecordType常量 } */
    public static RECORD: number = 15;

    /**解绑手机 */
    public static UNBIND_PHONE: number = 16;
    /**绑定新手机 */
    public static BIND_NEW_PHONE: number = 17;
    /**游客绑定新手机 */
    public static TOURIST_BIND_PHONE: number = 18;
    /**强制引导的绑定手机 */
    public static FORCE_PHONE_BIND: number = 19;

    /**网络重联 */
    public static RETRY_CONNECT: number = 20;
    /**结局帷幕 */
    public static ENDING: number = 21;
    /**结局分享 */
    public static GAME_SHARE2: number = 22;
    /**其它渠道登录界面 */
    public static OTHER_LOGIN: number = 23;
    /**支付选择界面 */
    public static CHOOSE_PAY: number = 24;
    /**支付选择界面 */
    public static CHAOZHIZUHE: number = 25;

    /**他的故事界面 */
    public static OTHER_STORY: number = 26;
    /**微信二维码支付界面 */
    public static WECHAT_QRCODE: number = 27;
    /**大厅公告界面 */
    public static GAME_NOTICE: number = 28;
    /**心动币充值界面 */
    public static GAME_CHARGE: number = 29;
    /**大厅兑换码面板 */
    public static GAME_INVITE: number = 30;
    /**大厅图片公告界面 */
    public static GAME_IMAGE_NOTICE: number = 31;
    /**兑换码面板 */
    public static GAME_GIFT_KEY: number = 32;
    /**游戏活动面板 */
    public static GAME_ACTIVITIES: number = 33;
    /**tips面板 */
    public static GAME_TIPS: number = 34;

    //===========================房东==================
    /**房东AVG选项界面 */
    public static GAME_FANG_DONG_SELECT: number = 101;
    /**房东AVG取名 */
    public static GAME_FANG_DONG_BENAME: number = 102;
    /**房东AVG菜单 */
    public static GAME_FANG_DONG_MENU: number = 103;
    /**房东AVG回放 */
    public static GAME_FANG_DONG_REVIEW: number = 104;
    /**房东购买面板 */
    public static GAME_FANG_DONG_BUY: number = 105;
    /**房东状态界面 */
    public static GAME_FANG_DONG_STATUS: number = 106;
    /**房东自动解锁界面 */
    public static GAME_FANG_DONG_UNLOCK: number = 107;
    /**房东购买礼包 */
    public static GAME_FANG_DONG_BUY_ALL: number = 108;



    /** 通用弹窗提示 */
    public static ALERT: number = 1000;
    /** 通用弹窗提示 */
    public static ALERT2: number = 1001;
    /** GM面板 */
    public static GM: number = 2000;

    //-------------------------------Game 2 -----------------------------
    /** 微信面板 */
    public static G2_WeixinPanel: number = 200;
    /** 电话面板 */
    public static G2_DianhuaPanel: number = 201;
    /**登录面板 */
    // public static G2_LoginPanel: number = 202;
    /**注册面板 */
    // public static G2_RegisterPanel: number = 203;
    /**接通电话面板 */
    public static G2_JietongPanel: number = 204;
    /**拨号中面板 */
    public static G2_CallingPanel: number = 205;
    /**设置面板 */
    public static G2_SetPanel: number = 206;
    /**恋爱面板 */
    public static G2_LovePanel: number = 207;
    /**工作面板 */
    public static G2_WorkPanel: number = 208;
    /**工作进度面板 */
    public static G2_WorkProPanel: number = 209;
    /**恋爱进度面板 */
    public static G2_LoveProPanel: number = 210;
    /**恋爱完成面板 */
    public static G2_FinishLovePanel: number = 211;
    /**完成工作面板 */
    public static G2_FinishWorkPanel: number = 212;
    /**电话历史面板 */
    public static G2_CallHistoryPanel: number = 213;
    /**商城面板 */
    public static G2_ShopPanel: number = 214;
    /**背包面板 */
    public static G2_BagsPanel: number = 215;
    /**视频面板 */
    public static G2_ShipinPanel: number = 216;
    /**微博面板 */
    public static G2_WeiboPanel: number = 217;
    /**使用礼物面板 */
    public static G2_UseToolPanel: number = 218;
    /**购买礼物面板 */
    public static G2_BuyToolPanel: number = 219;
    /**恋爱工作一键完成大礼包 */
    public static G2_LibaoFinishPanel: number = 220;
    /**邮件面板 */
    public static G2_MailPanel: number = 221;
    /**邮件内容面板 */
    public static G2_MailDataPanel: number = 222;
    /**无冷却礼包面板 */
    public static G2_LibaoCDPanel: number = 223;
    /**秒回面板 */
    public static G2_LibaomiaohuiPanel: number = 224;
    /**珍藏视频面板 */
    public static G2_LibaoVideoPanel: number = 225;
    /**填写昵称 */
    public static G2_InputNamePanel: number = 226;
    /**协议 */
    public static G2_ProtocolPanel: number = 227;
    /**分享面板 */
    public static G2_SharePanel: number = 228;
    /**活动中心 */
    public static G2_ActPanel: number = 229;
    /**每日红包 */
    public static G2_RedPacketPanel: number = 230;
    /**通知 */
    public static G2_NoticeDialogPanel: number = 231;
    /**红包内容介绍 */
    public static G2_RedPacketRemindPanel: number = 232;
    /**商城钻石 */
    public static G2_ShopDiamondPanel: number = 233;
    /**商城金币 */
    public static G2_ShopGoldPanel: number = 234;
    /**商城道具礼包 */
    public static G2_ShopGiftToolPanel: number = 235;
    /**赵小野加载界面 */
    public static G2_GAME_LOAD_SCENE: number = 236;
    /**赵小野登录界面 */
    public static G2_GAME_LOGIN_SCENE: number = 237;
    /**赵小野主界面 */
    public static G2_GAME_SCENE: number = 238;
    /**赵小野DLC主面板 */
    public static G2_DlcMainPanel: number = 239;
    /**赵小野DLC信息界面 */
    public static G2_DlcMainDoc: number = 240;
    /**赵小野神秘商店 */
    public static G2_MysteriousShop: number = 241;
    /**赵小野DLC结束界面 */
    public static G2_DlcMainGameOver: number = 242;
    /**赵小野DLC主游戏界面 */
    public static G2_DlcMainGame: number = 243;
    /**赵小野心动币充值界面 */
    public static G2_SHOP_COIN_PANEL: number = 244;
}