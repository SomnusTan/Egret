class GameOtherLogin extends BasePanel {

    private _view: GameOtherLoginUI;

    private _loginData: any;

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new GameOtherLoginUI();
        this.addChild(this._view);
        if (Config.isLandscape) {
            this._view.imgBg.source = "img_other_login_bg1_jpg";
            this._view.width = Config.MAIN_HEIGHT;
            this._view.height = Config.MAIN_WIDTH;
            this._view.btnLogin.bottom = 138;
        }
        else {
            this._view.imgBg.source = "img_other_login_bg_jpg";
            this._view.width = Config.MAIN_WIDTH;
            this._view.height = Config.MAIN_HEIGHT;
        }
    }

    public show(data?: any): void {
        super.show(data);
        if (Config.isLandscape) {
            App.setOrientation(egret.OrientationMode.LANDSCAPE);
        }
        this._dispatcher.addEventListener(EventConst.U8LoginFail, this.onLoginFail, this);
        this._dispatcher.addEventListener(LoginEvent.GET_DEVICE_CODE_BACK, this.onGetDeviceCode, this);
        this._dispatcher.addEventListener(EventConst.U8LOGIN, this.onU8Login, this);
        this._dispatcher.addEventListener(LoginEvent.GET_SNOW_LOGIN_BACK, this.onSnowLogin, this);
        this._dispatcher.addEventListener(EventConst.STEAM_LOGIN, this.onSteamLogin, this);

        if (data) {
            if (data.type == 1) { //切换账号(登出后登录)
                App.nativeBridge.log("request login out");
                this._loginData = data.data;
                ProtocolCommon.instance().send_login_out(new FunctionVO(this.onLoginOut, this));
            }
            else if (data.type == 2) {//自动登录(已有登录数据)
                this._loginData = data.data;
                this.onLogin();
            }
        } else {
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onLogin, this, this._view.btnLogin);
        }
    }

    public hide(): void {
        super.hide();
        this._loginData = null;
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    /**
     * 登出后自动登录
     */
    private onLoginOut(response: any): void {
        if (ResponseUtil.checkResponseData(response, false)) {
            App.global.clearRoleData();
            App.nativeBridge.log("login out success");
            /**请求登录 */
            if (DeviceUtil.IsAndroid && Config.U8Login) {
                this.onLogin();
            }
        }
    }

    /**
     * 登录失败
     */
    private onLoginFail(): void {

    }

    /**
     * 点击登录
     */
    private onLogin(e?: egret.TouchEvent): void {
        /**请求登录 */
        if (DeviceUtil.IsWeb && Config.soEasy) {
            onSoeasyLogin(0, new FunctionVO(this.soEasyLoginBack, this));
        }
        else if (Config.isLocalApp) {
            this.startSteamLogin();
        }
        else if (DeviceUtil.IsAndroid && Config.U8Login) {
            this.startU8Login();
        }
        else if (DeviceUtil.IsIos && Config.isGZSnow) {
            this.startSnowIosLogin();
        }
    }

    /**
     * 请求IOS吊起广州冰雪登录SDK
     */
    private startSnowIosLogin(): void {
        App.nativeBridge.snowLogin();
    }

    private onSnowLogin(userData: any): void {
        ProtocolCommon.instance().send_snow_ios_login({ user_id: userData.userID, token: userData.usertoken }, new FunctionVO(this.onLoginBack, this));
    }

    /**
     * 请求steam ticket
     */
    private startSteamLogin(): void {
        // ProtocolCommon.instance().send_tourist_login(Number(App.global.userInfo.channelId), new FunctionVO(this.onLoginBack, this));
        // return;
        GameLog.log('请求steam ticket');
        SteamSDK.login();
    }

    /**
     * steam ticket 数据返回,请求登录
     */
    private onSteamLogin(ticket: string, appId: number): void {
        ProtocolCommon.instance().send_steam_login({ ticket: ticket, appid: appId }, new FunctionVO(this.onLoginBack, this));
    }

    /**soEasy登录返回 */
    private soEasyLoginBack(data: any): void {
        if (data.code == "200") { //保存账号和key
            App.data.game2Center.DataCenter.skey = data.data.avg_token;
            App.global.userInfo.skey = data.data.token;
            App.global.userInfo.uid = data.data.uid;
            App.global.userInfo.isNewUser = data.data.is_new;
            this.startGame();
        }
    }

    /**
    * 请求设备码
    */
    private startU8Login(): void {
        GameLog.log('请求u8登录');
        if (App.global.userInfo.deviceCode) {
            if (this._loginData) {
                this.onU8Login(this._loginData);
            }
            else {
                App.nativeBridge.sendU8Login("");
            }
        } else {
            App.nativeBridge.getDeviceCode();
        }
    }

    /**
     * 获取设备码返回
     */
    private onGetDeviceCode(): void {
        App.nativeBridge.log("get device code: " + App.global.userInfo.deviceCode);
        if (this._loginData) {
            this.onU8Login(this._loginData);
        }
        else {
            App.nativeBridge.sendU8Login("");
        }
    }

    /**
     * u8原生登录成功
     */
    private onU8Login(dataStr: string): void {
        App.nativeBridge.log("request login to server: " + dataStr);
        var data: any = JSON.parse(dataStr);
        ProtocolCommon.instance().send_u8_login({ userID: data.userID, sdkUserID: data.sdkUserID, token: data.token, DeviceNo: App.global.userInfo.deviceCode }, new FunctionVO(this.onLoginBack, this));
    }

    /**
     * 服务器返回U8登录
     */
    private onLoginBack(response: any): void {
        App.nativeBridge.log("get login data back from server: " + JSON.stringify(response));
        if (ResponseUtil.checkResponseData(response)) {
            App.global.userInfo.uid = Number(response.data.uid);
            App.global.userInfo.skey = response.data.token;
            App.data.game2Center.DataCenter.skey = response.data.avg_token;
            App.global.userInfo.isNewUser = response.data.is_new;
            if (Config.U8Login) {
                App.nativeBridge.sendUserData({ userID: App.global.userInfo.uid });
            }
            this.startGame();
        }
        else {
            App.nativeBridge.log("login error " + (response ? response.code : null));
            Alert.show(response.data, "确定");
        }
    }

    /**
     * 开始游戏
     */
    private startGame(): void {
        if (Config.isLocalApp) {
            //steam端跳过大厅,直接进入女主详情
            ProtocolCommon.instance().send_heroineslist_single(new FunctionVO(this.onListBack, this));
        } else {
            this.closePanel();
            //开始游戏
            PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
        }
    }

    /**
     * 获取女主列表完成
     */
    private onListBack(response: any): void {
        this.closePanel();
        PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getFirstHeroniesData());
    }

    public get width(): number {
        return Config.isLandscape ? Config.MAIN_HEIGHT : Config.MAIN_WIDTH;
    }

    public get height(): number {
        return Config.isLandscape ? Config.MAIN_WIDTH : Config.MAIN_HEIGHT;
    }

    /**
     * 是否需要发送数据
     */
    public get needSendUMeng(): boolean {
        return true;
    }
}
