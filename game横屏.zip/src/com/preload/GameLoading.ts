/**
 * 游戏加载面板
 */
class GameLoading extends h5_engine.GDisplayObjectContainer implements IPanelDispose {
    // 定义男生还没到达指定位置
    private is_arrive = true;

    private _loadingView: GameLoadingUI;
    // 初始骨骼动画
    private _dragonbonesFactory: dragonBones.EgretFactory;

    private _bgSp: h5_engine.GShape;

    private _boyOffsetX: number = 30;

    private _boyOffsetY: number = 1147;

    private _scrollRect: egret.Rectangle;
    // 定义男孩骨骼动画
    private _boy_armature: dragonBones.EgretArmatureDisplay;
    // 定义女孩骨骼动画
    private _girl_armature: dragonBones.EgretArmatureDisplay;

    private _list: string[];

    private _index: number;

    private _length: number;

    constructor() {
        super();
        this.init();
    }

    public init(): void {

        this._bgSp = new h5_engine.GShape();
        this._bgSp.graphics.beginFill(0xffffff);
        this._bgSp.graphics.drawRect(0, 0, Config.SCREEN_WIDTH, Config.SCREEN_HEIGHT);
        this._bgSp.graphics.endFill();
        this.addChild(this._bgSp);
        this._loadingView = new GameLoadingUI();
        if (Config.isLandscape) {
            this._loadingView.width = Config.MAIN_HEIGHT;
            this._loadingView.height = Config.MAIN_WIDTH;
        }
        this.addChild(this._loadingView);
        // 加载龙骨动画资源
        var dragonbonesData = RES.getRes("jindutiao2_ske_json");
        var textureData1 = RES.getRes("jindutiao2_tex_json");
        var texture1 = RES.getRes("jindutiao2_tex_png");
        // 创建龙骨工厂
        this._dragonbonesFactory = new dragonBones.EgretFactory;
        //往龙骨工厂里添加资源
        this._dragonbonesFactory.parseDragonBonesData(dragonbonesData);
        this._dragonbonesFactory.parseTextureAtlasData(textureData1, texture1);
        // 构建男孩骨架显示对象
        this._boy_armature = this._dragonbonesFactory.buildArmatureDisplay("armatureName");
        // 构建女孩显示对象
        this._girl_armature = this._dragonbonesFactory.buildArmatureDisplay("armatureName");
        // 把男孩女孩添加到舞台
        this.addChild(this._boy_armature);
        this.addChild(this._girl_armature);
        this._boyOffsetX = Config.isLandscape ? 285 : 30;
        this._boyOffsetY = Config.isLandscape ? 587 : 1147;
        // 设置男孩初始位置
        this._boy_armature.x = this._boyOffsetX;
        this._boy_armature.y = this._boyOffsetY;
        // 设置女孩初始位置
        this._girl_armature.x = Config.isLandscape ? 925 : 670;
        this._girl_armature.y = this._boyOffsetY;
        // 播放男孩及女孩动画
        this._boy_armature.animation.play("nanpao", -1);
        this._girl_armature.animation.gotoAndStopByFrame("nvhai", 0);

        this._scrollRect = new egret.Rectangle();
        this._scrollRect.height = 50;
        this.updateProgress("资源加载中", 0);
    }

    public show(data?: any): void {
        if (App.global.userInfo.isNewUser || App.global.userInfo.isFistStart) {
            App.nativeBridge.sendUMengData(EnumUMengEventID.GAME_PAGE_COUNT, {access_page:"1_初始加载界面"});
        }
        egret.Tween.get(this).set({ alpha: 0 }).to({ alpha: 1 }, 500).call(this.onShowComplete, this);
    }

    private onShowComplete(): void {
        this._index = 0;
        this._list = DeviceUtil.isWebIOS ? [EnumResGroupName.PRELOAD, EnumResGroupName.PRELOAD_SOUND] : [EnumResGroupName.PRELOAD];
        this._length = this._list.length;
        this.loadNext(null);
    }

    public hide(): void {
        this._list = null;
        egret.Tween.get(this).to({ alpha: 0 }, 1000).call(this.onHideComplete, this);
    }

    private onHideComplete(): void {
        App.dispatcher.dispatchEvent(PreloadEvent.HIDE_LOADING_COMPLETE);
        egret.Tween.removeTweens(this);
    }

    public loadNext(groupName: string): void {
        if (groupName)
            GameLog.log('加载初始化资源完成:' + groupName);
        if (this._index < this._list.length) {
            if (this._index == 0)
                App.res.setMaxLoadingThread(App.res.DEFAULT_LOAD_THREAD);
            else
                App.res.setMaxLoadingThread(1);
            App.res.loadGroup([this._list[this._index]], new FunctionVO(this.loadNext, this), new FunctionVO(this.onResourceProgress, this));
            this._index++;
        }
        else {
            App.res.setMaxLoadingThread(App.res.DEFAULT_LOAD_THREAD);
            this.onResourceLoadComplete(groupName);
        }
    }
    // 资源组加载完毕
    private onResourceLoadComplete(groupName: string): void {
        // 设置100%进度
        this.updateProgress("资源加载完毕", 1);

        // 修改播放女生亲吻
        this._boy_armature.animation.gotoAndPlayByFrame("nanzhanli", 1, 1);
        this._boy_armature.armature.proxy.addDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onBoyComplete, this);
    }

    private onBoyComplete(e: dragonBones.EgretEvent): void {
        this._boy_armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onBoyComplete, this);
        this._girl_armature.animation.gotoAndPlayByFrame("nvhaiwendao", 1, 1);
        this._girl_armature.armature.proxy.addDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onGirlComplete, this);
    }

    private onGirlComplete(e: dragonBones.EgretEvent): void {
        this._girl_armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onBoyComplete, this);
        // 回调资源
        App.dispatcher.dispatchEvent(PreloadEvent.PRELOAD_COMPLETE);
    }

    private onResourceProgress(event: RES.ResourceEvent): void {
        if (this._loadingView) {
            this.updateProgress("资源加载中", (this._index - 1) / this._length + event.itemsLoaded / event.itemsTotal / this._length);
        }
    }

    private updateProgress(str: string, progress: number): void {
        this._scrollRect.width = 669 * progress;
        this._loadingView.imgProgress.scrollRect = this._scrollRect;
        if (progress <= 1 / 3)
            str = "正在偷瞄女孩";
        else if (progress <= 2 / 3)
            str = "正在整理形象";
        else
            str = "正在翻看恋爱秘籍";

        this._loadingView.txtLabel.text = str + " " + Math.floor(progress * 100) + "%";
        // 提取男生位置
        // var boyPosition: number = this._boyOffsetX + this._scrollRect.width;
        // 判断男生位置是否小于 540
        if (this._scrollRect.width <= 510) {
            this._boy_armature.x = this._boyOffsetX + this._scrollRect.width;
        }
        else if (this._boy_armature.x != 510) {
            this._boy_armature.x = this._boyOffsetX + 510;
        }
    }

    public dispose(): void {
        // 停止男孩女孩骨骼动画
        if (this._boy_armature) {
            this._boy_armature.animation.stop();
            if (this._boy_armature.parent)
                this._boy_armature.parent.removeChild(this._boy_armature);
            this._boy_armature.dispose();
            this._boy_armature = null;
        }
        if (this._girl_armature) {
            this._girl_armature.animation.stop();
            if (this._girl_armature.parent)
                this._girl_armature.parent.removeChild(this._girl_armature);
            this._girl_armature.dispose();
            this._girl_armature = null;
        }

        this._loadingView.imgProgress.scrollRect = null;
        this._scrollRect = null;
        if (this._bgSp) {
            this._bgSp.remove();
            this._bgSp.graphics.clear();
            this._bgSp = null;
        }
        if (this._loadingView) {
            this._loadingView.dispose();
            this._loadingView = undefined;
        }
        if (this._dragonbonesFactory) {
            this._dragonbonesFactory.clear(true);
            this._dragonbonesFactory = null;
        }
        this.remove();
    }

    public needDispose(): boolean {
        return true;
    }

    /**
     * 是否需要发送数据
     */
    public get needSendUMeng(): boolean {
        return true;
    }
}