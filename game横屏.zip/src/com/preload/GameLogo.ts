/**
 * 游戏LOGO面板
 */
class GameLogo extends h5_engine.GDisplayObjectContainer implements IPanelDispose {
    // 初始骨骼动画
    private _dragonbonesFactory: dragonBones.EgretFactory;

    private _armature: dragonBones.EgretArmatureDisplay;

    private _sound: egret.Sound;

    public constructor() {
        super();
        this.init();
    }

    private init(): void {
        // 加载龙骨动画资源
        var dragonbonesData = RES.getRes(Config.isLandscape ? "GZSlogoDHHB_ske_json" : "GZSlogoDH2_ske_json");
        var textureData1 = RES.getRes(Config.isLandscape ? "GZSlogoDHHB_tex_json" : "GZSlogoDH2_tex_json");
        var texture1 = RES.getRes(Config.isLandscape ? "GZSlogoDHHB_tex_png" : "GZSlogoDH2_tex_png");
        // 创建龙骨工厂
        this._dragonbonesFactory = new dragonBones.EgretFactory;
        this._dragonbonesFactory.parseDragonBonesData(dragonbonesData);
        this._dragonbonesFactory.parseTextureAtlasData(textureData1, texture1);
        this._armature = this._dragonbonesFactory.buildArmatureDisplay("armatureName");
        this.addChild(this._armature);
        this._armature.x = (Config.SCREEN_WIDTH >> 1) - (Config.isLandscape ? 20 : 0);
        this._armature.y = (Config.SCREEN_HEIGHT >> 1) + (Config.isLandscape ? 80 : 0);
    }

    public show(data?: any): void {
        if (App.global.userInfo.isNewUser || App.global.userInfo.isFistStart) {
            App.nativeBridge.sendUMengData(EnumUMengEventID.GAME_PAGE_COUNT, {access_page:"0_Logo界面"});
        }
        if (Config.hasTouch) {
            this._sound = RES.getRes("logoyx_mp3");
            this._sound.type = egret.Sound.MUSIC;
            this._sound.play(0, 1);
        }
        this._armature.animation.timeScale = 1.5;
        this._armature.animation.gotoAndPlayByFrame("Z", 1, 1);
        this._armature.armature.proxy.addDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onPlayComplete, this);
        egret.Tween.get(this).set({ alpha: 0 }).to({ alpha: 1 }, 1000);
    }

    public hide(): void {
        egret.Tween.get(this).to({ alpha: 0 }, 1000).call(this.onHideComplete, this);
    }

    private onPlayComplete(e: dragonBones.EgretEvent): void {
        this._armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onPlayComplete, this);
        this._armature.animation.stop();
        this.hide();
    }


    private onHideComplete(): void {
        App.dispatcher.dispatchEvent(PreloadEvent.HIDE_LOGO_COMPLETE);
        egret.Tween.removeTweens(this);
    }

    public dispose(): void {
        this.remove();
        this._sound = null;
        if (this._armature) {
            if (this._armature.parent)
                this._armature.parent.removeChild(this._armature);
            this._armature.dispose();
            this._armature = null;
        }
        if (this._dragonbonesFactory) {
            this._dragonbonesFactory.clear(true);
            this._dragonbonesFactory = null;
        }
        App.res.destoryGroup([Config.isLandscape ? EnumResGroupName.LOGO1 : EnumResGroupName.LOGO]);
    }

    public needDispose(): boolean {
        return true;
    }
}