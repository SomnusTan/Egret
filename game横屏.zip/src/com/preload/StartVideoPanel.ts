class StartVideoPanel extends BasePanel {
    private _txtSkip: h5_engine.GTextField;
    private _spSkip: h5_engine.GSprite;

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._spSkip = new h5_engine.GSprite();
        this._spSkip.graphics.beginFill(0xFF0000, 0.01);
        this._spSkip.graphics.drawRect(0, 0, 160, 40);
        this._spSkip.graphics.endFill();
        this._spSkip.touchEnabled = true;
        this._spSkip.touchChildren = true;
        this.addChild(this._spSkip);

        this._txtSkip = new h5_engine.GTextField();
        this._txtSkip.size = 40;
        this._txtSkip.textColor = 0xffffff;
        this._txtSkip.stroke = 1;
        this._txtSkip.text = "跳过视频";
        this._txtSkip.touchEnabled = true;
        this._spSkip.addChild(this._txtSkip);

        this._txtSkip.x = this._spSkip.width - this._txtSkip.width >> 1;
        this._txtSkip.y = this._spSkip.height - this._txtSkip.height >> 1;

        this._spSkip.x = this.width - this._spSkip.width >> 1;
        // this._spSkip.y = this.height - this._spSkip.height >> 1;
        this._spSkip.y = this.height * 0.8;
    }

    public dispose(): void {
        if (this._txtSkip) {
            if (this._txtSkip.parent)
                this._txtSkip.parent.removeChild(this._txtSkip);
            this._txtSkip = null;
        }
        if (this._spSkip) {
            if (this._spSkip.parent)
                this._spSkip.parent.removeChild(this._spSkip);
            this._spSkip = null;
        }
        super.dispose();
    }

    public show(data?: any): void {
        super.show(data);
        this._txtSkip.visible = false;
        // Video.instance().init(ResPathUtil.getOpeningVideoRes(), true, false, new FunctionVO(this.onSkip, this));
        if (App.global.userInfo.startVideo) {
            this.onShowVideo();
        }
        else {
            this._dispatcher.addEventListener(LoginEvent.GET_AVG_SYSTEM_INIT, this.onShowVideo, this);
        }
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onSkip, this, this._spSkip);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onStartTouch, this, this._spSkip);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onReleaseTouch, this, this._spSkip);
    }

    private onReleaseTouch(e?: egret.TouchEvent): void {
        this._spSkip.filters = null;
    }

    private onStartTouch(e?: egret.TouchEvent): void {
        this._spSkip.filters = FilterUtil.FILTER_BLUE;
    }

    private onShowVideo(): void {
        Video.instance().init(App.global.userInfo.startVideo, true, false, new FunctionVO(this.onSkip, this), Video.BOTTOM, new FunctionVO(this.onShowTxt, this), Config.isLandscape);
    }

    private onShowTxt(): void {
        this._txtSkip.visible = true;
    }

    public hide(): void {
        super.hide();
        this._spSkip.filters = null;
        Video.instance().dispose();
    }

    private onSkip(e?: egret.TouchEvent): void {
        App.nativeBridge.log("touch skip video");
        App.dispatcher.dispatchEvent(PreloadEvent.PLAY_COMPLETE_START_VIDEO);
    }

    public get width(): number {
        return Config.MAIN_WIDTH;
    }

    public get height(): number {
        return Config.MAIN_HEIGHT;
    }
}