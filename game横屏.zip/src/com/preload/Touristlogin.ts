class Touristlogin extends WindowView {
    /*游客登录 */
    protected _view: TouristloginUI;
    /**操作类型 0：直接关闭面板 1：点击绑定关闭 2：点击游客登录 */
    protected _type: number;
    private _uid: number;

    public constructor() {
        super(500, 280);
    }

    protected initView(): void {
        this._view = new TouristloginUI;
        this.viewSp.addChild(this._view);
        // this._view.txt_Notlogging.visible = false;
        this.rightTitle = "绑定手机";
    }

    public show(data?: any): void {
        super.show(data);
        this._uid = data;
        this._type = 0;
        /**立即绑定*/
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtn_BindingPhoneTouch, this, this._view.btn_BindingPhone);
        // /*暂不登录*/
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.ontxt_NotloggingTouch, this, this._view.txt_Notlogging);
    }

    public hide(): void {
        super.hide();
        // if (this._type <= 1) {
        //     App.dispatcher.dispatchEvent(LoginEvent.GAME_LOGIN_RESET, this._type);
        // }
        // else {
        //     this.startGame();
        // }
    }

    private startGame(): void {
        PanelManager.removePanelByName(PanelRegister.LOGIN);
        //开始游戏
        PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
    }

    private onBtn_BindingPhoneTouch(): void {
        this._type = 1;
        PanelOpenManager.removePanel(EnumPanelID.TOURISTLOGIN);
        PanelOpenManager.openPanel(EnumPanelID.FORCE_PHONE_BIND, this._uid, false);
    }

    /**暂不绑定 */
    private ontxt_NotloggingTouch() {
        App.global.setPlayerNotBind("1");
        this.closePanel();
        // ProtocolCommon.instance().send_tourist_login(1, new FunctionVO(this.onTouristLoginBack, this));
    }

    /**
     * 游客登录反馈
     */
    private onTouristLoginBack(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.global.userInfo.uid = Number(response.data.uid);
            App.global.userInfo.skey = response.data.token;
            App.data.game2Center.DataCenter.skey = response.data.avg_token;
            this._type = 2;
            PanelOpenManager.removePanel(EnumPanelID.TOURISTLOGIN);
        }
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = undefined;
        }
        super.dispose();
    }

}