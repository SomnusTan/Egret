class GameLogin extends BasePanel {

    private _view: LoginUI;

    private _phoneRegExp: RegExp = new RegExp(EnumRegExp.PHONE_REGULAR_EXPRESSION);
    private _codeRegExp: RegExp = /^\d{6}$/;
    /**上次获取时间 */
    private _lastGetCodeTime: number = 0;
    /**能否发送验证码请求 */
    private _canSendCode: boolean = true;

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new LoginUI();
        this.addChild(this._view);
    }

    public dispose(): void {
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
        this._phoneRegExp = null;
        super.dispose();
    }

    public show(data?: any): void {
        super.show(data);
        this._view.groupYk.visible = !(DeviceUtil.IsNative && DeviceUtil.IsAndroid);

        App.sound.isCloseBgm = true;
        if (App.global.userInfo.loginVideo)
            this.onShowVideo();
        else
            this._dispatcher.addEventListener(LoginEvent.GET_AVG_SYSTEM_INIT, this.onShowVideo, this);
        // ProtocolCommon.instance().send_get_avg_system_init();

        this._view.panelLogin.y = Config.SCREEN_HEIGHT;
        egret.Tween.get(this._view.panelLogin).to({ y: Config.SCREEN_HEIGHT - this._view.panelLogin.height - 10 }, 600, egret.Ease.sineOut);

        this._canSendCode = true;
        this._view.txtCode.text = "";

        // this._view.txtPhoneNum.prompt = "请输入手机号码";
        var user_phone = App.global.storage.getItem(EnumStorageType.PHONE);
        if (user_phone) {
            this._view.txtPhoneNum.text = user_phone;
        } else {
            user_phone = App.global.storage.getItem(EnumStorageType.PHONE2);
            if (user_phone) {
                this._view.txtPhoneNum.text = user_phone;
            }
        }
        this.onGameLoginReset(Number(data));

        // 添加监听监控输入框变化
        this._dispatcher.addEventListener(egret.Event.CHANGE, this.onTxtPhoneNumChange, this, this._view.txtPhoneNum);
        this._dispatcher.addEventListener(egret.Event.CHANGE, this.onTxtCodeChange, this, this._view.txtCode);

        this._view.txtPhoneNum.inputType = egret.TextFieldInputType.TEL;
        this._view.txtCode.inputType = egret.TextFieldInputType.TEL;
        InputTextUtil.addNativeInputTextListener(this._view.txtPhoneNum);
        InputTextUtil.addNativeInputTextListener(this._view.txtCode);
        // 监控点击用户协议
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTxtUserAgreementTouch, this, this._view.txtUserAgreement);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCheckBoxTouch, this, this._view.checkBoxUserAgreement);
        // 监控点击快速登录
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtnLoginTouch, this, this._view.btnLogin);
        // 监控点击获取验证码
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtnGetCodeTouch, this, this._view.btnGetCode);
        //游客登录
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.ontxtTouristloginTouch, this, this._view.txtTouristlogin);

        this._dispatcher.addEventListener(LoginEvent.GAME_LOGIN_RESET, this.onGameLoginReset, this);
        this._dispatcher.addEventListener(EventConst.U8LOGIN, this.onAndroidLogin, this);
        this._dispatcher.addEventListener(LoginEvent.GET_DEVICE_CODE_BACK, this.onAndroidLoginRequest, this);
    }

    private onShowVideo(): void {
        Video.instance().init(App.global.userInfo.loginVideo, true, true, null, Video.BOTTOM, null, Config.isLandscape);
    }

    /**
     * 重置登录界面
     * @param type 0:登录按钮 1:绑定按钮
     * @param showTween 
     */
    private onGameLoginReset(type: number = 0, showTween: boolean = true): void {
        if (type == 0) {
            this._view.btnLogin.label = "快速登录";
            this._view.txtTouristlogin.text = "游客登录";
            this._view.boxCheckBox.visible = true;
        } else if (type == 1) {
            this._view.btnLogin.label = "立即绑定";
            this._view.txtTouristlogin.text = "暂不绑定";
            this._view.boxCheckBox.visible = false;
        }
        if (showTween) {
            egret.Tween.get(this._view.panelLogin).to({ y: Config.SCREEN_HEIGHT - this._view.panelLogin.height - 10 }, 600, egret.Ease.sineIn);
        }
        this.onTxtPhoneNumChange();
    }

    public hide(): void {
        super.hide();
        Video.instance().dispose(true);
        App.timer.clearTimer(this, this.onGetCodeTime);
        this._canSendCode = true;
        this._view.btnGetCode.label = "获取验证码"
        this._view.btnGetCode.filters = null;
        this._view.btnGetCode.touchEnabled = true;
        this._view.txtCode.text = "　";
        this._view.txtCode["textTemp"].text = "";
        InputTextUtil.removeNativeInputTextListener(this._view.txtPhoneNum);
        InputTextUtil.removeNativeInputTextListener(this._view.txtCode);
    }

    private onCheckBoxTouch(e: egret.TouchEvent): void {
        this.onTxtPhoneNumChange();
        if (this._view.checkBoxUserAgreement.selected == false) {
            this._view.txtTouristlogin.filters = null;
            this._view.txtTouristlogin.touchEnabled = true;
        } else {
            this._view.txtTouristlogin.filters = FilterUtil.FILTER_GRAY;
            this._view.txtTouristlogin.touchEnabled = false;
        }
    }

    private onTxtCodeChange(e: egret.Event = null): void {
        if (e)
            App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
        if (this.canLogin()) {
            // 手机号码正确,激活点击验证码按钮
            this._view.btnLogin.filters = null;
            this._view.btnLogin.touchEnabled = true;
        } else {
            // 手机号码不正确,熄灭点击验证码按钮
            this._view.btnLogin.filters = FilterUtil.FILTER_GRAY;
            this._view.btnLogin.touchEnabled = false;
        }
    }

    /**
     * 手机号码改变
     */
    private onTxtPhoneNumChange(e: egret.Event = null): void {
        if (e)
            App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
        if (this._canSendCode == false) {
            this._canSendCode = this.notInCodeValideCd();
            if (this._canSendCode) {
                App.timer.clearTimer(this, this.onGetCodeTime);
                this._view.btnGetCode.label = "获取验证码";
                this.onTxtPhoneNumChange();
            }
        }
        // 判断手机号码是否正确
        if (this.canGetCode()) {
            // 手机号码正确,激活点击验证码按钮
            this._view.btnGetCode.filters = null;
            this._view.btnGetCode.touchEnabled = true;
        } else {
            // 手机号码不正确,熄灭点击验证码按钮
            this._view.btnGetCode.filters = FilterUtil.FILTER_GRAY;
            this._view.btnGetCode.touchEnabled = false;
        }
        this.onTxtCodeChange();
    }

    /**
     * 登录按钮是否可用
     */
    private canLogin(): boolean {//this._codeRegExp.exec(this._view.txtCode.text) && this._phoneRegExp.exec(this._view.txtPhoneNum.text) && 
        return this._view.checkBoxUserAgreement.selected == false && this._view.txtPhoneNum.text.length == 11 && this._view.txtCode.text.length == 6;
    }

    /**
     * 获取验证码按钮是否可用
     */
    private canGetCode(): boolean {//this._phoneRegExp.exec(this._view.txtPhoneNum.text) && 
        var notInCd: boolean = this.notInCodeValideCd();//是否计时结束
        return notInCd && this._canSendCode && this._view.checkBoxUserAgreement.selected == false && this._view.txtPhoneNum.text.length == 11;
    }

    /**
     * 点击用户协议
     */
    private onTxtUserAgreementTouch(e: egret.TouchEvent): void {
        egret.Tween.get(this._view.panelLogin).to({ y: Config.SCREEN_HEIGHT }, 600, egret.Ease.backInOut).call(() => {
            PanelOpenManager.openPanel(EnumPanelID.USER_AGREEMENT);
        }, this);
    }

    /**
     * 点击登录
     */
    private onBtnLoginTouch(e: egret.TouchEvent): void {
        //官方安卓包先请求u8登录
        if (DeviceUtil.IsAndroid && DeviceUtil.IsNative && Config.U8Login)
            this.getDeviceCode();
        else if (DeviceUtil.IsIos && DeviceUtil.IsNative)
            this.iosLogin();
        else
            this.requestLogin();
    }

    private getDeviceCode(): void {
        if (App.global.userInfo.deviceCode) {
            App.nativeBridge.sendU8Login("");
        } else {
            App.nativeBridge.getDeviceCode();
        }
    }

    private iosLogin(): void {
        if (this.checkLogin()) {
            // 获取手机号码输入框数据
            var phone_text = this._view.txtPhoneNum.text;
            // 点击获取验证码
            var verif_code = this._view.txtCode.text;
            ProtocolCommon.instance().send_ios_login({
                tel: phone_text,
                code: verif_code,
                user_name: IOSConfig.iosID
            }, new FunctionVO(this.onLoginBack, this));
        }
    }

    /**
     * u8登录
     */
    private onAndroidLoginRequest(): void {
        App.nativeBridge.sendU8Login("");
    }

    /**
     * 向服务器请求U8官方登录
     */
    private onAndroidLogin(dataStr: string): void {
        App.nativeBridge.log("request login to server: " + dataStr);
        var data: any = JSON.parse(dataStr);
        // 获取手机号码输入框数据
        var phone_text = this._view.txtPhoneNum.text;
        // 点击获取验证码
        var verif_code = this._view.txtCode.text;
        ProtocolCommon.instance().send_android_login({
            userID: data.userID,
            sdkUserID: data.sdkUserID,
            token: data.token,
            DeviceNo: App.global.userInfo.deviceCode,
            tel: phone_text,
            code: verif_code,
            type: App.global.userInfo.portId,//默认为"0",现成都为"1"
            channel_id: Number(App.global.userInfo.channelId)
        }, new FunctionVO(this.onLoginBack, this));
    }

    private requestLogin(): void {
        if (this.checkLogin()) {
            // 获取手机号码输入框数据
            var phone_text = this._view.txtPhoneNum.text;
            // 点击获取验证码
            var verif_code = this._view.txtCode.text;
            if (this._view.btnLogin.label == "快速登录") {
                ProtocolCommon.instance().send_tel_login(phone_text, verif_code, Number(App.global.userInfo.channelId), new FunctionVO(this.onLoginBack, this));
            } else {
                ProtocolCommon.instance().send_tourist_bindphone(phone_text, verif_code, new FunctionVO(this.onLoginBack, this));
            }
        }
    }

    private checkLogin(): boolean {
        // 获取手机号码输入框数据
        var phone_text = this._view.txtPhoneNum.text;
        // 点击获取验证码
        var verif_code = this._view.txtCode.text;
        // 判断是否同意用户协议
        if (this._view.checkBoxUserAgreement.selected == false) {
            // 判断手机号码是否为空
            if (phone_text != "" && phone_text.length == 11) {
                // 判断验证码是否为空
                if (verif_code != "") {
                    if (/^\d{6}$/.exec(verif_code)) {
                        // 请求登录
                        return true;
                    } else {
                        Notice.showBottomCenterMessage("验证码格式有误");
                    }
                } else {
                    Notice.showBottomCenterMessage("请输入验证码");
                }
            } else {
                Notice.showBottomCenterMessage("请输入正确的手机号码");
            }
        } else {
            Notice.showBottomCenterMessage("请勾选同意用户协议");
        }
        return false
    }

    /** 点击登录返回 */
    private onLoginBack(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            // 保存用户id
            App.global.userInfo.uid = Number(response.data.uid);
            App.global.userInfo.skey = response.data.token;
            App.data.game2Center.DataCenter.skey = response.data.avg_token;
            // 保存手机号码
            App.global.storage.setItem(EnumStorageType.PHONE, this._view.txtPhoneNum.text);
            App.global.storage.removeItem(EnumStorageType.IS_TOURIST);
            // 保存token信息
            App.global.storage.setItem(EnumStorageType.TOKEN, response.data.token);
            App.global.storage.setItem(EnumStorageType.UID, String(App.global.userInfo.uid));
            App.global.storage.setItem(EnumStorageType.G2_TOKEN, response.data.avg_token);
            App.global.userInfo.isNewUser = response.data.is_new;
            if (Config.U8Login) {
                App.nativeBridge.sendUserData({ userID: App.global.userInfo.uid });
            }
            // 调用女主列表
            this.startGame();
        } else if (Number(response.code) == 210) {//输入错5次验证码，禁用按钮5分钟
            //禁用快速登录标签
            GameLog.log("禁用按钮！")
            this._canSendCode = false;
            this._view.txtCode.text = "";
            App.global.storage.setItem(EnumStorageType.FORBID_GETCODE_TIME + this._view.txtPhoneNum.text, Math.floor(new Date().getTime() * 0.001 + 300).toString());
            this.setGetCodeBtnCd(Number(App.global.storage.getItem(EnumStorageType.FORBID_GETCODE_TIME + this._view.txtPhoneNum.text)), "请稍候");
            this.onTxtPhoneNumChange();
        }
    }

    /** 验证码是否不在CD中 */
    private notInCodeValideCd(): boolean {
        var notInCd: boolean = true;
        var getCodeTime: string = App.global.storage.getItem(EnumStorageType.FORBID_GETCODE_TIME + this._view.txtPhoneNum.text);
        if (getCodeTime) {
            var value: number = Math.floor(new Date().getTime() * 0.001 - Number(getCodeTime));
            // GameLog.log('notInCodeValideCd: value = ', value);
            if (value < 0) {
                this.setGetCodeBtnCd(Number(getCodeTime), "请稍候");
                this._canSendCode = false;
                notInCd = false;
            }
        } else {
            getCodeTime = App.global.storage.getItem(EnumStorageType.GETCODE_CD_TIME + this._view.txtPhoneNum.text);
            if (getCodeTime) {
                value = Math.floor(new Date().getTime() * 0.001 - Number(getCodeTime));
                if (value < 0) {
                    this.setGetCodeBtnCd(Number(getCodeTime), "请稍候");
                    this._canSendCode = false;
                    notInCd = false;
                }
            }
        }
        // this._view.btnGetCode.filters = this._canSendCode ? null : FilterUtil.FILTER_GRAY;
        // this._view.btnGetCode.touchEnabled = this._canSendCode;
        return notInCd;
    }
    /** 验证码CD计时 */
    private setGetCodeBtnCd(time: number, btnLabel: string = "--"): void {
        App.timer.serverTimeEnd(this, this.onGetCodeTime, Math.floor(time), [btnLabel]);
    }

    private onGetCodeTime(serverTimeData: ServerTimeData, btnLabel: string = "--"): void {
        if (serverTimeData.spuleTime <= 0) {
            App.timer.clearTimer(this, this.onGetCodeTime);
            this._view.btnGetCode.label = "获取验证码";
            this._canSendCode = true;
            this.onTxtPhoneNumChange();
        } else {
            var value: number = serverTimeData.spuleTime;
            if (value > 60) {
                var min: number = Math.ceil(value / 60);
                this._view.btnGetCode.label = btnLabel + "(" + min + "分)";
            } else {
                this._view.btnGetCode.label = btnLabel + "(" + value + "秒)";
            }
        }
        // this._view.btnGetCode.filters = this._canSendCode ? null : FilterUtil.FILTER_GRAY;
        // this._view.btnGetCode.touchEnabled = this._canSendCode;
        // GameLog.log('onGetCodeTime == serverTimeData.spuleTime = ', serverTimeData.spuleTime);
    }

    /**
     * 点击获取验证码
     */
    private onBtnGetCodeTouch(e: egret.TouchEvent): void {
        // 获取当前输入框数据
        var phone_text = this._view.txtPhoneNum.text;
        // 判断是否同意用户协议
        if (this._view.checkBoxUserAgreement.selected == false) {
            // 判断手机号码是否为空
            if (phone_text.length == 11) { // 判断手机号码是否正确
                if (this.notInCodeValideCd()) { // 请求发送验证码
                    ProtocolCommon.instance().send_tel_code(phone_text, new FunctionVO(this.onGetCodeBack, this));
                } else {
                    Notice.showBottomCenterMessage("验证码错误次数过多，请稍后再试");
                }
            } else {
                Notice.showBottomCenterMessage("请输入正确的手机号码");
            }
        } else {
            Notice.showBottomCenterMessage("请勾选同意用户协议");
        }
    }

    /** 获得验证码返回 */
    private onGetCodeBack(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            if (response.data) {
                GameLog.log("验证码：" + response.data);
                this._view.txtCode.text = response.data;
                this.onTxtCodeChange();
            }
            // 修改短信发送状态
            this._canSendCode = false;
            // 验证码请求成功,修改倒数时间
            this._lastGetCodeTime = egret.getTimer();
            App.global.storage.setItem(EnumStorageType.GETCODE_CD_TIME + this._view.txtPhoneNum.text, Math.floor(new Date().getTime() * 0.001 + 60).toString());
            if (this._view.txtPhoneNum.text)
                App.global.storage.setItem(EnumStorageType.PHONE2, this._view.txtPhoneNum.text);
            this.setGetCodeBtnCd(ServerTime.serverTime + 60, "已发送");
            // 锁定请求验证码
            this._view.btnGetCode.filters = FilterUtil.FILTER_GRAY;
            this._view.btnGetCode.touchEnabled = false;
        }
    }

    /**
     * 点击游客登录
     */
    private ontxtTouristloginTouch(e: egret.TouchEvent) {
        if (this._view.txtTouristlogin.text == "游客登录") {
            // egret.Tween.get(this._view.panelLogin).to({ y: Config.SCREEN_HEIGHT }, 600, egret.Ease.backInOut).call(() => {
            //     PanelOpenManager.openPanel(EnumPanelID.TOURISTLOGIN);
            // }, this);
            if (DeviceUtil.IsNative && DeviceUtil.IsIos)
                ProtocolCommon.instance().send_tourist_login_ios(Number(App.global.userInfo.channelId), new FunctionVO(this.onTouristLoginBack, this));
            else
                this.ontxt_NotloggingTouch();
        } else {
            this.onNotloggingTouch();
        }
        App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
    }

    /**暂不绑定 */
    private ontxt_NotloggingTouch() {
        ProtocolCommon.instance().send_tourist_login(Number(App.global.userInfo.channelId), new FunctionVO(this.onTouristLoginBack, this));
    }

    private startGame(): void {
        PanelManager.removePanelByName(PanelRegister.LOGIN);
        //开始游戏
        PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
    }

    /**暂不绑定 */
    private onNotloggingTouch() {
        ProtocolCommon.instance().send_tourist_login(Number(App.global.userInfo.channelId), new FunctionVO(this.onTouristLoginBack, this));
    }
    /**
     * 游客登录反馈
     */
    private onTouristLoginBack(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            App.global.userInfo.uid = Number(response.data.uid);
            App.global.userInfo.skey = response.data.token;
            App.data.game2Center.DataCenter.skey = response.data.avg_token;
            App.global.storage.setItem(EnumStorageType.IS_TOURIST, "1");
            App.global.storage.setItem(EnumStorageType.TOKEN, response.data.token);
            App.global.storage.setItem(EnumStorageType.UID, response.data.uid);
            App.global.storage.setItem(EnumStorageType.G2_TOKEN, response.data.avg_token);
            App.global.userInfo.isNewUser = response.data.is_new;
            this.startGame();
        }
    }

    public get width(): number {
        return 720;
    }

    public get height(): number {
        return 1280;
    }

    /**
     * 是否需要发送数据
     */
    public get needSendUMeng(): boolean {
        return true;
    }
}