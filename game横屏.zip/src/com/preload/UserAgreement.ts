class UserAgreement extends WindowView {
	private _view: UserAgreementUI;//用户协议界面

	public constructor() {
		super(600, 500);
	}

	protected initView(): void {
		this._view = new UserAgreementUI();
		this.viewSp.addChild(this._view);

		this.centerTitle = "用户协议";

		this._view.dataList.useVirtualLayout = true;
		this._view.dataList.itemRenderer = UserAgreeItem;
		this._view.scroller.viewport = this._view.dataList;
	}

	public show(data?: any): void {
		super.show(data);
		this._view.dataList.dataProvider = new eui.ArrayCollection([App.global.userInfo.userAgreeInfo.content1]);

		/**用户协议确定按钮事件 */
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabBtnTouch, this, this._view.userAgreement_btn);
		App.timer.doTimeOnce(this, 1000, this.updateContent);
		ScrollerCenter.hideVerticalScrollBar(this._view.scroller);
	}

	private updateContent(): void {
		var content: string = App.global.userInfo.userAgreeInfo.content1 + App.global.userInfo.userAgreeInfo.content2;
		var conArr: string[] = content.split("\n");
		var divisor: number = 20;//除数
		var remainder: number = conArr.length % divisor;//余数
		var quotient: number = Math.floor(conArr.length / divisor);//商
		var add: string;
		var addStr: string[] = [];
		var length: number = divisor + (remainder > 0 ? 1 : 0);
		for (var i: number = 0; i < length; i++) {
			add = "";
			for (var j: number = quotient * i; j < quotient * (i + 1); j++) {
				if (j >= conArr.length) break;
				if (j < quotient * (i + 1)) {
					if (addStr.length == 0 && add == "") {
						add += conArr[j];
					} else {
						add += "\n" + conArr[j];
					}
				}
			}
			addStr.push(add);
		}
		this._view.dataList.dataProvider = new eui.ArrayCollection(addStr);
	}

	public hide(): void {
		super.hide();
		this._view.scroller.stopAnimation();
		this._view.dataList.scrollV = 0;
		this._view.dataList.dataProvider = new eui.ArrayCollection([]);
		App.timer.clearTimer(this, this.updateContent);
		App.dispatcher.dispatchEvent(LoginEvent.GAME_LOGIN_RESET, 0);
	}
	/**
	 * 确定按钮 取消用户协议
	 */
	private onTabBtnTouch(): void {
		PanelManager.removePanelByName(PanelRegister.USER_AGREEMENT);
	}
	/**
	 * 点击滑动组件之外的部分 取消的弹窗
	 */
	private onTabuserAgreeTouch(e: egret.TouchEvent) {
		PanelManager.removePanelByName(PanelRegister.USER_AGREEMENT);
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

}