class ResManager {

    private _isLoading: boolean;

    private _callBackHash: HashMap = new HashMap();

    private _progressHash: HashMap = new HashMap();
    /**中断加载的次数 */
    private STOP_LOAD_COUNT: number = 0;
    /**10秒一个资源加载间隔 */
    private RES_LOAD_DELAY: number = 10000;

    private _needCheckFailed: boolean = false;
    private _currentGroupName: string;

    /**默认加载线程数 */
    public DEFAULT_LOAD_THREAD: number = 4;


    public createGroup(name: string, keys: string[]): void {
        if (name && keys && keys.length > 0) {
            RES.createGroup(name, keys);
        }
    }

    /**
     * 加载组资源
     */
    public loadGroup(names: string[], callBack: FunctionVO, progressVO?: FunctionVO, priority?: number, needCheckFailed: boolean = false): void {
        if (names && names.length > 0) {
            this._currentGroupName = this.comboGroup(names);
            if (this._callBackHash.length == 0 && callBack) {
                this.addEvents();
            }
            if (progressVO)
                this._progressHash.put(this._currentGroupName, progressVO);
            this._callBackHash.put(this._currentGroupName, callBack);
            this._needCheckFailed = needCheckFailed;
            if (this._needCheckFailed) {
                this.RES_LOAD_DELAY = Config.isRelease ? 20000 : 3000;
                this.addCheckFailed();
            }
            RES.loadGroup(this._currentGroupName, priority);
        }
        else {
            callBack.exec();
        }
    }

    /**
     * 释放组资源
     */
    public destoryGroup(names: string[]): void {
        if (names && names.length > 0) {
            var name: string = this.comboGroup(names);
            RES.destroyRes(name);
        }
    }

    /**
    * 资源组是否已加载
    */
    public isGroupLoaded(groupName: string): boolean {
        return RES.isGroupLoaded(groupName);
    }


    /**
     * 组合组
     */
    private comboGroup(names: string[]): string {
        if (names.length > 1) {
            names.sort();
            var name: string = names.join("+");
            RES.createGroup(name, names);
            return name;
        }
        else {
            return names[0];
        }
    }

    /**
     * 添加单个资源加载时间过长判断失败定时器
     */
    private addCheckFailed(): void {
        App.timer.doTimeOnce(this, this.RES_LOAD_DELAY, this.checkResLoadFailed);
    }

    /**
     * 加载单个资源时间过长
     */
    private checkResLoadFailed(): void {
        this.STOP_LOAD_COUNT++;
        GameLog.log('资源加载时间过长,判定为加载失败', "\n当前占用加载线程" + this.STOP_LOAD_COUNT, "\n重新加载", GameLog.RED);
        RES.loadGroup(this._currentGroupName);
    }

    private addEvents(): void {
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onLoadAllComplete, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
        RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onLoadError, this);
    }

    private removeEvents(): void {
        RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onLoadAllComplete, this);
        RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this);
        RES.removeEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
        RES.removeEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onLoadError, this);
    }

    private onLoadError(event: RES.ResourceEvent): void {
        this.execCallBack(event.groupName, false);
        GameLog.logWarn("Url:" + event.resItem.url + " has failed to load");
    }

    private onResourceProgress(event: RES.ResourceEvent): void {
        var callBack: FunctionVO = this._progressHash.get(event.groupName);
        if (callBack)
            callBack.exec(event);
        if (this._needCheckFailed) {
            this.addCheckFailed();
        }
    }

    private onLoadAllComplete(event: RES.ResourceEvent): void {
        if (this._needCheckFailed) {
            App.timer.clearTimer(this, this.checkResLoadFailed);
        }
        this._currentGroupName = null;
        this.execCallBack(event.groupName);
    }

    private onResourceLoadError(event: RES.ResourceEvent): void {
        this.execCallBack(event.groupName, false);
        GameLog.logWarn("Group:" + event.groupName + " has failed to load");
    }

    private execCallBack(groupName: string, exec: boolean = true): void {
        if (exec) {
            var callBack: FunctionVO = this._callBackHash.get(groupName);
            if (callBack) {
                callBack.exec(groupName);
            }
        }
        this.removeGroup(groupName);
    }

    public setMaxLoadingThread(value: number): void {
        // if (isNaN(this.STOP_LOAD_COUNT))
        //     this.STOP_LOAD_COUNT = 0;
        // GameLog.log("设置加载线程最大数为:" + (value + this.STOP_LOAD_COUNT), GameLog.BLUE);
        // RES.setMaxLoadingThread(value + this.STOP_LOAD_COUNT);
    }

    public removeGroup(groupName: string): void {
        this._callBackHash.remove(groupName);
        this._progressHash.remove(groupName);
        if (this._callBackHash.length == 0) {
            this.removeEvents();
        }
    }

    public get currentGroupName(): string {
        return this._currentGroupName;
    }
}