class PanelOpenManager {
    /**
	 * 根据panelId打开面板
	 * @param panelId			EnumPanelID常量
	 * @param data				传递给面板的数据
	 * @param isSwitch			是否切换打开关闭
	 *
	 */
	public static openPanel(panelId: number, data: any = null, isSwitch: boolean = true): boolean {
		var panelName: string = PanelManager.getPanelName(panelId);
		if (panelName == null) {
			return false;
		}
		// var functionId: number = PanelManager.getFunctionID(panelId);
		// if (functionId > 0 && !App.global.funcOpen.isFunctionOpen(functionId)) {
		// 	return false;
		// }
		PanelManager.openPanel(panelName, data, isSwitch);
		return true;
	}
	/**
	 * 根据panelId关闭面板
	 */
	public static removePanel(panelId: number): boolean {
		var panelName: string = PanelManager.getPanelName(panelId);
		if (panelName == null) {
			return false;
		}
		PanelManager.removePanelByName(panelName);
		return true;
	}
}