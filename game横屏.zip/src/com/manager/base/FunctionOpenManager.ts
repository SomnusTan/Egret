/**
 * 功能开放管理
 */
class FunctionOpenManager
{
    public isFunctionOpen(functionId:number,needNotic:boolean=true):boolean
    {
        if(needNotic)
        {
            
        }
        return false;
    }
}