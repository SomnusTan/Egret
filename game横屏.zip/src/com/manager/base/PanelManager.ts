/**
 * 面板管理
 */
class PanelManager {

	/**无特效 */
	public static EFFECT_NONE: number = 0;
	/**放大 */
	public static EFFECT_SCALE: number = 1;
	/**渐现 */
	public static EFFECT_ALPHA: number = 2;

	private static _functionIDdic: HashMap = new HashMap();
	private static _disposeFailPanelHash: HashMap = new HashMap();
	private static _panelHash: HashMap = new HashMap();
	private static _allPanelHash: HashMap = new HashMap();
	private static _panelIDHash: HashMap = new HashMap();
	private static _panelNameHash: HashMap = new HashMap();
	private static _panelModalList: string[] = [];
	private static _panelOwnerHash: HashMap = new HashMap();
	/**显示面板总数 */
	public static showPanelCount: number = 0;

	/**
	 * 注册BasePanel基本信息
	 * @param panelName 面板名字
	 * @param className 面板类
	 * @param res 面板关联资源
	 * @param panelID 面板ID
	 * @param isModal 是否模态面板
	 * @param effectType 弹出播放动画类型 
	 * @param canTouchClose 点击模态区域是否能关闭面板
	 */
	public static registerPanel(panelName: string, className: any, res?: string[], panelID: number = -1, isModal: boolean = false, effectType: number = 1, canTouchClose: boolean = true): string {
		var panelFName: string = "";
		if (panelName.indexOf("#") != -1) {
			var list: string[] = panelName.split("#");
			panelFName = list[1];
			panelName = list[0];
		}
		if (panelID > 0) {
			this._panelNameHash.put(panelName, panelID);
			this._panelIDHash.put(panelID, panelName);
		}
		let app: PanelInfo = this._allPanelHash.get(panelName);
		if (!app) {
			app = new PanelInfo(panelName, panelFName, res, className, isModal, effectType, canTouchClose);
			this._allPanelHash.put(panelName, app);
		}
		return panelName;
	}

	/**
	 * 关联面板ID和功能开放ID(没有关联的panelID就不填)
	 * @param functionID	功能开放ID
	 * @param panelIDs		面板ID数组
	 * @return				功能开放ID
	 */
	public static registerFunctionID(functionID: number, panelIDs: any[]): number {
		if (panelIDs != null) {
			for (var i: number = 0; i < panelIDs.length; i++) {
				this._functionIDdic[panelIDs[i]] = functionID;
			}
		}
		return functionID;
	}

	public static getFunctionID(panelID: number): number {
		if (this._functionIDdic[panelID] == null) {
			return -1;
		}
		return this._functionIDdic[panelID];
	}

	/**
	 * 注册面板拥有者
	 */
	public static registerPanelOwner(gameId: number, panelNameList: string[]): void {
		this._panelOwnerHash.put(gameId, panelNameList);
	}

	/**
	 * 注册BasePanel父级
	 */
	public static registerPanelParent(panelName: string, panelContainer: egret.DisplayObjectContainer, effectType: number = 0): void {
		let app: PanelInfo = this.getPanelInfo(panelName);
		if (app) {
			app.parent = panelContainer;
			app.effectType = effectType;
			app.parentIndex = App.layer.getChildIndex(panelContainer);
		}
	}

	public static registerPanelSound(panelName: string, openSound: string = null, closeSound: string = null): void {
		let app: PanelInfo = this.getPanelInfo(panelName);
		if (app) {
			app.openSound = openSound;
			app.closeSound = closeSound;
		}
	}
	/**弹框的模态背景透明度 */
	public static registerModalAlpha(panelName: string, modalAlpha: number): void {
		let app: PanelInfo = this.getPanelInfo(panelName);
		if (app) {
			app.modalAlpha = modalAlpha;
		}
	}

	/**判定BasePanel是否显示 */
	public static isShowing(panelName: string): boolean {
		let panel: BasePanel = this._panelHash.get(panelName) as BasePanel;
		if (panel) {
			return panel.isShowing;
		}
		return false;
	}
	/** 
	 * 关闭所有窗口
	 */
	public static removeAllPanel(): void {
		let panels: BasePanel[] = this._panelHash.values;
		let panel: BasePanel
		for (let i: number = panels.length - 1; i >= 0; i--) {
			panel = panels[i];
			if (panel) {
				this.removePanelByName(panel.panelName, false);
			}
		}
	}

	/**
	 * 通过面板名字打开面板
	 */
	public static openPanel(panelName: string, data: any = null, isSwitch: boolean = true): void {
		let panel: BasePanel = this.getPanel(panelName) as BasePanel;
		let info: PanelInfo = this._allPanelHash.get(panelName) as PanelInfo;
		if (info) {
			if (!panel) {
				let clsName: any = info.className;
				panel = new clsName();
				this._panelHash.put(info.panelName, panel);
			}
		}
		else {
			throw "面板 " + panelName + "未注册！";
		}
		if (panel) {
			if (isSwitch && panel.isShowing) {
				this.removePanelByName(panelName);
			} else {
				if (info.isModal)
					this.addModal(panelName);
				info.lastShowTime = egret.getTimer();
				this.addPanelToCenter(panelName, panel, data, info.effectType);
			}
		}
	}

	private static addModal(panelName: string): void {
		if (this._panelModalList.indexOf(panelName) == -1) {
			this._panelModalList.push(panelName);
			this._panelModalList.sort(this.sortModalPanelList);
			this.updateModal(true);
		}
	}

	private static removeModal(panelName: string): void {
		var index: number = this._panelModalList.indexOf(panelName);
		if (index != -1) {
			this._panelModalList.splice(index, 1);
		}
		this.updateModal(false);
	}

	private static sortModalPanelList(panelName1: string, panelName2: string): number {
		var panelInfo1: PanelInfo = PanelManager.getPanelInfo(panelName1);
		var panelInfo2: PanelInfo = PanelManager.getPanelInfo(panelName2);
		if (panelInfo1.parentIndex > panelInfo2.parentIndex)
			return 1;
		else if (panelInfo1.parentIndex < panelInfo2.parentIndex)
			return -1;
		else {
			var panel1: BasePanel = PanelManager.getPanel(panelName1);
			var panel2: BasePanel = PanelManager.getPanel(panelName2);
			if (panel1 == null || panel1.parent == null)
				return 1;
			else if (panel2 == null || panel2.parent == null)
				return -1;
			else {
				var index1: number = panel1.parent.getChildIndex(panel1);
				var index2: number = panel2.parent.getChildIndex(panel2);
				if (index1 > index2)
					return 1;
				else
					return -1;
			}
		}
	}

	private static updateModal(isAdd: boolean): void {
		if (this._panelModalList.length > 0) {
			var panelName: string = this._panelModalList[this._panelModalList.length - 1];
			var panelInfo: PanelInfo = this._allPanelHash.get(panelName);
			App.layer.showModal(panelInfo.parent ? panelInfo.parent : App.layer.moduleLayer, panelInfo.modalAlpha, isAdd);
		}
		else {
			App.layer.hideModal();
		}
	}

	/**
	 * 移除第一个模态面板
	 */
	public static removeModalPanel(): void {
		if (this._panelModalList.length > 0) {
			var panelName: string = this._panelModalList[this._panelModalList.length - 1];
			var panelInfo: PanelInfo = this._allPanelHash.get(panelName);
			if (panelInfo.canTouchClose)
				this.removePanelByName(panelName);
		}
	}

	/**
	 * 移除BasePanel
	 */
	public static removePanelByName(panelName: string, useEffect: boolean = true): void {
		let panel: BasePanel = this._panelHash.get(panelName) as BasePanel;
		if (panel && panel.parent) {
			var info: PanelInfo = this.getPanelInfo(panelName);
			info.lastHideTime = egret.getTimer();
			if (info.closeSound)
				App.sound.playSoundSwitchClient(info.closeSound);

			var w: number = App.layer.rotation == 0 ? Config.SCREEN_WIDTH : Config.SCREEN_HEIGHT;
			var h: number = App.layer.rotation == 0 ? Config.SCREEN_HEIGHT : Config.SCREEN_WIDTH;
			if (useEffect && info.effectType == this.EFFECT_SCALE) {
				egret.Tween.get(panel).to({
					scaleX: 0, scaleY: 0, x: w >> 1, y: h >> 1
				}, 400, egret.Ease.backIn).call(this.onHideComplete, this, [panel]);
			} else {
				this.onHideComplete(panel);
			}
		}
	}
	/**
	 * 居中BasePanel
	 */
	private static addPanelToCenter(panelName: string, panel: BasePanel, data: any = null, effectType: number): void {
		if (!panel) return;
		let panelInfo: PanelInfo = this.getPanelInfo(panelName);
		let panelContainer: egret.DisplayObjectContainer = panelInfo.parent ? panelInfo.parent : App.layer.moduleLayer;
		panel.panelName = panelName;
		// panel.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onPanelRemove, this);
		panelContainer.addChild(panel);
		if (panel.isShowing == false) {
			this.showPanelCount++;
			if (panelInfo.openSound)
				App.sound.playSoundSwitchClient(panelInfo.openSound);
		}
		panel.isShowing = true;
		panel.show(data);
		panel.alpha = 0;
		var w: number = App.layer.rotation == 0 ? Config.SCREEN_WIDTH : Config.SCREEN_HEIGHT;
		var h: number = App.layer.rotation == 0 ? Config.SCREEN_HEIGHT : Config.SCREEN_WIDTH;
		panel.x = w - panel.width >> 1;
		panel.y = h - panel.height >> 1;
		// panel.resize();
		if (effectType == this.EFFECT_SCALE) {
			panel.alpha = 1;
			egret.Tween.get(panel).set({
				scaleX: 0, scaleY: 0, x: w >> 1, y: h >> 1
			}).to({
				scaleX: 1, scaleY: 1, x: w - panel.width >> 1, y: h - panel.height >> 1
			}, 400, egret.Ease.backOut).call(this.onShowComplete, this, [panel]);
		}
		else if (effectType == this.EFFECT_ALPHA) {
			egret.Tween.get(panel).to({
				alpha: 1
			}, 700, egret.Ease.backOut).call(this.onShowComplete, this, [panel]);
		} else {
			panel.alpha = 1;
		}
	}

	private static onHideComplete(panel: BasePanel): void {
		if (panel.parent) {
			this.onShowComplete(panel);
			panel.parent.removeChild(panel);
			panel.isShowing = false;
			panel.hide();
			this.removeModal(panel.panelName);
			this.showPanelCount--;
		}
	}

	private static onShowComplete(panel: BasePanel): void {
		egret.Tween.removeTweens(panel);
	}

	private static onPanelRemove(evt: egret.Event): void {
		let panel: BasePanel = evt.currentTarget as BasePanel;
		let pName: string = panel.panelName;
		let info: PanelInfo = this.getPanelInfo(pName);
	}

	/**
	 * 通过游戏ID释放面板
	 */
	public static disposePanelyByGameId(gameId: number): void {
		var list: string[] = this._panelOwnerHash.get(gameId) as string[];
		var values: any[] = this._panelHash.values;
		var panel: BasePanel;
		for (var i: number = 0, len: number = values.length; i < len; i++) {
			panel = values[i];
			if (panel && panel.needDispose() && list.indexOf(panel.panelName) != -1) {
				this._panelHash.del(panel.panelName);
				panel.dispose();
			}
		}
	}

	/**
	 * 检测BasePanel是否需要释放
	 */
	public static checkHidePanelDispose(): void {
		// let secTime: number = Config.isRelease ? 2 : 0;
		let secTime: number = 2;
		let maxTime: number = secTime * 60 * 1000;
		let crtTime: number = egret.getTimer();
		let hasDispose: boolean = false;
		let panelInfo: PanelInfo;
		let panel: BasePanel;
		let key: string;
		let values: any[] = this._panelHash.values;
		for (var i: number = 0, len: number = values.length; i < len; i++) {
			panel = values[i];
			if (panel.needDispose()) {
				key = panel.panelName;
				panelInfo = this.getPanelInfo(key);
				if (panelInfo.lastHideTime > panelInfo.lastShowTime && (crtTime - panelInfo.lastHideTime > maxTime)) {
					this._panelHash.del(key);
					panel.dispose();
					GameLog.log('定时释放了面板:' + panelInfo.panelName);
					// if (panelInfo && panelInfo.res) {
					// 	let resArr: string[] = panelInfo.res;
					// 	for (let i: number = 0; i < resArr.length; i++) {
					// 		if (resArr[i] == "") continue;
					// 		RES.destroyRes(resArr[i]);
					// 	}
					// }
				}
			} else {
				if (Config.isRelease == false) {
					hasDispose = true;
					if (this._disposeFailPanelHash.has(panel.panelName) == false) {
						this._disposeFailPanelHash.put(panel.panelName, panel.panelName);
					}
				}
			}
		}
		// if (hasDispose) {
		// 	GameLog.logWarn("面板checkDisposeSucc=false有", this._disposeFailPanelHash.keys);
		// }
	}

	public static get allPanelHash(): HashMap {
		return this._allPanelHash;
	}

	public static getPanelInfo(panelName: string): PanelInfo {
		return this._allPanelHash.get(panelName);
	}

	public static getPanelName(panelId: number): string {
		return this._panelIDHash.get(panelId);
	}

	public static getPanelId(panelName: string): number {
		return this._panelNameHash.get(panelName);
	}

	public static getPanel(panelName: string): BasePanel {
		return this._panelHash.get(panelName) as BasePanel;
	}

}
/**
 * 面板信息类
 */
class PanelInfo {

	/**面板名称 */
	public panelName: string = "";
	/**面板中文名 */
	public panelFName: string = "";
	/**资源名称 */
	public res: string[];
	/**面板类*/
	public className: any;
	/**是否是模态窗口 */
	public isModal: boolean = false;
	/**父容器 */
	public parent: egret.DisplayObjectContainer;
	/**弹出播放动画 */
	public effectType: number;
	/**能否点击模态关闭 */
	public canTouchClose: boolean;
	/**最后显示时间 */
	public lastShowTime: number = 0;
	/**最后关闭时间 */
	public lastHideTime: number = 0;
	/**父容器深度 */
	public parentIndex: number = 4;
	/**弹出音效 */
	public openSound: string;
	/**关闭音效 */
	public closeSound: string;
	/**面板蒙版的透明度 */
	public modalAlpha: number = 0.5;
	/**是否获取过统计数据 */
	public hasGetNameData: boolean;

	public constructor(panelName: string, panelFName: string, res: string[], className: any, isModal: boolean, effectType: number, canTouchClose: boolean) {
		this.panelName = panelName;
		this.panelFName = panelFName;
		this.res = res;
		this.className = className;
		this.isModal = isModal;
		this.effectType = effectType;
		this.canTouchClose = canTouchClose;
		this.hasGetNameData = false;
	}

	public get nameData(): any {
		this.hasGetNameData = true;
		return { access_page: this.panelFName };
	}
}