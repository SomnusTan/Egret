class SteamSDK {
    /**登录steam请求 */
    private static LOGIN_SIGN: string = "getAuthSessionTicket";
    /**获取APPID */
    private static GET_APP_ID: string = "getAppId";
    /**退出游戏 */
    private static EXIT_APP: string = "exitApp";
    /**支付回调 */
    private static MICRO_TXN_AUTHORIZATION_RESPONSE: string = "micro-txn-authorization-response";
    /**点击退出 */
    private static CLICK_EXIT: string = "click_exit";

    private static appId: string;

    public static init(): void {
        window["steamCall"] = SteamSDK.steamCallBack;
        if (window["steamSDK"])
            window["steamSDK"](SteamSDK.GET_APP_ID, SteamSDK.getAppIdBack);
        if (window["ipcRenderer"]) {
            window["ipcRenderer"].send("init");
            window["ipcRenderer"].on(SteamSDK.CLICK_EXIT, SteamSDK.onClickExit);
        }
    }

    public static onClickExit(): void {
        Alert.show("是否退出游戏", "确定|取消", new FunctionVO((data: any) => {
            if (data.type == Alert.OK) {
                window["ipcRenderer"].send("quit1");
            }else{
                window["ipcRenderer"].send("quit2");
            }
        }, this));
    }

    /**
     * 初始化获取APPID
     */
    public static getAppIdBack(appId): void {
        SteamSDK.appId = appId;
    }

    /**
     * steam登录
     */
    public static login(): void {
        window["steamSDK"](SteamSDK.LOGIN_SIGN, SteamSDK.loginSuccess, SteamSDK.errorBack);
    }

    public static loginSuccess(ticket): void {
        var key: string = ticket.ticket.toString("hex");
        GameLog.log('获取票证成功:' + key);
        App.dispatcher.dispatchEvent(EventConst.STEAM_LOGIN, key, SteamSDK.appId);
    }

    public static errorBack(error): void {
        GameLog.log('steam sdk error:' + error);
    }

    /**
     * steam 回调接口
     */
    public static steamCallBack(sign: string, data: any): void {
        GameLog.log(sign + ':' + data);
        if (sign == SteamSDK.MICRO_TXN_AUTHORIZATION_RESPONSE) {
            if (data.authorized) {
                GameLog.log("steam 支付成功(" + data.authorized + "),请求验证:" + data.ord_id);
                SteamSDK.checkOrder(data.ord_id, 20);
            }
            else {
                GameLog.log("steam 支付失败(" + data.authorized + ")");
            }
        }
    }

    public static checkOrder(order_id: number, leftNum: number): void {
        ProtocolCommon.sendBack(ProtocolHttpUrl.steam_is_bought, { order_id: order_id },
            new FunctionVO(SteamSDK.checkOrderBack, SteamSDK, order_id, leftNum));
    }

    /**
     * 订单验证
     */
    public static checkOrderBack(response: any, order_id: number, leftNum: number): void {
        if (ResponseUtil.checkResponseData(response) && response.data && response.data.type) {
            GameLog.log("后端验证成功:" + response.data.pid);
            App.dispatcher.dispatchEvent(EventType.BUY_SUCCESS, response.data.pid, response);
        }
        else {
            if (leftNum > 0) {
                App.timer.doTimeOnce(SteamSDK, 3000, SteamSDK.checkOrder, [order_id, leftNum - 1]);
            }
        }
    }
}