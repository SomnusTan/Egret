class ActivityManager {
    /**活动列表 */
    public activitiesList: ActivityVo[];
    /**兑换码功能是否开启 */
    public giftKey: boolean = false;

    public constructor() {

    }


    public initActivities(data: any[]): void {
        this.activitiesList = [];
        var vo: ActivityVo;
        for (var i: number = 0, len: number = data.length; i < len; i++) {
            vo = new ActivityVo(data[i]);
            this.activitiesList.push(vo);
        }
    }
}