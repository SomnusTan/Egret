/**
 * 面板注册
 */
class PanelRegister {

	/**通用弹窗提示 */
	public static ALERT: string = PanelManager.registerPanel("AlertPanel", AlertPanel, [], EnumPanelID.ALERT, true, PanelManager.EFFECT_SCALE, false);
	public static ALERT2: string = PanelManager.registerPanel("Alert2Panel", Alert2Panel, [], EnumPanelID.ALERT2, true, PanelManager.EFFECT_SCALE, false);
	public static GM: string = PanelManager.registerPanel("GmPanel", GmPanel, [], EnumPanelID.GM, false, PanelManager.EFFECT_NONE, false);
	/**登录界面 */
	public static LOGIN: string = PanelManager.registerPanel("GameLogin#2_通用登录界面", GameLogin, [], EnumPanelID.LOGIN);
	/**其它渠道登录界面 */
	public static OTHER_LOGIN: string = PanelManager.registerPanel("GameOtherLogin#2_渠道登录界面", GameOtherLogin, [], EnumPanelID.OTHER_LOGIN, false, PanelManager.EFFECT_ALPHA);
	/**游戏大厅 */
	public static GAME_HALL: string = PanelManager.registerPanel("GameHallPanel#3_盒子大厅界面", GameHallPanel, [], EnumPanelID.GAME_HALL);
	/**开场视频 */
	public static START_VIDEO: string = PanelManager.registerPanel("StartVideoPanel", StartVideoPanel, [], EnumPanelID.START_VIDEO);
	/**女主详细信息 */
	public static HEROINES_DETAIL: string = PanelManager.registerPanel("HeroinesDetailPanel#4_女主详情界面", HeroinesDetailPanel, [], EnumPanelID.HEROINES_DETAIL);
	/**加载资源loading */
	public static LOADING_RESVIEW: string = PanelManager.registerPanel("LoadingResView#5_AVG加载界面", LoadingResView, [], EnumPanelID.LOADING_RESVIEW, false, PanelManager.EFFECT_NONE);
	/**一个全屏的图片面板 */
	public static FULL_SCREEN_IMAGE: string = PanelManager.registerPanel("FullScreenImagePanel", FullScreenImagePanel, [], EnumPanelID.FULL_SCREEN_IMAGE);
	/**回忆 */
	public static MEMORY: string = PanelManager.registerPanel("MemoryPanel", MemoryPanel, [], EnumPanelID.MEMORY, false, PanelManager.EFFECT_NONE);
	/**读档存档面板 */
	public static RECORD: string = PanelManager.registerPanel("RecordPanel", RecordPanel, [], EnumPanelID.RECORD, false, PanelManager.EFFECT_NONE);
	/**视频按钮面板 */
	public static VIDEO_BUTTON: string = PanelManager.registerPanel("VideoButtonView", VideoButtonView, [], EnumPanelID.VIDEO_BUTTON, false, PanelManager.EFFECT_NONE);
	/**游戏大厅设置 */
	public static GAMEHALL_SETTING: string = PanelManager.registerPanel("GameHallSettingPanel", GameHallSettingPanel, [], EnumPanelID.GAMEHALL_SETTING, true);
	/**用户协议 */
	public static USER_AGREEMENT: string = PanelManager.registerPanel("UserAgreement", UserAgreement, [], EnumPanelID.USER_AGREEMENT, true);
	/** 暂不登录 */
	public static TOURISTLOGIN: string = PanelManager.registerPanel("Touristlogin", Touristlogin, [], EnumPanelID.TOURISTLOGIN, true, PanelManager.EFFECT_SCALE, false);
	/** 女主设置 */
	public static HERONIES_SETTING: string = PanelManager.registerPanel("HeroniesSettingPanel", HeroniesSettingPanel, [], EnumPanelID.HERONIES_SETTING, true);
	/**解绑手机 */
	public static UNBIND_PHONE: string = PanelManager.registerPanel("UnBindPhonePanel", UnBindPhonePanel, [], EnumPanelID.UNBIND_PHONE, true);
	/**绑定新手机 */
	public static BIND_NEW_PHONE: string = PanelManager.registerPanel("ToBindNewPhonePanel", ToBindNewPhonePanel, [], EnumPanelID.BIND_NEW_PHONE, true);
	/**游客绑定新手机 */
	public static TOURIST_BIND_PHONE: string = PanelManager.registerPanel("TouristBindPhonePanel", TouristBindPhonePanel, [], EnumPanelID.TOURIST_BIND_PHONE, true);
	/**强制引导玩家去绑定手机 */
	public static FORCE_PHONE_BIND: string = PanelManager.registerPanel("ForcePhoneBindPanel", ForcePhoneBindPanel, [], EnumPanelID.FORCE_PHONE_BIND, true, PanelManager.EFFECT_SCALE);
	/**游戏资源分享 */
	public static GAME_SHARE: string = PanelManager.registerPanel("GameSharePanel", GameSharePanel, [], EnumPanelID.GAME_SHARE, true);
	/**网络重联 */
	public static RETRY_CONNECT: string = PanelManager.registerPanel("RetryConnectPanel", RetryConnectPanel, [], EnumPanelID.RETRY_CONNECT, true, PanelManager.EFFECT_SCALE, false);
	/**结局帷幕 */
	public static ENDING: string = PanelManager.registerPanel("EndingPanel", EndingPanel, [], EnumPanelID.ENDING, false, PanelManager.EFFECT_NONE);
	/**结局分享 */
	public static GAME_SHARE2: string = PanelManager.registerPanel("GameShare2Panel", GameShare2Panel, [], EnumPanelID.GAME_SHARE2, true, PanelManager.EFFECT_NONE, false);
	/**他的故事 */
	public static OTHER_STORY: string = PanelManager.registerPanel("HeroinesOtherStoryPanel", HeroinesOtherStoryPanel, [], EnumPanelID.OTHER_STORY, true);
	/**支付选择界面 */
	public static CHOOSE_PAY: string = PanelManager.registerPanel("ChoosePayPanel", ChoosePayPanel, [], EnumPanelID.CHOOSE_PAY, true, PanelManager.EFFECT_SCALE, false);
	/**超值组合界面 */
	public static CHAOZHIZUHE: string = PanelManager.registerPanel("ChaoZhiZuHePanel", ChaoZhiZuHePanel, [], EnumPanelID.CHAOZHIZUHE, true, PanelManager.EFFECT_NONE, false);
	/**微信二维码支付界面 */
	public static WECHAT_QRCODE: string = PanelManager.registerPanel("WeChatQRCodePanel", WeChatQRCodePanel, [], EnumPanelID.WECHAT_QRCODE, true);
	/**大厅公告界面 */
	public static GAME_NOTICE: string = PanelManager.registerPanel("GameNoticePanel", GameNoticePanel, [], EnumPanelID.GAME_NOTICE, true, PanelManager.EFFECT_SCALE, false);
	/**心动币充值界面 */
	public static GAME_CHARGE: string = PanelManager.registerPanel("GameChargePanel", GameChargePanel, [], EnumPanelID.GAME_CHARGE, true);
	/**大厅邀请码面板 */
	public static GAME_INVITE: string = PanelManager.registerPanel("GameInvitePanel", GameInvitePanel, [], EnumPanelID.GAME_INVITE, true);
	/**大厅兑换码面板 */
	public static GAME_GIFT_KEY: string = PanelManager.registerPanel("GameGiftKeyPanel", GameGiftKeyPanel, [], EnumPanelID.GAME_GIFT_KEY, true);
	/**大厅图片公告界面 */
	public static GAME_IMAGE_NOTICE: string = PanelManager.registerPanel("GameImageNoticePanel", GameImageNoticePanel, [], EnumPanelID.GAME_IMAGE_NOTICE, true, PanelManager.EFFECT_ALPHA);
	/**大厅图片公告界面 */
	public static GAME_ACTIVITIES: string = PanelManager.registerPanel("GameActivitiesPanel", GameActivitiesPanel, [], EnumPanelID.GAME_ACTIVITIES, true, PanelManager.EFFECT_SCALE);
	/**tips面板 */
	public static GAME_TIPS: string = PanelManager.registerPanel("GameTipsPanel", GameTipsPanel, [], EnumPanelID.GAME_TIPS, true);
	//=================================房东=========================================
	/**房东AVG选项界面 */
	public static GAME_FANG_DONG_SELECT: string = PanelManager.registerPanel("GameFangDongSelectPanel", GameFangDongSelectPanel, [], EnumPanelID.GAME_FANG_DONG_SELECT, true, PanelManager.EFFECT_NONE, false);
	/**房东取名界面 */
	public static GAME_FANG_DONG_BENAME: string = PanelManager.registerPanel("GameFangDongBenamePanel", GameFangDongBenamePanel, [], EnumPanelID.GAME_FANG_DONG_BENAME, true, PanelManager.EFFECT_SCALE, false);
	/**房东菜单界面 */
	public static GAME_FANG_DONG_MENU: string = PanelManager.registerPanel("GameFangDongMenuPanel", GameFangDongMenuPanel, [], EnumPanelID.GAME_FANG_DONG_MENU, true, PanelManager.EFFECT_ALPHA, false);
	/**房东回放界面 */
	public static GAME_FANG_DONG_REVIEW: string = PanelManager.registerPanel("GameFangDongReviewPanel", GameFangDongReviewPanel, [], EnumPanelID.GAME_FANG_DONG_REVIEW, true, PanelManager.EFFECT_ALPHA, true);
	/**房东购买界面 */
	public static GAME_FANG_DONG_BUY: string = PanelManager.registerPanel("GameFangDongBuyPanel", GameFangDongBuyPanel, [], EnumPanelID.GAME_FANG_DONG_BUY, true, PanelManager.EFFECT_ALPHA, true);
	/**房东状态界面 */
	public static GAME_FANG_DONG_STATUS: string = PanelManager.registerPanel("GameStatusPanel", GameStatusPanel, [], EnumPanelID.GAME_FANG_DONG_STATUS, false, PanelManager.EFFECT_ALPHA, false);
	/**房东自动解锁界面 */
	public static GAME_FANG_DONG_UNLOCK: string = PanelManager.registerPanel("GameFangDongUnlockPanel", GameFangDongUnlockPanel, [], EnumPanelID.GAME_FANG_DONG_UNLOCK, true, PanelManager.EFFECT_SCALE, false);
	/**房东购买礼包界面 */
	public static GAME_FANG_DONG_BUY_ALL: string = PanelManager.registerPanel("GameFangDongBuyAllPanel", GameFangDongBuyAllPanel, [], EnumPanelID.GAME_FANG_DONG_BUY_ALL, true, PanelManager.EFFECT_ALPHA);

	// ===============================赵小野=============================================
	/**赵小野加载界面 */
	public static G2_GAME_LOAD_SCENE: string = PanelManager.registerPanel("LoadScene", LoadScene, [], EnumPanelID.G2_GAME_LOAD_SCENE);
	/**赵小野登录界面 */
	public static G2_GAME_LOGIN_SCENE: string = PanelManager.registerPanel("LoginScene", LoginScene, [], EnumPanelID.G2_GAME_LOGIN_SCENE);
	/**赵小野主界面 */
	public static G2_GAME_SCENE: string = PanelManager.registerPanel("GameScene", GameScene, [], EnumPanelID.G2_GAME_SCENE, false, PanelManager.EFFECT_NONE, false);
	/**赵小野dlc开始界面 */
	public static G2_DlcMainDoc: string = PanelManager.registerPanel("DlcMainDoc", DlcMainDoc, [], EnumPanelID.G2_DlcMainDoc, false, PanelManager.EFFECT_ALPHA, false);
	/**赵小野dlc主界面 */
	public static G2_DlcMainGame: string = PanelManager.registerPanel("DlcMainGame", DlcMainGame, [], EnumPanelID.G2_DlcMainGame, false, PanelManager.EFFECT_ALPHA, false);
	/**赵小野dlc结算界面 */
	public static G2_DlcMainGameOver: string = PanelManager.registerPanel("DlcMainGameOver", DlcMainGameOver, [], EnumPanelID.G2_DlcMainGameOver, false, PanelManager.EFFECT_SCALE, false);
	/**微信面板 */
	public static G2_WeixinPanel: string = PanelManager.registerPanel("WeixinPanel", WeixinPanel, [], EnumPanelID.G2_WeixinPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**电话面板 */
	public static G2_DianhuaPanel: string = PanelManager.registerPanel("DianhuaPanel", DianhuaPanel, [], EnumPanelID.G2_DianhuaPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**登录面板 */
	// public static G2_LoginPanel: string = PanelManager.registerPanel("LoginPanel", LoginPanel, [], EnumPanelID.G2_LoginPanel, true);
	/**注册面板 */
	// public static G2_RegisterPanel: string = PanelManager.registerPanel("RegisterPanel", RegisterPanel, [], EnumPanelID.G2_RegisterPanel, true);
	/**接通电话面板 */
	public static G2_JietongPanel: string = PanelManager.registerPanel("JietongPanel", JietongPanel, [], EnumPanelID.G2_JietongPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**拨号中面板 */
	public static G2_CallingPanel: string = PanelManager.registerPanel("CallingPanel", CallingPanel, [], EnumPanelID.G2_CallingPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**设置面板 */
	public static G2_SetPanel: string = PanelManager.registerPanel("SetPanel", SetPanel, [], EnumPanelID.G2_SetPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**恋爱面板 */
	public static G2_LovePanel: string = PanelManager.registerPanel("LovePanel", LovePanel, [], EnumPanelID.G2_LovePanel, true, PanelManager.EFFECT_ALPHA, false);
	/**工作面板 */
	public static G2_WorkPanel: string = PanelManager.registerPanel("WorkPanel", WorkPanel, [], EnumPanelID.G2_WorkPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**工作进度面板 */
	public static G2_WorkProPanel: string = PanelManager.registerPanel("WorkProPanel", WorkProPanel, [], EnumPanelID.G2_WorkProPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**恋爱进度面板 */
	public static G2_LoveProPanel: string = PanelManager.registerPanel("LoveProPanel", LoveProPanel, [], EnumPanelID.G2_LoveProPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**恋爱完成面板 */
	public static G2_FinishLovePanel: string = PanelManager.registerPanel("FinishLovePanel", FinishLovePanel, [], EnumPanelID.G2_FinishLovePanel, true, PanelManager.EFFECT_SCALE, false);
	/**完成工作面板 */
	public static G2_FinishWorkPanel: string = PanelManager.registerPanel("FinishWorkPanel", FinishWorkPanel, [], EnumPanelID.G2_FinishWorkPanel, true, PanelManager.EFFECT_SCALE, false);
	/**电话历史面板 */
	public static G2_CallHistoryPanel: string = PanelManager.registerPanel("CallHistoryPanel", CallHistoryPanel, [], EnumPanelID.G2_CallHistoryPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**商城面板 */
	public static G2_ShopPanel: string = PanelManager.registerPanel("ShopPanel", ShopPanel, [], EnumPanelID.G2_ShopPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**背包面板 */
	public static G2_BagsPanel: string = PanelManager.registerPanel("BagsPanel", BagsPanel, [], EnumPanelID.G2_BagsPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**视频面板 */
	public static G2_ShipinPanel: string = PanelManager.registerPanel("ShipinPanel", ShipinPanel, [], EnumPanelID.G2_ShipinPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**微博面板 */
	public static G2_WeiboPanel: string = PanelManager.registerPanel("WeiboPanel", WeiboPanel, [], EnumPanelID.G2_WeiboPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**使用礼物面板 */
	public static G2_UseToolPanel: string = PanelManager.registerPanel("UseToolPanel", UseToolPanel, [], EnumPanelID.G2_UseToolPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**购买礼物面板 */
	public static G2_BuyToolPanel: string = PanelManager.registerPanel("BuyToolPanel", BuyToolPanel, [], EnumPanelID.G2_BuyToolPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**恋爱工作一键完成大礼包 */
	public static G2_LibaoFinishPanel: string = PanelManager.registerPanel("LibaoFinishPanel", LibaoFinishPanel, [], EnumPanelID.G2_LibaoFinishPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**邮件面板 */
	public static G2_MailPanel: string = PanelManager.registerPanel("MailPanel", MailPanel, [], EnumPanelID.G2_MailPanel, true, PanelManager.EFFECT_SCALE, false);
	/**邮件内容面板 */
	public static G2_MailDataPanel: string = PanelManager.registerPanel("MailDataPanel", MailDataPanel, [], EnumPanelID.G2_MailDataPanel, true, PanelManager.EFFECT_SCALE, false);
	/**无冷却礼包面板 */
	public static G2_LibaoCDPanel: string = PanelManager.registerPanel("LibaoCDPanel", LibaoCDPanel, [], EnumPanelID.G2_LibaoCDPanel, true, PanelManager.EFFECT_SCALE, false);
	/**秒回面板 */
	public static G2_LibaomiaohuiPanel: string = PanelManager.registerPanel("LibaomiaohuiPanel", LibaomiaohuiPanel, [], EnumPanelID.G2_LibaomiaohuiPanel, true, PanelManager.EFFECT_SCALE, false);
	/**珍藏视频面板 */
	public static G2_LibaoVideoPanel: string = PanelManager.registerPanel("LibaoVideoPanel", LibaoVideoPanel, [], EnumPanelID.G2_LibaoVideoPanel, true, PanelManager.EFFECT_ALPHA, false);
	/**填写昵称 */
	public static G2_InputNamePanel: string = PanelManager.registerPanel("InputNamePanel", InputNamePanel, [], EnumPanelID.G2_InputNamePanel, true, PanelManager.EFFECT_NONE, false);
	/**协议 */
	public static G2_ProtocolPanel: string = PanelManager.registerPanel("ProtocolPanel", ProtocolPanel, [], EnumPanelID.G2_ProtocolPanel, true, PanelManager.EFFECT_SCALE, false);
	/**分享面板 */
	public static G2_SharePanel: string = PanelManager.registerPanel("SharePanel", SharePanel, [], EnumPanelID.G2_SharePanel, true, PanelManager.EFFECT_SCALE, false);
	/**活动中心 */
	public static G2_ActPanel: string = PanelManager.registerPanel("ActPanel", ActPanel, [], EnumPanelID.G2_ActPanel, true, PanelManager.EFFECT_SCALE, false);
	/**每日红包 */
	public static G2_RedPacketPanel: string = PanelManager.registerPanel("RedPacketPanel", RedPacketPanel, [], EnumPanelID.G2_RedPacketPanel, true, PanelManager.EFFECT_SCALE, false);
	/**通知 */
	public static G2_NoticeDialogPanel: string = PanelManager.registerPanel("NoticeDialogPanel", NoticeDialogPanel, [], EnumPanelID.G2_NoticeDialogPanel, true, PanelManager.EFFECT_SCALE, false);
	/**红包内容介绍 */
	public static G2_RedPacketRemindPanel: string = PanelManager.registerPanel("RedPacketRemindPanel", RedPacketRemindPanel, [], EnumPanelID.G2_RedPacketRemindPanel, true, PanelManager.EFFECT_SCALE, false);
	/**商城钻石 */
	public static G2_ShopDiamondPanel: string = PanelManager.registerPanel("ShopDiamondPanel", ShopDiamondPanel, [], EnumPanelID.G2_ShopDiamondPanel, false, PanelManager.EFFECT_ALPHA, false);
	/**商城金币 */
	public static G2_ShopGoldPanel: string = PanelManager.registerPanel("ShopGoldPanel", ShopGoldPanel, [], EnumPanelID.G2_ShopGoldPanel, false, PanelManager.EFFECT_ALPHA, false);
	/**商城道具礼包 */
	public static G2_ShopGiftToolPanel: string = PanelManager.registerPanel("ShopGiftToolPanel", ShopGiftToolPanel, [], EnumPanelID.G2_ShopGiftToolPanel, false, PanelManager.EFFECT_ALPHA, false);
	/**赵小野DLC主面板 */
	public static G2_DlcMainPanel: string = PanelManager.registerPanel("DlcMainPanel", DlcMainPanel, [], EnumPanelID.G2_DlcMainPanel, false, PanelManager.EFFECT_ALPHA, false);
	/**赵小野神秘商城 */
	public static G2_MysteriousShop: string = PanelManager.registerPanel("MysteriousShop", MysteriousShop, [], EnumPanelID.G2_MysteriousShop, false, PanelManager.EFFECT_SCALE, false);
	/**赵小野心动币充值界面 */
	public static G2_SHOP_COIN_PANEL: string = PanelManager.registerPanel("ShopCoinPanel", ShopCoinPanel, [], EnumPanelID.G2_SHOP_COIN_PANEL, false, PanelManager.EFFECT_ALPHA, false);

	/**
	 * 注册模块父容器非module层显示
	 */
	public static init(): void {
		this.registerParent();
		this.registerSound();
		this.registerAlpha();
		this.registerPanelOwner();
	}

	/**
	 * 注册父容器
	 */
	private static registerParent(): void {
		PanelManager.registerPanelParent(this.LOGIN, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.START_VIDEO, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.GAME_HALL, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.HEROINES_DETAIL, App.layer.mainLayer);
		// PanelManager.registerPanelParent(this.LOADING_RESVIEW, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.VIDEO_BUTTON, App.layer.videoLayer);
		PanelManager.registerPanelParent(this.FULL_SCREEN_IMAGE, App.layer.popLayer);
		PanelManager.registerPanelParent(this.GAME_SHARE2, App.layer.popLayer);
		PanelManager.registerPanelParent(this.GAME_SHARE, App.layer.popLayer);
		// PanelManager.registerPanelParent(this.GAME_FANG_DONG_MENU, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.GAME_FANG_DONG_SELECT, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.GAME_FANG_DONG_BENAME, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.RETRY_CONNECT, App.layer.popLayer);
		PanelManager.registerPanelParent(this.ALERT, App.layer.popLayer);
		PanelManager.registerPanelParent(this.ALERT2, App.layer.popLayer);

		PanelManager.registerPanelParent(this.G2_GAME_LOAD_SCENE, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.G2_GAME_LOGIN_SCENE, App.layer.mainLayer);
		PanelManager.registerPanelParent(this.G2_GAME_SCENE, App.layer.mainLayer);

		PanelManager.registerPanelParent(this.GAME_TIPS, App.layer.tipLayer);
	}

	/**
	 * 注册面板开关音效
	 */
	private static registerSound(): void {
		PanelManager.registerPanelSound(this.USER_AGREEMENT, EnumSoundId.WRITE, EnumSoundId.SCROLL_PAPER);
		PanelManager.registerPanelSound(this.GAMEHALL_SETTING, null, EnumSoundId.PANEL_CLOSE);
		PanelManager.registerPanelSound(this.UNBIND_PHONE, EnumSoundId.BUBBLE, EnumSoundId.PANEL_CLOSE);
		PanelManager.registerPanelSound(this.BIND_NEW_PHONE, EnumSoundId.BUBBLE, EnumSoundId.PANEL_CLOSE);
		PanelManager.registerPanelSound(this.TOURIST_BIND_PHONE, EnumSoundId.BUBBLE, EnumSoundId.PANEL_CLOSE);
		PanelManager.registerPanelSound(this.FORCE_PHONE_BIND, EnumSoundId.NOTICE);
		PanelManager.registerPanelSound(this.HERONIES_SETTING, EnumSoundId.BUBBLE, EnumSoundId.PANEL_CLOSE);
		PanelManager.registerPanelSound(this.GAME_FANG_DONG_MENU, null, EnumSoundId.PANEL_CLOSE);
		PanelManager.registerPanelSound(this.ALERT, null, EnumSoundId.PANEL_CLOSE);
		// PanelManager.registerPanelSound(this.RECORD, EnumSoundId.BUBBLE);
		PanelManager.registerPanelSound(this.GAME_FANG_DONG_REVIEW, null, EnumSoundId.PANEL_CLOSE);
		// PanelManager.registerPanelSound(this.GAME_FANG_DONG_REVIEW, EnumSoundId.FILM, EnumSoundId.FILM);
	}

	/**
	 * 注册面板蒙版透明度
	 */
	private static registerAlpha(): void {
		PanelManager.registerModalAlpha(this.G2_FinishLovePanel, 0.8);
		PanelManager.registerModalAlpha(this.G2_FinishWorkPanel, 0.8);
		PanelManager.registerModalAlpha(this.GAME_SHARE2, 0.01);
	}

	private static registerPanelOwner(): void {
		PanelManager.registerPanelOwner(EnumGameID.FANG_DONG, [this.GAME_FANG_DONG_SELECT, this.GAME_FANG_DONG_BENAME, this.GAME_FANG_DONG_MENU, this.GAME_FANG_DONG_REVIEW, this.GAME_FANG_DONG_STATUS]);

		PanelManager.registerPanelOwner(EnumGameID.GAME2, [this.G2_GAME_LOAD_SCENE, this.G2_GAME_LOGIN_SCENE, this.G2_GAME_SCENE, this.G2_DlcMainDoc, this.G2_DlcMainGame
			, this.G2_DlcMainGameOver, this.G2_WeixinPanel, this.G2_DianhuaPanel, this.G2_JietongPanel, this.G2_CallingPanel, this.G2_SetPanel
			, this.G2_LovePanel, this.G2_WorkPanel, this.G2_WorkProPanel, this.G2_LoveProPanel, this.G2_FinishLovePanel, this.G2_FinishWorkPanel
			, this.G2_CallHistoryPanel, this.G2_ShopPanel, this.G2_BagsPanel, this.G2_ShipinPanel, this.G2_WeiboPanel, this.G2_UseToolPanel
			, this.G2_BuyToolPanel, this.G2_LibaoFinishPanel, this.G2_MailPanel, this.G2_MailDataPanel, this.G2_LibaoCDPanel, this.G2_LibaomiaohuiPanel
			, this.G2_LibaoVideoPanel, this.G2_InputNamePanel, this.G2_ProtocolPanel, this.G2_SharePanel, this.G2_ActPanel, this.G2_RedPacketPanel
			, this.G2_NoticeDialogPanel, this.G2_RedPacketRemindPanel, this.G2_ShopDiamondPanel, this.G2_ShopGoldPanel, this.G2_ShopGiftToolPanel, this.G2_DlcMainPanel
			, this.G2_MysteriousShop, this.ALERT2, this.G2_SHOP_COIN_PANEL]);

	}
}