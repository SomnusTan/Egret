class LogManager {
	public constructor() {
	}

	/**信息*/
	public info(... args):void {
		App.data.logDataCenter.inputMsgByType(EnumLogType.INFO, args);
	}

	/**消息*/
	public echo(... args):void {
		App.data.logDataCenter.inputMsgByType(EnumLogType.ECHO, args);
	}

	/**调试*/
	public debug(... args):void {
		App.data.logDataCenter.inputMsgByType(EnumLogType.DEBUG, args);
	}

	/**错误*/
	public error(... args):void {
		App.data.logDataCenter.inputMsgByType(EnumLogType.ERROR, args);
	}

	/**警告*/
	public warn(... args):void {
		App.data.logDataCenter.inputMsgByType(EnumLogType.WARN, args);
	}

	public xingneng(... args):void {
		App.data.logDataCenter.inputMsgByType(EnumLogType.XINGNENG, args);
	}

	public localLog(... args):void {
		App.data.logDataCenter.inputMsgByType(EnumLogType.LOCAL_LOG, args);
	}
}