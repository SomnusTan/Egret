/**
 * 数据存储
 */
class ClientDataManager {

	/**大厅数据 */
	private _gameHallCenter: GameHallCenter;

	/**背包数据 */
	private _bagItemCenter: BagItemCenter;
	/**日志数据 */
	private _log: LogCenter;
	/**游戏资源数据 */
	private _gameResourceCenter: GameResourceCenter;
	/**房东游戏数据 */
	private _gameFangDongCenter: GameFangDongCenter;
	/**赵小野游戏数据 */
	private _game2Center: Game2Center;

	public constructor() {
	}

	/**
     * 日志数据
     */
	public get logDataCenter(): LogCenter {
		if (!this._log) {
			this._log = new LogCenter();
		}
		return this._log;
	}

	/**
     * 背包数据
     */
	public get bagItemDataCenter(): BagItemCenter {
		if (!this._bagItemCenter) {
			this._bagItemCenter = new BagItemCenter();
		}
		return this._bagItemCenter;
	}
	/**
     * 大厅数据
     */
	public get gameHallCenter(): GameHallCenter {
		if (!this._gameHallCenter) {
			this._gameHallCenter = new GameHallCenter();
		}
		return this._gameHallCenter;
	}

	/**
	 * 游戏资源
	 */
	public get gameResourceCenter(): GameResourceCenter {
		if (!this._gameResourceCenter) {
			this._gameResourceCenter = new GameResourceCenter();
		}
		return this._gameResourceCenter;
	}


	/**
	 * 房东游戏数据
	 */
	public get gameFangDongCenter(): GameFangDongCenter {
		if (this._gameFangDongCenter == null)
			this._gameFangDongCenter = new GameFangDongCenter();
		return this._gameFangDongCenter;
	}

	public get game2Center(): Game2Center {
		if (this._game2Center == null)
			this._game2Center = new Game2Center();
		return this._game2Center
	}

}
