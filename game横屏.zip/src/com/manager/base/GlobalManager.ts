class GlobalManager {
	public stageX: number = 0;
	public stageY: number = 0;
	private _avgAutoPay: boolean = false;

	public globalPoint: egret.Point = new egret.Point();

	public userInfo: UserInfoManager;
	/**对象创建*/
	// public thing: ObjectCreateManager;
	/**功能开启管理 */
	// public funcOpen: FunctionOpenManager;
	/**道具使用管理 */
	// public itemUse: ItemUseManager;
	/**GM操作管理 */
	// public gmOperate: GmOperateManager;
	/**活动管理 */
	public activity: ActivityManager;
	/**活动相关按钮管理 */
	// public menuBtn: MenuButtonManager;
	/** 提示管理 */
	// public msgMng: MsgManager;
	/** 红点提示管理 */
	// public red: RedManager;
	/** 本地数据存储管理 */
	public storage: LocalStorageManager;
	/** 引导管理 */
	public guide: GuideManager;



	public constructor() {
		this.userInfo = new UserInfoManager();
		// this.thing = new ObjectCreateManager();
		// this.itemUse = new ItemUseManager();
		// this.funcOpen = new FunctionOpenManager();
		// this.gmOperate = new GmOperateManager();
		this.activity = new ActivityManager();
		// this.menuBtn = new MenuButtonManager();
		// this.msgMng = new MsgManager();
		// this.red = new RedManager();
		this.storage = new LocalStorageManager();
		this.guide = new GuideManager();
	}

	/**
	 * 能否分享
	 */
	public get canShare(): boolean {
		if (Config.isRelease && DeviceUtil.IsWeb) {
			return false;
		}
		if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
			return this.userInfo.channelId == EnumChannel.C_DEFAULT;//官方包1773
		}
		if (DeviceUtil.IsIos && DeviceUtil.IsNative) {
			return true;
		}
		return true;
	}

	/**
	 * 大厅设置面板是否隐藏退出按钮
	 */
	public get needHideExit(): boolean {
		return (Config.U8Login &&
			(App.global.userInfo.channelId == EnumChannel.C_OPPO
				|| App.global.userInfo.channelId == EnumChannel.C_VIVO
				|| App.global.userInfo.channelId == EnumChannel.C_UC
				|| App.global.userInfo.channelId == EnumChannel.C_UC1
				|| App.global.userInfo.channelId == EnumChannel.C_SOUGOU
				|| App.global.userInfo.channelId == EnumChannel.C_SOUGOU1
				|| App.global.userInfo.channelId == EnumChannel.C_SOUGOU2
				|| App.global.userInfo.channelId == EnumChannel.C_SOUGOU3))
			|| Config.isLocalApp;
	}

	/**
	 * 清除用户数据
	 */
	public clearRoleData(): void {
		App.global.userInfo.uid = undefined;
		App.global.userInfo.skey = "";
		App.data.game2Center.DataCenter.skey = "";
		if (App.global.storage.getItem(EnumStorageType.PHONE))
			App.global.storage.setItem(EnumStorageType.PHONE2, App.global.storage.getItem(EnumStorageType.PHONE));
		App.global.storage.removeItem(EnumStorageType.TOKEN);
		App.global.storage.removeItem(EnumStorageType.UID);
		App.global.storage.removeItem(EnumStorageType.PHONE);
		App.global.storage.removeItem(EnumStorageType.G2_TOKEN);
		App.global.userInfo.hasShowNotice = false;
	}

	/**
	 * 是否有邀请功能
	 */
	public get canInvite(): boolean {
		return EnumChannel.CAN_INVITE_LIST.indexOf(this.userInfo.channelId) != -1;
	}

	/** 强制引导去绑定手机 */
	public forceToPhoneBind(): boolean {
		var phone: string = App.global.storage.getItem(EnumStorageType.PHONE);
		// GameLog.log("forceToPhoneBind ==  " + phone);
		var playerNotBind: string = App.global.storage.getItem(EnumStorageType.PLAYER_NOT_BIND + this.userInfo.uid);
		if (!playerNotBind && this.userInfo.hasFirstCharged && !phone && !Config.U8Login && !Config.soEasy) {
			PanelOpenManager.openPanel(EnumPanelID.TOURISTLOGIN, this.userInfo.uid, false);
			return true;
		}
		return false;
	}

	/**玩家付费后暂不绑定手机*/
	public setPlayerNotBind(value: string): void {
		App.global.storage.setItem(EnumStorageType.PLAYER_NOT_BIND + this.userInfo.uid, value);
		if (value)
			App.dispatcher.dispatchEvent(GameEvent.GAME_UNLOCK_SUCCESS, this.userInfo.uid);
	}

	/**
	 * 初始化AVG自动解锁数据
	 */
	public initAvgAutoPay(): void {
		this._avgAutoPay = this.storage.getItem(EnumStorageType.AVG_AUTO_PAY + this.userInfo.uid) ? true : false
		this.storage.setItem(EnumStorageType.AVG_AUTO_PAY + this.userInfo.uid, this._avgAutoPay ? "1" : "");
	}

	/**
	 * avg自动解锁
	 */
	public get avgAutoPay(): boolean {
		return this._avgAutoPay;
	}

	/**
	 * avg自动解锁
	 */
	public set avgAutoPay(value: boolean) {
		if (this._avgAutoPay != value) {
			this._avgAutoPay = value;
			this.storage.setItem(EnumStorageType.AVG_AUTO_PAY + this.userInfo.uid, this._avgAutoPay ? "1" : "");
		}
	}
}