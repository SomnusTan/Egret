class UserInfoManager {

    /**安卓设备码 */
    public deviceCode: string;

    /**开场视频地址 */
    public startVideo: string;
    /**登录背景视频地址 */
    private _loginVideo: string;

    /**http请求权鉴 */
    public skey: string = "";
    /**角色ID */
    public uid: number;
    /**版本信息 */
    public authorInfo: any;
    /**用户协议内容   */
    public userAgreeInfo: UserAgreeInfo = new UserAgreeInfo();
    /** 女主资源数据 */
    public HeroinesData = {};
    /**渠道ID */
    public channelId: string = "1";
    /**渠道端口ID */
    public portId: string = "0";

    /**渠道默认登录数据 */
    public loginData: any;
    /**是否显示过公告 */
    public hasShowNotice: boolean;
    /**是否新玩家 */
    public isNewUser: boolean = false;
    /**是否第一次打开游戏*/
    public isFistStart: boolean = false;
	/**心动币 */
    public xdCoin: number = 0;
    /**充值数据 */
    public chargeList: ChargeVo[];
    /**是否首充过 */
    public hasFirstCharged: boolean = false;

    public get loginVideo(): string {
        return this._loginVideo;
    }

    public set loginVideo(value: string) {
        if (DeviceUtil.IsNative && value.indexOf("//") == 0)
            this._loginVideo = "https:" + value;
        else
            this._loginVideo = value;
    }

    /**
     * 通过充值ID获取充值数据
     */
    public getChargeVoById(id: number): ChargeVo {
        if (this.chargeList) {
            for (var i: number = 0, len: number = this.chargeList.length; i < len; i++) {
                if (this.chargeList[i].id == id) {
                    return this.chargeList[i];
                }
            }
        }
        return null;
    }
}