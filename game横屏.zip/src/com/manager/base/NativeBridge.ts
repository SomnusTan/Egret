/**
 * 原生通信
 * @author huanglong
 * 2017-03-23
 */

class NativeBridge {

    public constructor() {

    }

    /**
     * 添加原生消息监听
     */
    public init() {
        //播放结束
        this.addCallback("viedoFinishPlay", App.nativeBridge.videoFinish);
        this.addCallback("videoPrepared", App.nativeBridge.videoPrepared);
        this.addCallback("payFinish", App.nativeBridge.iosPayFinish);
        this.addCallback("u8Login", App.nativeBridge.revU8Login);        //原生登录
        this.addCallback("pay", App.nativeBridge.revU8Pay);             //u8支付返回
        this.addCallback("logout", App.nativeBridge.revU8Logout);        //u8账号登出
        this.addCallback("keyExit", App.nativeBridge.revKeyExit);        //手机退出键
        this.addCallback("u8LoginFail", App.nativeBridge.revU8LoginFail);   //登录失败
        this.addCallback("getIosID", App.nativeBridge.revGetIosID);     //获取ios设备码
        this.addCallback("pushQQGroup", App.nativeBridge.revPushQQGroup); //加入QQ群返回
        this.addCallback("pushOfficialNetwork", App.nativeBridge.revPushOfficialNetwork);//网址跳转
        this.addCallback("U8Share", App.nativeBridge.shareBack);//网址跳转
        this.addCallback("getIMEI", App.nativeBridge.getDeviceCodeBack);//设备码返回
        this.addCallback("getChannelId", App.nativeBridge.getChannelIdBack);//渠道返回
        this.addCallback("switchAccount", App.nativeBridge.revU8ReLogin);//渠道切换登录
        this.addCallback("changeText", InputTextUtil.updateNativeText);//改变输入文本
        this.addCallback("startOrientation", App.nativeBridge.getStartOrientationBack);//获取初始横竖屏
        this.addCallback("isFirstStart", App.nativeBridge.getIsFirstLoginAndroidBack);//获取是否第一次登录安卓
        this.addCallback("iOSQLLogin", App.nativeBridge.getSnowLoginBack);//获取初始横竖屏
    }

    public addCallback(tag: string, callback) {
        if (Config.isIosHybird) {
            window["ExternalInterface"].addCallback(tag, callback);
        }
        else {
            egret.ExternalInterface.addCallback(tag, callback);
        }
    }

    public call(tag: string, data: string) {
        if (Config.isIosHybird) {
            window["ExternalInterface"].call(tag, data);
        }
        else {
            egret.ExternalInterface.call(tag, data);
        }
    }

    //发送Native登出
    public sendLogOut() {
        this.call("u8Logout", "");
    }

    //请求ios设备码
    public sendGetIosID() {
        App.data.game2Center.LoadingLock.lockScreen();
        this.call("getIosID", "");
    }

    /**获取ios设备码 */
    public revGetIosID(data) {
        GameLog.log("NativeBridge >> revGetIosID:", data);
        App.data.game2Center.LoadingLock.unLockScreen();
        //保存数据
        let json = JSON.parse(data);
        IOSConfig.channel = json.channel;
        IOSConfig.iosID = json.iosID;
        App.global.userInfo.channelId = "2";//ios渠道号为2,写死的
    }

    /**
     * 广州冰雪登录
     */
    public snowLogin(): void {
        this.call("iOSQLLogin", "");
    }

    public getSnowLoginBack(data): void {
        var userData = JSON.parse(data);
        if (userData) {
            App.dispatcher.dispatchEvent(LoginEvent.GET_SNOW_LOGIN_BACK, userData);
        }
    }

    /**接收手机退出键 */
    public revKeyExit(data) {
        //只有登录和游戏界面才响应退出
        if (GameManager.isPlaying == false) {
            //当按下第二次手机退出按钮后，第二次直接退出
            Alert.show("是否退出游戏", "确定|取消", new FunctionVO((data: any) => {
                if (data.type == Alert.OK) {
                    App.nativeBridge.requestExit();
                }
            }, this));
        }
        else {
            if (PanelManager.isShowing(PanelRegister.LOADING_RESVIEW) || PanelManager.isShowing(PanelRegister.G2_GAME_LOAD_SCENE)) {
                GameLog.log("资源加载中无法返回大厅");
                return;
            }
            Alert.show("是否返回游戏大厅", "确定|取消", new FunctionVO((data: any) => {
                if (data.type == Alert.OK) {
                    PanelManager.removeAllPanel();
                    GameManager.exitGame();
                    Video.instance().dispose(true);
                    if (Config.isLandscape)
                        App.setOrientation(egret.OrientationMode.LANDSCAPE);
                    PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
                }
            }, this));
        }
    }

    /**
     * 退出应用
     */
    public requestExit(): void {
        this.call("keyExit", "");
    }

    /**
     * 请求 u8登录
     * @param user 用户账号，游客为空字符串""
     */
    public sendU8Login(user: string) {
        GameLog.log("EgeretU8 >> egret调用u8Login接口:" + user);
        App.nativeBridge.log("request u8 data");
        this.call("u8Login", user);
    }

    /**
     * u8登录返回u8数据 向服务端请求登录
     * @param data u8数据是string
     */
    public revU8Login(data) {
        GameLog.log("EgretU8 >> 返回u8Login接口:" + data);
        App.nativeBridge.log("get u8 data back");
        if (Config.startPlaySoundEffect) {
            App.dispatcher.dispatchEvent(EventConst.U8LOGIN, data);
        }
        else {
            App.global.userInfo.loginData = data;
        }
    }

    /**
     * u8切换账号
     */
    public revU8ReLogin(data) {
        App.dispatcher.dispatchEvent(LoginEvent.RELOGIN, data);
    }

    /**
     * 接收u8登录失败(取消)
     */
    public revU8LoginFail(data) {
        App.nativeBridge.log("u8 login failed");
        // Alert.show("登录失败,是否重试?", "确定", new FunctionVO((data: any) => {
        //     if (data.type == Alert.OK) {
        //         App.nativeBridge.sendU8Login("");
        //     }
        // }, this))
        App.dispatcher.dispatchEvent(EventConst.U8LoginFail);
    }

    /**登出 */
    public revU8Logout() {
        App.nativeBridge.log("u8 login out");
        App.dispatcher.dispatchEvent(LoginEvent.RELOGIN);
    }

    /**发送播放视频
     *@param url  视频链接
     *@param muted 是否静音
     *@param loop 是否循环
     *@param isLandscapePlay 是否横屏
     */
    public sendPlayVideo(url: string, muted: boolean, loop: boolean, isLandscapePlay: boolean) {
        // App.data.game2Center.LoadingLock.lockBlack();
        // App.data.game2Center.SoundManager.stopBGM();
        App.data.game2Center.DataCenter.isVideoPlaying = true;

        let data = { auth: url, isCirclePlay: loop, isMuteMode: muted, isLandscapePlay: isLandscapePlay };

        // let data = { type: "", auth: {}, aliyun: "" };
        // data.type = type;
        // data.auth = url;
        // if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
        //     data.aliyun = "1";   //阿里云解析
        // } else {
        //     data.aliyun = "0";   //原生播放
        // }
        App.nativeBridge.log("request play video " + url);
        this.call("videoStartPlay", JSON.stringify(data));
    }

    /**
     * 视频预加载完成
     */
    public videoPrepared(): void {
        Video.instance().hideMaskSp();
    }

    /**
     * 视频暂停
     */
    public sendVideoPause() {
        this.call("videoPause", "");
    }

    /**
     * 视频继续
     */
    public sendVideoResume() {
        this.call("videoResume", "");
    }

    /**
     * 视频结束
     */
    public sendVideoStop() {
        this.call("videoStop", "");
    }

    /**视频播放结束 */
    public videoFinish(data) {
        // App.data.game2Center.LoadingLock.unLockScreen();
        // App.data.game2Center.LoadingLock.unLockBlack();
        App.data.game2Center.DataCenter.isVideoPlaying = false;

        App.nativeBridge.log("video play complete");
        Video.instance().execCompleteHandler();


        // App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
        // App.dispatcher.dispatchEvent(EventConst.guide);
        //播放视频完成
        // App.dispatcher.dispatchEvent(EventConst.VIDEO_PLAY_FISNISH);
    }

    /**
     * 请求App.data.game2Center内部跳转 加入QQ群
     * @param type:类型
     * @param data:QQ群     
     */
    public pushQQGroup(type, data) {
        let datas = { type: "", data: { key: "", group: "" } };
        datas.type = type;
        datas.data = data;
        GameLog.log(datas);
        this.call("joinQQGroup", JSON.stringify(datas));
    }

    public revPushQQGroup(data) {
        if (data == false) {
            return;
        }
        // window.open("https://jq.qq.com/?_wv=1027&k=5M9qH37");
    }

    /**
     * 请求App.data.game2Center内部跳转 跳转官网
     */
    public pushOfficialNetwork(type, data) {
        let datas = { type: "", data: { url: "" } };
        datas.type = type;
        datas.data = data;
        this.call("callNative", JSON.stringify(datas));
    }

    public revPushOfficialNetwork(data) {
        if (data == false) {
            return;
        }
        // window.open("http://www.aqgame.cn");
    }

    /**发起支付 ios、web、android */
    public sendPay(data) {
        if (DeviceUtil.IsWeb) {
            if (WanBaSDK.getIntance().wanBaData && data.code == 200) {
                //发货
                let objWanBa: any = WanBaSDK.getIntance().wanBaData;
                let paymentWanbaDoData = {
                    openid: objWanBa.openid,
                    openkey: objWanBa.openkey,
                    zoneid: objWanBa.platform,
                    channel: "wanba",
                    Authorization: App.data.game2Center.DataCenter.skey,
                    gid: data.data.pid,
                    order_id: data.data.order_id,
                    product_id: data.data.product_id
                };

                ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.paymentWanbaDo, paymentWanbaDoData, new FunctionVO((data) => {
                    if (data.code == 200) {
                        App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                    }
                }, this));
                Notice.showBottomCenterMessage(data.info);
                App.data.game2Center.LoadingLock.unlock();
                return;
            } else if (WanBaSDK.getIntance().wanBaData && data.code == 981) {
                GameLog.log("初始支付数据->>>>" + JSON.stringify(data));
                let windowObj: any = window;
                let sendPuy = {
                    version: "v2",
                    defaultScore: data.data.amount,
                    appid: parseInt(data.data.appid)
                };
                GameLog.log("支付数据->>>>" + JSON.stringify(sendPuy));
                windowObj.popPayTips(sendPuy);
                windowObj.__paySuccess = function () {
                    //支付成功执行
                    GameLog.log("支付成功执行");
                    //发货
                    let objWanBa: any = WanBaSDK.getIntance().wanBaData;
                    let paymentWanbaDoData = {
                        openid: objWanBa.openid,
                        openkey: objWanBa.openkey,
                        zoneid: objWanBa.platform,
                        channel: "wanba",
                        Authorization: App.data.game2Center.DataCenter.skey,
                        gid: data.data.pid,
                        order_id: data.data.order_id,
                        product_id: data.data.product_id
                    };

                    ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.paymentWanbaDo, paymentWanbaDoData, new FunctionVO((data) => {
                        if (data.code == 200) {
                            App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                        }
                    }, this));
                }

                windowObj.__payError = function () {
                    //支付失败执行
                    GameLog.log("支付失败执行");
                    Notice.showBottomCenterMessage("支付失败");
                }

                windowObj.__payClose = function () {
                    //关闭对话框执行,IOS下无效
                    GameLog.log("关闭对话框执行,IOS下无效");
                    Notice.showBottomCenterMessage("支付取消");
                }
                return;
            } else if (MilletSDK.getInstance().millet && data.code == 200) {//小米支付
                MilletSDK.getInstance().order_id = data.data.cp_order_id;
                GameLog.log("调取小米支付-->" + JSON.stringify(data.data));
                MilletSDK.getInstance().pay(data.data.cp_order_id, data.data.cp_user_info, data.data.product_code, data.data.count, App.nativeBridge.H5_Millet_payBack, this);
                GameLog.log("小米支付");
                return;
            } else if (H5_Vivo_SDK.getInstance().vivoData && data.code == 200) {//vivo支付
                H5_Vivo_SDK.getInstance().order_id = data.data.order_id;
                GameLog.log("调取vivo支付-->" + JSON.stringify(data.data));
                let params = {
                    productName: data.data.payinfo.productName,
                    productDes: data.data.payinfo.productDes,
                    productPrice: data.data.payinfo.productPrice + "",
                    vivoSignature: data.data.payinfo.vivoSignature,
                    appId: H5_Vivo_SDK.getInstance().appid,
                    transNo: data.data.payinfo.transNo + "",
                    uid: H5_Vivo_SDK.getInstance().gameInfo.openid
                };
                H5_Vivo_SDK.getInstance().Vivo_pay(params, App.nativeBridge.H5_vivo_payBack, App.nativeBridge);
                return;
            }
            App.nativeBridge.webChanelPay(data.data.order_id, data.data.product_id, data.data.safeCode);
            //
        }
        else if (DeviceUtil.IsIos && DeviceUtil.IsNative) {
            App.nativeBridge.sendIOSPay(data.data.order_id, data.data.product_id);
        }
        else if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
            //App.nativeBridge.sendAndroidPay(data.data.order_id, data.data.product_id);
        }
    }

    public H5_Millet_payBack() {
        let order_id = MilletSDK.getInstance().order_id;
        GameLog.log("millet支付订单号" + order_id);

        let sendData = {
            order_id: order_id
        };
        App.timer.clearTimer(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish);
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, sendData, new FunctionVO((data) => {
            if (data.code == 200) {
                Notice.showBottomCenterMessage("支付成功");
                App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                App.data.game2Center.LoadingLock.unlock();
            } else {
                App.timer.serverTimeEnd(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish, ServerTime.serverTime + 20, [sendData]);
            }
        }, this));
    }

    public H5_vivo_payBack() {
        let order_id = H5_Vivo_SDK.getInstance().order_id;
        GameLog.log("vivo支付订单号" + order_id);
        let pos = 1;

        let sendData = {
            order_id: order_id
        };

        App.timer.clearTimer(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish);

        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, sendData, new FunctionVO((data) => {
            if (data.code == 200) {
                Notice.showBottomCenterMessage("支付成功");
                App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                App.data.game2Center.LoadingLock.unlock();
            } else {
                App.timer.serverTimeEnd(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish, ServerTime.serverTime + 60, [sendData]);
            }
        }, this));
    }

    //web渠道支付
    public webChanelPay(order_id, payid, code) {
        App.data.game2Center.LoadingLock.lock(null, null, false);
        //7k7k支付
        let auth_7k7k = window["auth_7k7k"];
        if (auth_7k7k) {
            let K7_SDK = window["K7_SDK"];
            K7_SDK.Pay({
                "safeCode": code
            });

            let pos = 1;

            let sendData = {
                order_id
            };

            App.timer.serverTimeEnd(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish, ServerTime.serverTime + 300, [sendData]);

            return false;
        }

    }

    /**IOS支付 */
    public sendIOSPay(order_id, payid) {
        App.data.game2Center.LoadingLock.lock(null, null, false);
        let data = { order_id: "", payId: "", authorization: "", url: "", channel: "" };
        data.order_id = "" + order_id;
        data.payId = "" + payid;
        data.authorization = "" + App.data.game2Center.DataCenter.skey;
        data.url = "" + ProtocolHttpUrlGame2.giftForUser;
        if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
            data.channel = IOSConfig.channel;
        }
        this.call("iosPay", JSON.stringify(data));
    }

    /**
     * 盒子IOS支付
     */
    public sendIOSPayNew(type: number, productId: number) {
        ProtocolCommon.instance().send_shop_please_pay(type, productId, EnumPayType.BUY_TYPE_CASH, new FunctionVO((response: any) => {
            if (ResponseUtil.checkResponseData(response)) {
                let orderid = response.data.order_id;
                let pid = response.data.code;
                let data = { order_id: "", payId: "", authorization: "", url: "", channel: "", price: 0 };
                data.order_id = "" + orderid;
                data.price = response.data.price;
                data.payId = "" + pid;
                if (DeviceUtil.IsNative && DeviceUtil.IsIos) {
                    data.channel = IOSConfig.channel;
                }
                this.call("iosPay", JSON.stringify(data));
            }
        }, this));
    }

    /**ios支付完成 */
    public iosPayFinish(data: string) {
        App.data.game2Center.LoadingLock.unlock();
        // if (GameManager.isPlaying && GameManager.lasetGameId == EnumGameID.GAME2)
        //     App.dispatcher.dispatchEvent(EventConst.GIFTFORUSER, data);
        // else {
            var obj: any = JSON.parse(data);
            if (obj.code == 200) {
                ProtocolCommon.sendBack(ProtocolHttpUrl.ios_is_bought, {
                    order_id: obj.data.order_id,
                    receipt: obj.data.receipt
                }, new FunctionVO(App.nativeBridge.checkIosPayFinish, App.nativeBridge, obj.data.order_id, obj.data.receipt, 20),
                    true, ProtocolHttpUrl.ip, true, false);
            } else {
                Notice.showBottomCenterMessage("" + obj.info);
            }
        // }
    }

    /**
     * 检测avg的IOS订单支付
     */
    public checkIosPayFinish(response: any, order_id: string, receipt: string, leftNum: number): void {
        if (ResponseUtil.checkResponseData(response) && response.data && response.data.type) {
            App.global.userInfo.xdCoin = response.data.balance;
            App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
            App.dispatcher.dispatchEvent(EventType.BUY_SUCCESS, response.data.pid, response);
        }
        else if (leftNum > 0) {
            App.timer.doTimeOnce(ProtocolCommon, 3000, ProtocolCommon.sendBack, [
                ProtocolHttpUrl.ios_is_bought,
                { order_id: order_id, receipt: receipt },
                new FunctionVO(App.nativeBridge.checkIosPayFinish, App.nativeBridge, order_id, receipt, leftNum - 1),
                true, ProtocolHttpUrl.ip, true, false
            ]);
        }
        else {
            Notice.showBottomCenterMessage("支付失败");
        }
    }

    //android支付
    public sendAndroidPay(gid, goodsDes) {
        let data = { gid, "token": App.data.game2Center.DataCenter.skey, goodsDes };
        this.call("pay", JSON.stringify(data));
    }

    /**
     * u8支付(心动1)
     * @param type "libao" "diamond" 礼包和钻石，用于区分拼接数据...
     * @param obj 购买的物品数据信息
     */
    public sendU8PayOld(type, obj) {
        let data = ProtocolHttp.giftBuy;
        data.gid = obj.id;
        data["channel"] = "u8";
        ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.giftBuy, data, new FunctionVO((res) => {
            if (res.code == 200) {
                let orderid = res.data.order_id;
                let pid = res.data.product_id;
                let diamonds = App.data.game2Center.DataCenter.UserInfo.diamond;

                let goodsDes = {};
                if (type == "libao") {
                    let packages = obj.package;
                    let { price } = obj;
                    let desc = "解锁" + packages[0]["cname"] + "功能";
                    if (packages.length > 1) {
                        desc += ",加送" + packages[1]["num"] + packages[1]["cname"];
                    }
                    goodsDes = {
                        buyNum: 1,
                        productName: packages[0]["cname"],
                        price: price,
                        productDesc: desc,
                        orderID: orderid,
                        productId: pid,
                        diamonds,
                        ratio: "",
                        serverID: "",
                        serverName: "赵小野",
                        gameType: 0
                    };
                } else if (type == "diamond") {
                    let goodPro = obj.package[0];
                    let { price } = obj;
                    goodsDes = {
                        buyNum: 1,
                        // productName: "购买" + goodPro["num"] + goodPro["cname"],
                        productName: goodPro["num"] + goodPro["cname"],
                        price: price,
                        productDesc: `只需${price}元即可获得${goodPro["num"]}${goodPro["cname"]}`,
                        orderID: orderid,
                        productId: pid,
                        diamonds,
                        ratio: "",
                        serverID: "",
                        serverName: "赵小野",
                        gameType: 0
                    };
                } else {
                    return false;
                }
                this.call("pay", JSON.stringify(goodsDes));
            }
        }, this));
    }

    /**
     * u8支付(盒子)
     * @param type 购买类型
     * @param obj 购买的物品数据信息
     */
    public sendU8PayNew(type: number, obj: any) {
        App.nativeBridge.log("盒子下单:" + JSON.stringify(obj));
        ProtocolCommon.instance().send_shop_please_pay(type, obj.productId, EnumPayType.BUY_TYPE_CASH, new FunctionVO((response: any) => {
            if (ResponseUtil.checkResponseData(response)) {
                let orderid = response.data.order_id;
                let pid = response.data.code;
                obj.gameType = 1;
                obj.orderID = orderid;
                obj.price = Number(response.data.price);
                obj.productId = pid;
                App.nativeBridge.log(JSON.stringify(obj));
                this.call("pay", JSON.stringify(obj));
            }
        }, this));
    }

    /**
     * 返回u8支付  
     * @param data {orderID:失败:"0"  成功:orderID,gameType:0:心动1项目 1:盒子}
     */
    public revU8Pay(dataStr) {
        var data = JSON.parse(dataStr);
        App.nativeBridge.log("u8 pay back:" + dataStr);
        if (!data || data.orderID == "0") {
            return;
        }

        let order_id = data.orderID;

        let sendData = {
            order_id: order_id
        };

        if (data.gameType == 0) {
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, sendData, new FunctionVO((data) => {
                if (data.code == 200) {
                    App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                    //Notice.showBottomCenterMessage(res)
                    App.data.game2Center.LoadingLock.unlock();
                } else {
                    App.timer.serverTimeEnd(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish, ServerTime.serverTime + 60, [sendData]);
                }
            }, this), false, false);
        }
        else if (data.gameType == 1) {
            ProtocolCommon.sendBack(ProtocolHttpUrl.shop_is_shop, { order_id: order_id },
                new FunctionVO(App.nativeBridge.checkAndroidPayFinishNew, App.nativeBridge, order_id, 20),
                true, ProtocolHttpUrl.ip, true, false);
        }
    }

    public checkAndroidPayFinish(serverTimeData: ServerTimeData): void {
        if (serverTimeData.spuleTime <= 0) {
            App.timer.clearTimer(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish);
        }
        else if (serverTimeData.spuleTime % 2 == 1) {//每2秒执行一次
            ProtocolGame2.sendCommom(ProtocolHttpUrlGame2.payStatusH5, serverTimeData.args[0], new FunctionVO((data) => {
                if (data.code == 200) {
                    App.timer.clearTimer(App.nativeBridge, App.nativeBridge.checkAndroidPayFinish);
                    App.dispatcher.dispatchEvent(EventConst.REQ_GAME_INFO);
                    App.data.game2Center.LoadingLock.unlock();
                }
            }, this), false, false);
        }
    }

    /**
     * 检测avg安卓支付
     */
    public checkAndroidPayFinishNew(response: any, order_id: string, leftNum: number): void {
        if (ResponseUtil.checkResponseData(response) && response.data && response.data.type) {
            App.global.userInfo.xdCoin = response.data.balance;
            App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
            App.dispatcher.dispatchEvent(EventType.BUY_SUCCESS, response.data.pid, response);
        }
        else if (leftNum > 0) {
            App.timer.doTimeOnce(ProtocolCommon, 3000, ProtocolCommon.sendBack, [
                ProtocolHttpUrl.shop_is_shop,
                { order_id: order_id },
                new FunctionVO(App.nativeBridge.checkAndroidPayFinishNew, App.nativeBridge, order_id, leftNum - 1),
                true, ProtocolHttpUrl.ip, true, false]);
        }
        else {
            Notice.showBottomCenterMessage("支付失败");
        }
    }

    /**
     * 分享
     * @param title 分享的标题 最大30字符
     * @param titleUrl  标题链接(该参数仅在QQ和QQ空间分享用到)
     * @param content 分享文本内容 最大130字符
     * @param imgUrl 图片链接地址
     * @param url 网址链接地址(该参数仅在微信分享网页和视频的时候会用到)
     * @param site 分享此内容的网站名称(该参数仅在QQ空间分享用到)
     * @param siteUrl 分享此内容的网站地址(该参数仅在QQ空间分享用到)
     * @param channelID 渠道ID 1:微信 2:QQ 3:新浪微博
     * @param type 分享类型 1:wx文字分享 2:wx图片分享 3:链接分享
     * @param scene 分享场景 1:微信好友 2:微信朋友圈 3:微信收藏  4:QQ 5:QQ空间 6:新浪微博
     */
    public share(title?: string, titleUrl?: string, content?: string, imgUrl?: string, url?: string,
        site?: string, siteUrl?: string, channelID?: number, type?: number, scene?: number): void {
        var data: any = {
            title: title,
            titleUrl: titleUrl,
            site: site,
            siteUrl: siteUrl,
            content: content,
            url: url,
            imgUrl: imgUrl,
            channelID: channelID,
            type: type,
            scene: scene
        };
        this.call("U8Share", JSON.stringify(data));
    }

    private shareBack(data: any): void {
        GameLog.log('分享返回数据：', data);
        App.nativeBridge.log('分享返回数据：' + data);
        // if (data != "分享成功")//失败才提示，成功不提示了
        Notice.showBottomCenterMessage(data);
        PanelOpenManager.removePanel(EnumPanelID.GAME_SHARE2);
    }

    /**停止开机画面 */
    public stopSplash() {
        this.call("stopSplash", "");
    }

    //发送角色信息
    public submitGameData(data) {
        this.call("submitGameData", JSON.stringify(data));
    }

    /**通知runtime加载页面已就绪,可以关闭runtime loading */
    public customLoadingFlag() {
        if (DeviceUtil.IsNative) {
            var json = { current: 10, total: 10 };
            var jsonStr = JSON.stringify(json);
            this.call("customLoadingFlag", jsonStr);
        }
    }

    /**
     * 获取设备码
     */
    public getDeviceCode(): void {
        this.call("getIMEI", "");
    }

    /**
     * 设备码返回
     */
    public getDeviceCodeBack(code: string): void {
        App.global.userInfo.deviceCode = code;
        App.dispatcher.dispatchEvent(LoginEvent.GET_DEVICE_CODE_BACK)
    }

    /**
     * 设置横竖屏
     */
    public setOrientation(isLandscape: string): void {
        this.call("isLandscape", isLandscape);
    }

    /**
     * 获取初始横竖屏
     */
    public getStartOrientation(): void {
        this.call("startOrientation", "");
    }

    /**
     * 获取初始横竖屏
     */
    public getStartOrientationBack(orientation: string): void {
        Config.isLandscape = orientation == egret.OrientationMode.LANDSCAPE;
        App.nativeBridge.log("get start orientation back:" + orientation + "(" + Config.isLandscape + ")");
        App.dispatcher.dispatchEvent(LoginEvent.GET_START_ORIENTATION_BACK);
    }

    /**
     * 获取渠道ID
     */
    public getChannelId(): void {
        this.call("getChannelId", "");
    }

    public getChannelIdBack(channelDataStr: string): void {
        let channelData = JSON.parse(channelDataStr);
        App.global.userInfo.channelId = channelData.channelId;
        App.global.userInfo.portId = channelData.portId;
        App.nativeBridge.log("渠道数据为:" + channelDataStr);
    }

    /**
     * 获取是否第一次登录安卓
     */
    public getIsFirstLoginAndroid(): void {
        this.call("isFirstStart", "");
    }

    public getIsFirstLoginAndroidBack(str: string): void {
        var data: any = JSON.parse(str);
        App.global.userInfo.isFistStart = data.isFirstStart;
    }

    /**
     * 日志打印
     */
    public log(str: string): void {
        this.call("testLog", "egert => " + str);
    }

    /**
     * 发送友盟日志
     */
    public sendUMengData(eventID: string, params: any): void {
        var logData: string = "[UMeng]" + eventID + ":" + JSON.stringify(params);
        GameLog.log(logData);
        App.nativeBridge.log(logData);
        var data = { eventID: eventID, data: params };
        this.call("UMeng", JSON.stringify(data));
    }

    /**
     * 上传角色信息
     */
    public sendUserData(data): void {
        this.call("setUserID", JSON.stringify(data));
    }

    /*
	 * 复制文本
     */
    public sendCopy(str: string): void {
        this.call("copy", str);
    }
}