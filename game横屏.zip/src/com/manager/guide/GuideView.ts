class GuideView extends eui.Component implements IDispose {
	public isDispose: boolean;
	private showArea: egret.Bitmap;//可视点击区域
	private showAreaS: egret.Sprite;//可视点击区域
	private container: egret.DisplayObjectContainer;
	private bgMask: egret.Shape;//黑色蒙版
	private renderTexture: egret.RenderTexture;
	private bitmap: egret.Bitmap;

	public guideId: number;
	private textBg: eui.Image;
	private textDesc: egret.TextField;
	private _display: egret.DisplayObject;

	private _effect: ListenEffect;

	public constructor() {
		super();
	}

	public show(datas: Array<any>): void {
		var t: number = egret.getTimer();
		var display: egret.DisplayObject = datas[0];//引导可视对象
		this.guideId = datas[1];
		var px: number = display.localToGlobal().x;
		var py: number = display.localToGlobal().y;
		var sw: number = display.width;
		var sh: number = display.height;
		let effectSize: number;
		this._display = display;
		this._display.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onClickDisplay, this);
		if (!this.container) this.container = new egret.DisplayObjectContainer();

		//引导蒙版
		if (!this.bgMask) {
			this.bgMask = new egret.Shape();
			this.container.addChild(this.bgMask);
		}
		this.bgMask.graphics.clear();
		this.bgMask.graphics.beginFill(0x000000, 0.65);
		this.bgMask.graphics.drawRect(0, 0, Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
		this.bgMask.graphics.endFill();
		if (!this.showArea) {
			this.showArea = new egret.Bitmap();
		}
		// GameLog.log('display instanceof eui.Button = ', (display instanceof eui.Button));
		//引导透视区域// || display instanceof eui.Image
		var useTexture: boolean = display instanceof eui.Button;
		if (useTexture) { //按钮和图片类型的用本身的资源做可视区域
			var img: eui.Image;
			if (display instanceof eui.Button) {
				img = (display as eui.Button).getChildAt(0) as eui.Image;
			} else {
				img = display as eui.Image;
			}
			this.container.addChild(this.showArea);
			this.showArea.texture = img.texture;
			this.showArea.x = px;
			this.showArea.y = py;
			this.showArea.width = sw;
			this.showArea.height = sh;
			this.showArea.blendMode = egret.BlendMode.ERASE;
			if (this.showAreaS && this.showAreaS.parent) {
				this.showAreaS.parent.removeChild(this.showAreaS);
			}
			effectSize = sh * 0.8;
		} else {
			effectSize = sh * 2;
			if (this.showArea && this.showArea.parent) {
				this.showArea.parent.removeChild(this.showArea);
			}
			if (!this.showAreaS) {
				this.showAreaS = new egret.Sprite();
				this.showAreaS.touchEnabled = false;
			}
			this.container.addChild(this.showAreaS);
			this.showAreaS.graphics.clear();
			this.showAreaS.graphics.beginFill(0xff0000);
			this.showAreaS.graphics.drawRoundRect(px - 5, py - 5, sw + 10, sh + 10, sw * 0.3, sh * 0.3);
			this.showAreaS.graphics.endFill();
			this.showAreaS.blendMode = egret.BlendMode.ERASE;
		}
		if (!this.renderTexture) {
			this.renderTexture = new egret.RenderTexture();
		}
		this.renderTexture.drawToTexture(this.container);

		//引导整个画面
		if (!this.bitmap) {
			this.bitmap = new egret.Bitmap();
			this.addChild(this.bitmap);
			this.bitmap.touchEnabled = true;  //允许点击
			this.bitmap.pixelHitTest = true;  //镂空区域不响应点击，这样可以穿透点击到下面的背景
		}
		this.bitmap.texture = this.renderTexture;

		//引导文本框+文本
		if (datas[2]) {
			if (!this.textBg) {
				this.textBg = new eui.Image("img_guide_wordbg_png")
				this.textBg.scale9Grid = new egret.Rectangle(90, 86, 40, 10);
				this.textBg.touchEnabled = false;
				this.addChild(this.textBg);

				this.textDesc = new egret.TextField();
				this.textDesc.textColor = 0xFFFFFF;
				this.textDesc.size = 26;
				this.textDesc.wordWrap = true;
				this.textDesc.multiline = true;
				this.textDesc.textAlign = "center";
				this.textDesc.lineSpacing = 10;
				this.textDesc.touchEnabled = false;
				this.addChild(this.textDesc);
			}
			this.textBg.visible = true;
			this.textDesc.visible = true;
			this.textDesc.text = datas[2];
			this.textBg.width = Math.max(this.textDesc.textWidth + 76, 200);
			this.textBg.height = Math.max(this.textDesc.textHeight + 78, 150);
			this.textBg.x = Math.min(px + (sw - this.textBg.width) * 0.5, Config.MAIN_WIDTH - this.textBg.width - 20);
			this.textBg.y = py - this.textBg.height - 20;
			this.textDesc.x = this.textBg.x + (this.textBg.width - this.textDesc.textWidth) * 0.5 + 12;
			this.textDesc.y = this.textBg.y + (this.textBg.height - this.textDesc.textHeight) * 0.5 + 12;
		} else {
			if (this.textBg) {
				this.textBg.visible = false;
				this.textDesc.visible = false;
			}
		}
		//引导特效
		if (!this._effect) {
			this._effect = new ListenEffect(effectSize, 0.5, 500);
		}
		this.addChild(this._effect);
		this._effect.x = px + sw * 0.5;
		this._effect.y = py + sh * 0.5;
		this._effect.play();

		// GameLog.log("引导的绘制时间：time=", egret.getTimer() - t);
		App.timer.doTimeOnce(this, 2000, this.addClickEvent);
		this.touchEnabled = false;
		// this.touchChildren = false;
	}

	private addClickEvent(): void {
		App.timer.clearTimer(this, this.addClickEvent);
		this.touchEnabled = true;
		// this.touchChildren = true;
		this.removeEffect();//2秒后关闭特效
		this.bitmap.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBg, this);
	}

	private onClickDisplay(e: egret.TouchEvent) {
		App.global.guide.removeView(this.guideId);
		if (this.guideId == EnumGuideType.START_AUTOPLAY) {
			App.global.storage.setItem(EnumStorageType.HERONIES_SETTING_AUTOPLAY + App.global.userInfo.uid + "_" + App.data.gameFangDongCenter.gameId, "1");
			if (App.data.gameFangDongCenter.gameId)
				App.data.gameFangDongCenter.updateSetting();
		}
	}

	private onClickBg(e: egret.TouchEvent) {
		App.global.guide.removeView(this.guideId);
		App.global.guide.showNextView(this.guideId);
	}

	private removeEffect(): void {
		if (this._effect) {
			this._effect.stop();
			this._effect.remove();
		}
	}

	public dispose(): void {
		App.timer.clearTimer(this, this.addClickEvent);
		this.removeEffect();
		if (this.bitmap) {
			this.bitmap.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBg, this);
		}
		if (this._display) {
			this._display.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onClickDisplay, this);
		}
		if (this.parent) {
			this.parent.removeChild(this);
		}
		GuideView.pool.push(this);
	}

	private static pool: GuideView[] = [];
	public static getView(): GuideView {
		if (this.pool.length) {
			this.pool.pop();
		}
		return new GuideView();
	}

}