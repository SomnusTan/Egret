class GuideManager {
	private descHash: HashMap;
	private guideHash: HashMap;
	private displayHash: HashMap;

	/** 所有引导状态数据，存本地 */
	private guideStates: string;
	private guideView: GuideView;
	/** fangdong\_guide\_角色ID */
	private allGuidesKey: string;
	/** 是否初始化所有引导状态 */
	private _initState: boolean;

	/**当前引导id */
	public guideId: number;

	public constructor() {
		this.init();
	}
	/**初始化所有引导的信息 */
	private init(): void {
		this.descHash = new HashMap();
		this.guideHash = new HashMap();
		this.displayHash = new HashMap();
		this.descHash.put(EnumGuideType.OPEN_MENU, ["做选择之前保存一下，\n选错还可以读取存档获得\n重新选择的机会哦！"]);
		this.descHash.put(EnumGuideType.AVG_MENU_SAVE, ["故事中有许多节点会将剧情引向\n不同的分支，在关键的节点处\n进行保存，轻松体验多样剧情！"]);
		this.descHash.put(EnumGuideType.REVIEW, ["回顾之前的内容，给寇雅最恰当的回应吧！"]);
		this.descHash.put(EnumGuideType.DETAIL_MEMORY, ["解锁了新的回忆\n快来看看吧！"]);
		this.descHash.put(EnumGuideType.AVG_HELP, ["不知道该怎么选？\n问问朋友们吧！"]);
		this.descHash.put(EnumGuideType.START_AUTOPLAY, ["点此开始自动播放"]);
		this.descHash.put(EnumGuideType.PRESS_JUMPREAD, ["长按跳过已读内容"]);
		this.descHash.put(EnumGuideType.END_SHARE, ["解锁了新的结局\n分享给大家看看吧！"]);
		this.descHash.put(EnumGuideType.DETAIL_READ, ["不同的回答有不同的后续内容\n解锁后续故事前还有很多没有探索呢~\n读取存档和寇雅多相处一会儿吧！"]);
		this.descHash.put(EnumGuideType.OPEN_MENU2, ["对选择不太满意？读取之前\n保存的进度，重新选择一次吧！"]);
		this.descHash.put(EnumGuideType.AVG_MENU_READ, ["系统会自动保存最近一次选择的\n节点，对寇雅的回应不满意？\n读取进度再试一次吧！"]);
	}

	/**初始化所有引导的状态 */
	public initState(): void {
		if (this._initState) return;
		this._initState = true;
		var uid: number = App.global.userInfo.uid;
		if (!uid) { GameLog.logError('未获得角色id'); return; }
		this.allGuidesKey = EnumStorageType.FANGDONG_PLAYER_GUIDE + uid;
		this.readExistGuideData();
		//可引导状态，第一次遇到就加引导
		this.changeGuideTo_stateN(EnumGuideType.REVIEW);
		this.changeGuideTo_stateN(EnumGuideType.DETAIL_MEMORY);
		this.changeGuideTo_stateN(EnumGuideType.START_AUTOPLAY);
		this.changeGuideTo_stateN(EnumGuideType.END_SHARE);
		//等待状态：需要某条件触发后才可以添加引导
		this.changeGuideTo_state0(EnumGuideType.OPEN_MENU);
		this.changeGuideTo_state0(EnumGuideType.AVG_MENU_SAVE);
		this.changeGuideTo_state0(EnumGuideType.OPEN_MENU2);
		this.changeGuideTo_state0(EnumGuideType.AVG_MENU_READ);
		this.changeGuideTo_state0(EnumGuideType.AVG_HELP);
		this.changeGuideTo_state0(EnumGuideType.PRESS_JUMPREAD);
		this.changeGuideTo_state0(EnumGuideType.DETAIL_READ);
	}
	/**提前注册引导id对应的按钮 */
	public addDisplayer(display: egret.DisplayObject, guideId: number): void {
		this.displayHash.put(guideId, display);
	}
	/**
	 * 添加引导：display：引导对象，guideId：引导id，delay：是否需要延后1帧显示
	 */
	public showView(display: egret.DisplayObject, guideId: number, panelName: string = "", delay: boolean = false): void {
		if (Config.skipGuide) return;
		if (Config.isRelease == false) {
			this.readExistGuideData();//时时读取引导的状态，用来测试
		}
		var guideState: string = this.getGuideStorageValue(guideId);
		if (guideState != EnumGuideType.STATE_N) return;
		var parentCon: egret.DisplayObjectContainer;
		if (panelName == "") {//AVG里面
			parentCon = App.layer.specialMenuLayer;
			if (GameManager.currentGame == null) return;//退出游戏就不加引导了
		} else {
			let info: PanelInfo = PanelManager.getPanelInfo(panelName);
			if (!info) { GameLog.logError('面板不存在:', panelName); return; }
			parentCon = info.parent ? info.parent : App.layer.moduleLayer;
			if (PanelManager.isShowing(panelName) == false) return;//面板关掉了就不加引导了
		}
		if (delay) {
			App.timer.doFrameOnce(this, 1, this.showGuide, [display, guideId, parentCon]);
		} else {
			this.showGuide(display, guideId, parentCon);
		}
	}

	private showGuide(display: egret.DisplayObject, guideId: number, parentCon: egret.DisplayObjectContainer = App.layer.sceneLayer): void {
		this.setGuideStorageData(guideId, EnumGuideType.STATE_1);//已经引导
		App.timer.clearTimer(this, this.showGuide);
		if (this.guideView == null)
			this.guideView = GuideView.getView();
		var desc: string = this.descHash.get(guideId)[0];
		this.guideId = guideId;
		this.guideView.show([display, guideId, desc]);
		parentCon.addChild(this.guideView);
		if (this.guideId == EnumGuideType.REVIEW) {
			this.changeGuideTo_stateN(EnumGuideType.OPEN_MENU);
		} else if (this.guideId == EnumGuideType.OPEN_MENU) {
			this.changeGuideTo_stateN(EnumGuideType.AVG_MENU_SAVE);
		} else if (this.guideId == EnumGuideType.AVG_MENU_SAVE) {
			this.changeGuideTo_stateN(EnumGuideType.AVG_HELP);
		} else if (this.guideId == EnumGuideType.OPEN_MENU2) {
			this.changeGuideTo_stateN(EnumGuideType.AVG_MENU_READ);
		}
	}
	/**移除引导 */
	public removeView(guideId: number): void {
		if (this.guideView && this.guideView.guideId == guideId) {
			this.guideId = -1;
			this.guideView.dispose();
			this.guideView = undefined;
		}
	}
	/** 连续的引导 */
	public showNextView(guideId: number): void {
		var display: egret.DisplayObject;
		var showNextGuideId: number = -1;
		if (guideId == EnumGuideType.REVIEW) {//回放不打开面板，关掉引导的话，下一步直接引导菜单
			showNextGuideId = EnumGuideType.OPEN_MENU;
		}
		if (showNextGuideId != -1) {
			display = this.displayHash.get(showNextGuideId);
			if (display) {
				this.showView(display, showNextGuideId);
			}
		}
	}
	/**移除存在的引导 */
	public removeExistGuide(): void {
		if (this.guideView) {
			this.removeView(this.guideView.guideId);
		}
	}

	/**
	 * 改变引导状态：由等待状态的不可引导 变成 可引导
	 */
	public changeGuideTo_stateN(guideId: number): void {
		var storageValue: string = this.getGuideStorageValue(guideId);
		if (!storageValue || storageValue == EnumGuideType.STATE_0) {
			this.setGuideStorageData(guideId, EnumGuideType.STATE_N);
		}
	}

	/**
	 * 改变引导状态：由可引导 变成 等待状态的不可引导
	 */
	private changeGuideTo_state0(guideId: number): void {
		var storageValue: string = this.getGuideStorageValue(guideId);
		if (!storageValue || storageValue == EnumGuideType.STATE_N) {
			this.setGuideStorageData(guideId, EnumGuideType.STATE_0);
		}
	}

	/**
	 * 设置引导的本地存储数据
	 */
	private setGuideStorageData(guideId: number, value: string, updateAll: boolean = true): void {
		this.guideHash.put(guideId, value);
		if (updateAll) {
			this.updateAllGuideStates();
		}
	}
	/**
	 * 获得本地存储引导数据
	 */
	private getGuideStorageValue(guideId: number): string {
		return this.guideHash.get(guideId);
	}
	/**读取本地存储的引导数据 */
	private readExistGuideData(): void {
		var allGuides: string = App.global.storage.getItem(this.allGuidesKey);
		if (allGuides && allGuides.length == EnumGuideType.MAX_NUM) {
			for (var i: number = 0; i < EnumGuideType.MAX_NUM; i++) {
				this.setGuideStorageData(i, allGuides.charAt(i), i == EnumGuideType.MAX_NUM - 1);
			}
		}
	}
	/**更新所有的引导数据 */
	private updateAllGuideStates(): void {
		this.guideStates = "";
		for (var i: number = 0; i < EnumGuideType.MAX_NUM; i++) {
			this.guideStates += this.getGuideStorageValue(i);
		}
		App.global.storage.setItem(this.allGuidesKey, this.guideStates);
	}

}