class DispatcherRegister {
	public constructor() {
		this._mouseEventHash = new HashMap();
		this._moduleEventHash = new HashMap();
	}

	/**
	 * 注册事件侦听器
	 * type 	事件的类型
	 * listener 处理事件的侦听器函数
	 * thisArg  侦听函数绑定的this对象
	 * target   事件对象<若传值则为egret原生事件 反之为普通回调事件>
	 */
	public addEventListener(type: string, listener: Function, thisArg: any, target?: egret.IEventDispatcher): void {
		if (target) {
			let targetHash: HashMap = this._mouseEventHash.get(target);
			let o: FunctionVO;
			if (!targetHash) {
				targetHash = new HashMap();
				this._mouseEventHash.put(target, targetHash);
			}
			if (!targetHash.get(type)) {
				o = new FunctionVO(listener, thisArg);
				targetHash.put(type, [o]);
				target.addEventListener(type, this.eventHandler, this);
			} else {
				if (!this.hasEventListener(type, listener, thisArg, target)) {
					let listeners: any[] = targetHash.get(type);
					o = new FunctionVO(listener, thisArg);
					listeners.push(o);
				}
			}
		} else {
			let funcList: any[] = this._moduleEventHash.get(type);
			if (!funcList) {
				funcList = [];
				this._moduleEventHash.put(type, funcList);
			}
			if (!this.hasEventListener(type, listener, thisArg)) {
				let v: FunctionVO = new FunctionVO(listener, thisArg);
				funcList.push(v);
				App.dispatcher.addEventListener(type, listener, thisArg);
			}
		}
	}

	/**
	 * 派发事件<仅针对普通回调事件>
	 * type 事件类型
	 * args 参数
	 */
	public dispatchEvent(type: string, ...args): void {
		let funcList: any[] = this._moduleEventHash.get(type);
		if (funcList) {
			App.dispatcher.dispatchEvent(type, args);
		}
	}

	/**
	 * 是否为特定事件类型注册了任何侦听器
	 * type 	事件类型
	 * listener 侦听函数
	 * target   事件对象
	 */
	public hasEventListener(type: string, listener: Function, thisArg: any, target?: egret.IEventDispatcher): boolean {
		if (target) {
			let targetHash: HashMap = this._mouseEventHash.get(target) as HashMap;
			if (!targetHash) {
				return false;
			}
			let listeners: any[] = targetHash.get(type);
			if (!listeners || listeners.length == 0) {
				return false;
			}
			let method: Function;
			let arg: any;
			for (let j: number = 0; j < listeners.length; j++) {
				method = listeners[j].fun;
				arg = listeners[j].thisObject;
				if (method == listener && arg == thisArg) {
					return true;
				}
			}
			return false;
		} else {
			let funcList: any[] = this._moduleEventHash.get(type);
			if (!funcList == undefined || funcList.length == 0) {
				return false;
			} else {
				if (!listener) {
					return true;
				} else {
					let len: number = funcList.length;
					for (let i: number = 0; i < len; i++) {
						if (funcList[i].fun == listener && funcList[i].thisObject == thisArg) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	/**
	 * 移除事件侦听器
	 * type     时间类型
	 * listener 侦听函数
	 * thisArg  侦听函数绑定的this对象
	 * target   事件对象
	 */
	public removeEventListener(type: string, listener: Function, thisArg: any, target?: egret.IEventDispatcher): void {
		if (target) {
			if (this.hasEventListener(type, listener, thisArg, target)) {
				let targetHash: HashMap = this._mouseEventHash.get(target) as HashMap;
				let listeners: any[] = targetHash.get(type);
				for (let j: number = 0; j < listeners.length; j++) {
					if (listeners[j].fun == listener && listeners[j].thisObject == thisArg) {
						listeners.splice(j, 1);
						break;
					}
				}
				if (listeners.length == 0) {
					targetHash.remove(type);
					target.removeEventListener(type, this.eventHandler, this);
				}
				if (targetHash.size == 0) {
					this._mouseEventHash.remove(target);
				}
			}
		}
		else {
			let funcList: any[] = this._moduleEventHash.get(type);
			if (funcList) {
				let length: number = funcList.length;
				let listen: Function = undefined;
				let thisArgs: any;
				for (let i: number = 0; i < length; i++) {
					listen = funcList[i].listener;
					thisArgs = funcList[i].thisObject;
					if (listen == listener && thisArg == thisArgs) {
						funcList.splice(i, 1);
						App.dispatcher.removeEventListener(type, listen, thisArgs);
						if (funcList.length == 0) {
							this._moduleEventHash.remove(type);
						}
						break;
					}
				}
			}
		}
	}

	private eventHandler(e: egret.Event): void {
		let target: egret.IEventDispatcher = e.currentTarget as egret.IEventDispatcher;
		let targetHash: HashMap = this._mouseEventHash.get(target);
		if (targetHash) {
			let listeners: any[] = targetHash.get(e.type);
			if (!listeners || listeners.length == 0) {
				return;
			}
			let v: FunctionVO;
			let method: Function;
			let thisArg: any;
			for (let i: number = 0; i < listeners.length; i++) {
				v = listeners[i];
				method = v.fun;
				thisArg = v.thisObject;
				FunctionApply.doExecute(method, thisArg, [e]);
			}
		}
	}

	/**
	 * 移除所有侦听器
	 */
	public removeAllListeners(): void {
		let types: any[] = this._moduleEventHash.keys;
		let i: number = 0;
		let j: number = 0;
		let functionList: any[];
		let type: string;
		for (i = 0; i < types.length; i++) {
			type = types[i];
			functionList = this._moduleEventHash.get(types[i]);
			for (j = 0; j < functionList.length; j++) {
				App.dispatcher.removeEventListener(type, functionList[j].fun, functionList[j].thisObject);
			}
		}
		this._moduleEventHash.clear();
		let mouseTargets: any[] = this._mouseEventHash.keys;
		let hash: HashMap;
		let len: number = mouseTargets.length;
		let target: egret.IEventDispatcher;
		let keys: any[];
		for (i = 0; i < len; i++) {
			target = mouseTargets[i] as egret.IEventDispatcher;
			hash = this._mouseEventHash.get(target);
			if (target && hash) {
				keys = hash.keys;
				for (let j: number = 0; j < keys.length; j++) {
					target.removeEventListener(keys[i], this.eventHandler, this);
				}
			}
		}
		this._mouseEventHash.clear();
	}

	private _mouseEventHash: HashMap;
	private _moduleEventHash: HashMap;
}