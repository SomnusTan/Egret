class EventManager {
	public constructor() {
	}

	/**
	 * 派发事件
	 * @param type	事件类型
	 * @param args	携带数据
	 *
	 */
	public dispatchEvent(type: string, ...args): void {
		let funcList: any[] = this._eventHash.get(type);
		if (funcList) {
			let list: any[] = funcList.concat();
			let length: number = list.length;
			let listen: Function;
			let thisArg: any;
			if (length > 0) {
				for (let i: number = 0; i < length; i++) {
					listen = funcList[i].listener as Function;
					thisArg = funcList[i].thisArg;
					if (listen) {
						FunctionApply.doExecute(listen, thisArg, args);
					}
				}
			}
		}
	}

	/**
	 * 是否含有事件侦听
	 * type		事件类型
	 * listener	对应的事件函数，如果填了此项，则会继续匹配函数
	 * @return
	 */
	public hasEventListener(type: string, listener?: Function, thisArg?: any): boolean {
		let bool: boolean = false;
		let funcList: any[] = this._eventHash.get(type);
		if (!funcList || funcList.length == 0) {
			bool = false;
		} else {
			if (!listener) {
				bool = true;
			} else {
				let len: number = funcList.length;
				let listen: Function = undefined;
				let thisArgs: any;
				for (let i: number = 0; i < len; i++) {
					listen = funcList[i].listener;
					thisArgs = funcList[i].thisArg;
					if (listen == listener && thisArg == thisArgs) {
						bool = true;
						break;
					}
				}
			}
		}
		return bool;
	}

	/**
	 * 添加事件侦听
	 * type		事件类型
	 * listener	事件函数
	 * thisArg  作用域
	 */
	public addEventListener(type: string, listener: Function, thisArg: any): void {
		let funcList: any[] = this._eventHash.get(type);
		if (!funcList) {
			funcList = [];
			this._eventHash.put(type, funcList);
		}
		if (!this.hasEventListener(type, listener, thisArg)) {
			let listenerObj: any = { 'listener': listener, 'thisArg': thisArg };
			funcList.push(listenerObj);
		}
	}

	/**
	 * 移除事件侦听
	 * type		事件类型
	 * listener	事件函数
	 */
	public removeEventListener(type: string, listener: Function, thisArg: any): void {
		let funcList: any[] = this._eventHash.get(type);
		if (funcList) {
			let length: number = funcList.length;
			let listen: Function = undefined;
			let thisArgs: any;
			for (let i: number = 0; i < length; i++) {
				listen = funcList[i].listener;
				thisArgs = funcList[i].thisArg;
				if (listen == listener && thisArgs == thisArg) {
					funcList.splice(i, 1);
					if (funcList.length == 0) {
						this._eventHash.remove(type);
					}
					break;
				}
			}
		}
	}

	/**
	 * 移除所有事件函数
	 */
	public removeAllEventListener(): void {
		this._eventHash.clear();
	}

	/**
	 * 移除某类型的所有事件函数
	 * type	事件类型，如果为null则移除所有事件函数
	 */
	public removeEventListeners(type?: string): void {
		if (type) {
			this._eventHash.remove(type);
		} else {
			this.removeAllEventListener();
		}
	}

	private _eventHash: HashMap = new HashMap();
}