class RedDisplay {
	public constructor() {
	}
	/** 设置显示对象红点
	 * @param display	增加红点的对象
	 * @param state		true增加false删除
	 * @param type		类型：1静态图片，2动态
	 * @param x			坐标X
	 * @param y			坐标Y
	 */
	public static setRedByDisPlayer(display: egret.DisplayObjectContainer, state: boolean, type?: number, x?: number, y?: number): eui.Image {
		let signImg: eui.Image = RedDisplay.getRedImage(display, state);
		if (signImg) {
			signImg.visible = state;
		}
		if (state) {
			if (x) {
				signImg.x = x;
			} else {
				signImg.x = display.width;
			}
			if (y) {
				signImg.y = y;
			} else {
				signImg.y = 0;
			}
			if (type == 2) {
				this.onMoveOver1(signImg);
			}
		} else {
			if (signImg) {
				egret.Tween.removeTweens(signImg);
			}
		}
		return signImg;
	}

	private static onMoveOver1(signImg: eui.Image): void {
		egret.Tween.get(signImg).to({ scaleX: 1.5, scaleY: 1.5 }, 1000).call(this.onMoveOver2, this, [signImg]);
		// GameLog.log("onMoveOver1-------------------------------------");
	}
	private static onMoveOver2(signImg: eui.Image): void {
		egret.Tween.get(signImg).to({ scaleX: 1, scaleY: 1 }, 1000).call(this.onMoveOver1, this, [signImg]);
		// GameLog.log("onMoveOver2-+++++++++++++++++++++++++++++++++++++++++");
	}
	/** 红点图标集合 */
	private static _redImageList: eui.Image[] = [];
	private static _redListLen: number = 0;

	/** 获取显示对象红点 */
	public static getRedImage(display: egret.DisplayObjectContainer, orNew: boolean = false, type: number = 1): eui.Image {
		let image: eui.Image = display.getChildByName('RedPoint') as eui.Image;
		if (orNew && image == null) {
			if (RedDisplay._redListLen > 0) {
				image = RedDisplay._redImageList.pop();
				RedDisplay._redListLen--;
			} else {
				image = new eui.Image;
				image.width = 26;
				image.height = 26;
				image.anchorOffsetX = 13;
				image.anchorOffsetY = 13;
				image.name = "RedPoint";
				if (type == 1) {//静态的可能会换资源，一个红点
					image.source = "common_v1_json.common_v1_heart_png";
				} else {
					image.source = "common_v1_json.common_v1_heart_png";
				}
			}
			image.visible = true;
			display.addChild(image);
		}
		return image;
	}
	/** 回收红点 */
	public static setRedImage(display: egret.DisplayObjectContainer): void {
		let image: eui.Image = display.getChildByName('RedPoint') as eui.Image;
		if (image) {
			egret.Tween.removeTweens(image);
			display.removeChild(image);
			image.x = image.y = 0;
			RedDisplay._redImageList.push(image);
			RedDisplay._redListLen++;
		}
	}
}