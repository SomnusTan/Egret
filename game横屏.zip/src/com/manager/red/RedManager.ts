class RedManager
{
    
}