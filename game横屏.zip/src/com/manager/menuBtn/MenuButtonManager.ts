class MenuButtonManager
{
    
}