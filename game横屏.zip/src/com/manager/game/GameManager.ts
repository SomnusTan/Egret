/**
 * 游戏管理类
 */
class GameManager {

    private static _gameHash: HashMap;
    /**当前进行中的类 */
    private static _currentGame: IGame;
    /**是否正在进行游戏 */
    private static _isPlaying: boolean = false;
    /**上一个游戏ID */
    private static _lastGameId: number = 0;
    /**上一个dlcID */
    private static _lastDlcID: number = 0;

    public static init(): void {
        this._gameHash = new HashMap();
        this.registerGame(EnumGameID.FANG_DONG, EnumGameID.NO_DLC, GameFangDong, "6_纯情房东俏房客");
        this.registerGame(EnumGameID.GAME2, EnumGameID.NO_DLC, Game2, "8_心动女生-赵小野");
        this.registerGame(EnumGameID.FANG_DONG, EnumGameID.FANG_DONG_DLC_1, GameFangDong, "7_寇雅的前男友");
    }

    /**
     * 注册游戏
     * @param gameId 女主游戏ID
     * @param dlcID  0:非dlc >0:dlcID
     * @param gameClass 游戏对象
     */
    public static registerGame(gameId: number, dlcID: number, gameClass: any, gameName: string): void {
        if (this._gameHash.has(gameId + "_" + dlcID))
            throw "游戏ID重复注册";
        else {
            var gameInfo: GameInfo = new GameInfo(gameId, dlcID, gameClass, gameName);
            this._gameHash.put(gameId + "_" + dlcID, gameInfo);
        }
    }

    /**
     * 开始游戏
     * @param gameId 女主游戏ID
     * @param dlcID
     * @param data
     */
    public static startGame(gameId: number, dlcID: number, data?: any): void {
        this.exitGame();
        var info: GameInfo = this._gameHash.get(gameId + "_" + dlcID);
        if (info && info.gameClass) {
            this._lastGameId = gameId;
            this._lastDlcID = dlcID;
            if (info.gameControl == null) {
                info.gameControl = new info.gameClass();
                if (info.hasGetNameData == false && (App.global.userInfo.isNewUser || App.global.userInfo.isFistStart)) {
                    App.nativeBridge.sendUMengData(EnumUMengEventID.GAME_PAGE_COUNT, info.nameData);
                }
            }
            this._currentGame = info.gameControl;
            App.layer.sceneLayer.addChild(this._currentGame.getView());
            this._isPlaying = true;
            this._currentGame.show(data);
        }
    }

    /**
     * 退出游戏
     */
    public static exitGame(): void {
        if (this._currentGame) {
            this._currentGame.getView().remove();
            this._currentGame.hide();
            this._currentGame = null;
            this._isPlaying = false;
        }
    }

    public static get currentGame(): IGame {
        return this._currentGame;
    }

    /**
     * AVG游戏是否在时行中
     */
    public static get isPlaying(): boolean {
        return this._isPlaying;
    }

    /**
     * 上一个游戏ID
     */
    public static get lasetGameId(): number {
        return this._lastGameId;
    }

    /**
     * 上一个dlcID
     */
    public static get lasetDlcID(): number {
        return this._lastDlcID;
    }

    public static isCurrentGame(gameId: number): boolean {
        return this._currentGame && this._currentGame.gameId == gameId;
    }

    /**
     * 释放某个游戏管理器
     */
    public static disposeGame(gameId: number, dlcID: number): void {
        if (this._gameHash.has(gameId + "_" + dlcID)) {
            var gameInfo: GameInfo = this._gameHash.get(gameId + "_" + dlcID);
            if (gameInfo) {
                gameInfo.dispose();
            }
        }
    }
}

/**
 * 游戏注册信息类
 */
class GameInfo {
    /**游戏id */
    public id: number;
    /**DLC ID */
    public dlcID: number;
    /**游戏管理类 */
    public gameClass: any;
    /**实例 */
    public gameControl: IGame;
    /**游戏名字 */
    public gameName: string;
    /**是否获取过统计数据 */
    public hasGetNameData: boolean;

    public constructor(gameId: number, dlcID: number, gameClass: any, gameName: string) {
        this.id = gameId;
        this.dlcID = dlcID;
        this.gameClass = gameClass;
        this.gameName = gameName;
        this.hasGetNameData = false;
    }

    public dispose(): void {
        if (this.gameControl) {
            this.gameControl.dispose();
            this.gameControl = null;
        }
    }

    public get nameData(): any {
        this.hasGetNameData = true;
        return { access_page: this.gameName };
    }

}