class LocalStorageManager {
	public constructor() {
	}
	
    /**
     * 保存数据
     * @param key {string} 要保存的键名称
     * @param value {string} 要保存的值
     * @returns {boolean} 数据保存是否成功
     */
	public setItem(key: string, value: string): boolean {
		return egret.localStorage.setItem(key, value);
	}
	/**
	 * 读取数据
     * @param key {string} 要读取的键名称
	 */
	public getItem(key: string): string {
		return egret.localStorage.getItem(key);
	}
	/**
	 * 删除数据
     * @param key {string} 要删除的键名称
	 */
	public removeItem(key: string): void {
		egret.localStorage.removeItem(key);
	}
	/**
	 * 将所有数据清空
	 */
	public clear(): void {
		 egret.localStorage.clear();
	}
}