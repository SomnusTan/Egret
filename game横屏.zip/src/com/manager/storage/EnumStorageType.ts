class EnumStorageType {
	public constructor() {
	}
	/** 玩家token数据 */
	public static TOKEN: string = "token";
	/**玩家ID */
	public static UID: string = "uid";
	/** 玩家手机号 */
	public static PHONE: string = "phone";
	/** 玩家获取验证码的手机号-未登录成功 */
	public static PHONE2: string = "phone2";
	/** 绑定玩家ID uid ID */
	public static USER_UID: string = "user_uid";
	/** 获得登录验证码CD时间 */
	public static GETCODE_CD_TIME: string = "getcode_cd_time";
	// /** 获得修改手机号验证码CD时间 */
	// public static GETCODE_CHANGE_CD_TIME: string = "getcode_change_cd_time";
	/** 禁用获得验证码时间+手机号 */
	public static FORBID_GETCODE_TIME: string = "forbid_getcode_time";
	/** 解绑手机验证码+手机号 */
	public static UNBIND_GETCODE_TIME: string = "unbind_getcode_time";
	/** 绑定手机验证码+手机号 */
	public static BIND_GETCODE_TIME: string = "bind_getcode_time";
	/**是否游客登录*/
	public static IS_TOURIST: string = "is_tourist";
	/**玩家主动不绑定手机*/
	public static PLAYER_NOT_BIND: string = "player_not_bind";
	/**avg自动解锁章节 */
	public static AVG_AUTO_PAY: string = "avg_auto_pay_";


	/** 女主版本号,要加角色UID -- eg. heronies_version+uid {id:id,version:version} */
	public static HERONIES_VERSION: string = "heronies_version";
	/** 女主资源路径：要加女主id -- eg. heroines_urltext1 */
	public static HERONIES_URLTEXT: string = "heroines_urltext";


	/** 女主设置背景音乐：要加女主id -- eg. heronies_setting_bgm1 */
	public static HERONIES_SETTING_BGM: string = "heronies_setting_bgm";
	/** 女主设置-音效：要加女主id -- eg. heronies_setting_effect1 */
	public static HERONIES_SETTING_EFFECT: string = "heronies_setting_effect";
	/** 女主设置-角色语音：要加女主id -- eg. heronies_setting_rolesound1 */
	public static HERONIES_SETTING_ROLESOUND: string = "heronies_setting_rolesound";
	/** 女主设置-自动播放：要加女主id -- eg. heronies_setting_autoplay1 */
	public static HERONIES_SETTING_AUTOPLAY: string = "heronies_setting_autoplay";
	/** 女主设置-文字速度：要加女主id -- eg. heronies_setting_wordspeed1 ("语速 1:慢, 2:普通, 3:快")*/
	public static HERONIES_SETTING_WORDSPEED: string = "heronies_setting_wordspeed";
	/**大厅音乐设置 */
	public static HALL_MUSIC_SETTING: string = "Hall_music_setting";
	/** 大厅音效设置 */
	public static HALL_SOUND_SETTING: string = "Hall_sound_setting";

	//====================赵小野数据==========================
	/**心动1账号 */
	public static G2_ACCOUNT: string = "account";
	/**是否游客 */
	public static G2_GUEST: string = "guest";
	/**自动语音 */
	public static G2_AUTO_VOICE: string = "autoVoice";
	/**允许特效 */
	public static G2_ALLOW_EFFECT: string = "allowEffect";
	/**允许音乐 */
	public static G2_ALLOW_MUSIC: string = "allowMusic";
	/**允许音乐 */
	public static G2_NICK_NAME: string = "nickName";
	/**电话引导 */
	public static G2_TEL_GUIDE: string = "telGuide";
	/**心动1TOKEN */
	public static G2_TOKEN: string = "g2_token";


	//====================房东新手引导数据==========================
	/** 新手引导 */
	public static FANGDONG_PLAYER_GUIDE: string = "fangdong_guide_";

}