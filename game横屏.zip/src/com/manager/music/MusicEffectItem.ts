class MusicEffectItem {
	public constructor() {
	}

	public get lastPlaying(): number {
		return this._lastPlayingTime;
	}

	public set lastPlaying(value: number) {
		this._lastPlayingTime = value;
	}

	public set volume(value: number) {
		this._volume = value;
		if (this._soundChannel) {
			this._soundChannel.volume = this._volume;
		}
	}

	public get volume(): number {
		return this._volume;
	}

	public get path(): string {
		return this._path;
	}

	public set path(value: string) {
		this._path = value;
	}

	public get isPlaying(): boolean {
		return this._isPlaying;
	}

	public playSound(volume: number, isLoop: boolean = false, returnCallBack: FunctionVO = null, callBack: FunctionVO = null): void {
		this._volume = volume;
		this._returnCallBack = returnCallBack;
		this._callBack = callBack;
		this._isLoop = isLoop;
		if (this._isPlaying) {
			return;
		}
		if (this.isKey && RES.hasRes(this.path) == false) {
			GameLog.logError(this.path + "音效不存在");
			return;
		}
		if (!this._sound) {
			if (this.isKey) {
				this._sound = RES.getRes(this.path);
				this._sound.type = egret.Sound.EFFECT;
				this._isPlaying = true;
				this.onLoadComplete(null);
			} else {
				this._sound = new egret.Sound();
				this._sound.type = egret.Sound.EFFECT;
				this._sound.addEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
				this._sound.load(this.path);
				this._isPlaying = true;
			}
		}
		else {
			this._isPlaying = true;
			this.onLoadComplete(null);
		}
	}

	private onLoadComplete(evt: egret.Event): void {
		if (this._isPlaying) {
			this._sound.removeEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
			if (this._soundChannel) {
				this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			this._soundChannel = this._sound.play(0, this._isLoop ? 0 : 1);
			this._soundChannel.volume = this._volume;
			if (this._soundChannel) {
				this._soundChannel.addEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			else {
				this.stopSound();
			}
		}
		else {
			this.stopSound();
		}
	}

	private onSoundComplete(event: egret.Event): void {
		this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
		this.stopSound();
	}

	public stopSound(): void {
		this._isPlaying = false;
		if (this._returnCallBack != null) {
			this._returnCallBack.exec(this);
		}
		if (this._callBack != null) {
			this._callBack.exec(this);
		}
		if (this._soundChannel) {
			this._soundChannel.stop();
			this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			this._soundChannel = null;
		}
	}

	public dispose(): void {
		if (this._soundChannel) {
			this._soundChannel.stop();
			this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			this._soundChannel = null;
		}
		if (this._sound) {
			if (this.isKey == false) {
				try {
					this._sound.close();
				}
				catch (e) {
				}
			}
			this._sound = null;
		}
		this._volume = 0;
	}

	private _sound: egret.Sound;
	private _soundChannel: egret.SoundChannel;
	private _path: string;
	private _volume: number = 0;
	private _isLoop: boolean = false;
	private _returnCallBack: FunctionVO;
	private _callBack: FunctionVO;
	private _lastPlayingTime: number = 0;
	private _isPlaying: boolean = false;
	public isKey: boolean = false;
}