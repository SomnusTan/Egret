/**
 * 音乐音效管理
 */
class MusicManager {

	private _currentBackBgmSound: MusicBgmItem;
	/**当前播放背景音乐路径 */
	private _currentBackBgms: string;
	/**背景音乐路径是否是KEY */
	private _bgmIsKey: boolean;
	/**当前音效音量 */
	private _effectVolume: number = 1;
	/**当前背景音乐音量 */
	private _bgmVolume: number = 1;
	/**是否关闭背景音乐 */
	private _isCloseBgm: boolean = false;
	/**是否播放音效 */
	private _isCloseSound: boolean = false;

	private _maxEffectSoundLen: number = 10;
	private _playingSoundHash: HashMap;
	private _soundHash: HashMap;
	/**当前语音 */
	private _currentVoice: MusicVoiceItem;
	/**是否关闭语音 */
	private _isCloseVoice: boolean = false;
	/**语音音量 */
	private _voiceVolume: number = 1;
	/**是否跳过全局音效播放 */
	public needSkip: boolean;
	/**是否启用 */
	public enabled: boolean = true;

	public constructor() {
		this._soundHash = new HashMap();
		this._playingSoundHash = new HashMap();
	}

	public get currentBackBgms(): string {
		return this._currentBackBgms;
	}

	public get soundHashLength(): number {
		return this._soundHash.size;
	}

	public set bgmVolume(value: number) {
		this._bgmVolume = value;
		if (this._currentBackBgmSound) {
			this._currentBackBgmSound.volume = this._bgmVolume;
		}
	}

	public get bgmVolume(): number {
		return this._bgmVolume;
	}

	public get voiceVolume(): number {
		return this._voiceVolume;
	}

	public set voiceVolume(value: number) {
		this._voiceVolume = value;
		if (this._currentVoice) {
			this._currentVoice.volume = this._bgmVolume;
		}
	}

	public set effectVolume(value: number) {
		this._effectVolume = value;
		if (this._playingSoundHash) {
			let len: number = this._playingSoundHash.size;
			let values: Array<MusicEffectItem> = this._playingSoundHash.values;
			for (let i: number = 0; i < len; i++) {
				values[i].volume = this._effectVolume;
			}
		}
	}

	public get effectVolue(): number {
		return this._effectVolume;
	}

	/**
	 * 是否背景音乐播放中
	 */
	public get isBgmPlaying(): boolean {
		return this._currentBackBgmSound != null && this._currentBackBgmSound.isPlaying;
	}

	/**
	 * 是否关闭背景音乐
	 */
	public get isCloseBgm(): boolean {
		return this._isCloseBgm;
	}

	public set isCloseBgm(value: boolean) {
		if (this._isCloseBgm != value) {
			this._isCloseBgm = value;
			if (value) {
				this.closeBgm(false, true);
			}
			else {
				if (this._currentBackBgms) {
					this.playBgm(this._currentBackBgms, 2000, this._bgmIsKey, true);
				}
			}
		}
	}

	/**
	 * 是否关闭语音
	 */
	public get isCloseVoice(): boolean {
		return this._isCloseVoice;
	}

	public set isCloseVoice(value: boolean) {
		if (this._isCloseVoice != value) {
			this._isCloseVoice = value;
			if (value) {
				this.closeVoice();
			}
		}
	}

	/**
	 * 是否关闭音效
	 */
	public get isCloseSound(): boolean {
		return this._isCloseSound;
	}

	public set isCloseSound(value: boolean) {
		if (this._isCloseSound != value) {
			this._isCloseSound = value;
		}
	}

	/**
	 * 播放背景音乐
	 * @param path 路径
	 * @param delay 播放延迟
	 * @param isKey 是否是KEY资源
	 * @param fadeIn 是否淡入
	 */
	public playBgm(path: string, delay: number = 2000, isKey: boolean = false, fadeIn: boolean = true): void {
		if (this._currentBackBgms == path) {
			if (this._isCloseBgm == false && Config.hasTouch) {
				if (this._currentBackBgmSound) {
					if (this._currentBackBgmSound.isPlaying)
						return;
					else
						this._currentBackBgmSound.stopSound(false);
				}
				this.playBgmSound(path, delay, fadeIn);
			}
		}
		else {
			this._currentBackBgms = path;
			this._bgmIsKey = isKey;
			if (this._isCloseBgm == false && Config.hasTouch) {
				if (this._currentBackBgmSound) {
					this._currentBackBgmSound.stopSound(false);
				}
				this.playBgmSound(path, delay, fadeIn);
			}
		}
	}

	private playBgmSound(path: string, delay: number, fadeIn: boolean): void {
		if (path) {
			this._currentBackBgmSound = new MusicBgmItem();
			if (this._currentBackBgmSound && this._currentBackBgmSound.isPlaying == false) {
				this._currentBackBgmSound.playSound(path, delay, this._bgmIsKey, this.bgmVolume, 0, fadeIn);
			}
		}
	}

	/**
	 * 关闭背景音乐
	 */
	public closeBgm(clearUrl: boolean = false, fadeOut: boolean = true): void {
		if (this._currentBackBgmSound) {
			this._currentBackBgmSound.stopSound(fadeOut);
		}
		this._currentBackBgmSound = null;
		if (clearUrl)
			this._currentBackBgms = null;
	}

	/**
	 * 背景音乐放大音量
	 */
	public makeBgmUp(value: number = 1, time: number = 500): void {
		if (this.bgmVolume != value) {
			// this.bgmVolume = 1;
			egret.Tween.get(this).to({ bgmVolume: value }, time);
		}
	}

	/**
	 * 背景音乐减半音量
	 */
	public makeBgmDown(value: number = 0.3, time: number = 500): void {
		if (this.bgmVolume != value) {
			// this.bgmVolume = 0.3;
			egret.Tween.get(this).to({ bgmVolume: value }, time);
		}
	}

	/**
	 * 播放语音
	 */
	public playVoice(path: string, callBack: FunctionVO): boolean {
		if (this._isCloseVoice == false) {
			if (this._currentVoice) {
				this._currentVoice.stopSound();
			}
			if (path) {
				this._currentVoice = new MusicVoiceItem();
				if (this._currentVoice && this._currentVoice.isPlaying == false) {
					this._currentVoice.path = path;
					return this._currentVoice.playSound(this.voiceVolume, callBack);
				}
			}
		}
		return false;
	}

	public playVoiceByKey(key: string, callBack: FunctionVO): boolean {
		if (this._isCloseVoice == false) {
			if (this._currentVoice) {
				this._currentVoice.stopSound(false);
			}
			if (key) {
				this._currentVoice = new MusicVoiceItem();
				if (this._currentVoice && this._currentVoice.isPlaying == false) {
					this._currentVoice.path = key;
					this._currentVoice.playSoundByKey(key, this.voiceVolume, callBack);
					return true;
				}
			}
		}
		return false;
	}

	public closeVoice(): void {
		if (this._currentVoice && this._currentVoice.isPlaying) {
			this._currentVoice.stopSound();
			this._currentVoice = null;
		}
	}

	public playSoundByKey(key: string, isLoop: boolean = false, gap: number = 0, value: number = 1, callback: FunctionVO = null): boolean {
		if (this._isCloseSound || Config.hasTouch == false) {
			return false;
		}
		let sdItem: MusicEffectItem;
		let crt: number = 0;
		let v: number = NaN;
		if (this._playingSoundHash.size < this._maxEffectSoundLen && key) {
			sdItem = this._soundHash.get(key) as MusicEffectItem;
			crt = egret.getTimer();
			if (sdItem && crt - sdItem.lastPlaying < 0) {
				return false;
			}
			sdItem = this.getSoundItem(key, sdItem, true);
			if (sdItem) {
				sdItem.lastPlaying = crt + gap;
				v = value * this._effectVolume;
				sdItem.playSound(v, isLoop, new FunctionVO(this.playEndBlack, this), callback);
				this._playingSoundHash.put(key, sdItem);
				return sdItem.isPlaying;
			}
		}
		return false;
	}

	/**
	 * 播放音效
	 */
	public playSound(path: string, isLoop: boolean = false, gap: number = 0, value: number = 1, callback: FunctionVO = null): void {
		if (this._isCloseSound || Config.hasTouch == false) {
			return;
		}
		let sdItem: MusicEffectItem;
		let crt: number = 0;
		let v: number = NaN;
		if (this._playingSoundHash.size < this._maxEffectSoundLen && path && path != "0") {
			sdItem = this._soundHash.get(path) as MusicEffectItem;
			crt = egret.getTimer();
			if (sdItem && crt - sdItem.lastPlaying < 0) {
				return;
			}
			sdItem = this.getSoundItem(path, sdItem);
			if (sdItem) {
				sdItem.lastPlaying = crt + gap;
				v = value * this._effectVolume;
				sdItem.playSound(v, isLoop, new FunctionVO(this.playEndBlack, this), callback);
				this._playingSoundHash.put(path, sdItem);
			}
		}
	}

	private playEndBlack(sdItem: MusicEffectItem): void {
		this._playingSoundHash.remove(sdItem.path);
	}

	public stopSound(key: string): void {
		var item: MusicEffectItem = this._playingSoundHash.get(key);
		if (item) {
			item.stopSound();
		}
	}

	private getSoundItem(path: string, sdItem?: MusicEffectItem, isKey: boolean = false): MusicEffectItem {
		if (!path) {
			return null;
		}
		let sdItem2: MusicEffectItem;
		if (sdItem && sdItem.isPlaying == false) {
			return sdItem;
		}
		else {
			sdItem2 = new MusicEffectItem();
			sdItem2.path = path;
			sdItem2.isKey = isKey;
		}
		if (this._soundHash.has(path) == false) {
			this._soundHash.put(path, sdItem2);
		}
		return sdItem2;
	}

	/**
	 * 通过客户端播放声音
	 */
	public playSoundSwitchClient(key: string, isLoop: boolean = false): void {
		if (DeviceUtil.isWebIOS) {
			this.playSoundByKey(key + "_mp3", isLoop);
		}
		else {
			this.playSound(ResPathUtil.getSoundPath(key), isLoop);
		}
	}

	/**
	 * 心动1通过客户端播放声音
	 */
	public playSoundSwitchClient1(key: string, isLoop: boolean = false): void {
		if (DeviceUtil.isWebIOS) {
			this.playSoundByKey(key + "_mp3", isLoop);
		}
		else {
			this.playSound(ResPathUtil.getSoundPath1(key), isLoop);
		}
	}

	public stopSoundSwitchClient(key: string): void {
		if (DeviceUtil.isWebIOS) {
			this.stopSound(key + "_mp3");
		}
		else {
			this.stopSound(ResPathUtil.getSoundPath(key));
		}
	}

	/**
	 * 心动1通过客户端停止声音
	 */
	public stopSoundSwitchClient1(key: string): void {
		if (DeviceUtil.isWebIOS) {
			this.stopSound(key + "_mp3");
		}
		else {
			this.stopSound(ResPathUtil.getSoundPath1(key));
		}
	}

	public stopAll(): void {
		let sdType: any;
		if (this._playingSoundHash) {
			let len: number = this._playingSoundHash.size;
			let values: Array<MusicEffectItem> = this._playingSoundHash.values;
			for (let i: number = 0; i < len; i++) {
				values[i].stopSound();
			}
		}
		if (this._currentBackBgmSound) {
			this._currentBackBgmSound.stopSound(false);
		}
	}

	public addvanceTime(): void {
		let key: any;
		let sound: MusicEffectItem;
		let ct: number = egret.getTimer();
		let cha: number = 10 * 60 * 1000;
		let keys: Array<any> = this._soundHash.keys;
		let len: number = keys.length;
		for (let i: number = 0; i < len; i++) {
			key = keys[i];
			sound = this._soundHash.get(key) as MusicEffectItem;
			if (sound && ct - sound.lastPlaying > cha && sound.isPlaying == false) {
				sound.dispose();
				this._soundHash.remove(key);
			}
		}
	}
}