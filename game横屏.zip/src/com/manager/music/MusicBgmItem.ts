/**
 * 背景音乐
 */
class MusicBgmItem {
	public constructor() {

	}

	public set isPlaying(value: boolean) {
		this._isPlaying = value;
	}

	public get isPlaying(): boolean {
		return this._isPlaying;
	}

	public set volume(value: number) {
		this._volume = value;
		if (this._soundChannel) {
			this._soundChannel.volume = this._volume;
		}
	}

	public get volume(): number {
		return this._volume;
	}

	public playSound(url: string, delay: number = 2000, isKey: boolean, volume: number = 0.3, num: number = 1, fadeIn: boolean = true, back: FunctionVO = null): void {
		if (isKey && RES.hasRes(url) == false) {
			GameLog.logError(url + " 背景音乐不存在");
			return;
		}
		if (this._isPlaying) {
			return;
		}
		this._isKey = isKey;
		this._delay = delay;
		this._num = num;
		this._volume = volume;
		this._isPlaying = true;
		this._url = url;
		this._fadeIn = fadeIn;
		this._callBack = back;
		if (this._delay == 0) {
			this._delay = 1;
		}
		if (!this._sound) {
			if (isKey) {
				this._sound = RES.getRes(url);
				this._sound.type = egret.Sound.MUSIC;
				this.onLoadComplete();
			}
			else {
				this._sound = new egret.Sound();
				this._sound.type = egret.Sound.MUSIC;
				this._sound.addEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
				this._sound.load(url);
			}
		}
	}

	private onLoadComplete(evt?: egret.Event): void {
		this._isLoadingFinish = true;
		// GameLog.log('加载背景音乐完成');
		if (this._isPlaying) {
			// GameLog.log("开始播放");
			this._sound.removeEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
			if (this._soundChannel) {
				this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			this._soundChannel = this._sound.play(0, this._num);
			this._startTime = egret.getTimer();
			if (this._fadeIn) {
				this._soundChannel.volume = 0;
				egret.Tween.get(this._soundChannel).to({ volume: this._volume }, 500);
			}
			else
				this._soundChannel.volume = this._volume;
			if (this._soundChannel) {
				this._soundChannel.addEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			else {
				this.stopSound(false);
			}
		}
		else {
			this.stopSound(false);
		}
	}

	protected onSoundComplete(event: egret.Event): void {
		this._crtPlayCount++;
		this._isPlaying = false;
		this.stopSound(false);
		App.timer.doTimeOnce(this, this._delay, this.onTimeHandler);
	}

	private onTimeHandler(): void {
		App.timer.clearTimer(this, this.onTimeHandler);
		if (this._callBack) {
			this._callBack.exec();
		}
	}

	private onFadeOutComplete(soundChannel: egret.SoundChannel): void {
		if (soundChannel) {
			soundChannel.stop();
		}
	}

	public stopSound(fadeOut: boolean = true): void {
		if (egret.getTimer() - this._startTime < 300) {
			App.timer.doTimeOnce(this, 300, this.stopSound, [fadeOut]);
			return;
		}
		App.timer.clearTimer(this, this.onTimeHandler);
		if (this._soundChannel) {
			egret.Tween.removeTweens(this._soundChannel);
			if (fadeOut) {
				egret.Tween.get(this._soundChannel).to({ volume: 0 }, 500).call(this.onFadeOutComplete, this, [this._soundChannel, this._isKey ? null : this._sound]);
				this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			else {
				this._soundChannel.stop();
				this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
		}
		if (this._sound) {
			this._sound.removeEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
			if (this._isLoadingFinish == false && this._isKey == false) {
				try {
					this._sound.close();
				}
				catch (e) {
				}
			}
		}
		this._isPlaying = false;
		this._volume = 0;
		this._sound = null;
		this._soundChannel = null;
	}

	private _crtPlayCount: number = 0;
	private _soundChannel: egret.SoundChannel;
	private _isLoadingFinish: boolean = false;
	private _sound: egret.Sound;
	private _volume: number = 0;
	private _delay: number = 0;
	private _url: string;
	private _num: number = 0;
	private _callBack: FunctionVO;
	private _isPlaying: boolean = false;
	private _isKey: boolean = false;
	/**淡入 */
	private _fadeIn: boolean = false;
	/**淡出 */
	private _fadeOut: boolean = false;
	/**开始播放时间 */
	private _startTime: number;
}