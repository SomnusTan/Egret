class MusicVoiceItem {
	private _sound: egret.Sound;
	private _soundChannel: egret.SoundChannel;
	private _path: string;
	private _volume: number = 0;
	private _callBack: FunctionVO;
	private _lastPlayingTime: number = 0;
	private _isPlaying: boolean = false;
	/**音效资源类型 0:路径 1:RES */
	private _isKey: boolean;
	/**开始播放时间 */
	private _startTime: number;

	public constructor() {
	}

	public get lastPlaying(): number {
		return this._lastPlayingTime;
	}

	public set lastPlaying(value: number) {
		this._lastPlayingTime = value;
	}

	public set volume(value: number) {
		this._volume = value;
		if (this._soundChannel) {
			this._soundChannel.volume = this._volume;
		}
	}

	public get volume(): number {
		return this._volume;
	}

	public get path(): string {
		return this._path;
	}

	public set path(value: string) {
		this._path = value;
	}

	public get isPlaying(): boolean {
		return this._isPlaying;
	}

	public playSound(volume: number, callBack: FunctionVO): boolean {
		this._volume = volume;
		this._callBack = callBack;
		if (this._isPlaying) {
			return false;
		}
		if (!this._sound) {
			this._isKey = false;
			this._sound = new egret.Sound();
			this._sound.type = egret.Sound.EFFECT;
			this._sound.addEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
			this._sound.load(this.path);
			this._isPlaying = true;
			// GameLog.log('开始加载语音');
			return true;
		}
		this._isPlaying = true;
		return false;
	}

	public playSoundByKey(key: string, volume: number, callBack: FunctionVO): void {
		if (RES.hasRes(key) == false) {
			GameLog.logError(key + "语音不存在");
			if (callBack) {
				callBack.exec();
			}
			return;
		}
		this._volume = volume;
		this._callBack = callBack;
		if (this._isPlaying) {
			return;
		}
		if (!this._sound) {
			if (this._soundChannel) {
				this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			this._isPlaying = true;
			this._isKey = true;
			this._sound = RES.getRes(key);
			this._sound.type = egret.Sound.EFFECT;
			this._soundChannel = this._sound.play(0, 1);
			this._startTime = egret.getTimer();
			this._soundChannel.volume = this._volume;
			if (this._soundChannel) {
				this._soundChannel.addEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			else {
				this.stopSound();
			}
		}
	}

	private onLoadComplete(evt: egret.Event): void {
		// GameLog.log('加载语音完成');
		if (this._isPlaying) {
			this._sound.removeEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
			if (this._soundChannel) {
				this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			this._soundChannel = this._sound.play(0, 1);
			this._startTime = egret.getTimer();
			this._soundChannel.volume = this._volume;
			if (this._soundChannel) {
				this._soundChannel.addEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			}
			else {
				this.stopSound();
			}
		}
		else {
			this.stopSound();
		}
	}

	private onSoundComplete(event: egret.Event): void {
		this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
		this.stopSound();
	}

	public stopSound(needCallback: boolean = true): void {
		if (egret.getTimer() - this._startTime < 300) {
			App.timer.doTimeOnce(this, 300, this.stopSound, [needCallback]);
			return;
		}
		this._isPlaying = false;
		if (needCallback && this._callBack != null) {
			this._callBack.param = [this];
			this._callBack.exec();
		}
		this.dispose();
	}

	public dispose(): void {
		this._callBack = null;
		if (this._soundChannel) {
			this._soundChannel.stop();
			this._soundChannel.removeEventListener(egret.Event.SOUND_COMPLETE, this.onSoundComplete, this);
			this._soundChannel = null;
		}
		if (this._sound) {
			if (this._isKey == false) {
				try {
					this._sound.close();
				}
				catch (e) {
				}
			}
			this._sound = null;
		}
		this._volume = 0;
	}
}