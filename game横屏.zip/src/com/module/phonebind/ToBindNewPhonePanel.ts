/**
 * 解绑后绑定新手机
 */
class ToBindNewPhonePanel extends BasePhoneBindPanel {
	public constructor() {
		super();
		this._type = 1;
	}
	/**
	 * 登录重置页面
	 */
	protected onGameLoginReset() {
		this.rightTitle = "绑定手机";
		this._view.telephoneNumber.enabled = true;
		this._view.telephoneNumber.prompt = "请输入手机号";
		this._view.telephoneNumber.visible = true;
		this._view.bindNewNumber.label = "绑定新号码";
		this._view.cancelEdit.text = "取消绑定";
		this._phoneText = this._view.telephoneNumber.text;
		super.onGameLoginReset();
	}

	public hide(): void {
		super.hide();
		if (Config.hasEnterGame)
			PanelOpenManager.openPanel(EnumPanelID.GAMEHALL_SETTING);
	}

	/**获取验证码 */
	protected sendGetCodeMsg(): void {
		ProtocolCommon.instance().send_Untied_new_code(this._phoneText, new FunctionVO(this.onGetCodeBack, this));
	}

    /**
     * 获取验证码按钮是否可用
     */
	protected canGetCode(): boolean {
		var notInCd: boolean = this.notInCodeValideCd();//是否计时结束
		return notInCd && this._canSendCode && this._phoneText.length == 11;
	}

    /**
     * 登录按钮是否可用
     */
	protected canLogin(): boolean {
		return this._phoneText.length == 11 && this._view.verificationCode.text.length == 6;
	}

	protected getKey(): string {
		return EnumStorageType.BIND_GETCODE_TIME + this._phoneText;
	}
	/** 绑定成功返回 */
	protected bindSuccess(): void {
		App.global.storage.setItem(EnumStorageType.PHONE, this._phoneText);
		super.bindSuccess();
	}
}