/**
 * 游客去绑定手机
 */
class TouristBindPhonePanel extends BasePhoneBindPanel {
	public constructor() {
		super();
		this._type = 2;
	}
	/**
	 * 登录重置页面
	 */
	protected onGameLoginReset() {
		this.rightTitle = "绑定手机";
		this._view.telephoneNumber.enabled = true;
		this._view.telephoneNumber.prompt = "请输入手机号";
		this._view.telephoneNumber.visible = true;
		this._view.bindNewNumber.label = "绑定手机";
		this._view.cancelEdit.text = "取消绑定";
		this._phoneText = this._view.telephoneNumber.text;
		super.onGameLoginReset();
	}

	public hide(): void {
		super.hide();
		if (Config.hasEnterGame)
			PanelOpenManager.openPanel(EnumPanelID.GAMEHALL_SETTING);
	}

	/**获取验证码 */
	protected sendGetCodeMsg(): void {
		ProtocolCommon.instance().send_tourist_bindphone_code(this._phoneText, new FunctionVO(this.onGetCodeBack, this));
	}

    /**
     * 获取验证码按钮是否可用
     */
	protected canGetCode(): boolean {
		var notInCd: boolean = this.notInCodeValideCd();//是否计时结束
		return notInCd && this._canSendCode && this._phoneText.length == 11;
	}

    /**
     * 登录按钮是否可用
     */
	protected canLogin(): boolean {
		return this._phoneText.length == 11 && this._view.verificationCode.text.length == 6;
	}

	protected getKey(): string {
		return EnumStorageType.BIND_GETCODE_TIME + this._phoneText;
	}

	protected bindSuccess(): void {
		/*** 重新存储本地数据 */
		App.global.storage.setItem(EnumStorageType.PHONE, this._view.telephoneNumber.text);
		App.global.storage.setItem(EnumStorageType.TOKEN, App.global.userInfo.skey);
		App.global.storage.setItem(EnumStorageType.UID, String(App.global.userInfo.uid));
		App.global.storage.removeItem(EnumStorageType.IS_TOURIST);
		super.bindSuccess();
	}
}