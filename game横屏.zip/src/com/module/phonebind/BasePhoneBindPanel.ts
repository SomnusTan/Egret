/**
 * 绑定手机
 */
class BasePhoneBindPanel extends WindowView {
	protected _view: GameHallChangePasswordUI;
	/**能否发送验证码请求 */
	protected _canSendCode: boolean = true;
	protected _phoneText: string;//手机号文本
	/**0:解绑手机页面,1:解绑后绑定新手机，2:强制绑定手机号 */
	protected _type: number;

	public constructor() {
		super(550, 527);
	}

	protected initView(): void {
		this._view = new GameHallChangePasswordUI();
		this._view.y = 105;
		this.viewSp.addChild(this._view);
	}

	protected initSkinType(): void {
		this._skinType = EnumWindowType.TYPE_3;
	}

	public show(data?: any): void {
		super.show(data);
		this._canSendCode = true;

		this._view.telephoneNumber.inputType = egret.TextFieldInputType.TEL;
        this._view.verificationCode.inputType = egret.TextFieldInputType.TEL;
		this._view.getVerificationCode.label = "获取验证码";
		this._view.telephoneNumber.text = "";
		this._view.verificationCode.text = "";

		this.onGameLoginReset();

		/**手机号码 验证码发现改变 */
		this._dispatcher.addEventListener(egret.Event.CHANGE, this.onTxtPhoneNumChange, this, this._view.telephoneNumber);
		this._dispatcher.addEventListener(egret.Event.CHANGE, this.onTxtCodeChange, this, this._view.verificationCode);
		InputTextUtil.addNativeInputTextListener(this._view.telephoneNumber);
		InputTextUtil.addNativeInputTextListener(this._view.verificationCode);
		/**取消绑定 */
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabcancelEdit, this, this._view.cancelEdit)
		/**绑定新号码 */
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabbindNewNumber, this, this._view.bindNewNumber)
		/**获取验证码 */
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabgetVerificationCode, this, this._view.getVerificationCode);
	}
	/**
	 * 登录重置页面
	 */
	protected onGameLoginReset() {
		this.onTxtPhoneNumChange();
	}

	/**获取验证码 */
	protected onTabgetVerificationCode(e: egret.TouchEvent): void {
		if (this._type == 0) {	//解绑手机页面
			this.sendGetCodeMsg();
		} else if (this._type == 1 || this._type == 2) {
			if (this._phoneText && this._phoneText.length == 11) { // 判断手机号码是否正确
				if (this.notInCodeValideCd()) { // 请求发送验证码
					this.sendGetCodeMsg();
				} else {
					Notice.showBottomCenterMessage("验证码错误次数过多，请稍后再试");
				}
			} else {
				Notice.showBottomCenterMessage("请输入正确的手机号码");
			}
		}
	}

	protected sendGetCodeMsg(): void {
	}

    /**
     * 获取验证码按钮是否可用
     */
	protected canGetCode(): boolean {
		return false;
	}

    /**
     * 登录按钮是否可用
     */
	protected canLogin(): boolean {
		return false;
	}
	/**
	 * 旧手机验证之后跳转页面
	 */
	protected onsend_tel_code(response: any) {
		if (ResponseUtil.checkResponseData(response)) {
			this.bindSuccess();
		} else if (Number(response.code) == 210) {
			//禁用快速登录标签
			// GameLog.log("禁用按钮！")
			this._canSendCode = false;
			this._view.verificationCode.text = "";
			var key: string = this.getKey();
			var cdTime: string = Math.floor(new Date().getTime() * 0.001 + 300).toString();
			App.global.storage.setItem(key, cdTime);
			this.setGetCodeBtnCd(Number(cdTime), "请稍候");
			this.onTxtPhoneNumChange();
		}
	}

	protected getKey(): string {
		return "";
	}

	/** 绑定成功返回 */
	protected bindSuccess(): void {
		PanelManager.removePanelByName(this.panelName);
		App.dispatcher.dispatchEvent(EventType.BIND_PHONE_SUCCESS);
	}
	/**绑定新号码 解绑旧手机 */
	protected onTabbindNewNumber(e: egret.TouchEvent): void {
		if (this._phoneText != null) {
			if (this._phoneText.length == 11) {
				// 判断验证码是否为空
				if (this._view.verificationCode.text != "") {
					// 判断验证码格式是否有误
					if (this._view.verificationCode.text.length > 5) {
						let code = this._view.verificationCode.text;
						if (this._type == 1) {
							ProtocolCommon.instance().send_Untied_old_Newphone(this._phoneText, code, new FunctionVO(this.onsend_tel_code, this));
						} else {
							ProtocolCommon.instance().send_tourist_bindphone(this._phoneText, code, new FunctionVO(this.onsend_tel_code, this));
						}
					} else {
						Notice.showBottomCenterMessage("验证码格式有误");
					}
				} else {
					Notice.showBottomCenterMessage("请输入验证码");
				}
			}
		} else {
			Notice.showBottomCenterMessage("请输入手机号码！");
		}
	}

	protected onTxtPhoneNumChange(e: egret.Event = null): void {
		if (e)
			App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
		if (this._type != 0) {
			this._phoneText = this._view.telephoneNumber.text;
		}
		if (this._canSendCode == false) {
			this._canSendCode = this.notInCodeValideCd();
			if (this._canSendCode) {
				App.timer.clearTimer(this, this.onGetCodeTime);
				this._view.getVerificationCode.label = "获取验证码";
				this.onTxtPhoneNumChange();
			}
		}
		if (this.canGetCode()) {
			// 手机号码正确,激活点击验证码按钮
			this._view.getVerificationCode.filters = null;
			this._view.getVerificationCode.touchEnabled = true;
		} else {
			// 手机号码不正确,熄灭点击验证码按钮
			this._view.getVerificationCode.filters = FilterUtil.FILTER_GRAY;
			this._view.getVerificationCode.touchEnabled = false;
		}
		this.onTxtCodeChange();
	}

	protected setGetCodeBtnCd(time: number, btnLabel: string = "--"): void {
		App.timer.serverTimeEnd(this, this.onGetCodeTime, Math.floor(time), [btnLabel]);
	}

	/**函数回调 */
	protected onGetCodeBack(response: any): void {
		GameLog.log("验证码：" + response.data);
		if (ResponseUtil.checkResponseData(response)) {
			// 修改短信发送状态
			this._canSendCode = false;
			App.global.storage.setItem(EnumStorageType.GETCODE_CD_TIME + this._type, Math.floor(new Date().getTime() * 0.001 + 60).toString());
			this.setGetCodeBtnCd(ServerTime.serverTime + 60, "已发送");
			// 锁定请求验证码
			this._view.getVerificationCode.filters = FilterUtil.FILTER_GRAY;
			this._view.getVerificationCode.touchEnabled = false;
		}
	}
	/** 验证码是否没有倒计时CD，返回true是可以点击 */
	protected notInCodeValideCd(): boolean {
		var notInCd: boolean = true;
		var key: string = this.getKey();
		var getCodeTime: string = App.global.storage.getItem(key);
		if (getCodeTime) {
			var value: number = Math.floor(new Date().getTime() * 0.001 - Number(getCodeTime));
			if (value < 0) {
				this.setGetCodeBtnCd(Number(getCodeTime), "请稍候");
				this._canSendCode = false;
				notInCd = false;
			}
		} else {
			getCodeTime = App.global.storage.getItem(EnumStorageType.GETCODE_CD_TIME + this._type);
			if (getCodeTime) {
				value = Math.floor(new Date().getTime() * 0.001 - Number(getCodeTime));
				if (value < 0) {
					this.setGetCodeBtnCd(Number(getCodeTime), "请稍候");
					this._canSendCode = false;
					notInCd = false;
				}
			}
		}
		return notInCd;
	}

	private onGetCodeTime(serverTimeData: ServerTimeData, btnLabel: string = "--"): void {
		if (serverTimeData.spuleTime <= 0) {
			this._view.getVerificationCode.label = "获取验证码";
			this._canSendCode = true;
			this.onTxtPhoneNumChange();
			App.timer.clearTimer(this, this.onGetCodeTime);
		}
		else {
			var value: number = serverTimeData.spuleTime;
			if (value > 60) {
				var min: number = Math.ceil(value / 60);
				this._view.getVerificationCode.label = btnLabel + "(" + min + "分)";
			} else {
				this._view.getVerificationCode.label = btnLabel + "(" + value + "秒)";
			}
		}
	}

	public hide(): void {
		super.hide();
		InputTextUtil.removeNativeInputTextListener(this._view.telephoneNumber);
		InputTextUtil.removeNativeInputTextListener(this._view.verificationCode);
		App.timer.clearTimer(this, this.onGetCodeTime);
	}

	/**判断验证码  绑定新手机号码按钮*/
	private onTxtCodeChange(e: egret.Event = null): void {
		if (e)
			App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
		if (this.canLogin()) {
			this._view.bindNewNumber.filters = null;
			this._view.bindNewNumber.touchEnabled = true;
		} else {
			this._view.bindNewNumber.filters = FilterUtil.FILTER_GRAY;
			this._view.bindNewNumber.touchEnabled = false;
		}
	}

	/**取消绑定 */
	private onTabcancelEdit(): void {
		App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
		PanelManager.removePanelByName(this.panelName);
		// PanelOpenManager.openPanel(EnumPanelID.GAMEHALL_SETTING);
	}

	public dispose(): void {
		super.dispose();
		if (this._view) {
			this._view.dispose();
			this._view = null;
		}
	}

}