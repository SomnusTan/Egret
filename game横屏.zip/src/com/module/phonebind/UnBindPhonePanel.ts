/**
 * 解绑手机
 */
class UnBindPhonePanel extends BasePhoneBindPanel {
	/**关闭面板时是否要显示大厅设置 */
	private _needShowGameHallSetting: boolean;

	public constructor() {
		super();
		this._type = 0;
	}
	/**
	 * 登录重置页面
	 */
	protected onGameLoginReset() {
		this.rightTitle = "修改手机";
		this._view.telephoneNumber.enabled = false;
		/**获取手机号码 并且显示手机号码*/
		let phoneValue: string = App.global.storage.getItem(EnumStorageType.PHONE);
		// this._view.telephoneNumber.text = phoneValue;
		this._phoneText = phoneValue;
		phoneValue = phoneValue.concat().substr(0, 3) + "*****" + phoneValue.concat().substr(phoneValue.length - 3, phoneValue.length);
		this._view.telephoneNumber.prompt = phoneValue;
		this._view.bindNewNumber.label = "确定修改";
		this._view.cancelEdit.text = "取消修改";
		super.onGameLoginReset();
	}

	public show(data?: any): void {
		this._needShowGameHallSetting = true;
		super.show(data);
	}

	public hide(): void {
		super.hide();
		if (this._needShowGameHallSetting && Config.hasEnterGame)
			PanelOpenManager.openPanel(EnumPanelID.GAMEHALL_SETTING);
	}

	/**获取验证码 */
	protected sendGetCodeMsg(): void {
		ProtocolCommon.instance().send_Untied_old_phone(null, new FunctionVO(this.onGetCodeBack, this));
	}

    /**
     * 获取验证码按钮是否可用
     */
	protected canGetCode(): boolean {
		var notInCd: boolean = this.notInCodeValideCd();//是否计时结束
		return notInCd && this._canSendCode;
	}

    /**
     * 登录按钮是否可用
     */
	protected canLogin(): boolean {
		return this._view.verificationCode.text.length == 6;
	}

	/** 存储key */
	protected getKey(): string {
		return EnumStorageType.UNBIND_GETCODE_TIME + this._phoneText;
	}

	/** 绑定成功返回 */
	protected bindSuccess(): void {
		this._needShowGameHallSetting = false;
		super.bindSuccess();
		PanelOpenManager.openPanel(EnumPanelID.BIND_NEW_PHONE);
	}
	/**绑定新号码 解绑旧手机 */
	protected onTabbindNewNumber(e: egret.TouchEvent): void {
		if (this._view.verificationCode.text.length > 5) {
			ProtocolCommon.instance().send_Untied_old_phone(this._view.verificationCode.text, new FunctionVO(this.onsend_tel_code, this));
		} else {
			Notice.showBottomCenterMessage("验证码格式有误");
		}
	}
}