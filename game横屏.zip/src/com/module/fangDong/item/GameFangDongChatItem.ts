class GameFangDongChatBaseItem extends BaseUI {

    public constructor(skin: string) {
        super(skin);
    }

    public initData(data: any): void {
    }

    public get canNext(): boolean {
        return true;
    }

    /**
     * 自动下一步
     */
    public autoNext(): void {
        if (App.data.gameFangDongCenter.isAutoPlay) {
            App.timer.doTimeOnce(this, 500, this.requestNext);
        }
    }

    protected requestNext(): void {
        ProtocolFangDong.instance().send_chat_select(App.data.gameFangDongCenter.gameId, App.data.gameFangDongCenter.dlcID);
    }
}

class GameFangDongChatTimeItem extends GameFangDongChatBaseItem {

    public txtTime: eui.Label;

    public constructor() {
        super("GameFangDongChatTimeItemSkin");

    }

    public initData(data: any): void {
        if (data) {
            this.txtTime.text = data.time;
        }
    }
}

class GameFangDongChatItem extends GameFangDongChatBaseItem {

    public imgHead: eui.Image;
    public imgLabelBg: eui.Image;
    public txtLabel: eui.Label;

    public constructor() {
        super("GameFangDongChatItemSkin");
    }

    protected createComplete(): void {
        super.createComplete();
        this.imgLabelBg.scale9Grid = new egret.Rectangle(20, 54, 40, 10);
    }

    public initData(data: any): void {
        if (data) {
            // this.imgHead.source = App.data.gameResourceCenter.getRes(data.headURL);
            // this.imgLabelBg.source = App.data.gameResourceCenter.getRes(data.headURL);
            this.txtLabel.width = 460;
            this.txtLabel.text = data.text;
            if (this.txtLabel.height > 40)
                this.txtLabel.textAlign = "left";
            this.imgLabelBg.width = this.txtLabel.textWidth + 50;
            this.imgLabelBg.height = this.txtLabel.textHeight + 50;
            this.height = this.imgLabelBg.height;
        }
    }

    public get canNext(): boolean {
        return false;
    }

}

class GameFangDongChatVoiceItem extends GameFangDongChatBaseItem {

    public imgHead: eui.Image;
    public imgVoice: eui.Image;
    public imgRed: eui.Image;
    public txtTime: eui.Label;

    private _voiceURL: string;

    private _voiceComplete: boolean;

    public constructor() {
        super("GameFangDongChatVoiceItemSkin");

    }

    protected createComplete(): void {
        super.createComplete();
        this.imgVoice.scale9Grid = new egret.Rectangle(64, 2, 180, 2);
    }

    public initData(data: any): void {
        if (data) {
            this._voiceComplete = false;
            this._voiceURL = data.voiceURL;
            this.txtTime.text = data.time;
            // this.imgHead.source = App.data.gameResourceCenter.getRes(data.headURL);
            // this.imgVoice.source = App.data.gameResourceCenter.getRes(data.headURL);
            var iw: number = 90 + data.voiceLength * 20;
            this.imgVoice.width = iw > 400 ? 400 : iw;
            this.txtTime.text = data.voiceLength + '"';
            this.txtTime.x = this.imgVoice.x + this.imgVoice.width + 8;
            this.imgRed.x = this.txtTime.x + this.txtTime.textWidth + 4;
            this.imgVoice.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
            // App.sound.playSound(ResPathUtil.getSoundPath(EnumSoundId.RING_MESSAGE));
        }
    }

    private onTouch(e?: egret.TouchEvent): void {
        this.imgVoice.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
        if (this.imgRed.visible)
            App.data.gameResourceCenter.playVoice(this._voiceURL, new FunctionVO(this.onVoiceComplete, this));
        // App.sound.playVoice(this._voiceURL, new FunctionVO(this.onVoiceComplete, this));
        this.imgRed.visible = false;
    }

    /**
     * 语音播放完成
     */
    private onVoiceComplete(): void {
        GameLog.log('微信语音播放结束');
        this._voiceComplete = true;
        // super.autoNext();
        this.requestNext();
    }

    public dispose(): void {
        super.dispose();
        this.imgVoice.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
    }

    public get canNext(): boolean {
        return this._voiceComplete;
    }

    public autoNext(): void {
        this.onTouch();
    }
}