class BgImageControl extends eui.Group {

    /**资源路径 */
    public url: string;

    private _images: EffectImage[];

    public index: number = 0;

    public constructor() {
        super();
        this.initImages();
    }

    /**
     * 初始化控件
     */
    private initImages(): void {
        this._images = [];
        var img1: EffectImage = new EffectImage();
        this.addChild(img1);

        var img0: EffectImage = new EffectImage();
        this.addChild(img0);
        this._images.push(img0, img1);
    }

    public remove(): void {
        if (this._images) {
            for (var i: number = 0, len: number = this._images.length; i < len; i++) {
                this._images[i].source = null;
                this._images[i].lastEffectType = null;
                this._images[i].removeStaticEffect();
                this._images[i].resetBaseData();
            }
        }
        this.url = null;
    }

    public stopEffect(): void {
        if (this._images) {
            for (var i: number = 0, len: number = this._images.length; i < len; i++) {
                this._images[i].resetEffect();
            }
        }
    }

    /**
     * 获取顶层的图片
     */
    public getFirstImage(): EffectImage {
        return this._images[0];
    }

    /**
     * 切换图片
     * @param source 新图片资源路径
     * @param fastSpeed 
     * @param effectType 切换特效类型 EnumEffectType
     * @param time 特效时间
     * @param param 特效参数
     * @returns 特效消耗时间
     */
    public changeImage(source: any, fastSpeed: boolean, isRole: boolean, effectType: string = null, time: number = 500, param?: any): number {
        var costTime: number = 0;
        if (source) {
            this._images[1].source = source;
            this.addChildAt(this._images[1], 0);
            this.url = source;
        }
        //EnumImageEffect.APART_SHAKE需要强制播放
        if (fastSpeed && effectType != EnumImageEffect.APART_SHAKE) {
            if (source) {
                this._images[0].showEffect(EnumImageEffect.NONE_OUT);
                this._images[0].resetEffect();
                this._images[1].showEffect(EnumImageEffect.NONE_IN);
                this._images.reverse();
            }
            else if (isRole) {
                this._images[0].showEffect(EnumImageEffect.NONE_OUT);
                this._images[0].resetEffect();
                this._images[1].showEffect(EnumImageEffect.NONE_OUT);
                this._images[1].resetEffect();
            }
            return costTime;
        }
        else {
            var effectName: EffectName = EnumImageEffect.getEffect(effectType);
            if ((source == null && EnumImageEffect.NO_CHANGE_EFFECT_LIST.indexOf(effectType) == -1) &&
                !(effectName && (effectName.isInName(effectType) || effectName.isOutName(effectType)))) {
                //不换底图时,需要切换底图的效果则结束执行
                return costTime;
            }
            if (effectType == EnumImageEffect.CHANGE_SCALE || effectType == EnumImageEffect.LOOP_MOVE
                || effectType == EnumImageEffect.MOVE || effectType == EnumImageEffect.SHAKE_BLUR || effectType == EnumImageEffect.SHAKE
                || effectType == EnumImageEffect.FLASH_WHITE_LIGHT || effectType == EnumImageEffect.FLASH_BLACK_LIGHT
                || effectType == EnumImageEffect.APART_SHAKE || effectType == EnumImageEffect.REMOVE_APART_SHAKE) {
                if (source) {
                    this._images[0].showEffect(EnumImageEffect.FADE_OUT, 500);
                    this._images[1].showEffect(effectType, time, 0, param);
                    costTime = time > 500 ? time : 500;
                }
                else {
                    if (this._images[0].source)
                        this._images[0].showEffect(effectType, time, 0, param);
                    else
                        this._images[1].showEffect(effectType, time, 0, param);
                    costTime = time;
                }
                if (effectType == EnumImageEffect.APART_SHAKE) {
                    costTime = 1600 * 8 + 500;
                }
            }
            else if (effectType == EnumImageEffect.MEMORY || effectType == EnumImageEffect.DARK || effectType == EnumImageEffect.WHITE_IMAGINATION || effectType == EnumImageEffect.CLEAR) {
                if (source) {
                    this._images[0].showEffect(EnumImageEffect.FADE_OUT, 500);
                    this._images[1].showEffect(effectType);
                }
                else {
                    if (this._images[0].source)
                        this._images[0].showEffect(effectType);
                    else
                        this._images[1].showEffect(effectType);
                }
            }
            else {
                if (effectName) {
                    if (effectName.isInName(effectType)) {
                        (source ? this._images[1] : this._images[0]).showEffect(effectName.inName, time, 0, param);
                        if (this._images[0] && this._images[0].source)
                            this._images[0].showEffect(EnumImageEffect.NONE_OUT);
                        costTime = time;
                    }
                    else if (effectName.isOutName(effectType)) {
                        if (this._images[0].source) {
                            this._images[0].showEffect(effectName.outName, time, 0, param);
                        }
                        else if (this._images[1].source) {
                            this._images[1].showEffect(effectName.outName, time, 0, param);
                        }
                        this.url = null;
                        costTime = time;
                    }
                    else {
                        if (this._images[0].source) {//已经显示图片则要显示切出切入效果
                            this._images[0].showEffect(effectName.showOutName ? effectName.showOutName : effectName.outName, time, 0, param);
                            this._images[1].showEffect(effectName.inName, time, effectName.inWaitTime ? time : 0, param);
                            costTime = effectName.inWaitTime ? time * 2 : time;
                        }
                        else {//如果未显示过图片只要显示切入效果
                            this._images[1].showEffect(effectName.defaultInName, time);
                            costTime = time;
                        }
                    }
                }
                else {
                    if (source) {
                        this._images[0].showEffect(EnumImageEffect.NONE_OUT);
                        this._images[1].showEffect(EnumImageEffect.NONE_IN);
                    }
                }
            }
        }
        if (source) {
            this._images.reverse();
        }
        return isNaN(costTime) ? 0 : costTime;
    }

    public addStaticEffect(effectType: string, param: any = null): void {
        this._images[0].addStaticEffect(effectType, param);
    }

    public hideImage(fastSpeed: boolean, effectType: string = null, time: number = 500, param?: any): void {
        if (effectType == EnumImageEffect.FADE_OUT) {
            this._images[0].showEffect(EnumImageEffect.FADE_OUT, time);
        }
        else if (effectType == EnumImageEffect.CLOCK_OUT) {
            this._images[0].showEffect(EnumImageEffect.CLOCK_OUT, time);
        }
        else if (effectType == EnumImageEffect.CUT_IMAGE_OUT) {
            this._images[0].showEffect(EnumImageEffect.CUT_IMAGE_OUT, time);
        }
        App.timer.doTimeOnce(this, time, this.remove);
    }

    public setBaseX(value: number, changeSrc: boolean = false) {
        if (this._images) {
            if (this._images[0])
                this._images[0].setBaseX(value, changeSrc);
            if (this._images[1])
                this._images[1].setBaseX(value, changeSrc);
        }
    }
    public setBaseY(value: number, changeSrc: boolean = false) {
        if (this._images) {
            if (this._images[0])
                this._images[0].setBaseY(value, changeSrc);
            if (this._images[1])
                this._images[1].setBaseY(value, changeSrc);
        }
    }
    public setBaseScale(value: number, changeSrc: boolean = false) {
        if (this._images) {
            if (this._images[0])
                this._images[0].setBaseScale(value, changeSrc);
            if (this._images[1])
                this._images[1].setBaseScale(value, changeSrc);
        }
    }

    public dispose(): void {
        if (this._images) {
            for (var i: number = 0, len: number = this._images.length; i < len; i++) {
                this._images[i].dispose();
            }
            this._images.length = 0;
            this._images = null;
        }
        this.url = null;
    }
}