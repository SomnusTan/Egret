/**
 * 立绘控制
 */
class RoleImageControl {
    private _roleList: BgImageControl[];

    private _box: eui.Group;

    public constructor() {

    }

    public init(box: eui.Group): void {
        this._box = box;
        this._roleList = [];
    }

    public remove(): void {
        if (this._roleList) {
            for (var i: number = 0, len: number = this._roleList.length; i < len; i++) {
                if (this._roleList[i])
                    this._roleList[i].remove();
            }
        }
    }

    public stopEffect(): void {
        if (this._box) {
            for (var i: number = 0, len: number = this._box.numChildren; i < len; i++) {
                (this._box.getChildAt(i) as BgImageControl).stopEffect();
            }
        }
    }

    /**
     * 显示角色
     */
    public showRole(fastSpeedPlay: boolean = false): number {
        var costTime: number = 0;
        var data: GameFangDongCenter = App.data.gameFangDongCenter;
        var infoList: RoleSkinInfo[] = data.imageEffectInfo.roleList;
        var img: BgImageControl;
        var effectData: any;
        var staticEffectData: any;
        var effectName: EffectName;
        for (var i: number = 0, len: number = infoList.length; i < len; i++) {
            staticEffectData = null;
            if (infoList[i]) {
                img = this.getRoleImage(i);
                if (img.parent == null)
                    this._box.addChild(img);
                staticEffectData = data.imageEffectInfo.getRoleEffectByLayer(i, true);
                effectData = data.imageEffectInfo.getRoleEffectByLayer(i, false);
                infoList[i].updateImage(img, effectData == null || (effectData.module != EnumImageEffect.MOVE && effectData.module != EnumImageEffect.CHANGE_SCALE));
                if (img.url != infoList[i].roleURL) {
                    if (effectData) {
                        costTime = img.changeImage(infoList[i].roleURL, fastSpeedPlay, true, effectData.module, effectData.time, effectData);
                    }
                    else {
                        costTime = img.changeImage(infoList[i].roleURL, fastSpeedPlay, true, EnumImageEffect.FADE_IN_OUT, 500);
                    }
                }
                else if (effectData) {
                    costTime = img.changeImage(null, fastSpeedPlay, true, effectData.module, effectData.time, effectData);
                }
                if (staticEffectData) {
                    img.addStaticEffect(staticEffectData.module);
                }
                img.index = infoList[i].index;
            } else {
                if (this.hasShowRoleImage(i)) {
                    img = this.getRoleImage(i);
                    effectData = data.imageEffectInfo.getRoleEffectByLayer(i, false);
                    if (effectData) {
                        effectName = EnumImageEffect.getEffect(effectData.module);
                        if (effectName)
                            costTime = img.changeImage(null, fastSpeedPlay, true, effectName.outName, effectData.time, effectData);
                        else
                            costTime = img.changeImage(null, fastSpeedPlay, true, EnumImageEffect.FADE_OUT, 500, null);
                    }
                    else {
                        costTime = img.changeImage(null, fastSpeedPlay, true, EnumImageEffect.FADE_OUT, 500, null);
                    }
                    if (staticEffectData) {
                        img.addStaticEffect(staticEffectData.module);
                    }
                }
            }
        }
        this.sortImageDepth();
        return Number(costTime);
    }

    /**
     * 尝试排序
     */
    private sortImageDepth(): void {
        if (this._box.numChildren > 1) {
            var list: BgImageControl[] = [];
            for (var i: number = 0, len: number = this._box.numChildren; i < len; i++) {
                list.push(this._box.getChildAt(i) as BgImageControl);
            }
            list.sort(this.compare);
            for (i = 0, len = list.length; i < len; i++) {
                this._box.addChild(list[i]);
            }
        }
    }

    /**
     * 比较函数
     */
    private compare(x: BgImageControl, y: BgImageControl): number {
        if (x.index < y.index) {
            return -1;
        } else if (x > y) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * 获取对象池对象
     */
    private getRoleImage(index: number): BgImageControl {
        if (this._roleList[index] == null)
            this._roleList[index] = new BgImageControl();
        return this._roleList[index];
    }

    /**
     * 是否显示
     */
    private hasShowRoleImage(index: number): boolean {
        if (this._roleList[index] && this._roleList[index].parent) {
            return true;
        }
        return false;
    }

    public dispose(): void {
        if (this._roleList) {
            for (var i: number = 0, len: number = this._roleList.length; i < len; i++) {
                if (this._roleList[i])
                    this._roleList[i].dispose();
            }
            this._roleList.length = 0;
            this._roleList = null;
        }
        this._box = null;
    }
}