class FangDongSelectButton extends BaseButton {
    public constructor() {
        super();
        this.skinName = "ImageButtonSkin";
    }

    protected createChildren(): void {
        super.createChildren();
    }

    public set selected(value: boolean) {
        (this.getChildAt(0) as eui.Image).source = App.data.gameResourceCenter.getRes(value ? EnumGameRes1.SELECTED_BUTTON : EnumGameRes1.SELECT_BUTTON);
    }

    public show(): void {
        this.touchEnabled = false;
        var targetX: number = -this.width >> 1
        this.x = Config.MAIN_WIDTH - (Config.MAIN_WIDTH - this.width >> 1);
        this.alpha = 0;
        egret.Tween.get(this).wait((this.data - 1) * 200).to({ x: targetX, alpha: 1 }, 300, egret.Ease.sineOut).call(this.onShowComplete, this);
    }

    private onShowComplete(bool: boolean = true): void {
        egret.Tween.removeTweens(this);
        this.touchEnabled = bool;
    }

    public hide(waitTime: number = 0): void {
        this.alpha = 1;
        egret.Tween.get(this).wait(waitTime).to({ alpha: 0 }, 500, egret.Ease.sineOut).call(this.onShowComplete, this, [false]);
    }

    public dispose(): void {
        super.dispose();
        egret.Tween.removeTweens(this);
    }
}