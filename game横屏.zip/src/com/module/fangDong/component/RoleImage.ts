/**
 * 立绘图片
 */
class RoleImage extends eui.Group {

    private _img: eui.Image;
    /**立绘资源路径 */
    private _url: string;

    public constructor() {
        super();
        this.init();
    }

    private init(): void {
        this._img = new eui.Image();
        this.addChild(this._img);
    }

    /**
     * 设置图片数据
     */
    public setImgData(info: RoleSkinInfo, skipEffect: boolean): void {
        if (this.url != info.roleURL) {
            this._url = info.roleURL;
            this._img.source = App.data.gameResourceCenter.getRes(this._url);
        }
        this.x = info.x;
        this.y = info.y;
        // this._img.alpha = info.alpha;
        // this._img.scaleX=this._img.scaleX=info.scale;
        if (!skipEffect)
            this.showEffect(info.effectType, info.effectTime);
    }

    public get url(): string {
        return this._url;
    }

    /**
     * 播放显示特效
     */
    public showEffect(type: string, time: number = 1000): void {
        if (type == EnumEffectType.CROSS_FADE) {
            ImageEffectUtil.fadeIn(this, time);
        }
    }

    /**
     * 重置图片
     */
    public reset(skipEffect: boolean): void {
        if (this.parent) {
            if (skipEffect) {
                this._img.source = null;
                this.parent.removeChild(this);
            }
            else {
                ImageEffectUtil.fadeOut(this, 1000, true);
            }
        }
        this._url = null;
    }

    public dispose(): void {
        this.reset(true);
        this._img = null;
    }

    public remove(): void {
        if (this.parent)
            this.parent.removeChild(this);
    }

}