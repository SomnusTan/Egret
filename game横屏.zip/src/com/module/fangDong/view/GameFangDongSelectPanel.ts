/**
 * AVG选项面板
 */
class GameFangDongSelectPanel extends BasePanel {

    private _view: GameFangDongSelectViewUI;

    private _pool: FangDongSelectButton[];

    public constructor() {
        super();

    }

    protected init(): void {
        super.init();
        this._view = new GameFangDongSelectViewUI();
        this.addChild(this._view);
        this._pool = [];
    }

    public dispose(): void {
        super.dispose();
        if (this._pool) {
            while (this._pool.length) {
                this._pool.shift().dispose();
            }
            this._pool = null;
        }

        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    /**
     * 显示面板,初始化按钮
     */
    public show(data?: any): void {
        super.show(data);
        var options: any[] = App.data.gameFangDongCenter.options;
        if (options && options.length) {
            var button: FangDongSelectButton;
            var len: number = options.length;
            var h: number = 102;
            var allH: number = len * h;
            var initY: number;
            if (len <= 3) {
                initY = this._view.boxBtn.height - allH >> 1;
            } else {
                initY = this._view.boxBtn.height - allH;
            }
            for (var i: number = 0, len: number = options.length; i < len; i++) {
                button = this.getButton();
                button.selected = false;
                button.y = initY + i * 102;
                button.data = i + 1;
                this._view.boxBtn.addChild(button);
                button.label = options[i].title;
                button.touchEnabled = true;
                button.show();
                this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchSelect, this, button);
            }
        }
    }

    private onTouchSelect(e: egret.TouchEvent): void {
        // App.sound.needSkip = true;
        var button: FangDongSelectButton = e.currentTarget;
        App.timer.doTimeOnce(ProtocolFangDong.instance(), 2000, ProtocolFangDong.instance().send_chat_select, [App.data.gameFangDongCenter.gameId, App.data.gameFangDongCenter.dlcID, button.data]);
        button.selected = true;
        for (var i: number = 0, len: number = this._view.boxBtn.numChildren; i < len; i++) {
            button = this._view.boxBtn.getChildAt(i) as FangDongSelectButton;
            button.hide(button == e.currentTarget ? 1500 : 0);
            button.touchEnabled = false;
        }
        App.dispatcher.dispatchEvent(GameEvent.SELECTED_OPTION);
    }

    private getButton(): FangDongSelectButton {
        if (this._pool.length > 0) {
            return this._pool.shift();
        }
        return new FangDongSelectButton();
    }

    public hide(): void {
        super.hide();
        var button: FangDongSelectButton;
        while (this._view.boxBtn.numChildren > 0) {
            button = this._view.boxBtn.removeChildAt(0) as FangDongSelectButton;
            this._pool.push(button);
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}