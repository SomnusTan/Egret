class GameFangDongChatView extends eui.Group {

    private _view: GameFangDongChatUI;

    private _currentItem: GameFangDongChatBaseItem;

    public constructor() {
        super();
        this.init();
    }

    protected init(): void {
        this._view = new GameFangDongChatUI();
        this.addChild(this._view);
    }

    public show(): void {
        this._view.imgBg.source = App.data.gameResourceCenter.getRes("s1_img_chat_app_bg_png");
        this.alpha = 0;
        egret.Tween.get(this).to({ alpha: 1 }, 500).call(() => {
            egret.Tween.removeTweens(this);
        });
        this._view.btnBack.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBack, this);
        this._view.btnSend.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchSend, this);
    }

    /**
     * 点击返回
     */
    private onTouchSend(e: egret.TouchEvent): void {
        if (this._currentItem instanceof GameFangDongChatItem) {
            this._view.boxChat.addChild(this._currentItem);
            this._view.txtSend.text = " ";
            ProtocolFangDong.instance().send_chat_select(App.data.gameFangDongCenter.gameId, App.data.gameFangDongCenter.dlcID);
        }
    }

    /**
     * 点击返回
     */
    private onTouchBack(e: egret.TouchEvent): void {
        GameManager.exitGame();
        if (Config.isLandscape) {
            App.setOrientation(egret.OrientationMode.LANDSCAPE);
        }
        if (Config.isLocalApp)
            PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getFirstHeroniesData());
        else
            PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
    }

    public dispose(): void {
        if (this._view) {
            this._view.btnBack.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBack, this);
            this._view.dispose();
            this._view = null;
        }
    }

    public hide(): void {
        this._view.btnBack.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBack, this);
        this._view.btnSend.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchSend, this);
        this.alpha = 1;
        egret.Tween.get(this).to({ alpha: 0 }, 500).call(() => {
            egret.Tween.removeTweens(this);
            while (this._view.boxChat.numChildren) {
                (this._view.boxChat.removeChildAt(0) as GameFangDongChatBaseItem).dispose();
            }
            if (this.parent)
                this.parent.removeChild(this);
        });
    }

    /**
     * 添加新的项
     * @param data
     * @returns 等待时间
     */
    public addChatItem(data: any): void {
        var waitTime: number = 0;
        if (data.type == 0) {
            this._currentItem = new GameFangDongChatTimeItem();
        }
        else if (data.type == 1) {
            this._currentItem = new GameFangDongChatItem();
        }
        else {
            this._currentItem = new GameFangDongChatVoiceItem();
            if (this._view.boxChat.numChildren != 0) {
                waitTime = Math.floor(Math.random() * 1000 + 1000);
            }
        }
        this._currentItem.initData(data);
        if (data.type != 1) {
            this._view.boxChat.addChild(this._currentItem);
        }
        else {
            this._view.txtSend.text = data.text;
        }
        if (waitTime != 0) {
            this._currentItem.visible = false;
            App.timer.doTimeOnce(this, waitTime, () => {
                this._currentItem.visible = true;
                App.sound.playSoundSwitchClient(EnumSoundId.RING_MESSAGE);
                if (App.data.gameFangDongCenter.isAutoPlay) {
                    this._currentItem.autoNext();
                }
            });
        }
        else if (this._currentItem instanceof GameFangDongChatVoiceItem) {
            if (App.data.gameFangDongCenter.isAutoPlay) {
                this._currentItem.autoNext();
            }
        }
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

    public get canNext(): boolean {
        return this._currentItem ? this._currentItem.canNext : true;
    }
}