class GameFangDongBuyAllPanel extends WindowView {

    private _view: GameFangDongBuyAllUI;

    private _data: any;

    public constructor() {
        super(597 + 40, 867, true);
    }

    protected initView(): void {
        this._view = new GameFangDongBuyAllUI();
        this.viewSp.addChild(this._view);
        this._view.x = 20;
        this._view.y = -50;
        this.topTitle = "优惠";
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this._data = data;
        if (this._data.gift_package) {
            this._view.txtAllPrice.text = this._data.gift_package.balance_money;
            if (this._view.boxAll.parent == null) {
                this._view.addChild(this._view.boxAll);
            }
            this._view.rectLine.width = this._view.txtAllOldPrice.width + 5;
            this.setWH(597 + 40, 867 - 40, true);
        }
        else {
            this._view.boxAll.visible = false;
            if (this._view.boxAll.parent) {
                this._view.boxAll.parent.removeChild(this._view.boxAll);
            }
            this.setWH(597 + 40, 427 - 40, true);
        }
        this._view.txtSingleDiscount.text = this._data.actual.discount;
        this._view.txtSinglePrice.text = this._data.actual.price;

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this._view.boxSingle);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this._view.boxAll);
    }

    public hide(): void {
        super.hide();

    }


    private onTouch(e: egret.TouchEvent): void {
        if (e.currentTarget == this._view.boxSingle) {
            Alert.show(StringUtil.substitute(EnumAlertContent.BUY_CHAO_ZHI_GIFT_SINGLE, this._data.actual.price, this._data.actual.title), "确定|取消",
                new FunctionVO(this.onSureBuy, this, this._data.actual.id, EnumPayType.BUY_KOUYA, this._data.actual.price));
        }
        else if (e.currentTarget == this._view.boxAll) {
            Alert.show(StringUtil.substitute(EnumAlertContent.BUY_CHAO_ZHI_GIFT, this._data.gift_package.balance_money, this._data.gift_package.title), "确定|取消",
                new FunctionVO(this.onSureBuy, this, this._data.gift_package.id, EnumPayType.BUY_ZUHE, this._data.gift_package.balance_money));
        }
    }

    private onSureBuy(data: any, id: number, type: number, price: number): void {
        if (data.type == Alert.OK) {
            if (App.global.userInfo.xdCoin >= price)
                ProtocolCommon.instance().send_shop_please_pay(type, id, EnumPayType.BUY_TYPE_COIN, new FunctionVO(this.onBuyBack, this, id, type));
            else
                PanelOpenManager.openPanel(EnumPanelID.GAME_CHARGE, { type: 0, minCoin: price, successClose: true });
        }
    }

    private onBuyBack(response: any, id: number, type: number): void {
        if (ResponseUtil.checkResponseData(response) && response.data.type == "balance") {
            Notice.showBottomCenterMessage(`购买${response.data.name}成功`);
            App.global.userInfo.xdCoin = response.data.balance;
            App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
            App.data.gameHallCenter.updateHeroniesProps(id, { is_shop: true });
            this.closePanel();
            if (type == EnumPayType.BUY_KOUYA)
                App.dispatcher.dispatchEvent(EventType.BUY_SUCCESS, response.data.pid, response);
            else if (type == EnumPayType.BUY_ZUHE)
                App.dispatcher.dispatchEvent(EventType.DETAIL_BUY_CZZH);
        }
        else if (response.code == 234) {
            PanelOpenManager.openPanel(EnumPanelID.GAME_CHARGE, { type: 0, minCoin: this._data.balance_money, successClose: true });
        }
    }
}