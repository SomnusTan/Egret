/**
 * 房东取名
 */
class GameFangDongBenamePanel extends BasePanel {

    private _view: GameFangDongBeNameUI;

    public constructor() {
        super();

    }

    protected init(): void {
        super.init();
        this._view = new GameFangDongBeNameUI();
        this.addChild(this._view);

    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);

        this._view.txtName["textTemp"].textColor = 0xffffff;

        this._view.btnName["img_down"].source = this._view.btnName["img_up"].source = App.data.gameResourceCenter.getRes(EnumGameRes1.MENU_BASE_BUTTON);
        this._view.btnRandom["img_down"].source = this._view.btnRandom["img_up"].source = App.data.gameResourceCenter.getRes(EnumGameRes1.RANDOM_BUTTON);

        this._view.imgBg.source = App.data.gameResourceCenter.getRes(EnumGameRes1.INPUT_BG);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchRandomName, this, this._view.btnRandom);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBename, this, this._view.btnName);

        this._dispatcher.addEventListener(GameEvent.GAME_RANDOM_NAME, this.onGetRandomName, this);

        InputTextUtil.addNativeInputTextListener(this._view.txtName);
    }

    public hide(): void {
        super.hide();
        InputTextUtil.removeNativeInputTextListener(this._view.txtName);
    }

    /**
     * 随机名字
     */
    private onTouchRandomName(e: egret.TouchEvent): void {
        ProtocolFangDong.instance().send_random_name();
    }

    private onGetRandomName(name: string): void {
        this._view.txtName.text = name;
    }

    private onTouchBename(e: egret.TouchEvent): void {
        var txt: string = this._view.txtName.text;
        if (txt == "") {
            Notice.showBottomCenterMessage("名字不能为空");
            return;
        }
        if (txt.length < 2) {
            Notice.showBottomCenterMessage("名字长度至少2个字");
            return;
        }
        if (txt.length > 12) {
            Notice.showBottomCenterMessage("名字长度不能超过12个字");
            return;
        }
        ProtocolFangDong.instance().send_bename(txt, App.data.gameFangDongCenter.gameId);
    }

    public get width(): number {
        return 536;
    }

    public get height(): number {
        return 270;
    }
}