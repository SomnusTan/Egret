class GameFangDongBuyPanel extends BasePanel {

    private _view: GameFangDongBuyUI;

    private _uid: number;

    private _orderId: string;//请求支付的订单id
    private _waitTimes: number;//请求支付的等待时间，超过5分钟关闭面板
    private _needSendBuy: boolean;//请求是否支付成功

    private _data: any;

    private _tempWin: Window;
    private _czzhBtn: ChaoZhiZuHeButton;

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new GameFangDongBuyUI();
        this.addChild(this._view);
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this._data = data;
        this.onTouchRelease();
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this, this._view.btn_unlock);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouchRelease, this, this._view.btn_unlock);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_unlock);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onQuitClick, this, this._view.btn_quit);
        this._dispatcher.addEventListener(EventType.BUY_SUCCESS, this.onBuySuccess, this);
        this._dispatcher.addEventListener(EventType.SHOP_IS_SHOP, this.onCheckShop, this);
        this._uid = this._data.id;
        if (this._data.gift_package && !this._data.in_shop_chat) {
            this.addCzzhBtn();
        } else {
            this.removeCzzhBtn();
        }

        if (DeviceUtil.IsWeb && DeviceUtil.isMobile && (Config.soEasy == false && H5_360_Sdk.getInstance().config360 == null) &&
            (DeviceUtil.isWeiBoBrowser || DeviceUtil.isWeiXinBrowser || DeviceUtil.isQQInBrowser || DeviceUtil.isSogouBrowser)) {
            Notice.showBottomCenterMessage("因内嵌浏览器无法弹出支付窗口,请使用\n谷歌浏览器支付体验");
        }
        this.addButtonTween();
        this.showActPrice();
    }

    public hide(): void {
        super.hide();
        egret.Tween.removeTweens(this._view.boxButton);
        this.clearTimer();
        App.timer.clearTimer(this, this.onActTimer);
        App.timer.clearTimer(this, this.sendGetEndOrder);
        this._data = null;
        this.onTouchBegin();
        this.removeCzzhBtn();
        this._tempWin = null;
    }

    private addCzzhBtn(): void {
        if (!this._czzhBtn) {
            this._czzhBtn = new ChaoZhiZuHeButton(this._data.gift_package);
            this._czzhBtn.x = 620;
            this._czzhBtn.y = 905;
            this._view.addChild(this._czzhBtn);
        }
    }

    private removeCzzhBtn(): void {
        if (this._czzhBtn) {
            this._czzhBtn.dispose();
            this._czzhBtn = null;
        }
    }

    private addButtonTween(): void {
        egret.Tween.get(this._view.boxButton, { loop: true }).to({ scaleX: 1.3, scaleY: 1.3 }, 80).to({ scaleX: 1, scaleY: 1 }, 800, egret.Ease.elasticOut).wait(100);
    }

    private showActPrice(): void {
        if (this._data.in_shop_chat) {
            this._view.txt_price.visible = false;
            this._view.groupBtnLabel.verticalCenter = 0;
            this._view.group_old.x = 0;
            this._view.groupTime.visible = false;
            this._view.group_old.visible = false;
            this._view.img_payword.visible = false;
        } else {
            this._view.txt_price.visible = true;
            this._view.img_payword.visible = true;
            this._view.txt_price.text = "￥" + this._data.money;
            this._view.groupBtnLabel.verticalCenter = -28;
            var originalMoney: number = this._data.originalMoney;
            if (originalMoney) {
                this._view.group_old.x = 140;
                this._view.txt_oldprice.text = "￥" + originalMoney;
                this._view.group_old.visible = true;
                if (this._data.endTime > 0) {
                    this._view.groupTime.visible = true;
                    App.timer.serverTimeEnd(this, this.onActTimer, this._data.endTime);
                } else {
                    this._view.groupTime.visible = false;
                }
            } else {
                this._view.group_old.x = 0;
                this._view.groupTime.visible = false;
                this._view.group_old.visible = false;
            }
        }
    }

    private onActTimer(data: ServerTimeData): void {
        if (data.spuleTime > 0) {
            this._view.txt_actTime.text = "优惠时间剩余 " + StringUtil.formatLeftTimeDHM(data.spuleTime);
        } else {
            App.timer.clearTimer(this, this.onActTimer);
        }
    }

    /**
     * 购买成功
     */
    private onBuySuccess(id: number, data: any): void {
        if (id == this._uid) {
            this.onHttpShopPayBack(data);
        }
    }

    private onTouchBegin(e?: egret.TouchEvent): void {
        this._view.imgLight.visible = true;
    }

    private onTouchRelease(e?: egret.TouchEvent): void {
        this._view.imgLight.visible = false;
    }

    private onClick(e: egret.TouchEvent): void {
        if (this._data.in_shop_chat) {
            App.dispatcher.dispatchEvent(GameEvent.GAME_UNLOCK_SUCCESS, this._uid);
            this.onTouchRelease(e);
            this.closePanel();
            return;
        }
        // 查询服务端版本数据
        if (DeviceUtil.IsWeb) {
            if (Config.soEasy || Config.isLocalApp || H5_360_Sdk.getInstance().config360) {
                ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_KOUYA, this._uid, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayOtherBack, this));
            }
            else {
                Alert.choosePay({ price: this._data.money, closeHandler: new FunctionVO(this.onChooseBack, this) });
                // if (Config.skipVideo) {
                // } else {
                // 	this.onChooseBack({ payType: EnumPayType.PAY_ALIPAY });
                // }
            }
        }
        else {
            if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
                App.nativeBridge.sendU8PayNew(EnumPayType.BUY_KOUYA, {
                    productId: this._uid,
                    buyNum: 1,
                    price: this._data.money,
                    productName: this._data.title,
                    productDesc: "解锁《" + this._data.title + "》后续内容",
                    ratio: "",
                    serverID: "",
                    serverName: this._data.title
                });
            } else if (DeviceUtil.IsIos && DeviceUtil.IsNative) {
                App.nativeBridge.sendIOSPayNew(EnumPayType.BUY_KOUYA, this._uid);
            }
        }
        this.onTouchRelease(e);
    }
    /**
     *  {payType:支付类型 1：微信，2：支付宝}
     */
    private onChooseBack(data: any): void {
        if (Config.isRelease || Config.skipVideo) {
            if (data.payType == EnumPayType.PAY_WECHAT && DeviceUtil.isMobile) { //手机端微信支付
                var url: string = WebParams.ip + ProtocolHttpUrl.shop_please_pay + "?channel=wechat&type=" + EnumPayType.BUY_KOUYA + "&good_id=" + this._uid + "&setting=" + DeviceUtil.currentSetting +
                    "&channel_id=" + App.global.userInfo.channelId + "&Authorization=" + App.global.userInfo.skey + "&AuthorizationID=" + App.global.userInfo.uid;
                this._tempWin = window.open(url, "_blank");
                App.timer.doTimeOnce(this, 3000, this.sendGetEndOrder);
            } else if (data.payType == EnumPayType.PAY_ALIPAY || (!DeviceUtil.isMobile && data.payType == EnumPayType.PAY_WECHAT)) { //支付宝 || 微信web
                if (data.payType == EnumPayType.PAY_ALIPAY)
                    this._tempWin = WebParams.openWindow(WebParams.defaultURL);
                ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_KOUYA, this._uid, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayBack1, this, data.payType), data.payType);
            }
        } else {
            ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_KOUYA, this._uid, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayBack, this), data.payType);
        }
    }

    private sendGetEndOrder(): void {
        App.timer.clearTimer(this, this.sendGetEndOrder);
        ProtocolCommon.sendBack(ProtocolHttpUrlGame2.shop_end_order, { good_id: this._uid, type: EnumPayType.BUY_KOUYA }, new FunctionVO(this.checkOrder, this));
    }

    private checkOrder(data): void {
        if (data.code == 200) {
            this._orderId = data.data;
            this.clearTimer();
            App.timer.doTimeLoop(this, 3000, this.checkBuySuccess);
        }
    }

    /**
     * 请求跳转支付宝页面，并且循环检测是否支付完成
     * type:支付类型 1：微信，2：支付宝
     */
    private onHttpShopPayBack1(data: any, type: number): void {
        if (data.code == 200) {
            this._orderId = data.data.order_id;
            this._waitTimes = 0;
            this._needSendBuy = true;
            if (type == EnumPayType.PAY_WECHAT) {
                data.data.payType = type;
                PanelOpenManager.openPanel(EnumPanelID.WECHAT_QRCODE, data.data);
            } else if (type == EnumPayType.PAY_ALIPAY) {
                ProtocolCommon.instance().send_alipay_switch(data.data.code, this._tempWin);
            }
            this.clearTimer();
            App.timer.doTimeLoop(this, 3000, this.checkBuySuccess);
        }
    }

    /** 检测是否支付完成*/
    private checkBuySuccess(): void {
        this._waitTimes += 3;
        if (this._waitTimes >= 300) {
            this.clearTimer();
            Notice.showBottomCenterMessage("支付失败");
            return;
        }
        if (this._needSendBuy) {
            this._needSendBuy = false;
            ProtocolCommon.sendBack(ProtocolHttpUrl.shop_is_shop, { order_id: this._orderId }, new FunctionVO(this.onShopBack, this));
        }
    }

    private onCheckShop(): void {
        this._waitTimes = 0;
        this._needSendBuy = true;
        this.clearTimer();
        this.checkBuySuccess();
        App.timer.doTimeLoop(this, 3000, this.checkBuySuccess);
    }

    /** 支付完成返回*/
    private onShopBack(data: any): void {
        if (data.code == 200) {
            if (data.data.type) {//data.data == true时，成功
                this.clearTimer();
                this.onHttpShopPayBack(data);
            } else {
                this._needSendBuy = true;
            }
        }
    }

    private clearTimer(): void {
        App.timer.clearTimer(this, this.checkBuySuccess);
    }

    /** 支付完成返回*/
    private onHttpShopPayBack(data: any): void {
        if (data.code == 200) {
            PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
            this.closePanel();
            App.data.gameHallCenter.updateHeroniesProps(this._uid, { is_shop: true });
            if (!App.global.forceToPhoneBind()) {
                App.dispatcher.dispatchEvent(GameEvent.GAME_UNLOCK_SUCCESS, this._uid);
            }
            //window['closeWebView']();
        }
    }

    /**渠道支付返回 */
    private onHttpShopPayOtherBack(data: any): void {
        if (data.code == 200) {
            this._orderId = data.data.order_id;
            if (Config.soEasy) {
                let payinfojson = {
                    check: data.data.code, feeid: data.data.order_id, fee: String(Number(data.data.price) * 100), feename: data.data.productName,
                    extradata: data.data.order_id, serverid: "1", servername: data.data.ServerName
                }
                GameLog.log('------------请求支付房东----------------payinfojson--,', payinfojson);
                ZmSdk.getInstance().pay(payinfojson, function (data) {
                    GameLog.log('------------请求支付房东---------payBack:data,', data);
                    if (data.retcode === "0") {
                        App.dispatcher.dispatchEvent(EventType.SHOP_IS_SHOP);
                    } else if (data.retcode === "1") { //购买失败处理
                    } else if (data.retcode === "2") { //初购取消
                    } else if (data.retcode === "3") { // 跳转到了支付界面或渠道不支持
                    }
                });
            } else if (H5_360_Sdk.getInstance().config360) {
                H5_360_Sdk.getInstance().pay360Param = data.data.code;
                H5_360_Sdk.getInstance().order_id = data.data.order_id;
                H5_360_Sdk.getInstance().paySdk();
                App.dispatcher.dispatchEvent(EventType.SHOP_IS_SHOP);
                GameLog.log("360支付订单号：", this._orderId);
            }
            else if (Config.isLocalApp) {
                GameLog.log('请求后端调steam支付:' + this._orderId);
            }
        }
    }

    private onQuitClick(e: egret.TouchEvent): void {
        if (GameManager.isPlaying) {
            GameManager.exitGame();
            App.global.guide.changeGuideTo_stateN(EnumGuideType.DETAIL_READ);
            PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getHeroniesData(this._uid));
        }
        this.closePanel();
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }

}