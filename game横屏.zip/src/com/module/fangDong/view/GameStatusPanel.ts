/**
 * 游戏状态界面
 */
class GameStatusPanel extends BasePanel {

    private _view: GameStatusViewUI;

    private _labelData: string;

    private _index: number;

    private _baseLabel: string = "　　";

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
        this._view = new GameStatusViewUI();
        this.addChild(this._view);
    }

    public show(data?: any): void {
        super.show(data);
        var tData: GameFangDongCenter = App.data.gameFangDongCenter;
        this._view.imgRole.source = tData.imageEffectInfo.bgURL;
        this._view.imgStatus.source = "s1_img_status_word_" + tData.relationshipStatus + "_png";
        this._labelData = tData.windowInfo.label;
        this._view.txtInfo.text = "　　";
        this._view.imgRole.alpha = 0;
        this._view.imgStatus.alpha = 0;
        this._index = 0;
        this._view.boxCoin.show();
        this._view.imgFlag.visible = false;
        egret.Tween.get(this._view.imgRole).to({ alpha: 1 }, 500);
        egret.Tween.get(this._view.imgStatus).wait(400).to({ alpha: 1 }, 500).call(this.removeTween, this);
    }

    public hide(): void {
        this.removeTween(false);
        App.timer.clearTimer(this, this.onUpdateLabel);
        this._view.boxCoin.hide();
        super.hide();
    }

    /**
     * 
     * @param isAuto 是否自动播放完成
     */
    private removeTween(isAuto: boolean = true): void {
        egret.Tween.removeTweens(this._view.imgRole);
        egret.Tween.removeTweens(this._view.imgStatus);
        // this._view.imgFlag.visible = true;
        if (isAuto) {
            App.timer.doTimeLoop(this, 80, this.onUpdateLabel, [this._labelData.length]);
            // this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this);
        }
    }

    private onUpdateLabel(len: number): void {
        this._index++;
        this._view.txtInfo.text = this._baseLabel + this._labelData.slice(0, this._index);
        if (this._index >= len) {
            App.timer.clearTimer(this, this.onUpdateLabel);
            this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this);
            this._view.imgFlag.visible = true;
        }
    }

    private onTouch(e: egret.TouchEvent): void {
        // this.closePanel();
        ProtocolFangDong.instance().send_chat_select(App.data.gameFangDongCenter.gameId, App.data.gameFangDongCenter.dlcID);
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public get width(): number {
        return Config.MAIN_WIDTH;
    }

    public get height(): number {
        return Config.MAIN_HEIGHT;
    }
}