/**
 * 回放界面
 */
class GameFangDongReviewPanel extends BasePanel {

    private _view: GameFangDongReviewUI;
    /**滚动条 */
    private _scroll: eui.Scroller;
    /**总页数 */
    private _maxPage: number = 0;
    /**当前页 */
    private _curPage: number = 1;
    /**是否需要获取新页面数据 */
    private _needGet: boolean;
    /**文本对象池 */
    private _labelPool: eui.Label[];
    /**文本宽度 */
    private TXT_WIDTH: number = 570;

    public constructor() {
        super();

    }

    protected init(): void {
        super.init();
        this._view = new GameFangDongReviewUI();
        this.addChild(this._view);
        this._labelPool = [];
        this._scroll = new eui.Scroller()
        this._scroll.skinName="skins.ScrollerSkin";
        this._scroll.width = this.TXT_WIDTH + 20;
        this._scroll.height = 710;
        this._scroll.x = this._view.boxTxt.x;
        this._scroll.y = this._view.boxTxt.y;
        this._scroll.viewport = this._view.boxTxt;
        this._view.addChild(this._scroll);
    }

    public dispose() {
        super.dispose();
        if (this._scroll) {
            if (this._scroll.parent)
                this._scroll.parent.removeChild(this._scroll);
            this._scroll.viewport = null;
            this._scroll = null;
        }
        if (this._labelPool) {
            this._labelPool.length = 0;
            this._labelPool = null;
        }
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this._needGet = false;
        this._scroll.verticalScrollBar.autoVisibility = false;
        this._scroll.verticalScrollBar.visible = true;
        this._scroll.verticalScrollBar.touchChildren = true;
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this, this._scroll.verticalScrollBar.thumb);

        // this._scroll.viewport.scrollV=this._scroll.viewport.height-this._scroll.height;
        this._dispatcher.addEventListener(GameEvent.GAME_REVIEW_DATA, this.onUpdateReview, this);
        this._dispatcher.addEventListener(eui.UIEvent.CHANGE, this.onMoveScroll, this, this._scroll);
        this._dispatcher.addEventListener(eui.UIEvent.CHANGE_END, this.onMoveScrollEnd, this, this._scroll);
        ProtocolFangDong.instance().send_chat_review(App.data.gameFangDongCenter.gameId);
    }

    public hide(): void {
        super.hide();
        App.dispatcher.dispatchEvent(GameEvent.GAME_CONTINE);
        var label: eui.Label;
        while (this._view.boxTxt.numChildren) {
            label = this._view.boxTxt.removeChildAt(0) as eui.Label;
            label.text = "";
            this._labelPool.push(label);
        }
        this._maxPage = 0;
        this._curPage = 1;
    }

    private _thumbY: number;

    private onTouchBegin(e: egret.TouchEvent): void {
        e.stopImmediatePropagation();
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this, this.stage);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this, this.stage);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouchEnd, this, this.stage);
        this._thumbY = this._scroll.verticalScrollBar.thumb.y - e.stageY;
    }

    private onTouchMove(e: egret.TouchEvent): void {
        e.stopImmediatePropagation();
        var y: number = this._thumbY + e.stageY;
        var scroll: number = y / (this._scroll.height - this._scroll.verticalScrollBar.thumb.height);
        this._view.boxTxt.scrollV = (scroll < 0 ? 0 : scroll) * (this._view.boxTxt.contentHeight - this._scroll.height);
    }

    private onTouchEnd(e: egret.TouchEvent): void {
        this._dispatcher.removeEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this, this.stage);
        this._dispatcher.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this, this.stage);
        this._dispatcher.removeEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouchEnd, this, this.stage);
    }

    private onMoveScroll(e: eui.UIEvent): void {
        if (this._view.boxTxt.scrollV < -150) {
            this._needGet = true;
        }
    }

    /**
     * 拉到顶部请求数据
     */
    private onMoveScrollEnd(e: eui.UIEvent): void {
        if (this._needGet) {
            this._needGet = false;
            if (this._curPage < this._maxPage) {
                ProtocolFangDong.instance().send_chat_review(App.data.gameFangDongCenter.gameId, this._curPage + 1);
            }
        }
    }

    /**
     * 更新回放数据
     */
    private onUpdateReview(data: any): void {
        this._curPage = data.current;
        this._maxPage = data.sun_page;
        var label: eui.Label = this.getLabel();
        label.textFlow = this.getTextFlow(data.info);
        label.y = 5;
        var tempH: number = 5 + label.height;
        var tempLabel: eui.Label;
        for (var i: number = this._view.boxTxt.numChildren - 1; i >= 0; i--) {
            tempLabel = this._view.boxTxt.getChildAt(i) as eui.Label;
            tempLabel.y = tempH;
            tempH += tempLabel.height;
        }
        this._view.boxTxt.addChild(label);
        var scrollV: number;
        if (this._curPage == 1) {
            scrollV = label.height - this._scroll.height;
            if (scrollV < 0)
                scrollV = 0;
            this._view.boxTxt.scrollV = scrollV;
        }
        else {
            scrollV = label.height;
            this._view.boxTxt.scrollV = scrollV;
            scrollV -= 200;
            if (scrollV <= 0)
                scrollV = 0;
            egret.Tween.get(this._view.boxTxt).to({ scrollV: scrollV }, 200);
        }
    }

    /**
     * 解析显示的回放数据
     */
    private getTextFlow(dataList: any[]): egret.ITextElement[] {
        var txt: string = "";
        var data: any;
        var regExp: RegExp = /<(\/?br.*?\/)>|\\n/g;
        for (var i: number = dataList.length - 1; i >= 0; i--) {
            data = dataList[i];
            // txt += "<font color='"+data[i].color+"'>"+(data[i].name!=""?data[i].name + "\n":"")+data[i].depict+"\n\n</font>";
            if (data.is_option_text) {
                txt += "<font color='#999999'>——" + data.is_option_text + "——</font>\n\n"
            }
            txt += "<font color='" + data.color + "'>" + (data.name != "" ? data.name + "\n" : "") + data.depict.replace(regExp, "\n") + "</font>" + (i != 0 ? "\n\n" : "\n ");
        }
        return HtmlUtil.getHtmlStr(txt);
    }

    private getLabel(): eui.Label {
        if (this._labelPool.length > 0)
            return this._labelPool.shift();
        var label: eui.Label = new eui.Label();
        label.size = 28;
        label.multiline = true;
        label.wordWrap = true;
        // label.stroke = 1;
        label.lineSpacing = 5;
        label.width = this.TXT_WIDTH
        return label;
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}