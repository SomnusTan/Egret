class GameFangDongMenuPanel extends BasePanel {

    private _view: GameFangDongMenuUI;

    public constructor() {
        super();

    }

    protected init(): void {
        super.init();
        this._view = new GameFangDongMenuUI();
        this.addChild(this._view);
        this._view.width = Config.MAIN_WIDTH;
        this._view.height = Config.MAIN_HEIGHT;

        // this._view.btnSave["img_down"].source = this._view.btnSave["img_up"].source = App.data.gameResourceCenter.getRes(EnumGameRes1.SAVE_BUTTON);
        // this._view.btnRead["img_down"].source = this._view.btnRead["img_up"].source = App.data.gameResourceCenter.getRes(EnumGameRes1.READ_BUTTON);
        // this._view.btnContinue["img_down"].source = this._view.btnContinue["img_up"].source = App.data.gameResourceCenter.getRes(EnumGameRes1.CONTINUE_BUTTON);

        // this._view.btnSetting["img_down"].source = this._view.btnSetting["img_up"].source = App.data.gameResourceCenter.getRes(EnumGameRes1.SETTING_BUTTON);
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);

        this._view.btnSave.icon = App.data.gameResourceCenter.getRes(EnumGameRes1.SAVE_ICON);
        this._view.btnRead.icon = App.data.gameResourceCenter.getRes(EnumGameRes1.READ_ICON);
        this._view.btnContinue.icon = App.data.gameResourceCenter.getRes(EnumGameRes1.CONTINUE_ICON);

        (this._view.btnSave.getChildAt(0) as eui.Image).source = App.data.gameResourceCenter.getRes(EnumGameRes1.MENU_BASE_BUTTON);
        (this._view.btnRead.getChildAt(0) as eui.Image).source = App.data.gameResourceCenter.getRes(EnumGameRes1.MENU_BASE_BUTTON);
        (this._view.btnContinue.getChildAt(0) as eui.Image).source = App.data.gameResourceCenter.getRes(EnumGameRes1.MENU_BASE_BUTTON);

        this._view.btnBack["img_down"].source = this._view.btnBack["img_up"].source = App.data.gameResourceCenter.getRes(EnumGameRes1.BACK_BUTTON);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnSave);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnRead);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnContinue);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnBack);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnSetting);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnGm);

        this._view.btnGm.visible = App.data.gameFangDongCenter.isShowGmBtn;
        //引导
        App.global.guide.showView(this._view.btnSave, EnumGuideType.AVG_MENU_SAVE, this.panelName, true);
        App.global.guide.showView(this._view.btnRead, EnumGuideType.AVG_MENU_READ, this.panelName, true);
        if (App.data.gameFangDongCenter.isDLC) {
            if (this._view.btnRead.parent)
                this._view.btnRead.parent.removeChild(this._view.btnRead);
            if (this._view.btnSave.parent)
                this._view.btnSave.parent.removeChild(this._view.btnSave);
            this._view.btnContinue.y = 0;
        }
        else {
            if (this._view.btnRead.parent == null)
                this._view.boxButton.addChild(this._view.btnRead);
            if (this._view.btnSave.parent == null)
                this._view.boxButton.addChild(this._view.btnSave);
            this._view.btnContinue.y = 204;
        }
    }

    private onTouchBtn(e: egret.TouchEvent): void {
        if (e.currentTarget == this._view.btnContinue) {
            //继续游戏
            App.dispatcher.dispatchEvent(GameEvent.GAME_CONTINE);
        }
        else if (e.currentTarget == this._view.btnSave) {
            //打开存档界面
            PanelOpenManager.openPanel(EnumPanelID.RECORD, { uid: App.data.gameFangDongCenter.gameId, type: EnumRecordType.SAVE });
        }
        else if (e.currentTarget == this._view.btnRead) {
            //打开读档界面
            PanelOpenManager.openPanel(EnumPanelID.RECORD, { uid: App.data.gameFangDongCenter.gameId, type: EnumRecordType.READ });
        }
        else if (e.currentTarget == this._view.btnBack) {
            //返回大厅
            GameManager.exitGame();
            if (Config.isLandscape) {
                App.setOrientation(egret.OrientationMode.LANDSCAPE);
            }
            if (Config.isLocalApp)
                PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getFirstHeroniesData());
            else
                PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
        }
        else if (e.currentTarget == this._view.btnSetting) {
            //打开游戏设置
            PanelOpenManager.openPanel(EnumPanelID.HERONIES_SETTING, { id: App.data.gameFangDongCenter.gameId, panelName: this.panelName });
        }
        else if (e.currentTarget == this._view.btnGm) {
            PanelOpenManager.openPanel(EnumPanelID.GM, {
                id: App.data.gameFangDongCenter.isDLC ? App.data.gameFangDongCenter.dlcID : App.data.gameFangDongCenter.gameId,
                isDlc: App.data.gameFangDongCenter.isDLC
            });
        }
        PanelManager.removePanelByName(this.panelName);
    }

    public hide(): void {
        super.hide();
    }

    public get width(): number {
        return this._view.width;
    }

    public get height(): number {
        return this._view.height;
    }
}