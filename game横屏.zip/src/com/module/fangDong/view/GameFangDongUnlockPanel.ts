class GameFangDongUnlockPanel extends WindowView {
    private _view: GameFangDongUnlockUI;

    private _id: number;

    private _dlcID: number;

    private _price: number;

    private _data: any;

    private _czzhBtn: ChaoZhiZuHeButton;

    public constructor() {
        super(480, 266, true);
    }

    protected initView(): void {
        this._view = new GameFangDongUnlockUI();
        this.viewSp.addChild(this._view);
        this._view.y = -50;
        this.topTitle = "提示";
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this.touchChildren = true;
        this._id = data.id;
        this._dlcID = data.dlcID;
        this._price = data.price;
        this._data = data;
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClose, this, this._view.btnExit);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBuy, this, this._view.btnOK);
        this._dispatcher.addEventListener(EventType.BUY_SUCCESS, this.onBuySuccess, this);
        this._dispatcher.addEventListener(EventType.DETAIL_BUY_CZZH, this.onBuySuccess, this);
        if (data.actual)
            this._view.txtDesc.textFlow = HtmlUtil.getHtmlStr(StringUtil.substitute(EnumAlertContent.UNLOCK_AVG_VIDEO, this._price));
        else
            this._view.txtDesc.textFlow = HtmlUtil.getHtmlStr(StringUtil.substitute(EnumAlertContent.UNLOCK_AVG_VIDEO_LAST, this._price));

        if (data.actual) {
            this.showCZBtn();
        }
        else {
            this.hideCZBtn();
        }
    }

    private showCZBtn(): void {
        if (this._czzhBtn == null) {
            this._czzhBtn = new ChaoZhiZuHeButton();
            this._czzhBtn.x = 420;
            this._czzhBtn.y = 500;
        }
        this._czzhBtn.setData({
            panelID: EnumPanelID.GAME_FANG_DONG_BUY_ALL,
            effectType: this._data.gift_package ? 0 : 1,
            gift_package: this._data.gift_package,
            actual: {
                title: this._data.actual.actual_title,
                price: this._data.actual.actual_money,
                discount: this._data.actual.actual_discount,
                id: this._data.actual.actual_id
            }
        });
        if (this._czzhBtn.parent == null)
            this.addChild(this._czzhBtn);
    }

    private hideCZBtn(): void {
        if (this._czzhBtn) {
            this._czzhBtn.dispose();
            this._czzhBtn = null;
        }
    }

    public hide(): void {
        super.hide();
    }

    protected onClose(e?: egret.TouchEvent) {
        super.onClose(e);
        this.touchChildren = false;
        GameManager.exitGame();
        PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getHeroniesData(this._id));
    }

    private onBuy(e: egret.TouchEvent): void {
        if (App.global.userInfo.xdCoin >= this._price) {
            ProtocolFangDong.instance().send_chat_select(this._id, this._dlcID, 0, EnumPayType.AVG_BUY_TYPE_3);
            this.closePanel();
        }
        else {
            PanelOpenManager.openPanel(EnumPanelID.GAME_CHARGE, { type: 0, minCoin: this._price, successClose: true });
            Notice.showBottomCenterMessage("心动币不足，请充值");
        }
    }

    private onBuySuccess(id?: number, response?): void {
        ProtocolFangDong.instance().send_chat_select(this._id, this._dlcID);
        this.closePanel();
    }
}
