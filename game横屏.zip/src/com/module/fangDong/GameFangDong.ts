class GameFangDong extends BaseGame {
    /**微信界面 */
    private _weChatView: GameFangDongChatView;
    /**背景图控制 */
    private _bgImageControl: BgImageControl;

    private _view: GameFangDongUI;

    private _bgSp: egret.Shape;
    /**文字播放索引 */
    private _typingIndex: number;
    /**立绘控制 */
    private _roleImageControl: RoleImageControl;
    /**操作状态 0:初始化中 1:可下一步 2:播放语音中 3:播放视频中 4:播放文字动画中 */
    private _state: number;
    /**忽略弹起 */
    private _touchIgnore: boolean = false;
    /**上一次显示的类型 */
    private _lastType: number;
    /**房东数据管理中心 */
    private _data: GameFangDongCenter;
    /**等待次数 */
    private _waitNum: number = 0;
    /**存档ID */
    private _saveId: number;
    /**按钮基础Y坐标 */
    private _baseY: number;
    /**粒子效果 */
    private _particleEffect: BaseEffect;
    /**临时数据 */
    private _tempData: any;
    /**上一个视频ID */
    private _lastVideoId: number;
    /**分享按钮基础X坐标 */
    private _groupShareX: number;

    private _imgNext: ImgNextEffect;
    /**必须等待 */
    private _mustWait: boolean;

    public constructor() {
        super();
    }

    protected init(): void {
        super.init();
        if (App.data.gameResourceCenter.hasChapterResource(0)) {
            this.superInit();
        }
    }

    protected superInit(): void {
        this._bgSp = new egret.Shape();
        this._bgSp.graphics.beginFill(0);
        this._bgSp.graphics.drawRect(0, 0, Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
        this._bgSp.graphics.endFill();
        this.addChild(this._bgSp);

        this._view = new GameFangDongUI();
        this.addChild(this._view);

        this._bgImageControl = new BgImageControl();
        this._view.boxBg.addChild(this._bgImageControl);

        this._roleImageControl = new RoleImageControl();
        this._roleImageControl.init(this._view.boxRole);
        this._baseY = this._view.boxButton.y;
        this._groupShareX = this._view.groupShare.x;
        this._view.boxButton.x = Config.MAIN_WIDTH - this._view.boxButton.width - 20;

        var guangMask: egret.Sprite = new egret.Sprite();
        guangMask.graphics.clear();
        guangMask.graphics.beginFill(0);
        guangMask.graphics.drawCircle(55, 51, 51);
        guangMask.graphics.endFill();
        this._view.imgGuang.mask = guangMask;
        this._view.groupShare.addChild(guangMask);

        App.global.guide.addDisplayer(this._view.btnMenu, EnumGuideType.OPEN_MENU);
    }

    public dispose(): void {
        super.dispose();
        if (this._view.imgGuang) {
            this._view.imgGuang.mask = null;
        }
        if (this._bgImageControl) {
            this._bgImageControl.dispose()
            this._bgImageControl = null;
        }
        if (this._roleImageControl) {
            this._roleImageControl.dispose()
            this._roleImageControl = null;
        }
        if (this._weChatView) {
            this._weChatView.dispose();
            this._weChatView = null;
        }
        if (this._imgNext) {
            this._imgNext.dispose();
            this._imgNext = null;
        }
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
        if (this._bgSp) {
            this._bgSp.graphics.clear();
            if (this._bgSp.parent)
                this._bgSp.parent.removeChild(this._bgSp);
            this._bgSp = null;
        }
    }

    public show(data?: any): void {
        if (this._data == null) {
            this._data = App.data.gameFangDongCenter;
            this._data.init(Number(data.id), Number(data.hasOwnProperty("dlcID") ? data.dlcID : 0));
        }
        this._saveId = data.saveId;
        this._dispatcher.addEventListener(GameEvent.GAME_INIT, this.onGameInit, this);
        this._dispatcher.addEventListener(GameEvent.GAME_NEXT, this.onGameNext, this);
        this._dispatcher.addEventListener(GameEvent.GAME_RES_LOADED, this.onGameResLoaded, this);
        this._dispatcher.addEventListener(EventType.VIDEO_BACK, this.onVideoBack, this);

        if (this._view == null) {
            this._tempData = data;
        } else {
            this.superShow(data);
        }
        ProtocolFangDong.instance().send_chat_init(this._data.gameId, this._data.dlcID, this._saveId);
    }

    private superShow(data: any): void {
        /**关闭相关面板 */
        PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_SELECT);
        PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_BENAME);

        App.sound.closeBgm(true, true);
        this.initImgNext();
        this.updateImgFlag();

        this._view.btnMenu.alpha = this._view.btnReview.alpha = 0.8;

        this.hideShareGroup(false);

        this._view.visible = false;
        this._view.touchEnabled = true;
        this._mustWait = false;

        this._dispatcher.addEventListener(GameEvent.GAME_BENAME, this.onGameBename, this);
        this._dispatcher.addEventListener(GameEvent.GAME_CONTINE, this.onGameContine, this);
        this._dispatcher.addEventListener(GameEvent.SELECTED_OPTION, this.onSelectedOption, this);

        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onActivate, this, this._view.stage);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchImgNext, this, this._view.boxNext);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this, this._view);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchNext, this, this._view);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnMenu);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnReview);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBtn, this, this._view.btnShare);

        (this._view.btnReview.getChildAt(0) as eui.Image).source = this.getRes(EnumGameRes1.REVIEW_BUTTON);//this._view.btnReview["img_down"].source = this._view.btnReview["img_up"].source = this.getRes(EnumGameRes1.REVIEW_BUTTON);
        (this._view.btnMenu.getChildAt(0) as eui.Image).source = this.getRes(EnumGameRes1.MENU_BUTTON);//this._view.btnMenu["img_down"].source = this._view.btnMenu["img_up"].source = this.getRes(EnumGameRes1.MENU_BUTTON);
        this.setState(EnumGameState.INIT);
        if (!Config.isLocalApp) {
            this._view.boxCoin.show();
            this._view.boxCoin.setAlpha(0.3);
        }
        else {
            this._view.boxCoin.visible = false;
        }

        this._lastType = EnumChatType.CHAT;
        this._isFirst = data.isInGame ? false : true;
        this._view.boxDialog.visible = false;
        this._view.boxName.visible = false;
        this._view.boxButton.visible = false;
        this._view.btnReview.visible = !this._data.isDLC;
        super.show(data);
    }

    public hide(): void {
        super.hide();
        if (this._data) {
            this._data.resetAutoPlay();
            this._data.dispose();
            this._data = null;
        }
        this._mustWait = false;
        if (!Config.isLocalApp)
            this._view.boxCoin.hide();
        App.sound.closeBgm(true, true);
        App.sound.closeVoice();
        App.sound.makeBgmUp();
        if (this._view) {
            this.hideWeChat();
            this._bgImageControl.remove();
            this._roleImageControl.remove();
            this.moveButtonToTop(false);
            if (this._particleEffect) {
                this._particleEffect.dispose();
                this._particleEffect = null;
            }
            this.hideShareGroup(false);
            egret.Tween.removeTweens(this._view.imgGuang.mask);
        }
        if (this._imgNext) {
            this._imgNext.stop();
        }
        App.global.guide.removeExistGuide();
        PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_SELECT);
        PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_BENAME);
        PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_MENU);
        PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_STATUS);
        App.sound.closeVoice();
        App.timer.clearTimer(this, this.onUpdateDialog);
        App.timer.clearTimer(this, this.onStartFastSpeedPlay);
        App.timer.clearTimer(this, this.requestNext);
        App.timer.clearTimer(this, this.onVideoComplete);
        App.timer.clearTimer(this, this.showRoleEffect);
        App.timer.clearTimer(this, this.playSound);
        this._tempData = null;
    }

    /**
     * 视频界面点击返回,返回到女主详情界面
     */
    private onVideoBack(): void {
        GameManager.exitGame();
        PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getHeroniesData(App.data.gameFangDongCenter.gameId));
    }

    private initImgNext(): void {
        if (this._imgNext == null) {
            this._imgNext = new ImgNextEffect();
            this._imgNext.init(EnumGameRes1.IMG_TEX_JSON, EnumGameRes1.IMG_TEX_PNG, EnumGameRes1.IMG_SKE_JSON);
            this._imgNext.horizontalCenter = 0;
            this._imgNext.verticalCenter = 0;
            this._view.boxNext.addChild(this._imgNext);
        }
    }

    /**
     * 点击全屏,激活声音
     */
    private onActivate(e: egret.TouchEvent): void {
        App.data.gameResourceCenter.activateSound();
    }

    /**
     * 初始化完成
     */
    private onGameInit(): void {
        if (this._view == null) {
            if (App.data.gameResourceCenter.hasChapterResource(0) && App.data.gameResourceCenter.hasChapterResource(App.data.gameFangDongCenter.currentChapter)) {
                this.superInit();
                this.superShow(this._tempData);
                this._tempData = null;
            }
            else {
                PanelOpenManager.openPanel(EnumPanelID.LOADING_RESVIEW, {
                    chapter: App.data.gameFangDongCenter.currentChapter,
                    completeEvent: GameEvent.GAME_INIT
                }, false);
            }
            return;
        }
        else {
            if (!App.data.gameResourceCenter.hasChapterResource(App.data.gameFangDongCenter.currentChapter)) {
                PanelOpenManager.openPanel(EnumPanelID.LOADING_RESVIEW, {
                    chapter: App.data.gameFangDongCenter.currentChapter,
                    completeEvent: GameEvent.GAME_INIT
                }, false);
                return;
            }
        }
        if (this._state == EnumGameState.START_VIDEO)
            return;
        GameLog.log('游戏初始化==>id:' + this._data.id);
        this._view.visible = true;
        this.nextReset();
        this.setState(EnumGameState.CAN_DO_NEXT);
        this.moveButtonToTop(true);
        this.showNext();
    }

    /**
     * 跳转下一步
     */
    private onGameNext(): void {
        if (this._data.chatType != EnumChatType.VIDEO && (App.data.gameResourceCenter.hasChapterResource(this._data.nextChapter) == false ||
            (this._data.nextChapter != this._data.currentChapter && App.data.gameResourceCenter.hasChapterResourceByNative(this._data.nextChapter) == false))) {
            if (PanelManager.isShowing(PanelRegister.LOADING_RESVIEW) == false) {//未在加载中时打开加载面板
                PanelOpenManager.openPanel(EnumPanelID.LOADING_RESVIEW, {
                    chapter: this._data.nextChapter,
                    completeEvent: GameEvent.GAME_NEXT
                }, false);
            }
            return;
        }
        // else if(this._data.currentChapter){

        // }
        GameLog.log('下一步==>id:' + this._data.id);
        this.nextReset();
        this.setState(EnumGameState.CAN_DO_NEXT);
        this.showNext();
    }


    private nextReset(): void {
        this.hideShareGroup();
        if (PanelManager.isShowing(PanelRegister.GAME_FANG_DONG_SELECT)) {
            PanelManager.removePanelByName(PanelRegister.GAME_FANG_DONG_SELECT);
        }
    }

    /**
     * 资源加载完成
     */
    private onGameResLoaded(): void {
        //如果视频还在播放中,则不处理,否则
        if (Video.instance().src == null) {
            //如果已经请求到下一步数据,则开始执行
            if (this._data.id != this._lastVideoId) {
                this.onGameNext();
            }
        }
    }

    protected startGame(): void {
        //判断是否已经有了下一步的数据
        if (this._data.currentChapter != 0)
            this.onGameInit();
    }

    /**
     * 播放开始视频
     */
    protected playStartVideo(): void {
        if (Config.skipVideo) {
            this.startGame();
        } else {
            this.setState(EnumGameState.START_VIDEO);
            var videoURL: string = App.data.gameResourceCenter.baseURL + "start.mp4";
            if ((DeviceUtil.IsNative || Config.soEasy) && videoURL.indexOf("//") == 0)
                videoURL = "https:" + videoURL;
            App.timer.doTimeOnce(Video.instance(), 100, Video.instance().init, [
                videoURL, DeviceUtil.isWebIOS ? true : false, false, new FunctionVO(this.onStartVideoComplete, this), Video.TOP, null, Config.isLandscape
            ]);
            // Video.instance().init(videoURL, DeviceUtil.isWebIOS ? true : false, false, new FunctionVO(this.onStartVideoComplete, this), Video.TOP,nul,Config.isLandscape);
        }
    }

    private onStartVideoComplete(): void {
        Video.instance().dispose();
        this.setState(EnumGameState.INIT);
        this.startGame();
    }

    /**
     * 游戏继续
     */
    private onGameContine(): void {
        App.sound.makeBgmUp();
        this.updateImgFlag();
        if (this._state == EnumGameState.CAN_DO_NEXT && this._data.isAutoPlay) {
            this.requestNext();
        }
        else if (this._state == EnumGameState.SELECT &&
            this._data.isPlayingVoice == false &&
            App.timer.hasTimer(this.onUpdateDialog, this) == false) {
            this.showShareGroup();
            PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_SELECT);
            App.global.guide.showView(this._view.btnMenu, EnumGuideType.OPEN_MENU);
        }
        else if (this._state == EnumGameState.BENAME) {
            PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_BENAME);
        }
    }

    private onTouchImgNext(e: egret.TouchEvent): void {
        if (this._touchIgnore == false && this._data.isAutoPlay == false) {
            this._data.resetAutoPlay(true);
            this.updateImgFlag();
            App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
            if (this._state == EnumGameState.CAN_DO_NEXT && this._data.isAutoPlay) {
                this.requestNext();
            }
            e.stopPropagation();
        }
    }

    /**
     * 开始点击
     */
    private onTouchBegin(e: egret.TouchEvent): void {
        if (this._mustWait)
            return;
        this._touchIgnore = false;
        if (this._data.hasRead) {
            App.timer.doTimeOnce(this, 500, this.onStartFastSpeedPlay);
        }
        this.stage.once(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this);
    }

    /**
     * 点击结束
     */
    private onTouchEnd(e: egret.TouchEvent): void {
        this.setFastSpeedPlay(false);
        App.timer.clearTimer(this, this.onStartFastSpeedPlay)
    }

    /**
     * 跳过打字或者跳转下一步
     */
    private onTouchNext(e: egret.TouchEvent): void {
        if (this._view.touchEnabled == false)
            return;
        if (this._touchIgnore)
            return;
        if (this._mustWait)
            return;
        if (this._weChatView && this._weChatView.parent && this._weChatView.canNext == false) {
            return;
        }
        if (this._data.isAutoPlay) {
            this._data.resetAutoPlay();
            App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
        }
        if (this._state == EnumGameState.SELECT || this._state == EnumGameState.INIT || this._state == EnumGameState.BENAME)
            return;
        else if (this._state == EnumGameState.AUTO_TIME || this._state == EnumGameState.CAN_DO_NEXT) {
            App.timer.clearTimer(this, this.showRoleEffect);
            App.timer.clearTimer(this, this.playSound);
            this.requestNext();
            return;
        }
        this.finishShow();
    }

    /**
     * 结束对话
     */
    private finishShow(fastSpeedPlay: boolean = false): void {
        if (this._data.chatType == EnumChatType.WECHAT && this._weChatView && this._weChatView.canNext == false)
            return;
        if (this._state == EnumGameState.BG_EFFECT_PLAYING) {
            this._bgImageControl.stopEffect();
            this._roleImageControl.showRole(true);
            this.finishChat();
        }
        else if (this._state == EnumGameState.ROLE_EFFECT_PLAYING) {
            this._bgImageControl.stopEffect();
            this._roleImageControl.stopEffect();
            this.finishChat();
        }
        else if (this._state == EnumGameState.SOUND_PLAYING) {
            this.setState(EnumGameState.CAN_DO_NEXT);//特殊处理下
            App.sound.stopSound(this._data.bgmInfo.soundEffectURL);
            this.finishChat();
        }
        else if (this._state == EnumGameState.VOICE_TYPING_PLAYING) {
            this.finishChat(false);
        }
        App.timer.clearTimer(this, this.showRoleEffect);
        App.timer.clearTimer(this, this.playSound);
        this.setState(EnumGameState.CAN_DO_NEXT);
        this.updateImgFlag();
        if (fastSpeedPlay)
            this.updateState(0);
        else
            this.doAutoNext();
    }

    private finishChat(needUpdateVisible: boolean = true): void {
        if (needUpdateVisible) {
            //对话框样式
            this._data.windowInfo.transform(this._view.boxDialog, this._view.imgDialogBox, this._view.txtDialog);
            //名字框样式
            this._data.windowInfo.transformName(this._view.boxName, this._view.txtName, this._view.imgName);
            this._view.boxButton.visible = this._view.boxDialog.visible && (this._weChatView == null || this._weChatView.parent == null);
            this.setDialogText(this._data.windowInfo.label);
        }
        else {
            if (App.timer.hasTimer(this.onUpdateDialog, this)) {
                App.timer.clearTimer(this, this.onUpdateDialog);
                this.setDialogText(this._data.windowInfo.label);
            }
            if (this._data.isPlayingVoice) {
                App.sound.closeVoice();
                this._data.isPlayingVoice = false;
            }
        }
        //请求前结束声音
        if (this._data.bgmInfo.soundEffectURL && this._data.bgmInfo.soundEffectType == 1)
            App.data.gameResourceCenter.stopSound(this._data.bgmInfo.soundEffectURL);
        this._data.isPlayingSyncSound = false;
    }

    /**
     * 开始快进播放
     */
    private onStartFastSpeedPlay(): void {
        this._touchIgnore = true;
        this.setFastSpeedPlay(true);
        this.finishShow(true);
    }

    /**
     * 请求下一步
     */
    private requestNext(): void {
        App.timer.clearTimer(this, this.requestNext);
        App.timer.clearTimer(this, this.onVideoComplete);
        /*if (this._data.fastSpeedPlay) {
            GameLog.log(`快进========>请求(${egret.getTimer()}ms)`, GameLog.BLUE);
        }*/
        ProtocolFangDong.instance().send_chat_select(this._data.gameId, this._data.dlcID);
    }

    /**
     * 点击功能按钮
     */
    private onTouchBtn(e: egret.TouchEvent): void {
        // e.stopPropagation();
        if (e.currentTarget == this._view.btnMenu) {
            PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_MENU);
            App.sound.makeBgmDown();
        }
        else if (e.currentTarget == this._view.btnReview) {
            PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_REVIEW);
            App.sound.makeBgmDown();
        }
        else if (e.currentTarget == this._view.btnShare) {
            ProtocolCommon.instance().send_share_link(this._data.gameId, this._data.dlcID, this._data.id, new FunctionVO(this.onCallBack, this));
            return;
        }

        if (this._state == EnumGameState.SELECT) {
            this.nextReset();
        }
        else if (this._state == EnumGameState.BENAME) {
            PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_BENAME);
        }
    }

    private onCallBack(data: any): void {
        if (data.code == "200") {
            PanelOpenManager.openPanel(EnumPanelID.GAME_SHARE2, { url: data.data.collect_image, effect: true });
        }
    }

    /**
     * 取名反馈
     */
    private onGameBename(name: string): void {
        PanelManager.removePanelByName(PanelRegister.GAME_FANG_DONG_BENAME);
        this.setState(EnumGameState.CAN_DO_NEXT);
        this.requestNext();
    }

    /**
     * 解锁成功
     */
    private onUnlockSuccess(gameId: number): void {
        if (gameId == this._data.gameId) {
            this.requestNext();
        }
    }

    private showNext(): void {
        //如果上一个是视频,则释放视频
        if (this._lastType == EnumChatType.VIDEO) {
            Video.instance().dispose();
        }
        else if (this._baseY != this._view.boxButton.y) {
            this._view.boxButton.y = this._baseY;
        }
        switch (this._data.getNewMemory) {
            case 1:
                // Notice.showBottomCenterMessage(`解锁了新的壁纸(${this._data.hasGetMemoryNum}/${this._data.memoryTotal})`, Notice.BOTTOM_COLOR, 0, this._data.chatType != EnumChatType.VIDEO);
                GameLog.log(`解锁了新的壁纸(${this._data.hasGetMemoryNum}/${this._data.memoryTotal})`);
                break;
            case 2:
                // Notice.showBottomCenterMessage(`解锁了新的回忆(${this._data.hasGetMemoryNum}/${this._data.memoryTotal})`, Notice.BOTTOM_COLOR, 0, this._data.chatType != EnumChatType.VIDEO);
                GameLog.log(`解锁了新的回忆(${this._data.hasGetMemoryNum}/${this._data.memoryTotal})`);
                break;
            case 3:
                // Notice.showBottomCenterMessage(`解锁了新的结局(${this._data.hasGetMemoryNum}/${this._data.memoryTotal})`, Notice.BOTTOM_COLOR, 0, this._data.chatType != EnumChatType.VIDEO);
                GameLog.log(`解锁了新的结局(${this._data.hasGetMemoryNum}/${this._data.memoryTotal})`);
                break;
            case 4:
                // Notice.showBottomCenterMessage(`解锁了新的结局(${this._data.hasGetMemoryNum}/${this._data.memoryTotal})`, Notice.BOTTOM_COLOR, 0, this._data.chatType != EnumChatType.VIDEO);
                Notice.showBottomCenterMessage("解锁了额外福利视频 - " + this._data.endTitle, Notice.BOTTOM_COLOR, 0, this._data.chatType != EnumChatType.VIDEO);
                break;
        }
        App.timer.clearTimer(this, this.onUpdateDialog);
        App.timer.clearTimer(this, this.onVideoComplete);
        // PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_UNLOCK, {
        //         id: this._data.gameId,
        //         dlcID: this._data.dlcID,
        //         price: 200,
        //     });
        if (this._data.type == EnumGameStepType.SHOP || this._data.lastType != EnumGameStepType.SHOP && this._data.in_shop_chat) {//弹出购买面板
            PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_BUY, {
                id: this._data.gameId,
                money: this._data.costMoney,
                originalMoney: this._data.originalMoney,
                gift_package: this._data.gift_package,
                endTime: this._data.stop_time,
                in_shop_chat: this._data.in_shop_chat,
                title: App.data.gameHallCenter.getHeroniesData(this._data.gameId).title
            });
            this._dispatcher.addEventListener(GameEvent.GAME_UNLOCK_SUCCESS, this.onUnlockSuccess, this);
            this.setFastSpeedPlay(false);
            this.playBgm();
        }
        else if (this._data.type == EnumGameStepType.SUBSCRIPTION) {
            PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_UNLOCK, this._data.gift_package, false);
        }
        else if (this._data.type == EnumGameStepType.END) {//结局
            GameManager.exitGame();
            PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getHeroniesData(App.data.gameFangDongCenter.gameId));
        }
        else if (this._data.type == EnumGameStepType.CHAT) {//剧情
            this.updateImgFlag();

            this.updateEffect();
            // this._view.boxButton.visible = true;
            if ((this._lastType == EnumChatType.WECHAT || this._lastType == EnumChatType.WECHAT_DIALOG) &&
                (this._data.chatType != EnumChatType.WECHAT && this._data.chatType != EnumChatType.WECHAT_DIALOG)) {
                this.hideWeChat();
            }
            else if (this._lastType == EnumChatType.SHOW_STATUS && PanelManager.isShowing(PanelRegister.GAME_FANG_DONG_STATUS)) {
                PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_STATUS);
            }
            this._lastType = this._data.chatType;
            switch (this._data.chatType) {
                case EnumChatType.CHAT:
                case EnumChatType.OPTION:
                    this.showChat();
                    break;
                case EnumChatType.WECHAT:
                    this.showWeChat(true);
                    break;
                case EnumChatType.WECHAT_DIALOG:
                    this.showWeChat(false);
                    break;
                case EnumChatType.BENAME:
                    this.setFastSpeedPlay(false);
                    this.setState(EnumGameState.BENAME);
                    PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_BENAME);
                    this.showChat();
                    break;
                case EnumChatType.VIDEO:
                case EnumChatType.END_VIDEO:
                    this.showVideo();
                    this._bgImageControl.remove();
                    this._roleImageControl.remove();
                    break;
                case EnumChatType.END_IMAGE:
                    PanelOpenManager.openPanel(EnumPanelID.ENDING);
                    break;
                case EnumChatType.SHOW_STATUS:
                    this.setFastSpeedPlay(false);
                    this.setState(EnumGameState.SHOW_STATUS);
                    PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_STATUS, null, false);
                    break;
            }
        }
    }

    private updateEffect(): void {
        if (this._particleEffect) {
            this._particleEffect.dispose();
            this._particleEffect = null;
        }
        if (this._data.particleEffect) {
            if (this._data.particleEffect.indexOf("_") != -1) {
                var particleData: string[] = this._data.particleEffect.split("_");
                if (particleData) {
                    if (Number(particleData[1]) == 1) {
                        this._particleEffect = new GuideTouchEffect();
                        this._particleEffect.init(Number(particleData[2]), Number(particleData[3]), 60);
                        this._particleEffect.callBack = new FunctionVO(this.requestNext, this);
                        this._view.boxEffect.addChild(this._particleEffect);
                    }
                }
            }
            else {
                this._particleEffect = new ParticleEffect();
                this._particleEffect.init(this._data.particleEffect);
                this._view.addChild(this._particleEffect);
                this._particleEffect.touchEnabled = false;
                this._particleEffect.touchThrough = true;
                this._particleEffect.play();
            }
        }
    }

    /**
     * 显示微信
     */
    private showWeChat(addNewItem: boolean): void {
        if (this._weChatView == null) {
            this._weChatView = new GameFangDongChatView();
        }
        if (this._weChatView.parent == null) {
            this._view.boxWeChat.addChild(this._weChatView);
            this._weChatView.show()
            this._bgImageControl.remove();
        }
        if (addNewItem) {
            this.setFastSpeedPlay(false);
            var data: any = {};
            if (this._data.bgmInfo.voiceURL) {
                data.type = 2;
                data.voiceLength = Number(this._data.windowInfo.label);
                data.voiceURL = this._data.bgmInfo.voiceURL;
            }
            else {
                data.type = 1;
                data.text = this._data.windowInfo.label;
            }
            this._weChatView.addChatItem(data);
            this._view.boxDialog.visible = false;
            this._view.boxName.visible = false;
            this._view.boxButton.visible = false;
            this.showNextImage(false);
        }
        else {
            this._view.touchEnabled = true;
            this._view.boxButton.visible = true;
            this.setState(EnumGameState.BG_EFFECT_PLAYING);
            this.updateTextDialog();
        }
    }

    /**
     * 隐藏微信
     */
    private hideWeChat(): void {
        if (this._view)
            this._view.touchEnabled = true;
        if (this._weChatView && this._weChatView.parent) {
            this._weChatView.hide();
        }
    }

    /**
     * 标识图片类型
     */
    private updateImgFlag(): void {
        if (this._data.fastSpeedPlay) {
            // this._view.imgNext.source = this.getRes(EnumGameRes1.FAST_SPEED_PLAY);
            this.showNextImage(true);
            this._imgNext.play("KJjz", false);
        }
        else if (this._data.isAutoPlay) {
            // this._view.imgNext.source = this.getRes(EnumGameRes1.AUTO_PLAYING);
            this.showNextImage(this._view.boxDialog.visible);
            this._imgNext.play("ZDZ", true);
        }
        else {
            // this._view.imgNext.source = this.getRes(EnumGameRes1.NEXT_WORD);
            this.showNextImage(this._state == EnumGameState.CAN_DO_NEXT && this._view.boxDialog.visible);
            this._imgNext.play("DJJX", true);
        }
    }

    /**
     * 显示视频
     */
    private showVideo(): void {
        this._lastVideoId = this._data.id;
        App.sound.closeBgm(false, false);
        this.setState(EnumGameState.VIDEO_PLAYING);
        Video.instance().init(this._data.videoURL, false, false, new FunctionVO(this.onVideoComplete, this), Video.TOP, null, Config.isLandscape);
        //显示视频播放控件
        PanelOpenManager.openPanel(EnumPanelID.VIDEO_BUTTON, { type: EnumVideoType.AVG_SHIPIN, canSkip: this._data.hasRead });
        this._view.boxDialog.visible = false;
        this._view.boxName.visible = false;
        this._view.boxButton.visible = false;
        this.showNextImage(false);

        if (App.data.gameResourceCenter.hasChapterResource(this._data.nextChapter) == false ||
            (this._data.nextChapter != this._data.currentChapter && App.data.gameResourceCenter.hasChapterResourceByNative(this._data.nextChapter) == false)) {
            PanelOpenManager.openPanel(EnumPanelID.LOADING_RESVIEW, {
                chapter: this._data.nextChapter,
                completeEvent: GameEvent.GAME_RES_LOADED
            }, false);
        }
    }

    /**
     * 视频播放完成/自动跳转
     */
    private onVideoComplete(): void {
        if (this._isPlaying) {
            this.setState(EnumGameState.CAN_DO_NEXT);
            this.requestNext();
            // this._view.boxButton.visible = false;
        }
    }

    /**
     * 显示聊天信息
     */
    private showChat(): void {
        if ((this._data.windowInfo.hasDialog == false || this._data.imageEffectInfo.isSameEffect) && this._view.boxDialog.visible) {
            this._view.boxDialog.visible = false;
            this._view.boxName.visible = false;
            this.showNextImage(false);
        }
        this._view.boxButton.visible = this._view.boxDialog.visible;
        //背景音乐
        this.playBgm();
        //未读则停止快进
        if (!this._data.hasRead)
            this.setFastSpeedPlay(false);
        this.playSound(1);
        //背景图效果
        var costTime: number = this.showBgEffect();
        //弹出选项框
        if (this._data.hasSelectOptions) {
            this.showOption();
            this._roleImageControl.showRole();
            return;
        }
        else {
            if ((this._data.imageEffectInfo.isSameEffect || costTime == 0 || this._data.fastSpeedPlay) && this._mustWait == false) {
                /*if (this._data.fastSpeedPlay)
                    GameLog.log(`快进========>背景(${egret.getTimer()}ms)`, GameLog.BLUE);*/
                this.showRoleEffect(costTime);
            }
            else
                App.timer.doTimeOnce(this, costTime, this.showRoleEffect);
        }
    }

    /**
     * 播放背景音乐
     */
    private playBgm(): void {
        if (this._data.bgmInfo.bgMusicChanged) {
            this._data.bgmInfo.bgMusicChanged = false;
            if (this._data.bgmInfo.bgMusicURL) {
                // GameLog.log('播放背景音乐:', this._data.bgmInfo.bgMusicURL);
                App.data.gameResourceCenter.playBgmSound(this._data.bgmInfo.bgMusicURL);
            }
            else {
                App.sound.closeBgm(true, false);
            }
        }
        //调整背景音乐音量
        if (App.sound.isBgmPlaying && this._data.bgmInfo.bgMusicVolumeChanged) {
            this._data.bgmInfo.bgMusicVolumeChanged = false;
            App.sound.makeBgmDown(this._data.bgmInfo.bgMusicVolume);
        }
    }

    /**
     * 播放背景效果
     * @returns 效果消耗时间
     */
    private showBgEffect(): number {
        var costTime: number;
        if (this._data.imageEffectInfo.bgURL != this._bgImageControl.url)
            var bgURL: string = this._data.imageEffectInfo.bgURL;
        if (this._data.imageEffectInfo.bgEffect && this._data.imageEffectInfo.bgEffect.length > 0) {
            if (this._data.imageEffectInfo.bgEffect[0] && this._data.imageEffectInfo.bgEffect[1]) {
                costTime = this._bgImageControl.changeImage(bgURL, this._data.fastSpeedPlay, false, this._data.imageEffectInfo.bgEffect[1].module,
                    Number(this._data.imageEffectInfo.bgEffect[1].time), this._data.imageEffectInfo.bgEffect[1]);
                this._bgImageControl.addStaticEffect(this._data.imageEffectInfo.bgEffect[0].module, this._data.imageEffectInfo.bgEffect[0]);
                if (this._data.imageEffectInfo.bgEffect[1].module == EnumImageEffect.APART_SHAKE) {
                    this._mustWait = true;
                }
            }
            else {
                var effectData: any = this._data.imageEffectInfo.bgEffect[0] ? this._data.imageEffectInfo.bgEffect[0] : this._data.imageEffectInfo.bgEffect[1];
                costTime = this._bgImageControl.changeImage(bgURL, this._data.fastSpeedPlay, false, effectData.module, Number(effectData.time), effectData);
                if (effectData.module == EnumImageEffect.APART_SHAKE) {
                    this._mustWait = true;
                }
            }
        }
        else {
            costTime = this._bgImageControl.changeImage(bgURL, this._data.fastSpeedPlay, false, EnumImageEffect.FADE_IN_OUT, this._data.imageEffectInfo.bgEffectTime);
        }
        this.setState(EnumGameState.BG_EFFECT_PLAYING);
        return Number(costTime);
    }

    /**
     * 显示选项
     */
    private showOption(): void {
        if (this.isPaused() == false) {
            this.showShareGroup();
            PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_SELECT);
            //引导
            App.global.guide.showView(this._view.btnReview, EnumGuideType.REVIEW);
        }
        //有选项时停止自动播放
        this.setFastSpeedPlay(false);
        this.setState(EnumGameState.SELECT);
        this._view.boxDialog.visible = false;
        this._view.boxName.visible = false;
        this.showNextImage(false);
        if (this._data.options && this._data.options.length > 3) {
            this._view.boxButton.y = this._baseY - (this._data.options.length - 3) * 102 + 40;
        }
        this._view.boxButton.visible = true;
    }

    /**
     * 播放立绘效果
     */
    private showRoleEffect(bgCostTime: number = 0): void {
        this._mustWait = false;
        var costTime: number = this._roleImageControl.showRole(this._data.fastSpeedPlay);
        if (this._data.imageEffectInfo.isSameEffect && bgCostTime > costTime)
            costTime = bgCostTime;
        this.setState(EnumGameState.ROLE_EFFECT_PLAYING);
        if (this._data.fastSpeedPlay) {
            // GameLog.log(`快进========>人物(${egret.getTimer()}ms)`, GameLog.BLUE);
            // GameLog.log(`快进========>音效(${egret.getTimer()}ms)`, GameLog.BLUE);
            this.updateTextDialog();
        } else {
            if (costTime > 0) {
                App.timer.doTimeOnce(this, costTime, this.playSound);
            }
            else {
                this.playSound();
            }
        }
    }

    /**
     * 播放音效
     * @param type 0:正常流程播放 1:跟转同时播放
     */
    private playSound(type: number = 0): void {
        if (this._data.bgmInfo.soundEffectURL && type == this._data.bgmInfo.soundEffectType && this._data.fastSpeedPlay == false) {
            GameLog.log('播放音效:' + this._data.bgmInfo.soundEffectURL);
            if (type == 0) {
                App.data.gameResourceCenter.playSound(this._data.bgmInfo.soundEffectURL, new FunctionVO(this.updateTextDialog, this));
                this.setState(EnumGameState.SOUND_PLAYING);
            }
            else {
                App.data.gameResourceCenter.playSound(this._data.bgmInfo.soundEffectURL, new FunctionVO(this.onPlaySoundComplete, this));
                this._data.isPlayingSyncSound = true;
            }
        }
        else {
            this.updateTextDialog();
        }
    }

    /**
     * 播放同步音效完成
     */
    private onPlaySoundComplete(): void {
        this._data.isPlayingSyncSound = false;
        if (this._state == EnumGameState.CAN_DO_NEXT) {
            this.doAutoNext();
            this.updateState(100);
        }
    }

    /**
     * 语音
     */
    private playVoice(): void {
        if (this._data.fastSpeedPlay == false && this._data.bgmInfo.voiceURL) {
            GameLog.log('播放语音:' + this._data.bgmInfo.voiceURL);
            this._data.isPlayingVoice = App.data.gameResourceCenter.playVoice(this._data.bgmInfo.voiceURL, new FunctionVO(this.onVoiceComplete, this))
            if (this._data.isPlayingVoice)
                this.setState(EnumGameState.VOICE_TYPING_PLAYING);
        }
    }

    private updateTextDialog(): void {
        if (this._state == EnumGameState.CAN_DO_NEXT || this._state == EnumGameState.AUTO_TIME)
            return;
        if (this._data == null)
            return;
        //对话框样式
        this._data.windowInfo.transform(this._view.boxDialog, this._view.imgDialogBox, this._view.txtDialog);
        //名字框样式
        this._data.windowInfo.transformName(this._view.boxName, this._view.txtName, this._view.imgName);
        this._view.boxButton.visible = this._view.boxDialog.visible && (this._weChatView == null || this._weChatView.parent == null);
        //对话框表现
        if (this._view.boxDialog.visible) {
            if (this._data.fastSpeedPlay) {
                // GameLog.log(`快进========>文字(${egret.getTimer()}ms)`, GameLog.BLUE);
                this.setState(EnumGameState.CAN_DO_NEXT);
                this.setDialogText(this._data.windowInfo.label);
                this.showNextImage();
                // this.doAutoNext();
                this.updateState(100);
            }
            else if (this._data.windowInfo.labelSpeed == 0) {
                this.setState(EnumGameState.CAN_DO_NEXT);
                this.setDialogText(this._data.windowInfo.label);
                this.showNextImage();
                this.doAutoNext();
                this.updateState(100);
            }
            else {
                //播放语音
                this.playVoice();
                this._waitNum = 0;
                App.timer.doTimeLoop(this, this._data.typingSpeed, this.onUpdateDialog, [this._data.windowInfo.label, this._data.windowInfo.label.length]);
                this._typingIndex = -1;
                this.setDialogText("");
                this.onUpdateDialog(this._data.windowInfo.label, this._data.windowInfo.label.length);
                this.setState(EnumGameState.VOICE_TYPING_PLAYING);
                this.showNextImage(this._data.isAutoPlay ? true : false);
            }
        }
        else {
            this.setState(EnumGameState.CAN_DO_NEXT);
            this.doAutoNext();
            this.updateState(100);
        }
    }

    /**
     * 执行定时跳转
     */
    private doAutoNext(): void {
        if (this._data.isPlayingSyncSound)
            return;
        if (this._data.survivalTime > 0 && this._data.fastSpeedPlay == false) {
            App.timer.doTimeOnce(this, this._data.survivalTime, this.onVideoComplete);
            this.setState(EnumGameState.AUTO_TIME);
        }
        this.showNextImage();
    }

    private setDialogText(str: string): void {
        this._view.txtDialog.text = str;
    }

    private setFastSpeedPlay(value: boolean): void {
        if (this._data.fastSpeedPlay != value) {
            this._data.fastSpeedPlay = value;
            if (this._data.fastSpeedPlay)
                App.sound.makeBgmDown();
            else
                App.sound.makeBgmUp();
            this.updateImgFlag();
        }
    }

    /**
     * 设置状态
     */
    private setState(state: number): void {
        this._state = state;
    }

    /**
     * 语音播放完成
     */
    private onVoiceComplete(): void {
        if (this._data) {
            this._data.isPlayingVoice = false;
            if (App.timer.hasTimer(this.onUpdateDialog, this) == false) {
                this.setState(EnumGameState.CAN_DO_NEXT);
                this.showNextImage();
                this.doAutoNext();
                this.updateState();
            }
        }
    }

    /**
     * 更新对话文本
     */
    private onUpdateDialog(label: string, len: number): void {
        if (this._waitNum > 0) {
            this._waitNum--;
            return;
        }
        if (this._typingIndex >= len - 1) {
            App.timer.clearTimer(this, this.onUpdateDialog);
            this.setDialogText(label);
            if (this._data && this._data.isPlayingVoice == false) {
                this.setState(EnumGameState.CAN_DO_NEXT);
                this.showNextImage();
                this.doAutoNext();
                this.updateState(this._data.bgmInfo.voiceURL == null && this._data.isAutoPlay ? 1500 : 500);//没有语音且自动播放时,文字结束等待1500毫秒
            }
        }
        else {
            this._typingIndex++;
            // this._view.txtDialog.appendText(label[this._typingIndex]);
            this.setDialogText(label.slice(0, this._typingIndex + 1));
            if (this._typingIndex < len - 1 && EnumTypingSpeed.SYMBOL.indexOf(label[this._typingIndex]) != -1) {
                this._waitNum = Math.ceil(EnumTypingSpeed.SYMBOL_TIME / this._data.typingSpeed);
            }
        }
    }

    private showNextImage(bool: boolean = true): void {
        if (bool) {
            if (this._data.survivalTime == 0 && this._particleEffect == null) {
                this._view.boxNext.visible = true;
                //引导
                if (this._data.isAutoPlay == false && this._data.fastSpeedPlay == false) {
                    App.global.guide.showView(this._view.boxNext, EnumGuideType.START_AUTOPLAY);
                    App.global.guide.showView(this._view.boxNext, EnumGuideType.PRESS_JUMPREAD);
                }
            }
        }
        else {
            this._view.boxNext.visible = false;
        }
    }

    /**
     * 更新AVG状态
     * @param delay 延迟进入下一步的时间
     */
    private updateState(delay: number = 500): void {
        if (this._data.isPlayingSyncSound)
            return;
        //判断可执行下一步
        if (this._state == EnumGameState.CAN_DO_NEXT && (this._data.fastSpeedPlay || this._data.isAutoPlay || this._data.windowInfo.autoChange) && this.isPaused() == false) {
            if (delay <= 0)
                this.requestNext();
            else
                App.timer.doTimeOnce(this, delay, this.requestNext);
        }
    }

    /**
     * 是否暂停(面板弹出,用于关闭自动播放)
     */
    private isPaused(): boolean {
        return PanelManager.showPanelCount > 1 ||
            (PanelManager.showPanelCount == 1 && PanelManager.isShowing(PanelRegister.ALERT) == false && PanelManager.isShowing(PanelRegister.OTHER_STORY) == false);
    }

    /**
     * 把按钮显示在顶层容器
     */
    private moveButtonToTop(isTop: boolean): void {
        if (isTop)
            App.layer.specialMenuLayer.addChild(this._view.boxButton);
        else
            this._view.addChild(this._view.boxButton);
    }

    private onSelectedOption(): void {
        this.hideShareGroup();
        App.global.guide.changeGuideTo_stateN(EnumGuideType.OPEN_MENU2);
        App.global.guide.showView(this._view.btnMenu, EnumGuideType.OPEN_MENU2);
    }

    /**
     * 显示分享按钮
     */
    private showShareGroup(): void {
        this.hideShareGroup();
        if (App.global.canShare)
            App.timer.doTimeOnce(this, 1000, this.playShareEffect);
    }

    /**
     * 播放分享特效
     */
    private playShareEffect(): void {
        this._view.groupShare.visible = true;
        egret.Tween.get(this._view.groupShare).to({ x: this._groupShareX }, 500, egret.Ease.backOut).call(() => {
            //引导
            App.global.guide.showView(this._view.btnShare, EnumGuideType.AVG_HELP);
            egret.Tween.removeTweens(this._view.groupShare);
        }, this);
        this._view.imgGuang.x = -110;
        egret.Tween.get(this._view.imgGuang, { loop: true }).to({ x: 110 }, 800).call(() => { this._view.imgGuang.x = -110 }, this).wait(3000);
    }

    /**
     * 隐藏分享按钮
     */
    private hideShareGroup(showEffect: boolean = true): void {
        if (this._view.groupShare.visible) {
            egret.Tween.removeTweens(this._view.groupShare);
            if (showEffect) {
                this._view.groupShare.alpha = 1;
                egret.Tween.get(this._view.groupShare).to({ alpha: 0 }, 500).call(() => {
                    this._view.groupShare.alpha = 1;
                    this._view.groupShare.visible = false;
                    this._view.groupShare.x = Config.MAIN_WIDTH - this._view.boxButton.x;
                    egret.Tween.removeTweens(this._view.groupShare);
                    egret.Tween.removeTweens(this._view.imgGuang);
                }, this)
            } else {
                this._view.groupShare.visible = false;
                this._view.groupShare.x = Config.MAIN_WIDTH - this._view.boxButton.x;
            }

        }
        App.timer.clearTimer(this, this.playShareEffect);
    }

}