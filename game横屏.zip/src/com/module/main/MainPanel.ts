class MainPanel extends h5_engine.GDisplayObjectContainer
{
    public resize():void
    {
        
    }
}