class BaseEffect extends eui.Group {

    public callBack: FunctionVO;

    public init(...arg): void {

    }

    public play(): void {

    }

    public stop(): void { }

    public dispose(): void {
        this.callBack = null;
    }

    public remove(): void {
        if (this.parent) {
            this.parent.removeChild(this);
        }
    }
}