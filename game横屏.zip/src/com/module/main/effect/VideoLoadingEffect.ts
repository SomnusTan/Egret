class VideoLoadingEffect extends GMovieClip{

    public constructor(){
        super();
        this.init("VideoLoading_json", "VideoLoading_png", "VideoLoading");
    }
}