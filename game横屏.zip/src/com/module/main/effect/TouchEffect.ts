class TouchEffect extends GMovieClip
{

    public constructor()
    {
        super();
        this.init("dianji_mc_json", "dianji_tex_png", "dianjiAnim");
    }

    public playOnce():void
    {
        this.gotoAndPlay(1);
        this.once(egret.Event.COMPLETE, this.onPlayComplete, this);
    }

    private onPlayComplete(e: egret.Event):void
    {
        this.remove();
        this.stop();
        this.dispose();
    }

    public dispose():void
    {
        ObjectPool.getPool(EnumEffectName.TouchEffect).push(this);
    }

}