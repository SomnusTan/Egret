class ImgNextEffect extends eui.Group implements IDispose {

    public isDispose: boolean = false;

    private _dragonbonesFactory: dragonBones.EgretFactory

    private _armature: dragonBones.EgretArmatureDisplay;

    private _action: string;

    private _isLoop: boolean;

    private _interval: number;

    private _isPlaying: boolean;

    public constructor() {
        super();

    }

    public init(tex_json: any, tex_png: any, ske_json: any): void {
        var dragonbonesData = RES.getRes(ske_json);
        var textureData1 = RES.getRes(tex_json);
        var texture1 = RES.getRes(tex_png);
        this._isPlaying = false;
        // 创建龙骨工厂
        this._dragonbonesFactory = new dragonBones.EgretFactory();
        this._dragonbonesFactory.parseDragonBonesData(dragonbonesData);
        this._dragonbonesFactory.parseTextureAtlasData(textureData1, texture1);
        this._armature = this._dragonbonesFactory.buildArmatureDisplay("armatureName");
        this.addChild(this._armature);
    }

    public play(action: string, loop: boolean = true, interval: number = 0): void {
        if (this._armature) {
            if (this._action != action || this._isPlaying == false) {
                this._action = action;
                this._isLoop = loop;
                this._interval = interval;
                this._isPlaying = true;
                if (this._isLoop) {
                    if (this._interval > 0) {
                        this._armature.animation.gotoAndPlayByFrame(action, 1, 1);
                        this._armature.armature.proxy.addDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onPlayComplete, this);
                    }
                    else {
                        this._armature.animation.gotoAndPlayByFrame(action, 1, 0);
                    }
                }
                else {
                    this._armature.animation.gotoAndPlayByFrame(action, 1, 1);
                }
            }
        }
    }

    private onPlayComplete(e: dragonBones.EgretEvent): void {
        if (this._isLoop) {
            if (this._interval == 0)
                this._armature.animation.gotoAndPlayByFrame(this._action, 1, 1);
            else
                App.timer.doTimeOnce(this._armature.animation, this._interval, this._armature.animation.gotoAndPlayByFrame, [this._action, 1, 1]);
        }
        else {
            this._armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onPlayComplete, this);
        }
    }

    public stop() {
        if (this._armature) {
            this._isPlaying = false;
            this._armature.animation.stop();
            this._armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onPlayComplete, this);
            App.timer.clearTimer(this._armature, this._armature.animation.gotoAndPlayByFrame);
        }
    }

    public dispose(): void {
        this._isPlaying = false;
        if (this._dragonbonesFactory) {
            this._dragonbonesFactory.clear(true);
            this._dragonbonesFactory = null;
        }
        if (this._armature) {
            App.timer.clearTimer(this._armature, this._armature.animation.gotoAndPlayByFrame);
            this._armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onPlayComplete, this);
            if (this._armature.parent)
                this._armature.parent.removeChild(this._armature);
            this._armature.animation.stop();
            this._armature.dispose(true);
            this._armature = null;
        }
        this.remove();
        this.isDispose = true;
    }

    public remove(): void {
        if (this.parent)
            this.parent.removeChild(this);
    }

}