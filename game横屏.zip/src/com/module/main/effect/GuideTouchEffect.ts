class GuideTouchEffect extends BaseEffect {

    private _effects: egret.Shape[];

    private _bgMask: egret.Bitmap;

    private _size: number;

    private _x: number;

    private _y: number;

    public constructor() {
        super();
        this._effects = [];
        this.touchEnabled = true;
    }


    /**
     * 显示遮罩背景
     */
    public init(x: number, y: number, size: number = 40, color: number = 0, alpha: number = 0): void {
        this._size = size;
        this._x = x;
        this._y = y;
        if (this._bgMask == null) {
            this._bgMask = new egret.Bitmap();
        }
        this.addChild(this._bgMask);
        this.drawMask(x, y, this._size, color, alpha);
        this.play();
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
    }

    private drawMask(x: number, y: number, size: number, color: number, alpha: number): void {
        if (this._bgMask.texture)
            this._bgMask.texture.dispose();
        var sw: number = Config.MAIN_WIDTH;
        var sh: number = Config.MAIN_HEIGHT;
        var container: egret.Sprite = new egret.Sprite();

        var shape: egret.Shape = new egret.Shape();
        shape.graphics.beginFill(color, alpha);
        shape.graphics.drawRect(0, 0, sw, sh);
        shape.graphics.endFill();
        container.addChild(shape);

        shape = new egret.Shape();
        shape.graphics.beginFill(color, alpha);
        shape.graphics.drawCircle(x, y, size);
        shape.graphics.endFill();
        shape.blendMode = egret.BlendMode.ERASE;
        container.addChild(shape);

        var texture: egret.RenderTexture = new egret.RenderTexture();
        texture.drawToTexture(container);
        this._bgMask.texture = texture;
    }

    private onTouch(e: egret.TouchEvent): void {
        e.stopImmediatePropagation();
        var distance: number = Math.sqrt((e.localX - this._x) * (e.localX - this._x) + (e.localY - this._y) * (e.localY - this._y));
        if (distance <= this._size) {
            if (this.callBack) {
                this.callBack.exec();
            }
            this.dispose();
        }
    }

    public play(): void {
        super.play();
        var item: egret.Shape = this.getShape();
        egret.Tween.get(item).to({ alpha: 0, scaleX: 1, scaleY: 1 }, 1000).call(this.onTweenFinish, this, [item]);
        item = this.getShape();
        egret.Tween.get(item).set({ alpha: 0 }).wait(300).set({ alpha: 1 }).to({ alpha: 0, scaleX: 1, scaleY: 1 }, 1000).call(this.onTweenFinish, this, [item]);
        item = this.getShape();
        egret.Tween.get(item).set({ alpha: 0 }).wait(600).set({ alpha: 1 }).to({ alpha: 0, scaleX: 1, scaleY: 1 }, 1000).call(this.onTweenFinish, this, [item, true]);
    }

    public stop(): void {
        super.stop();
        var shape: egret.DisplayObject;
        while (this.numChildren) {
            shape = this.removeChildAt(0) as egret.DisplayObject;
            if (shape != this._bgMask) {
                egret.Tween.removeTweens(shape);
                this._effects.push(shape as egret.Shape);
            }
        }
        this.remove();
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
    }

    public dispose() {
        var shape: egret.DisplayObject;
        while (this.numChildren) {
            shape = this.removeChildAt(0) as egret.DisplayObject;
            if (shape != this._bgMask) {
                egret.Tween.removeTweens(shape);
            }
            else {
                if (this._bgMask.texture) {
                    this._bgMask.texture.dispose();
                    this._bgMask.texture = null;
                }
            }
        }
        if (this._effects) {
            this._effects.length = 0;
            this._effects = null;
        }
        this._bgMask = null;
        this.remove();
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
        super.dispose();
    }

    private onTweenFinish(item: egret.Shape, autoPlay: boolean = false): void {
        if (item) {
            if (item.parent)
                item.parent.removeChild(item);
            this._effects.push(item);
        }
        if (autoPlay) {
            this.play();
        }
    }

    private getShape(): egret.Shape {
        var shape: egret.Shape;
        if (this._effects.length == 0) {
            shape = new egret.Shape();
            shape.graphics.lineStyle(6, 0xeeeeee, 1, true);
            shape.graphics.drawCircle(0, 0, this._size);
            shape.x = this._x;
            shape.y = this._y;
        }
        else {
            shape = this._effects.shift();
        }
        shape.alpha = 1;
        shape.scaleX = shape.scaleY = 0.05;
        this.addChild(shape);
        return shape;
    }

}