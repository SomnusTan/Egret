class ListenEffect extends h5_engine.GSprite {
    private _diameter: number;
    private _alpha: number;
    private _loopTime: number;
    /**
     * diameter：直径，alpha：透明度，loopTime：扩散时间
     */
    public constructor(diameter?: number, alpha?: number, loopTime?: number) {
        super();
        this._diameter = diameter ? diameter : 386;
        this._alpha = alpha ? alpha : 0.1;
        this._loopTime = loopTime ? loopTime : 950;
        this.touchEnabled = false;
        this.touchChildren = false;
    }

    private createShape(): egret.Shape {
        var shp: egret.Shape = new egret.Shape();
        shp.graphics.clear();
        shp.graphics.beginFill(0xFFFFFF, this._alpha);
        shp.graphics.drawCircle(0, 0, this._diameter * 0.5);
        shp.graphics.endFill();
        return shp;
    }


    public play(): void {
        var img: egret.Shape;
        for (var i: number = 0, len: number = 4, num: number = this.numChildren; i < len; i++) {
            if (i < num) {
                img = this.getChildAt(i) as egret.Shape;
            }
            else {
                img = this.createShape();
                this.addChild(img);
            }
            egret.Tween.removeTweens(img);
            img.alpha = 0;
            img.scaleX = img.scaleY = 0.5
            egret.Tween.get(img).wait(i * this._loopTime).set({ alpha: 0, scaleX: 0.5, scaleY: 0.5 }, img).
                to({ alpha: 1, scaleX: 1.25, scaleY: 1.25 }, this._loopTime).
                to({ alpha: 0, scaleX: 2, scaleY: 2 }, this._loopTime).wait(this._loopTime * 2).call(this.onNext, this, [img]);
        }
    }

    private onNext(img: egret.Shape): void {
        egret.Tween.removeTweens(img);
        egret.Tween.get(img, { loop: true }).set({ alpha: 0, scaleX: 0.5, scaleY: 0.5 }, img).
            to({ alpha: 1, scaleX: 1.25, scaleY: 1.25 }, this._loopTime).
            to({ alpha: 0, scaleX: 2, scaleY: 2 }, this._loopTime).wait(this._loopTime * 2);
    }

    public stop(): void {
        for (var i: number = 0, len: number = this.numChildren; i < len; i++) {
            egret.Tween.removeTweens(this.getChildAt(i));
        }
    }

    public dispose(): void {
        super.dispose();
        var img: egret.Shape;
        for (var i: number = 0, len: number = this.numChildren; i < len; i++) {
            img = this.removeChildAt(0) as egret.Shape;
            egret.Tween.removeTweens(img);
            img = null;
        }
        this.remove();
    }
}