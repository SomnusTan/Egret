class ParticleEffect extends BaseEffect {

    private _particle: particle.GravityParticleSystem;

    private _name: string;

    private _isPlaying: boolean = false;

    public initTexture(texture: any, config: any): void {
        if (this._particle == null) {
            this._particle = new particle.GravityParticleSystem(texture, config);
        }
        this.addChild(this._particle);
        if (this._isPlaying)
            this._particle.start();
    }

    public init(name: string): void {
        this._name = name;
        App.res.createGroup(name, [name + "_json", name + "_png"]);
        App.res.loadGroup([name], new FunctionVO(this.onLoadComplete, this));
    }

    private onLoadComplete(groupName: string): void {
        if (groupName == this._name)
            this.initTexture(RES.getRes(this._name + "_png"), RES.getRes(this._name + "_json"));
    }

    public play(): void {
        if (this._particle) {
            this._particle.start();
        }
        this._isPlaying = true;
    }

    public stop(): void {
        if (this._particle) {
            this._particle.stop();
        }
        this._isPlaying = false;
    }

    public dispose(): void {
        this.stop();
        if (this._particle) {
            this._particle = null;
        }
        this.remove();
    }
}