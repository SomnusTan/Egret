/**
 * 游戏场景基类
 */
class BaseGame extends h5_engine.GDisplayObjectContainer implements IGame {

	/**游戏ID */
	public gameId: number;

	protected _dispatcher: DispatcherRegister;

	protected _orientation: string;

	/**是否第一次打开此游戏 */
	protected _isFirst: boolean = true;
	/**AVG是否正在进行 */
	protected _isPlaying: boolean = false;

	public constructor() {
		super();
		this.init();
	}

	protected init(): void {
		this._dispatcher = new DispatcherRegister();
		// this._dispatcher.addEventListener(egret.Event.RESIZE, this.onStageSize, this, App.stage);
		// this._dispatcher.addEventListener(egret.Event.ACTIVATE, this.onActiveChange, this, App.stage);
		// this._dispatcher.addEventListener(egret.Event.DEACTIVATE, this.onActiveChange, this, App.stage);

	}

	public dispose(): void {
		super.dispose();
		this._dispatcher = null;
		this._isFirst = true;
	}

	public show(data?: any): void {
		if (data)
			this.gameId = data.id;
		if (this._isFirst) {
			this._isFirst = false;
			this.playStartVideo();
		} else {
			this.startGame();
		}
		this._isPlaying = true;

	}

	public hide(): void {
		this._dispatcher.removeAllListeners();
		this._isPlaying = false;
	}

	/**
	 * 开始游戏
	 */
	protected startGame(): void {

	}
	/**
	 * 播放开场视频
	 */
	protected playStartVideo(): void {

	}

	public getView(): h5_engine.GDisplayObjectContainer {
		return this;
	}

	protected getRes(path: string): any {
		return App.data.gameResourceCenter.getRes(path);
	}

	// private onActiveChange(event: egret.Event): void {
	// 	if (event.type == egret.Event.ACTIVATE) {
	// 		GameLog.log("Flash焦点恢复");
	// 		//执行现有的动画进行数据更新的处理
	// 		// Config.isFlashPlayerActive = true;
	// 	} else {
	// 		GameLog.log("Flash焦点失去");
	// 		//要加入所有动画表现停止的逻辑判断
	// 		// Config.isFlashPlayerActive = false;
	// 	}
	// }

}