/**
 * 分享渠道界面
 */
class GameSharePanel extends WindowView {
	private _view: GameShareUI;
	private _data: any;

	public constructor() {
		super(553, 387);
	}

	protected initView(): void {
		this._view = new GameShareUI();
		this._view.y = -15;
		this.viewSp.addChild(this._view);

		this.topTitle = "一键分享";
	}

	protected initSkinType(): void {
		this._skinType = EnumWindowType.TYPE_4;
	}

	public show(data?: any): void {
		super.show(data);
		this._data = data;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareWx);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareWxquan);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareWb);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareQQ);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareQZone);
	}
	/** 分享跳转 */
	private onClick(e: egret.TouchEvent): void {
		var title: string = ""; // 分享的标题
		var titleUrl: string = "";//  标题链接(该参数仅在QQ和QQ空间分享用到)
		var content: string = "";// 分享文本内容
		var imgUrl: string = this._data.imgUrl;// 图片链接地址
		var url: string = "";// 网址链接地址(该参数仅在微信分享网页和视频的时候会用到)
		var site: string = "";// 分享此内容的网站名称(该参数仅在QQ空间分享用到)
		var siteUrl: string = "";// 分享此内容的网站地址(该参数仅在QQ空间分享用到)
		var channelID: number;// 渠道ID 1:微信 2:QQ 3:新浪微博
		var type: number = 2;// 分享类型 1:wx文字分享 2:wx图片分享 3:链接分享
		var scene: number;// 分享场景 1:微信好友 2:微信朋友圈 3:微信收藏  4:QQ 5:QQ空间 6:新浪微博
		switch (e.currentTarget) {
			case this._view.groupShareWx:
				title = "微信标题+内容";
				channelID = 1;
				scene = 1;
				break;
			case this._view.groupShareWxquan:
				title = "朋友圈标题+内容";
				channelID = 1;
				scene = 2;
				break;
			case this._view.groupShareQQ:
				title = "QQ标题+内容";
				channelID = 2;
				scene = 4;
				break;
			case this._view.groupShareQZone:
				title = "QZone标题+内容";
				channelID = 2;
				scene = 5;
				break;
			case this._view.groupShareWb:
				title = "微博标题+内容";
				channelID = 3;
				scene = 6;
				break;
		}
		App.nativeBridge.share(title, titleUrl, content, imgUrl, url, site, siteUrl, channelID, type, scene);
	}

	public dispose(): void {
		super.dispose();
		if (this._view) {
			this._view.dispose();
			this._view = null;
		}
	}
}