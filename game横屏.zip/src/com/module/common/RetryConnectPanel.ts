/**
 * 断网重联面板
 */
class RetryConnectPanel extends WindowView {

    private _view: RetryConnectUI;
    private _data: any;

    public constructor() {
        super(400, 250);

    }

    protected initView(): void {
        super.initView();
        this._view = new RetryConnectUI();
        this.viewSp.addChild(this._view);
        (<eui.Label>this._view.btnRetry.labelDisplay).size = 24
        // GameLog.log(this._view.btnRetry.labelDisplay);

        this.centerTitle = "提示";
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
        this._data = null;
    }

    /**
     * 
     * @param data {url: string, data: any , responseType: string, method: string,headers: string[]}
     */
    public show(data?: any): void {
        super.show(data);
        this._data = data;
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this._view.btnRetry);

        this._view.btnRetry.touchEnabled = true;
        this._view.btnRetry.filters = null;
    }

    public hide(): void {
        super.hide();
        this._data = null;
    }

    private onTouch(e: egret.TouchEvent): void {
        if (this._data) {
            ProtocolCommon.sendBack(this._data.url, JSON.parse(this._data.data), this._data.callBack, this._data.notice,this._data.baseURL,this._data.needAddToken);
            this._view.btnRetry.touchEnabled = false;
            this._view.btnRetry.filters = FilterUtil.FILTER_GRAY;
        }
    }

}