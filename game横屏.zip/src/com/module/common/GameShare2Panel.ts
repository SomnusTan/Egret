class GameShare2Panel extends BasePanel {
	private _view: GameShare2UI;
	private _data: any;

	private _curBmp: egret.Bitmap;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new GameShare2UI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		this._data = data;
		this._view.bg.source = this._data.url;
		this._view.bg.alpha = 0;
		this._view.groupShare.y = this.height;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareWx);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareWxquan);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareWb);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareQQ);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShareQZone);

		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBegin, this, this._view.groupShareWx);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onEnd, this, this._view.groupShareWx);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onEnd, this, this._view.groupShareWx);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBegin, this, this._view.groupShareWxquan);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onEnd, this, this._view.groupShareWxquan);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onEnd, this, this._view.groupShareWxquan);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBegin, this, this._view.groupShareWb);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onEnd, this, this._view.groupShareWb);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onEnd, this, this._view.groupShareWb);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBegin, this, this._view.groupShareQQ);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onEnd, this, this._view.groupShareQQ);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onEnd, this, this._view.groupShareQQ);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBegin, this, this._view.groupShareQZone);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onEnd, this, this._view.groupShareQZone);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onEnd, this, this._view.groupShareQZone);

		if (this._data.effect) {
			this._view.imgWhite.x = 0;
			this._view.imgWhite.y = 0;
			this._view.imgWhite.width = Config.MAIN_WIDTH;
			this._view.imgWhite.height = Config.MAIN_HEIGHT;
			var texture: egret.Texture = BitmapDataUtil.createTextureByClass(GameManager.currentGame.getView(), new egret.Rectangle(0, 0, Config.MAIN_WIDTH, Config.MAIN_HEIGHT));
			if (!this._curBmp) {
				this._curBmp = new egret.Bitmap();
			}
			this._curBmp.alpha = 1;
			this._view.imgWhite.alpha = 1;
			this._curBmp.texture = texture;
			this._curBmp.x = 10;
			this._curBmp.y = 10;
			var scaleX: number = 700 / 720;
			var scaleY: number = 1260 / 1280;
			// GameLog.log("scaleX:" + scaleX + " ,scaleY:" + scaleY);
			// App.nativeBridge.log("scaleX:" + scaleX + " ,scaleY:" + scaleY);
			//设置宽高在手机App上显示有问题，所以用缩放比例
			this._curBmp.scaleX = scaleX;// this._curBmp.width = Config.SCREEN_WIDTH - this._curBmp.x * 2;
			this._curBmp.scaleY = scaleY;// this._curBmp.height = Config.SCREEN_HEIGHT - this._curBmp.y * 2;
			this._view.imgWhite.scaleX = 1;
			this._view.imgWhite.scaleY = 1;

			var props: any = { x: 0, y: Config.SCREEN_HEIGHT, scaleX: 0.01, scaleY: 0.01 };
			egret.Tween.get(this._view.imgWhite).wait(250).call(() => {
				this._view.addChild(this._curBmp);
			}, this).wait(250).to(props, 500);
			egret.Tween.get(this._curBmp).wait(500).to(props, 500).call(this.photoOver, this);
		} else {
			this.photoOver();
		}
	}

	private photoOver(): void {
		if (this._curBmp) {
			this._curBmp.alpha = 0;
			egret.Tween.removeTweens(this._curBmp);
			if (this._curBmp.parent) {
				this._curBmp.parent.removeChild(this._curBmp);
			}
		}
		this._view.imgWhite.alpha = 0;
		egret.Tween.removeTweens(this._view.imgWhite);
		egret.Tween.get(this._view.bg).to({ alpha: 1 }, 300).call(() => {
			egret.Tween.removeTweens(this._view.bg);
		}, this);
		App.timer.doTimeOnce(this, 500, this.onShowShare);
	}

	public hide(): void {
		super.hide();
		if (this._view.bg.source) {
			RES.destroyRes(this._view.bg.source.toString());
			this._view.bg.source = undefined;
		}
		if (this._curBmp) {
			if (this._curBmp.texture) {
				this._curBmp.texture.dispose();
				this._curBmp.texture = undefined;
			}
			egret.Tween.removeTweens(this._curBmp);
		}
		egret.Tween.removeTweens(this._view.imgWhite);
		App.timer.clearTimer(this, this.onShowShare);
		this._data = undefined;
	}
	private onShowShare(): void {
		App.timer.clearTimer(this, this.onShowShare);
		egret.Tween.get(this._view.groupShare).to({ y: this.height - this._view.groupShare.height }, 300).call(this.onCallBack, this);
	}
	private onCallBack(): void {
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closePanel, this, this._view.bg);
	}
	/** 分享跳转 */
	private onClick(e: egret.TouchEvent): void {
		var title: string = ""; // 分享的标题
		var titleUrl: string = "";//  标题链接(该参数仅在QQ和QQ空间分享用到)
		var content: string = "";// 分享文本内容
		var imgUrl: string = this._data.url;// 图片链接地址
		var url: string = "http://xdns.dmgame.com";// 网址链接地址(该参数仅在微信分享网页和视频的时候会用到)
		var site: string = "心动女生";// 分享此内容的网站名称(该参数仅在QQ空间分享用到)
		var siteUrl: string = "http://xdns.dmgame.com";// 分享此内容的网站地址(该参数仅在QQ空间分享用到)
		var channelID: number;// 渠道ID 1:微信 2:QQ 3:新浪微博
		var type: number = 2;// 分享类型 1:wx文字分享 2:wx图片分享 3:链接分享
		var scene: number;// 分享场景 1:微信好友 2:微信朋友圈 3:微信收藏  4:QQ 5:QQ空间 6:新浪微博
		switch (e.currentTarget) {
			case this._view.groupShareWx:
				// title = "微信标题+内容";
				channelID = 1;
				scene = 1;
				break;
			case this._view.groupShareWxquan:
				// title = "朋友圈标题+内容";
				channelID = 1;
				scene = 2;
				break;
			case this._view.groupShareQQ:
				// title = "QQ标题+内容";
				channelID = 2;
				scene = 4;
				break;
			case this._view.groupShareQZone:
				// title = "QZone标题+内容";
				channelID = 2;
				scene = 5;
				break;
			case this._view.groupShareWb:
				// title = "微博标题+内容";
				channelID = 3;
				scene = 6;
				break;
		}
		App.nativeBridge.share(title, titleUrl, content, imgUrl, url, site, siteUrl, channelID, type, scene);
	}

	public dispose(): void {
		super.dispose();
		if (this._curBmp) {
			if (this._curBmp.parent) {
				this._curBmp.parent.removeChild(this._curBmp);
			}
			if (this._curBmp.texture) {
				this._curBmp.texture.dispose();
				this._curBmp.texture = undefined;
			}
			this._curBmp = null;
		}
		if (this._view) {
			this._view.dispose();
			this._view = null;
		}
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}

	private onBegin(e: egret.TouchEvent): void {
		(e.currentTarget as eui.Group).filters = [new egret.GlowFilter(0xF0F0F0, 1, 5, 5, 10, 10, false, false)];
	}
	private onEnd(e: egret.TouchEvent): void {
		(e.currentTarget as eui.Group).filters = null;

	}
}