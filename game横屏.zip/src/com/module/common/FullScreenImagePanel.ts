class FullScreenImagePanel extends BasePanel {
	private _view: eui.Image;

	private _openPanelId: number;
	private _delay: number;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new eui.Image();
		this._view.verticalCenter = 0;
		this._view.horizontalCenter = 0;
		this.addChild(this._view);
	}

	public hide(): void {
		super.hide();
		if (this._view.source) {
			RES.destroyRes(this._view.source.toString());
			this._view.source = undefined;
		}
		App.timer.clearTimer(this, this.openGameShare);
		PanelOpenManager.removePanel(EnumPanelID.GAME_SHARE);
	}

	public show(data?: any): void {
		super.show(data);
		this._openPanelId = 0;
		this._delay = 0;
		this._view.source = data.url;
		//屏蔽
		// this._openPanelId = data.panelId;
		// this._delay = data.delay;
		if (this._openPanelId) {
			if (this._delay) {
				App.timer.doTimeOnce(this, 1000, this.openGameShare);
			} else {
				this.openGameShare();
			}
		} else {
			this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this);
		}
	}

	private openGameShare(): void {
		PanelOpenManager.openPanel(EnumPanelID.GAME_SHARE, { imgUrl: this._view.source });
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this);
	}

	private onClick(e: egret.TouchEvent): void {
		App.sound.playSoundSwitchClient(EnumSoundId.PANEL_CLOSE);
		this.closePanel();
	}

	private onLoadCom(data: egret.Texture): void {
		// GameLog.log("FullScreenImagePanel::onLoadCom() --  " + data);
		this._view.source = data;
	}

	public dispose(): void {
		if (this._view) {
			if (this._view.parent) {
				this._view.parent.removeChild(this._view);
			}
			this._view.texture = undefined;
			this._view = undefined;
		}
		super.dispose();
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}
}