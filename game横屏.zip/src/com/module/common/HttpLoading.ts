/**
 * http请求显示的Loading
 */
class HttpLoading extends eui.Group {

    private _view: h5_engine.GShape;
    /**图片自己旋转 */
    // private _imgLoading: eui.Image;
    // private _imgLoading2: eui.Image;
    /**序列帧 */
    private _loadingEffect: GMovieClip;

    // private BASE_SIZE: number = 56;
    // private TEXT_HEIGHT: number = 16;


    public constructor() {
        super();
        this.init();
    }

    protected init(): void {
        this._view = new h5_engine.GShape();
        this._view.touchEnabled = true;
        this.addChild(this._view);

        // this._imgLoading = new eui.Image();
        // this._imgLoading.source = "imgLoading_png";
        // this._imgLoading.horizontalCenter = 0;
        // this._imgLoading.verticalCenter = 0;
        // this._imgLoading.anchorOffsetX = this.BASE_SIZE;
        // this._imgLoading.anchorOffsetY = this.BASE_SIZE;
        // this.addChild(this._imgLoading);

        // this._imgLoading2 = new eui.Image();
        // this._imgLoading2.source = "imgLoading2_png";
        // this._imgLoading2.verticalCenter = this.BASE_SIZE + this.TEXT_HEIGHT;
        // this._imgLoading2.horizontalCenter = 0;
        // this.addChild(this._imgLoading2);

        this._loadingEffect = new GMovieClip();
        this._loadingEffect.init("loadingEffect_json", "loadingEffect_png", "loadingEffect");
    }

    public show(data?: any): void {
        // this._imgLoading.alpha = 0;
        // this._imgLoading2.alpha = 0;
        App.timer.doTimeOnce(this, 500, this.onShowImage);
        App.stage.addEventListener(egret.Event.RESIZE, this.onResize, this);
        this.onResize();
    }

    public hide(): void {
        App.timer.clearTimer(this, this.onShowImage);
        if (this._loadingEffect) {
            this._loadingEffect.stop();
            if (this._loadingEffect.parent)
                this._loadingEffect.parent.removeChild(this._loadingEffect);
        }
        if (this.parent)
            this.parent.removeChild(this);
        //egret.Tween.removeTweens(this._imgLoading);
        App.stage.removeEventListener(egret.Event.RESIZE, this.onResize, this);
    }

    private onShowImage(): void {
        this._loadingEffect.play(-1);
        this.addChild(this._loadingEffect);
        // this._imgLoading.alpha = 1;
        // this._imgLoading2.alpha = 1;
        // this._imgLoading.rotation = 0;
        // egret.Tween.get(this._imgLoading, { loop: true }).to({ rotation: 360 }, 2000);
    }

    private onResize(e?: egret.Event): void {
        var sw: number = App.layer.rotation == 0 ? Config.SCREEN_WIDTH : Config.SCREEN_HEIGHT;
        var sh: number = App.layer.rotation == 0 ? Config.SCREEN_HEIGHT : Config.SCREEN_WIDTH;
        if (sw != this._view.width || sh != this._view.height) {
            this._view.graphics.clear();
            this._view.graphics.beginFill(0, 0);
            this._view.graphics.drawRect(0, 0, sw, sh);
            this._view.graphics.endFill();
            this._loadingEffect.x = sw >> 1;
            this._loadingEffect.y = sh >> 1;
            this.width = sw;
            this.height = sh;
        }
    }

}