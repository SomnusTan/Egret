class Alert2Panel extends WindowView2 {
	private _view: Alert2UI;
	private _closeHandler: FunctionVO;

	public constructor() {
		super(565, 370);
	}

	protected initView(): void {
		this._view = new Alert2UI();
		this.viewSp.addChild(this._view);
	}
	/** 
	 * {isHtml:"",txt:"",btnLabels:"确 定|取 消",title:"",closeHandler:Function, params:any }
	 */
	public show(data?: any): void {
		super.show(data);
		this._view.txtDesc.textFlow = null;
		this._view.txtDesc.text = "";
		if (data.hasOwnProperty("txt")) {
			if (data.isHtml) {
				this._view.txtDesc.textFlow = HtmlUtil.getHtmlStr(data.txt);
			} else {
				this._view.txtDesc.text = data.txt;
			}
		} else {
			this._view.txtDesc.text = "";
		}
		if (data.hasOwnProperty("btnLabels") && data.btnLabels) {
			var btnLabels: string = data.btnLabels;
			var arr: string[] = btnLabels.split("|");
			if (arr.length > 1) {
				// this._view.btnConfirm.label = arr[0];
				// this._view.btnCancel.label = arr[1];
				this._view.btnCancel.visible = true;
				this._view.btnConfirm.horizontalCenter = 127;
			} else {
				// this._view.btnConfirm.label = arr[0];
				this._view.btnConfirm.horizontalCenter = 0;
				this._view.btnCancel.visible = false;
			}
		} else {
			// this._view.btnConfirm.label = "确 定";
			// this._view.btnCancel.label = "取 消";
		}
		this._view.txtTitle.text = data.title;
		this._closeHandler = data.closeHandler;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClose, this, this._view.btnConfirm);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClose, this, this._view.btnCancel);
	}

	protected onClose(e: egret.TouchEvent): void {
		var type: number;
		switch (e.currentTarget) {
			case this._view.btnConfirm:
				type = Alert.OK;
				break;
			case this._view.btnCancel:
				App.sound.needSkip = true;
				type = Alert.CANCEL;
				break;
		}
		if (this._closeHandler) {
			if (this._closeHandler.param && this._closeHandler.param.length > 0)
				this._closeHandler.param.unshift({ type: type });
			else
				this._closeHandler.param = [{ type: type }];
			this._closeHandler.exec();
		}
		super.onClose(e);
	}

	public hide(): void {
		super.hide();
		this._closeHandler = undefined;
	}

	public dispose(): void {
		super.dispose();
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
	}
}