class GameActivitiesPanel extends WindowView {
    private _view: GameActiviesViewUI;

    public constructor() {
        super(650, 430, true);
    }

    protected initView(): void {
        this._view = new GameActiviesViewUI();
        this.viewSp.addChild(this._view);
        this.topTitle = "活动";
        this._view.width = 582;
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.boxItem
            for (var i: number = 0, len: number = this._view.boxItem.numChildren; i < len; i++) {
                (this._view.boxItem.getChildAt(0) as GameActivityItem).dispose();
            }
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this.updateList();
    }

    private updateList(): void {
        var item: GameActivityItem;
        var list: ActivityVo[] = App.global.activity.activitiesList;
        for (var i: number = 0, len: number = list.length, num: number = this._view.boxItem.numChildren; i < len || i < num; i++) {
            if (i < len) {
                if (i < num) {
                    item = this._view.boxItem.getChildAt(i) as GameActivityItem;
                } else {
                    item = new GameActivityItem();
                    this._view.boxItem.addChild(item);
                }
                item.show(list[i]);
            }
            else {
                item = this._view.boxItem.getChildAt(i) as GameActivityItem;
                item.dispose();
                num--;
                i--;
            }
        }
        if (this._view.boxItem.height <= 489) {//232*2+25
            this._view.height = 489;
        } else if (this._view.boxItem.height >= 771) {//232*3+25*2
            this._view.height = 717;
        }
        else {
            this._view.height = this._view.boxItem.height;
        }
        this.setWH(650, this._view.height + 40, true);
    }

    public hide(): void {
        super.hide();
    }

}
