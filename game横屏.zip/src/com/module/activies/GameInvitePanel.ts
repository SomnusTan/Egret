class GameInvitePanel extends WindowView {
    private _view: GameInviteViewUI;
    private _hasData: boolean;

    public constructor() {
        super(650, 430, true);
    }

    protected initView(): void {
        this._view = new GameInviteViewUI();
        this.viewSp.addChild(this._view);
        this._view.y = -50;
        this.topTitle = "招待萌新";
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClose, this, this._view.btnOK);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBind, this, this._view.btnBind);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCopy, this, this._view.btnCopy);
        InputTextUtil.addNativeInputTextListener(this._view.txtInviteCode);
        this._view.txtMyInviteCode.text = App.global.userInfo.uid.toString();
        this.getNewData();
        this._hasData = false;
    }

    public hide(): void {
        super.hide();
        InputTextUtil.removeNativeInputTextListener(this._view.txtInviteCode);
        this._view.txtInviteCode.text = " ";
    }

    /**
     * 获取新的数据
     */
    private getNewData(): void {
        ProtocolCommon.instance().send_user_invite_info(new FunctionVO(this.getDataBack, this));
    }

    private getDataBack(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            this._view.boxHasBinded.visible = response.data.user_invite;
            this._view.boxInputInvite.visible = !response.data.user_invite;
            this._view.txtInviteCode.text = "";
            this._view.txtPeopleCount.text = response.data.number;
            this._view.txtMyInviteCode.text = response.data.user_id;
            this._view.txtTotalCoin.text = response.data.total;
            this._view.txtCoin0.text = response.data.new_user_invitation;
            this._view.txtCoin1.text = response.data.invite_new_user_rewards;
            this._view.txtCoin2.text = response.data.invite_users_recharge_rewards;
            App.global.userInfo.xdCoin = response.data.balance;
            App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
            this._hasData = true;
        }
    }

    /**
     * 请求绑定
     */
    private onBind(e: egret.TouchEvent): void {
        if (!this._hasData) {
            Notice.showBottomCenterMessage("请在数据返回后再操作");
            return
        }
        if (this._view.txtInviteCode.text == "") {
            Notice.showBottomCenterMessage("请输入正确的招待码");
            return;
        }
        if (this._view.txtInviteCode.text == this._view.txtMyInviteCode.text) {
            Notice.showBottomCenterMessage("请勿输入自己的招待码");
            return;
        }
        ProtocolCommon.instance().send_user_bind_invite(Number(this._view.txtInviteCode.text), new FunctionVO(this.onBindBack, this));
    }

    private onBindBack(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {
            this._view.boxHasBinded.visible = response.data.user_invite;
            this._view.boxInputInvite.visible = !response.data.user_invite;
            this._view.txtTotalCoin.text = response.data.total;
            App.global.userInfo.xdCoin = response.data.balance;
            Notice.showBottomCenterMessage("获得奖励 心动币x" + response.data.new_user_invitation);
            App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
        }
    }

    private onCopy(e: egret.TouchEvent): void {
        HtmlUtil.copy(this._view.txtMyInviteCode.text);
        Notice.showBottomCenterMessage("复制成功!");
    }
}
