class GameGiftKeyPanel extends WindowView {
    private _view: GameGiftKeyViewUI;

    public constructor() {
        super(650, 430, true);
    }

    protected initView(): void {
        this._view = new GameGiftKeyViewUI();
        this.viewSp.addChild(this._view);
        this._view.y = -50;
        this.topTitle = "兑换码";
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        InputTextUtil.addNativeInputTextListener(this._view.txtKey);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onExchange, this, this._view.btnOK);
    }

    public hide(): void {
        super.hide();
        InputTextUtil.removeNativeInputTextListener(this._view.txtKey);
        PanelOpenManager.openPanel(EnumPanelID.GAMEHALL_SETTING);
    }

    private onExchange(e: egret.TouchEvent): void {
        if (this._view.txtKey.text == "") {
            Notice.showBottomCenterMessage("请输入兑换码");
            return;
        }

        
    }

    /**
     * 请求兑换码回调
     */
    private onExchangeBack(response: any): void {
        if (ResponseUtil.checkResponseData(response)) {

        }
    }

}
