class GameActivityItem extends eui.Group {
    private _img: eui.Image;

    private _data: ActivityVo;

    public constructor() {
        super();
        this.init();
    }

    private init(): void {
        this.width = 582;
        this.height = 232;
        this._img = new eui.Image();
        this.addChild(this._img);
    }

    public show(data: ActivityVo): void {
        this._img.scaleX = 1;
        this._img.scaleY = 1;
        this._img.x = 0;
        this._img.y = 0;
        this._data = data;
        this._img.source = "activities_item" + this._data.id;
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
        this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouch, this);
        this.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouch, this);
        if (this._data.type == 0) {
            this.filters = FilterUtil.FILTER_GRAY;
        }
        else {
            this.filters = null;
        }
    }

    private onTouch(e: egret.TouchEvent): void {
        if (e.type == egret.TouchEvent.TOUCH_BEGIN) {
            if (this._data.type == 1) {
                this._img.scaleX = 0.9;
                this._img.scaleY = 0.9;
                this._img.x = this._img.width * 0.1 >> 1;
                this._img.y = this._img.height * 0.1 >> 1;
            }
        }
        else if (e.type == egret.TouchEvent.TOUCH_TAP) {
            this._img.scaleX = 1;
            this._img.scaleY = 1;
            this._img.x = 0;
            this._img.y = 0;
            this.openActivity();
        }
        else if (e.type == egret.TouchEvent.TOUCH_RELEASE_OUTSIDE) {
            this._img.scaleX = 1;
            this._img.scaleY = 1;
            this._img.x = 0;
            this._img.y = 0;
        }
    }

    private openActivity(): void {
        if (this._data.id == Enum.ACTIVITIES.CheckIn) {
            //PanelOpenManager.openPanel(EnumPanelID.GAME_INVITE);
            Notice.showBottomCenterMessage("暂未开启,敬请期待");
        }
        else if (this._data.id == Enum.ACTIVITIES.Invite) {
            PanelOpenManager.openPanel(EnumPanelID.GAME_INVITE);
        }
    }

    public hide(): void {
        this._img.source = null;
        this._data = null;
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
        this.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouch, this);
        this.removeEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouch, this);
    }

    public dispose(): void {
        this.filters = null;
        this.remove();
    }

    public remove(): void {
        this.hide();
        this._img = null;
        if (this.parent)
            this.parent.removeChild(this);
    }
}