class GameCoinComponentUI extends BaseUI {
    public fontCoin: eui.BitmapLabel;
    public btnCoin: eui.Button;

    private _obj: any;
    private _tempAlpha: any;

    public constructor() {
        super("GameCoinSkin");
    }

    public show(): void {
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
        App.dispatcher.addEventListener(EventType.UPDATE_COIN, this.onUpdateCoin, this);
        this.update();
        this.setAlpha(1);
    }

    public hide(): void {
        this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
        App.dispatcher.removeEventListener(EventType.UPDATE_COIN, this.onUpdateCoin, this);
        if (this._obj) {
            this.removeTween(this._obj);
            this._obj = null;
        }
        this.removeTween(this);
        this.fontCoin.text = "0";
        this.width = this.fontCoin.width + this.btnCoin.width + 40;
    }

    public dispose(): void {
        super.dispose();
    }

    private onUpdateCoin(): void {
        this.update();
    }

    private onTouch(e: egret.TouchEvent): void {
        PanelOpenManager.openPanel(EnumPanelID.GAME_CHARGE, { type: 0 });
        this.showFullAlpha();
    }

    private removeTween(target: any): void {
        if (target)
            egret.Tween.removeTweens(target);
    }

    /**
     * 无透明显示动画
     */
    public showFullAlpha(): void {
        if (this._tempAlpha != 1) {
            this.alpha = 1;
            egret.Tween.get(this).wait(4000).to({ alpha: this._tempAlpha }, 500).call(this.removeTween, this, [this]);
        }
    }

    public setAlpha(value: number): void {
        this._tempAlpha = value;
        this.alpha = value;
        this.removeTween(this);
    }

    public update(): void {
        if (!this._obj) {
            this._obj = { coin: App.global.userInfo.xdCoin };
            this.updateText();
        } else {
            this.removeTween(this._obj);
            this._obj.coin = Number(this.fontCoin.text);
            egret.Tween.get(this._obj, { onChange: this.updateText, onChangeObj: this }).to({ coin: App.global.userInfo.xdCoin }, 1000, egret.Ease.quadIn).call(this.removeTween, this, [this._obj]);
            this.showFullAlpha();
        }
    }

    private updateText(): void {
        this.fontCoin.text = Math.floor(this._obj.coin).toString();
        this.width = this.fontCoin.width + this.btnCoin.width + 40;
    }

}