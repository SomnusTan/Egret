/**
 * 充值面板
 */
class GameChargePanel extends WindowView {

    private _view: GameChargeViewUI;

    private _currentItem: GameChargeItem;

    private _tempWin: Window;
    /**吊起类型 */
    private _type: number;
    /**最少充值币数 */
    private _minCoin: number;

    private _successClose: boolean;

    public constructor() {
        super(646, 480, true);
    }

    protected initView(): void {
        super.initView();
        this._view = new GameChargeViewUI();
        this.viewSp.addChild(this._view);
        this._view.x = 60;
        this._view.y = -40;
        this.topTitle = "充值心动币";
        this._view.boxItem.touchChildren = true;
        this._view.boxItem.touchEnabled = false;
    }

    public dispose(): void {
        if (this._view) {
            while (this._view.boxItem.numChildren) {
                (this._view.boxItem.getChildAt(0) as GameChargeItem).dispose();
            }
            this._view.dispose();
            this._view = null;
        }
        super.dispose();
    }

    public show(data?: any): void {
        super.show(data);

        this._type = data.type;
        this._minCoin = data.hasOwnProperty("minCoin") ? data.minCoin - App.global.userInfo.xdCoin : 0;
        this._successClose = data.hasOwnProperty("successClose") ? data.successClose : false;

        var list: ChargeVo[] = App.global.userInfo.chargeList;
        var item: GameChargeItem;
        var hasSelected: boolean = false;
        for (var i: number = 0, len: number = list.length; i < len; i++) {
            item = this.getItemByIndex(i);
            item.show(list[i]);
            if (list[i].num >= this._minCoin) {
                item.filters = null;
                if (hasSelected == false) {
                    hasSelected = true;
                    App.timer.doFrameOnce(this, 1, this.setSelectedItem, [item]);
                }
            }
            else {
                item.filters = FilterUtil.FILTER_GRAY;
            }
        }
        if (hasSelected == false) {
            App.timer.doFrameOnce(this, 1, this.setSelectedItem, [this._view.boxItem.getChildAt(0) as GameChargeItem]);
        }
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBox, this, this._view.boxItem);
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchBuy, this, this._view.btnBuy);
        this._dispatcher.addEventListener(EventType.SHOP_IS_SHOP, this.onCheckShop, this);
        this._dispatcher.addEventListener(EventType.BUY_SUCCESS, this.onPaySuccess, this);
    }

    public hide(): void {
        super.hide();
        this._currentItem = null;
        this._tempWin = null;
        this.clearTimer();
        // if (GameManager.isPlaying && GameManager.lasetGameId != EnumGameID.GAME2) {
        //     App.dispatcher.dispatchEvent(GameEvent.GAME_CONTINE);
        // }
    }

    private onTouchBuy(e: egret.TouchEvent): void {
        if (this._currentItem) {
            var id: number = this._currentItem.data.id;
            var price: number = this._currentItem.data.money;
            var productName: string = this._currentItem.data.name;
            var itemCount: number = this._currentItem.data.num;
            // 查询服务端版本数据
            if (DeviceUtil.IsWeb) {
                if (Config.soEasy || Config.isLocalApp || H5_360_Sdk.getInstance().config360) {
                    ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_COIN, id, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayOtherBack, this, id));
                } else {
                    Alert.choosePay({ price: price, id: id, closeHandler: new FunctionVO(this.onChooseBack, this) });
                }
            }
            else {
                if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
                    App.nativeBridge.sendU8PayNew(EnumPayType.BUY_COIN, {
                        productId: id,
                        buyNum: 1,
                        price: price,
                        productName: productName,
                        productDesc: StringUtil.substitute(EnumAlertContent.BUY_DESC, price, itemCount),
                        ratio: "",
                        serverID: "",
                        serverName: "心动女生"
                    });
                } else if (DeviceUtil.IsIos && DeviceUtil.IsNative) {
                    App.nativeBridge.sendIOSPayNew(EnumPayType.BUY_COIN, id);
                }
            }
        }
    }

    /**
     *  {payType:支付类型 1：微信，2：支付宝}
     */
    private onChooseBack(data: any): void {
        var id: number = data.id;
        if (Config.isRelease) {
            if (data.payType == EnumPayType.PAY_WECHAT && DeviceUtil.isMobile) { //手机端微信支付
                var url: string = WebParams.ip + ProtocolHttpUrl.shop_please_pay + "?channel=wechat&type=" + EnumPayType.BUY_COIN + "&good_id=" + id + "&setting=" + DeviceUtil.currentSetting +
                    "&channel_id=" + App.global.userInfo.channelId + "&Authorization=" + App.global.userInfo.skey + "&AuthorizationID=" + App.global.userInfo.uid;
                this._tempWin = window.open(url, "_blank");
                App.timer.doTimeOnce(this, 3000, this.sendGetEndOrder, [id]);
            } else if (data.payType == EnumPayType.PAY_ALIPAY || (!DeviceUtil.isMobile && data.payType == EnumPayType.PAY_WECHAT)) { //支付宝 || 微信web
                if (data.payType == EnumPayType.PAY_ALIPAY)
                    this._tempWin = WebParams.openWindow(WebParams.defaultURL);
                ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_COIN, id, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayBack1, this, data.payType, id), data.payType);
            }
        } else {
            ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_COIN, id, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayBack, this, id), data.payType);
        }
    }

    private sendGetEndOrder(id: number): void {
        App.timer.clearTimer(this, this.sendGetEndOrder);
        ProtocolCommon.sendBack(ProtocolHttpUrlGame2.shop_end_order, { good_id: id, type: EnumPayType.BUY_COIN }, new FunctionVO(this.checkOrder, this, id), true, ProtocolHttpUrl.ip);
    }

    private checkOrder(data, id: number): void {
        if (data.code == 200) {
            var order_id: string = data.data;
            this.onCheckShop(order_id, id);
        }
    }

    private onCheckShop(order_id: string, id: number): void {
        this.clearTimer();
        ProtocolCommon.sendBack(ProtocolHttpUrl.shop_is_shop, { order_id: order_id }, new FunctionVO(this.onShopBack, this, order_id, id, 10), true, ProtocolHttpUrl.ip);
    }

    /**渠道支付返回 */
    private onHttpShopPayOtherBack(data: any, id: number): void {
        if (data.code == 200) {
            var order_id: string = data.data.order_id;
            if (Config.soEasy) {
                let payinfojson = {
                    check: data.data.code, feeid: data.data.order_id, fee: String(Number(data.data.price) * 100), feename: data.data.productName,
                    extradata: data.data.order_id, serverid: "1", servername: data.data.ServerName
                }
                GameLog.log('------------请求支付房东----------------payinfojson--,', payinfojson);
                ZmSdk.getInstance().pay(payinfojson, function (data) {
                    GameLog.log('------------请求支付房东---------payBack:data,', data);
                    if (data.retcode === "0") {
                        App.dispatcher.dispatchEvent(EventType.SHOP_IS_SHOP, order_id, id);
                    } else if (data.retcode === "1") { //购买失败处理
                    } else if (data.retcode === "2") { //初购取消
                    } else if (data.retcode === "3") { // 跳转到了支付界面或渠道不支持
                    }
                });
            } else if (H5_360_Sdk.getInstance().config360) {
                H5_360_Sdk.getInstance().pay360Param = data.data.code;
                H5_360_Sdk.getInstance().order_id = data.data.order_id;
                H5_360_Sdk.getInstance().paySdk();
                App.dispatcher.dispatchEvent(EventType.SHOP_IS_SHOP, order_id, id);
                GameLog.log("360支付订单号：", order_id);
            }
            else if (Config.isLocalApp) {
                GameLog.log('请求后端调steam支付:' + order_id);
            }
        }
    }

    /** 支付完成返回*/
    private onHttpShopPayBack(data: any, id: number): void {
        if (data.code == 200) {
            var order_id: string = data.data.order_id;
            this.onCheckShop(order_id, id);
        }
    }

    private onPaySuccess(id: number, data?): void {
        this.clearTimer();
        PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
        if (this._type != 1)
            App.global.forceToPhoneBind();
        Notice.showBottomCenterMessage("充值成功");
        App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
        App.dispatcher.dispatchEvent(EventType.CHARGE_SUCCESS);
        if (this._successClose) {
            this.closePanel();
        }
    }

    /** 
	 * 请求跳转支付宝页面，并且循环检测是否支付完成
     * type:支付类型 1：微信，2：支付宝
	 */
    private onHttpShopPayBack1(data: any, type: number, id: number): void {
        if (data.code == 200) {
            if (type == EnumPayType.PAY_WECHAT) {
                data.data.payType = type;
                PanelOpenManager.openPanel(EnumPanelID.WECHAT_QRCODE, data.data);
            } else if (type == EnumPayType.PAY_ALIPAY) {
                ProtocolCommon.instance().send_alipay_switch(data.data.code, this._tempWin);
            }
            var order_id: string = data.data.order_id;
            this.onCheckShop(order_id, id);
        }
    }

    /** 支付完成返回*/
    private onShopBack(data: any, order_id: string, id: number, leftNum: number): void {
        if (data.code == 200) {
            if (data.data.type) {//data.data == true时，成功
                App.global.userInfo.xdCoin = data.data.balance;
                App.global.userInfo.hasFirstCharged = true;
                this.onPaySuccess(id);
            } else {
                App.timer.doTimeOnce(ProtocolCommon.instance(), 3000, ProtocolCommon.instance().send_check_order_status,
                    [{ order_id: order_id },
                    new FunctionVO(this.onShopBack, this, order_id, id, leftNum)]);
            }
        }
    }

    private clearTimer(): void {
        App.timer.clearTimer(ProtocolCommon.instance(), ProtocolCommon.instance().send_check_order_status);
    }

    /**
     * 点击充值项
     */
    private onTouchBox(e: egret.TouchEvent): void {
        var item: GameChargeItem = e.target as GameChargeItem;
        this.setSelectedItem(item);
    }

    private setSelectedItem(item: GameChargeItem): void {
        if (item && item != this._currentItem) {
            this._currentItem = item;
            this._view.imgSelected.x = this._currentItem.x + this._view.boxItem.x;
            this._view.imgSelected.y = this._currentItem.y + this._view.boxItem.y;
        }
    }

    private getItemByIndex(index): GameChargeItem {
        if (this._view.boxItem.numChildren > index) {
            return this._view.boxItem.getChildAt(index) as GameChargeItem;
        }
        else {
            var item: GameChargeItem = new GameChargeItem();
            this._view.boxItem.addChild(item);
            return item;
        }
    }
}
