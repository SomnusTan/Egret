class GameChargeItem extends BaseUI {

    public imgItem: eui.Image;
    public txtItem: eui.Label;
    public txtPrice: eui.Label;

    public data: ChargeVo;

    public constructor() {
        super("GameChargeItemSkin");
    }

    protected createComplete(): void {
        super.createComplete();
        this.touchChildren = false;
        this.touchEnabled = true;
    }

    public show(data: ChargeVo): void {
        this.data = data;
        this.imgItem.source = "charge_item_" + data.index;
        this.txtItem.text = "x" + data.num;
        this.txtPrice.text = "￥ " + data.money;
    }

    public dispose(): void {
        super.dispose();
        this.imgItem.source = null;
        this.data = null;
        this.filters = null;
    }
}