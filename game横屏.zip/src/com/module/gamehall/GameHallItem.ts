class GameHallItem extends BaseUI {
	public imgBg: eui.Image;
	public groupInfo: eui.Group;
	public img_state: eui.Image;
	public txtDesc: eui.Label;
	public txtName: eui.Label;
	public boxNew: eui.Group;
	public group_new: eui.Group;
	public img_new: eui.Image;
	public img_new_mask: eui.Image;
	public img_guang: eui.Image;

	private _dispatcher: DispatcherRegister = new DispatcherRegister();
	public data: HeroinesData;
	private itemIndex: number;
	private _isSingle: boolean;
	private _bubble: GameHallBubble;

	public constructor() {
		super("GameHallItemSkin");
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this);
	}

	private onClick(e: egret.TouchEvent): void {
		App.dispatcher.dispatchEvent(EventType.GAMEHALL_ITEM_CLICK);
		App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
		egret.Tween.removeTweens(this);
		var w: number = Config.isLandscape ? this.itemIndex * (this.width + 5) : 0;
		var h: number = Config.isLandscape ? 0 : this.itemIndex * (this.height + 5);
		egret.Tween.get(this).set({ alpha: 0.8, scaleX: 0.8, scaleY: 0.8, x: w + 60, y: h + 40 }).
			to({ alpha: 1, scaleX: 1, scaleY: 1, x: w, y: h }, 400, egret.Ease.backOut).call(this.onTweenOver, this);
	}

	private onTweenOver(): void {
		egret.Tween.removeTweens(this);
		PanelOpenManager.removePanel(EnumPanelID.GAME_HALL);
		if (this.data.id != EnumGameID.GAME2) {
			if (Config.isLandscape) {
				App.setOrientation(DeviceUtil.IsWeb && DeviceUtil.isMobile ? egret.OrientationMode.PORTRAIT : egret.OrientationMode.AUTO);
			}
			PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, this.data);
		}
		else {
			App.sound.closeBgm(true, true);
			ProtocolCommon.sendBack(ProtocolHttpUrl.char_love_one_click, { channel_id: App.global.userInfo.channelId }, new FunctionVO(this.onClickLoveOneBack, this));
		}
	}

	private onClickLoveOneBack(response: any): void {
		if (ResponseUtil.checkResponseData(response)) {
			if (response.data) {
				this.data.account = response.data;
			}
			if (App.data.gameResourceCenter.hasResource() && ((DeviceUtil.isMobile && DeviceUtil.IsWeb) || DeviceUtil.IsNative)) {
				PanelManager.disposePanelyByGameId(App.data.gameResourceCenter.gameId);
				GameManager.disposeGame(App.data.gameResourceCenter.gameId, App.data.gameResourceCenter.dlcID);
				App.data.gameResourceCenter.dispose();
			}
			GameManager.startGame(this.data.id, EnumGameID.NO_DLC, { id: this.data.id });
		}
	}

	public setData(data: HeroinesData, itemIndex: number, isSingle: boolean = false): void {
		this._isSingle = isSingle;
		this.data = data;
		this.itemIndex = itemIndex;
		this.txtDesc.text = this.data.title;
		this.txtName.text = "";//this.data.name;//策划要求不显示女主名
		this.txtName.x = this.txtDesc.x + this.txtDesc.width + 20;
		if (this._isSingle && Config.isLandscape == false) {
			this.imgBg.source = "gamehall_single_" + data.id + "_png";
			this.groupInfo.bottom = 30;
		} else {
			this.imgBg.source = "gamehall_" + data.id + "_png";
			this.groupInfo.bottom = 43;
		}
		this.img_state.source = data.type == 1 ? "gamehall_json.gamehall_relianzhong" : "gamehall_json.gamehall_dengdai";
		this.boxNew.visible = data.is_new;
		var w: number = Config.isLandscape ? itemIndex * (this.width + 5) : 0;
		var h: number = Config.isLandscape ? 0 : itemIndex * (this.height + 5);
		this.alpha = 0;
		// GameLog.log(itemIndex, this.data);
		if (itemIndex < 4) {
			var time: number = 500;
			if (Config.isLandscape) {
				egret.Tween.get(this).set({ alpha: 0, x: w + 400 }).wait(itemIndex * time * 0.5).to({ alpha: 1, x: w }, time, egret.Ease.sineOut);
			}
			else {
				egret.Tween.get(this).set({ alpha: 0, y: h + 400 }).wait(itemIndex * time * 0.5).to({ alpha: 1, y: h }, time, egret.Ease.sineOut);
			}
		} else {
			this.alpha = 1;
			this.x = w;
			this.y = h;
		}
		if (data.heart_fragment) {
			this.showBubble();
		} else {
			if (this._bubble) {
				this._bubble.dispose();
				this._bubble = null;
			}
		}
		if (data.if_new_plot) {
			this.showNewGroup();
		} else {
			this.hideNewGroup();
		}
	}

	private showNewGroup(): void {
		this.group_new.visible = true;
		this.img_guang.mask = this.img_new_mask;
		this.img_guang.blendMode = egret.BlendMode.ADD;
		egret.Tween.get(this.img_guang, { loop: true }).to({ x: 154, y: 168 }, 800).call(() => {
			this.img_guang.x = -40;
			this.img_guang.y = -35;
		}, this).wait(1000);
	}

	private showBubble(): void {
		if (!this._bubble) {
			this._bubble = new GameHallBubble(this.data);
			this.addChild(this._bubble);
			this._bubble.x = 200;
			this._bubble.y = 255;
		}
	}

	private hideNewGroup(): void {
		this.group_new.visible = false;
		egret.Tween.removeTweens(this.img_guang);
	}

	public get height(): number {
		return this._isSingle && Config.isLandscape == false ? 1096 : 551;
	}

	public get width(): number {
		return 700;
	}

	public dispose(): void {
		super.dispose();
		this.hideNewGroup();
		if (this._bubble) {
			this._bubble.dispose();
			this._bubble = null;
		}
		this._dispatcher.removeAllListeners();
		this._dispatcher = undefined;
	}

}