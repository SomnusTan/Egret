class GameHallSettingPanel extends WindowView {
	private _view: GameHallSettingUI;
	private Music_keyValue_pair: string = null;
	private sound_keyValue_pair: string = null;
	private phone_keyValue_pair: string = null;

	private _openPanelID: number;

	private _count: number = 0;

	public constructor() {
		super(550, 543);
	}

	protected initView(): void {
		this._view = new GameHallSettingUI();
		this.viewSp.addChild(this._view);
		this.rightTitle = "设置";
	}

	public hide(): void {
		super.hide();
		RedDisplay.setRedImage(this._view.signOut.parent);
		if (this._openPanelID > 0) {
			PanelOpenManager.openPanel(this._openPanelID);
			this._openPanelID = 0;
		}
	}

	public show(data?: any): void {
		super.show(data);
		this._view.txtVersion.text = "版本号：" + Config.version;
		this.Music_keyValue_pair = App.global.storage.getItem(EnumStorageType.HALL_MUSIC_SETTING);
		this.sound_keyValue_pair = App.global.storage.getItem(EnumStorageType.HALL_SOUND_SETTING);
		this.phone_keyValue_pair = App.global.storage.getItem(EnumStorageType.PHONE);
		if ((Config.U8Login && App.global.userInfo.channelId != EnumChannel.C_DEFAULT) ||
			Config.soEasy ||
			H5_360_Sdk.getInstance().config360 ||
			Config.isLocalApp) {
			this._view.TouristAccount.visible = false;
			this._view.modifyPhone.visible = false;
			if (App.global.needHideExit == false) {
				this._view.signOut.visible = true;
				this._view.signOut.label = "退出登录";
			}
			else {
				this._view.signOut.visible = false;
				this._view.UserAgreement_btn.horizontalCenter = 0;
			}
		} else {
			this._view.TouristAccount.visible = true;
			this._view.signOut.visible = true;
			this._view.UserAgreement_btn.horizontalCenter = 150;
			/** 手机号码 绑定手机玩家uid*/
			GameLog.log("玩家的手机号码", this.phone_keyValue_pair);
			if (this.phone_keyValue_pair) {
				var phoneValue: string = this.phone_keyValue_pair;
				phoneValue = phoneValue.concat().substr(0, 3) + "*****" + phoneValue.concat().substr(phoneValue.length - 3, phoneValue.length);
				this._view.TouristAccount.text = "手机号:" + phoneValue;
				this._view.modifyPhone.visible = true;
				this._view.signOut.label = "退出登录";
			} else {
				this._view.TouristAccount.text = "游客账号";
				this._view.modifyPhone.visible = false;
				this._view.signOut.label = "绑定手机";
			}
		}


		if (this._view.signOut.label == "绑定手机" && this._view.signOut.visible) {
			RedDisplay.setRedByDisPlayer(this._view.signOut.parent, !this.phone_keyValue_pair ? true : false, 2, this._view.signOut.x + this._view.signOut.width, this._view.signOut.y);
		}
		this._view.UserId.text = String(App.global.userInfo.uid);

		if (!this.Music_keyValue_pair) {
			App.global.storage.setItem(EnumStorageType.HALL_MUSIC_SETTING, "1");
			this.Music_keyValue_pair = "1";
		}
		if (!this.sound_keyValue_pair) {
			App.global.storage.setItem(EnumStorageType.HALL_SOUND_SETTING, "1");
			this.sound_keyValue_pair = "1";
		}
		this._view.Music_btn.selected = this.Music_keyValue_pair == "1";
		this._view.SoundEffect.selected = this.sound_keyValue_pair == "1";

		//兑换码按钮
		this._view.btnGiftKey.visible = App.global.activity.giftKey;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onShowGiftKeyPanel, this, this._view.btnGiftKey);
		/**用户协议 */
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabUserAgreement_btn, this, this._view.UserAgreement_btn);

		//修改手机
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabmodifyPhone, this, this._view.modifyPhone);

		//退出登录
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabsignOut, this, this._view.signOut);

		/**音乐按钮 */
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabMusic_btn, this, this._view.Music_btn);

		/**音效按钮 */
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTabSoundEffect, this, this._view.SoundEffect);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchVersion, this, this._view.rectVersion);
	}

	/**
	 * 打开兑换码面板
	 */
	private onShowGiftKeyPanel(e: egret.TouchEvent): void {
		PanelOpenManager.openPanel(EnumPanelID.GAME_GIFT_KEY);
		this.closePanel();
	}

	/**
	 * 点击版本号变GM
	 */
	private onTouchVersion(e: egret.TouchEvent): void {
		if (Config.skipVideo) {
			Notice.showBottomCenterMessage("你已经是GM了,不需要再点击");
			// Notice.showBottomCenterMessage("You are already a GM,don't touch again");
			return;
		}
		if (this._count >= 10) {
			this._count = 0;
			Config.skipVideo = true;
			App.timer.clearTimer(this, this.resetCount);
			Notice.showBottomCenterMessage("您已经变成GM了");
		}
		else {
			this._count++;
			App.timer.doTimeOnce(this, 1000, this.resetCount);
		}
	}

	private resetCount(): void {
		this._count = 0;
	}

	private onTabMusic_btn(e: egret.TouchEvent) {
		if (this._view.Music_btn.selected) {
			App.sound.isCloseBgm = false;
			App.sound.playBgm(ResPathUtil.getBgmPath(EnumSoundId.BGM));
			App.global.storage.setItem(EnumStorageType.HALL_MUSIC_SETTING, "1");
		} else {
			App.sound.isCloseBgm = true;
			App.global.storage.setItem(EnumStorageType.HALL_MUSIC_SETTING, "0");
		}
	}

	private onTabSoundEffect(e: egret.TouchEvent) {
		if (this._view.SoundEffect.selected) {
			App.sound.isCloseSound = false;
			App.global.storage.setItem(EnumStorageType.HALL_SOUND_SETTING, "1");
		} else {
			App.sound.isCloseSound = true;
			App.global.storage.setItem(EnumStorageType.HALL_SOUND_SETTING, "0");
		}
	}

	private onTabUserAgreement_btn(): void {
		PanelOpenManager.openPanel(EnumPanelID.USER_AGREEMENT);
	}

	/**修改手机 */
	private onTabmodifyPhone(): void {
		App.sound.needSkip = true;
		this.closePanel();
		this._openPanelID = EnumPanelID.UNBIND_PHONE;
	}

	/**退出登录 */
	private onTabsignOut(): void {
		if (this.phone_keyValue_pair) {
			// GameLog.log("退出登录！")
			App.sound.needSkip = true;
			ProtocolCommon.instance().send_login_out(new FunctionVO(this.onLoginOut, this));
		} else if (Config.U8Login) {
			App.nativeBridge.sendLogOut();
		}
		else {
			// GameLog.log("立即绑定！")
			this.closePanel();
			this._openPanelID = EnumPanelID.TOURIST_BIND_PHONE;
		}
	}

	/**
	 * 退出登录反馈
	 */
	private onLoginOut(response: any): void {
		//清楚本地数据
		if (ResponseUtil.checkResponseData(response)) {
			App.global.clearRoleData();
			PanelManager.removePanelByName(PanelRegister.GAME_HALL);
			this.closePanel();
			this._openPanelID = EnumPanelID.LOGIN;
		}
	}

	public dispose(): void {
		super.dispose();
		if (this._view) {
			this._view.dispose();
			this._view = null;
		}
	}

}