class GameHallBubble extends egret.Sprite {
	// 初始动画
	private _dragonbonesFactory: dragonBones.EgretFactory;
	// 定义爆破骨骼动画
	private _bubbleEffect: dragonBones.EgretArmatureDisplay;
	private num: number;

	private _icon: eui.Image;//碎片
	private _txt: eui.Label;//x 数量
	private _uid: number;

	public constructor(data: HeroinesData) {
		super();
		this.num = data.heart_fragment;//
		this._uid = data.id;
		var dragonbonesData = RES.getRes("suipian_ske_json");
		if (!dragonbonesData) {
			App.res.loadGroup([EnumResGroupName.SUIPIAN], new FunctionVO(this.onLoadComplete, this));
		} else {
			this.onLoadComplete();
		}
	}

	private onLoadComplete(): void {
		this.touchEnabled = true;
		this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
		this._dragonbonesFactory = new dragonBones.EgretFactory();
		// 加载龙骨动画资源
		var dragonbonesData = RES.getRes("suipian_ske_json");
		var textureData1 = RES.getRes("suipian_tex_json");
		var texture1 = RES.getRes("suipian_tex_png");
		//往龙骨工厂里添加资源
		this._dragonbonesFactory.parseDragonBonesData(dragonbonesData);
		this._dragonbonesFactory.parseTextureAtlasData(textureData1, texture1);
		// 构建男孩骨架显示对象
		this._bubbleEffect = this._dragonbonesFactory.buildArmatureDisplay("Armature");
		this.addChild(this._bubbleEffect);
		this._bubbleEffect.animation.play("suipian");

		this._txt = new eui.Label("x " + this.num);
		this._txt.italic = true;
		this._txt.size = 25;
		this._txt.textColor = 0xFFFFFF;
		this._txt.strokeColor = 0xFD44D0;
		this._txt.stroke = 2;
		this._txt.x = 50;
		this._txt.y = 70;
		this.addChild(this._txt);
		App.timer.doTimeLoop(this, 300, this.move);
	}

	private move(): void {
		var moveX: number = (Math.random() * 4 - 2) * 10;
		var moveY: number = (Math.random() * 2 - 1) * 10;
		var tx: number = this.x + moveX;
		var ty: number = this.y + moveY;
		if (tx <= 0) tx = -tx;
		if (tx >= 185 && ty <= 250) tx = 175;
		if (tx >= 185 && tx <= 410 && ty <= 250) tx = 420;
		if (tx >= 650) tx = 650;
		if (ty <= 0) ty = -ty;
		if (tx >= 185 && tx <= 410 && ty <= 250) ty = 260;
		if (ty >= 350) ty = 350;
		egret.Tween.get(this).to({ x: tx, y: ty }, 300);
	}

	private onClick(e: egret.TouchEvent): void {
		e.stopPropagation();
		App.timer.clearTimer(this, this.move);
		if (this._bubbleEffect) {
			this._bubbleEffect.animation.stop();
			if (this._bubbleEffect.parent)
				this._bubbleEffect.parent.removeChild(this._bubbleEffect);
			this._bubbleEffect.dispose();
			this._bubbleEffect = null;
		}
		if (this._dragonbonesFactory) {
			this._dragonbonesFactory.clear(true);
			this._dragonbonesFactory = null;
		}
		this._icon = new eui.Image();
		this._icon.source = "gamehall_json.gamehall_suipian";
		this._icon.anchorOffsetX = this._icon.anchorOffsetY = 33;
		App.layer.commonLayer.addChild(this._icon);

		var startP: egret.Point = this.localToGlobal();
		let sx: number = startP.x;
		let sy: number = startP.y;
		this._icon.x = sx + this._icon.anchorOffsetX;
		this._icon.y = sy + this._icon.anchorOffsetY;
		this._txt.x = sx + 40;
		this._txt.y = sy + 60;
		App.layer.commonLayer.addChild(this._txt);
		App.data.gameHallCenter.playBrokenEffect(this.localToGlobal(), new FunctionVO(this.playFlyEffect, this));
		App.sound.playSoundSwitchClient(EnumSoundId.BAOZHA);
		ProtocolCommon.instance().send_heroine_heart_fragment_convert(this._uid);
	}

	private playFlyEffect(): void {
		var target: GameHallItem = App.data.gameHallCenter.getZhaoXYItem();
		if (!target) return;
		this.flySuiPian(target.localToGlobal(target.width * 0.5, target.height * 0.5));
	}

	private flySuiPian(endP: egret.Point): void {
		var startP: egret.Point = this.localToGlobal();
		let sx: number = startP.x;
		let sy: number = startP.y;
		let tx: number = endP.x;
		let ty: number = endP.y;
		egret.Tween.get(this._icon).set({ x: sx + this._icon.anchorOffsetX, y: sy + this._icon.anchorOffsetY }).to({ x: tx, y: ty }, 1000, egret.Ease.sineOut);
		egret.Tween.get(this._txt).set({ x: sx + 30, y: sy + 40 }).to({ x: tx, y: ty }, 1000, egret.Ease.sineOut).call(this.onTweenOver, this);
	}

	private onTweenOver() {
		if (this._icon) {
			egret.Tween.removeTweens(this._icon);
			this._icon.source = null;
			if (this._icon.parent) {
				this._icon.parent.removeChild(this._icon);
			}
			this._icon = null;
		}
		if (this._txt) {
			egret.Tween.removeTweens(this._txt);
			this._txt.text = "";
			if (this._txt.parent) {
				this._txt.parent.removeChild(this._txt);
			}
			this._txt = null;
		}
	}

	public dispose(): void {
		if (this._icon) {
			this.onTweenOver();
		}
		this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
		if (this._bubbleEffect) {
			this._bubbleEffect.animation.stop();
			if (this._bubbleEffect.parent)
				this._bubbleEffect.parent.removeChild(this._bubbleEffect);
			this._bubbleEffect.dispose();
			this._bubbleEffect = null;
		}
		if (this._dragonbonesFactory) {
			this._dragonbonesFactory.clear(true);
			this._dragonbonesFactory = null;
		}
		App.timer.clearTimer(this, this.move);
		if (this.parent) {
			this.parent.removeChild(this);
		}
	}

}