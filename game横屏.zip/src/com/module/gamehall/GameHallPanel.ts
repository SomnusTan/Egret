class GameHallPanel extends BasePanel {
	private _view: GameHallUI;
	private _scrollPanel: eui.Scroller;
	private _heroinesPanel: LayoutContainer;
	/**单个女主的时候用大图背景 */
	private _heroniesSingleItem: GameHallItem;

	public constructor() {
		super();
	}

	protected init(): void {
		super.init();
		this._view = new GameHallUI();
		if (Config.isLandscape) {
			this._view.height = Config.MAIN_WIDTH;
			this._view.width = Config.MAIN_HEIGHT;
			this._view.imgBg.source = "skyblue_bg1_jpg";
		}
		else {
			this._view.imgBg.source = "skyblue_bg_jpg";
		}
		this.addChild(this._view);
		var w: number = Config.isLandscape ? 1240 : 700;
		this._heroinesPanel = new LayoutContainer(GameHallItem, w, 545, Config.isLandscape ? 20 : 1, new FunctionVO(this.itemUpdate, this));
		this._scrollPanel = new eui.Scroller();
		this._scrollPanel.skinName = "skins.ScrollerSkin"
		this._scrollPanel.x = this.width - w >> 1;
		this._scrollPanel.y = 156;
		this._scrollPanel.width = w;
		this._scrollPanel.height = Config.SCREEN_HEIGHT - this._scrollPanel.y;
		this._view.addChild(this._scrollPanel);

		if (Config.isEnterGame == false) {
			App.global.guide.initState();
			App.global.initAvgAutoPay();
		}
	}

	private itemUpdate(item: GameHallItem, data: HeroinesData, i: number): void {
		item.setData(data, i);
	}

	private onClickItem(): void {
		this.touchEnabled = false;
		this.touchChildren = false;
	}

    /**
     * 显示面板
     */
	public show(data?: any): void {
		super.show(data);
		this.touchEnabled = true;
		this.touchChildren = true;
		Config.hasEnterGame = true;
		// App.setOrientation(egret.OrientationMode.AUTO);
		var isPlay: string = App.global.storage.getItem(EnumStorageType.HALL_MUSIC_SETTING);
		if (isPlay == "0") {
			App.sound.isCloseBgm = true;
		} else {
			App.sound.isCloseBgm = false;
			App.sound.playBgm(ResPathUtil.getBgmPath(EnumSoundId.BGM), 2000, false, true);
		}
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onImgShezhi, this, this._view.img_shezhi);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onShowActivies, this, this._view.btnActivies);
		this._view.boxCoin.show();
		this._dispatcher.addEventListener(EventType.BIND_PHONE_SUCCESS, this.onBindSuccess, this);
		this._dispatcher.addEventListener(EventType.GAMEHALL_ITEM_CLICK, this.onClickItem, this);
		// 请求POST
		ProtocolCommon.instance().send_heroineslist_single(new FunctionVO(this.onListBack, this));

		this._view.btnActivies.visible = App.global.canShare;

		var phone: string = App.global.storage.getItem(EnumStorageType.PHONE);
		if (!Config.U8Login && !Config.soEasy && !H5_360_Sdk.getInstance().config360) {
			RedDisplay.setRedByDisPlayer(this._view.img_shezhi.parent, !phone ? true : false, 2, this._view.img_shezhi.x + 30, this._view.img_shezhi.y - 30);
		}
	}

	private onShowActivies(e: egret.TouchEvent): void {
		PanelOpenManager.openPanel(EnumPanelID.GAME_ACTIVITIES);
	}

	/**
	 * 游客绑定手机成功后去掉红点
	 */
	private onBindSuccess(): void {
		RedDisplay.setRedImage(this._view.img_shezhi.parent);
	}

	private onImgShezhi(e: egret.TouchEvent): void {
		egret.Tween.pauseTweens(this._view.img_shezhi);
		this._view.img_shezhi.rotation = 19;
		egret.Tween.get(this._view.img_shezhi).to({ rotation: 619 }, 1000, egret.Ease.sineOut);
		PanelOpenManager.openPanel(EnumPanelID.GAMEHALL_SETTING);
	}

	private onListBack(response: any): void {
		let list: Array<any> = response.data;
		if (list.length == 1) {
			this._heroinesPanel.dataProvider = undefined;
			if (!this._heroniesSingleItem) {
				this._heroniesSingleItem = new GameHallItem();
				this._scrollPanel.addChild(this._heroniesSingleItem);
			}
			let hd: HeroinesData = App.data.gameHallCenter.getFirstHeroniesData();
			this._heroniesSingleItem.setData(hd, 0, true);
		} else {
			if (this._heroniesSingleItem) {
				this._heroniesSingleItem.dispose();
				this._heroniesSingleItem = undefined;
			}
			this._heroinesPanel.dataProvider = App.data.gameHallCenter.heroinesDataList.values;
			this._scrollPanel.viewport = this._heroinesPanel;
			if (this._scrollPanel.viewport) {
				this._scrollPanel.viewport.scrollV = 0;//每次都是显示第一个
			}
			App.data.gameHallCenter.gameHallItems = this._heroinesPanel.dataGroup;
			ScrollerCenter.hideVerticalScrollBar(this._scrollPanel);
		}
		if (!App.global.userInfo.hasShowNotice) {
			ProtocolCommon.instance().send_game_notice(0, new FunctionVO(this.onGetNoticeBack, this));
		} else {
			this.getCoinData();
		}
	}

	private onGetNoticeBack(response: any): void {
		if (ResponseUtil.checkResponseData(response) && response.data.length) {
			App.global.userInfo.hasShowNotice = true;
			if (response.data[0].type == 1)
				PanelOpenManager.openPanel(EnumPanelID.GAME_NOTICE, { notice: response.data[0].depict }, false);
			else if (response.data[0].type == 2)
				PanelOpenManager.openPanel(EnumPanelID.GAME_IMAGE_NOTICE, { title: response.data[0].title, notice: response.data[0].depict }, false);
		}
		this.getCoinData();
	}

	/**
	 * 获取充值活动数据
	 */
	private getCoinData(): void {
		ProtocolCommon.instance().send_user_currency_info(new FunctionVO(this.getCoinDataBack, this));
	}

	private getCoinDataBack(response: any): void {
		if (ResponseUtil.checkResponseData(response)) {
			App.global.userInfo.xdCoin = response.data.balance;
			App.global.userInfo.hasFirstCharged = response.data.is_shop;
			if (App.global.userInfo.chargeList == null) {
				App.global.userInfo.chargeList = [];
				if (response.data.list) {
					response.data.list.sort((a, b): number => {
						if (a.index > b.index) return 1;
						else return -1;
					});
					for (var i: number = 0, len: number = response.data.list.length; i < len; i++) {
						App.global.userInfo.chargeList.push(new ChargeVo(response.data.list[i]));
					}
				}
			}
			this._view.boxCoin.update();
			if (App.global.activity.activitiesList == null) {//不重新创建,更好的方法是对象池更新
				App.global.activity.initActivities(response.data.activity);
			}
			App.global.activity.giftKey = response.data.redemption;
			App.global.forceToPhoneBind();
		}
	}

    /**
     * 隐藏面板
     */
	public hide(): void {
		super.hide();
		this._scrollPanel.removeChildren();
		this._heroinesPanel.clear();
		this._view.boxCoin.hide();
		if (this._heroniesSingleItem) {
			this._heroniesSingleItem.dispose();
			this._heroniesSingleItem = undefined;
		}
		App.data.gameHallCenter.gameHallItems = null;
		RedDisplay.setRedImage(this._view.img_shezhi.parent);
	}

    /**
     * 释放
     */
	public dispose(): void {
		super.dispose();
		if (this._view) {
			this._view.dispose();
			this._view = null;
		}
		this._scrollPanel = undefined;
		this._heroinesPanel = undefined;
	}

	public get width(): number {
		return Config.isLandscape ? Config.MAIN_HEIGHT : Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.isLandscape ? Config.MAIN_WIDTH : Config.MAIN_HEIGHT;
	}

	/**
     * 是否需要发送数据
     */
	public get needSendUMeng(): boolean {
		return true;
	}

}