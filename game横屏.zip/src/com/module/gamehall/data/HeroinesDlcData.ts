class HeroinesDlcData {
    /**dlc的ID */
    public dlcId: number;
    /**女主ID */
    public heroinesId: number;
    /**标题 */
    public title: string;
    /**描述 */
    public depict: string;
    /**是否通关过 */
    // public hasEnding: boolean;

    public parse(heroinesId: number, data: any): void {
        this.heroinesId = heroinesId;
        this.dlcId = data.id
        this.title = data.title;
        this.depict = data.depict;
        // this.hasEnding = data.hasOwnProperty("isEnding") ? data.isEnding == 1 : false;
    }

}