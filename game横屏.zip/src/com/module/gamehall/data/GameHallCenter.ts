class GameHallCenter {
	public constructor() {
	}
	/** 女主数据列表 */
	public heroinesDataList: HashMap = new HashMap();

	/** 更新女主数据 */
	public updateHeroniesProps(id: number, props: any): void {
		var data: HeroinesData = this.getHeroniesData(id);
		for (var key in props) {
			data[key] = props[key];
		}
		this.setHeroniesData(data);
	}

	/** 存储女主数据 */
	public setHeroniesData(data: HeroinesData): void {
		this.heroinesDataList.put(data.id, data);
	}
	/** 根据女主id获得女主数据 */
	public getHeroniesData(id: number): HeroinesData {
		return this.heroinesDataList.get(id);
	}

	/**
	 * 获取第一个女主
	 */
	public getFirstHeroniesData(): HeroinesData {
		return this.heroinesDataList.getByIndex(0);
	}

	/**
	 * 碎片爆破特效
	 */
	public playBrokenEffect(pos: egret.Point, backFunc: FunctionVO): void {
		this._brokenOverFunc = backFunc;
		if (!this._dragonbonesFactory) {
			this._dragonbonesFactory = new dragonBones.EgretFactory();
			// 加载龙骨动画资源
			var dragonbonesData = RES.getRes("suipian_ske_json");
			var textureData1 = RES.getRes("suipian_tex_json");
			var texture1 = RES.getRes("suipian_tex_png");
			//往龙骨工厂里添加资源
			this._dragonbonesFactory.parseDragonBonesData(dragonbonesData);
			this._dragonbonesFactory.parseTextureAtlasData(textureData1, texture1);
			// 构建男孩骨架显示对象
			this._brokenEffect = this._dragonbonesFactory.buildArmatureDisplay("Armature");
		}
		this._brokenEffect.x = pos.x;
		this._brokenEffect.y = pos.y;
		App.layer.effectLayer.addChild(this._brokenEffect);
		this._brokenEffect.armature.proxy.addDBEventListener(dragonBones.EgretEvent.COMPLETE, this.loop_com, this);
		this._brokenEffect.animation.play("baozha", 1);
	}

	private loop_com(e: dragonBones.AnimationEvent): void {
		this._brokenEffect.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.loop_com, this);
		if (this._brokenEffect && this._brokenEffect.parent) {
			this._brokenEffect.parent.removeChild(this._brokenEffect);
			if (this._brokenOverFunc) {
				this._brokenOverFunc.exec();
			}
			// App.dispatcher.dispatchEvent(EventType.GAMEHALL_BROKEN_OVER, new egret.Point(this._brokenEffect.x, this._brokenEffect.y), this._suipianNum);
		}
	}
	private _brokenOverFunc: FunctionVO;
	// 初始动画
	private _dragonbonesFactory: dragonBones.EgretFactory;
	// 定义爆破骨骼动画
	private _brokenEffect: dragonBones.EgretArmatureDisplay;
	public gameHallItems: GameHallItem[];

	public getZhaoXYItem(): GameHallItem {
		var items: GameHallItem[] = App.data.gameHallCenter.gameHallItems;
		for (var i: number = 0; i < items.length; i++) {
			if (items[i].data.id == EnumGameID.GAME2) {
				return items[i];
			}
		}
		return null;
	}
}