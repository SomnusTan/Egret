/**
 * 女主信息数据
 */
class HeroinesData {
	public constructor() {
	}
	/**女主状态0:等待邂逅，1：热恋中 */
	public type: number;
	/**女主标题,可用来传送SDKserverName */
	public title: string;
	/**女主名 */
	public name: string;
	/**女主描述 */
	public depict: string;
	/**女主标签 */
	public labels: string[];
	/**女主id */
	public id: number;
	/**dlc列表 */
	public dlcList: HeroinesDlcData[];
	/**需要播放的视频路径 */
	public videoUrl: string;
	/**关卡金额 */
	public money: number;
	/**当前关卡是否需要收费 */
	public is_toll: boolean;
	/**是否已经购买 */
	public is_shop: boolean;
	/** 记录状态 0:没有记录, 1:有记录, 2:已完结 */
	public record_type: number;
	/** 是否有新的收藏 */
	public is_new_collect: boolean;
	/** 超值组合礼包 */
	public gift_package: any;
	/**女主版本 */
	public version: string;
	/**获得碎片数量 */
	public heart_fragment: number;
	/**最新剧情 */
	public if_new_plot: number;
	/**是否有新内容 */
	public is_new: boolean;
	/**用户名 (限赵小野使用)*/
	public account: string;
	/**结局类型*/
	public getNewMemory: number;
}