class ChoosePayPanel extends BasePanel {
	private _view: ChoosePayUI;
	private _data: any;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new ChoosePayUI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		// { price: price, closeHandler: closeHandler }
		this._data = data;
		this._view.txt_money.text = data.price;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_wx);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_zfb);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_close);
	}
	// type:支付类型 1：微信，2：支付宝
	private onClick(e: egret.TouchEvent): void {
		switch (e.currentTarget) {
			case this._view.btn_wx:
				this._data.payType = EnumPayType.PAY_WECHAT;
				this._data.closeHandler.exec(this._data);
				break;
			case this._view.btn_zfb:
				this._data.payType = EnumPayType.PAY_ALIPAY;
				this._data.closeHandler.exec(this._data);
				break;
			case this._view.btn_close:
				break;
		}
		this.closePanel();
	}

	public hide(): void {
		super.hide();
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	public get width(): number {
		return 658;
	}

	public get height(): number {
		return 480;
	}

}