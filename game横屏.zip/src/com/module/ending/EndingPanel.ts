class EndingPanel extends BasePanel {
	private _view: EndingViewUI;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new EndingViewUI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupHome);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupMore);
		this._view.groupEndWord.alpha = 0;
		this._view.groupBtns.alpha = 0;

		if (App.data.gameFangDongCenter.isDLC) {//不显示读档按钮
			this._view.groupMore.parent && this._view.groupMore.parent.removeChild(this._view.groupMore);
		} else {
			this._view.groupBtns.addChildAt(this._view.groupMore, 1);
		}
		if (App.global.canShare) {
			this._view.groupBtns.addChildAt(this._view.groupShare, 2);
			this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.groupShare);
		} else {
			this._view.groupShare.parent && this._view.groupShare.parent.removeChild(this._view.groupShare);
		}

		this.showEnding();
	}

	public hide(): void {
		super.hide();
		App.timer.clearTimer(this, this.showEndWord);
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	private showEnding(): void {
		var data: GameFangDongCenter = App.data.gameFangDongCenter;
		this._view.bg.source = data.imageEffectInfo.bgURL;
		this._view.txtEndZw.text = data.endTitle;
		App.timer.doTimeOnce(this, 1000, this.showEndWord);
	}

	private showEndWord(): void {
		App.timer.clearTimer(this, this.showEndWord);
		egret.Tween.get(this._view.groupEndWord).to({ alpha: 1 }, 500).wait(1000).call(this.showButtons, this);
	}

	private showButtons(): void {
		//引导
		App.global.guide.showView(this._view.btnShare, EnumGuideType.END_SHARE, this.panelName);
		egret.Tween.get(this._view.groupBtns).to({ alpha: 1 }, 500);
	}

	private onClick(e: egret.TouchEvent): void {
		switch (e.currentTarget) {
			case this._view.groupHome:
				this.closePanel();
				GameManager.exitGame();
				App.data.gameHallCenter.updateHeroniesProps(App.data.gameFangDongCenter.gameId, { getNewMemory: App.data.gameFangDongCenter.getNewMemory });
				PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getHeroniesData(App.data.gameFangDongCenter.gameId));
				if (App.data.gameFangDongCenter.isDLC) {
					PanelOpenManager.openPanel(EnumPanelID.OTHER_STORY, App.data.gameHallCenter.getHeroniesData(App.data.gameFangDongCenter.gameId));
				}
				break;
			case this._view.groupMore:
				PanelOpenManager.openPanel(EnumPanelID.RECORD, { uid: App.data.gameFangDongCenter.gameId, type: EnumRecordType.READ, panelName: this.panelName });
				break;
			case this._view.groupShare:
				ProtocolCommon.instance().send_share_link(App.data.gameFangDongCenter.gameId, App.data.gameFangDongCenter.dlcID, App.data.gameFangDongCenter.id, new FunctionVO(this.onCallBack, this))
				break;
		}
	}

	private onCallBack(data: any): void {
		if (data.code == "200") {
			PanelOpenManager.openPanel(EnumPanelID.GAME_SHARE2, { url: data.data.collect_image });
		}
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}

}