class GmPanel extends BasePanel {
	private _view: GmUI;

	private _conditions: GmAvgAttriView[];
	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new GmUI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnClose);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnGo);
		this._dispatcher.addEventListener(GmCenter.INIT_GM_DATA, this.setData, this);
		this._dispatcher.addEventListener(GmCenter.SELECT_CHAPTER, this.onSelectChapter, this);
		GmCenter.instance().getVariable(data.id, data.isDlc);
	}

	private setData(): void {
		var chapterList: number[] = GmCenter.instance().chapterList;
		this._view.comboxChapter.show({ data: chapterList, type: 0 });

		this.clearConditions();
		this._conditions = [];
		var conNameList: string[] = GmCenter.instance().conditionNameList;
		var conValueList: string[] = GmCenter.instance().conditionValueList;
		var item: GmAvgAttriView;
		for (var i: number = 0; i < conNameList.length; i++) {
			item = new GmAvgAttriView();
			item.setData(conNameList[i], conValueList[i]);
			item.y = i * 50;
			this._view.groupAttri.addChild(item);
			this._conditions.push(item);
		}
	}

	private onSelectChapter(c: number): void {
		var sectionList: number[] = GmCenter.instance().getSectionByChapter(c);
		this._view.comboxSection.show({ data: sectionList, type: 1 });
	}

	private onClick(e: egret.TouchEvent): void {
		switch (e.currentTarget) {
			case this._view.btnClose:
				PanelOpenManager.removePanel(EnumPanelID.GM);
				break;
			case this._view.btnGo:
				if (!this._view.txtChatId.text && this._view.comboxChapter.selectNum < 0) {
					Notice.showBottomCenterMessage("请选择章");
				} else if (!this._view.txtChatId.text && this._view.comboxSection.selectNum < 0) {
					Notice.showBottomCenterMessage("请选择节");
				} else {
					var chatId: number;
					if (this._view.txtChatId.text) {
						chatId = Number(this._view.txtChatId.text);
					} else {
						if (this._view.comboxSection.txtSelected.text == "0")
							chatId = GmCenter.instance().getChatIdByCS(this._view.comboxChapter.selectNum + "");
						else
							chatId = GmCenter.instance().getChatIdByCS(this._view.comboxChapter.selectNum + "-" + this._view.comboxSection.selectNum);
					}
					GmCenter.instance().goToChar(App.data.gameFangDongCenter.isDLC ? App.data.gameFangDongCenter.dlcID : App.data.gameFangDongCenter.gameId, App.data.gameFangDongCenter.isDLC, chatId, this.getAllConditions());
					PanelOpenManager.removePanel(EnumPanelID.GM);
				}
				break;
		}
	}

	private getAllConditions(): any {
		var constr: string;
		var conditions: any = {};
		if (!this._conditions) return conditions;
		for (var i: number = 0; i < this._conditions.length; i++) {
			conditions[this._conditions[i].getKey()] = this._conditions[i].getValue();
		}
		constr = JSON.stringify(conditions);
		return constr;
	}

	private clearConditions(): void {
		if (this._conditions) {
			for (var i: number = 0; i < this._conditions.length; i++) {
				this._conditions[i] && this._conditions[i].remove();
			}
			this._conditions = undefined;
		}
	}

	public hide(): void {
		super.hide();
		this.clearConditions();
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}

}