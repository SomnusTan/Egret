class GmAvgAttriView extends BaseUI {
	public txtKey: eui.Label;
	public inputValue: eui.TextInput;

	public constructor() {
		super("GmAvgAttriSkin");
	}

	public setData(key: string, value: string): void {
		this.txtKey.text = key.split(".")[1];
		this.inputValue.text = value;
	}

	public getKey(): string {
		return "f." + this.txtKey.text;
	}

	public getValue(): any {
		return { value: this.inputValue.text };
	}

	public getCondition(): string {
		return this.txtKey.text + ":" + this.inputValue.text;
	}

	public remove(): void {
		this.txtKey.text = "";
		this.inputValue.text = "";
		super.remove();
	}

	public get width(): number {
		return 645;
	}

	public get height(): number {
		return 40;
	}

}