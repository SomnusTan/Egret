class GmCenter {
	private static _instance: GmCenter;
	public static INIT_GM_DATA: string = "GmCenter.INIT_GM_DATA";
	public static SELECT_CHAPTER: string = "GmCenter.SELECT_CHAPTER";
	public dataList: any;
	/**章列表 */
	public chapterList: number[];
	private csHashMap: HashMap;
	private chatIdHashMap: HashMap;
	/**节点id列表 */
	public chatidList: number[];
	/**条件键 */
	public conditionNameList: string[];
	/**条件值 */
	public conditionValueList: string[];
	public startId: number;
	public constructor() {
	}

	public static instance(): GmCenter {
		if (this._instance == null) {
			this._instance = new GmCenter();
		}
		return this._instance;
	}

	/** 根据章节获得节点id */
	public getChatIdByCS(cs: string): number {
		return Number(this.chatIdHashMap.get(cs));
	}

	/** 根据章获得节 */
	public getSectionByChapter(c: number): number[] {
		return this.csHashMap.get(c);
	}
	/**跳转到指定节点 */
	public goToChar(id: number, isDlc: boolean, chat_id: number, condition: string): any {
		var hData: HeroinesData = App.data.gameHallCenter.getHeroniesData(id);
		hData.record_type = 1;
		ProtocolCommon.sendBack("/Avg/DeBug/GoToChar", isDlc ? { dlc_id: id, chat_id: chat_id, condition: condition } : { heroine_id: id, chat_id: chat_id, condition: condition }, new FunctionVO(this.onSettingBack, this));
	}
	private onSettingBack(data: any): void {
		if (data.code == 200) {
			GameManager.startGame(App.data.gameFangDongCenter.gameId, App.data.gameFangDongCenter.dlcID,
				{
					id: App.data.gameFangDongCenter.gameId,
					dlcID: App.data.gameFangDongCenter.dlcID,
					saveId: App.data.gameFangDongCenter.isDLC ? 1 : 0,
					isInGame: true
				});
		}
	}
	/**获取女主变量及章节列表 */
	public getVariable(id: number, isDlc: boolean = false): any {

		ProtocolCommon.sendBack("/Avg/DeBug/GetVariable", isDlc ? { dlc_id: id } : { heroine_id: id }, new FunctionVO(this.getChapterList, this));
	}
	/**
	 * # 成功返回
	 * {
	 * 	"condition":                "变量表",
	 * 	"start_id":                 "女主初始节点",
	 * 	"chapter_list":             "章节列表"
	 * }
	 * # 失败返回
	 * {"info": "参数有误", "code": "804", "data":{}}
	 * {"info": "目标女主没有章节数据", "code": "827", "data":{}}
	 * {"info": "目标女主不存在", "code": "814", "data":{}}
	 */
	private getChapterList(data: any): void {
		if (data.code == 200) {
			this.dataList = data.data;
			this.parseChapterList();
			App.dispatcher.dispatchEvent(GmCenter.INIT_GM_DATA);
		} else {
		}
	}

	private parseChapterList(): void {
		this.csHashMap = new HashMap();
		this.chatIdHashMap = new HashMap();
		this.chapterList = [];
		this.chatidList = [];
		this.conditionNameList = [];
		this.conditionValueList = [];
		var list: any[] = this.dataList.chapter_list;// 0: {id: 134, name: "1-1"}
		for (var i: number = 0; i < list.length; i++) {
			this.chatidList.push(list[i].id);
			var value: string = list[i].name;
			this.chatIdHashMap.put(value, list[i].id);
			var c: number = Number(value.split("-")[0]);
			var s: number = Number(value.split("-")[1]);
			var sectionList: number[] = this.csHashMap.get(c);
			if (!sectionList) {
				sectionList = [];
			}
			sectionList.push(isNaN(s) ? 0 : s);
			this.csHashMap.put(c, sectionList);
		}
		this.chapterList = this.csHashMap.keys;
		this.chapterList.sort(function (a, b) { return a - b });
		// GameLog.log('this.chapterList,sort', this.chapterList);

		this.startId = this.dataList.start_id;
		var condition: any = this.dataList.condition;
		for (var key in condition) {
			this.conditionNameList.push(key);
			this.conditionValueList.push(condition[key]);
		}
	}

	public collectPlayerInfo(): void {
		GameLog.log('当前的浏览器信息navigator.userAgent.toLowerCase()：', navigator.userAgent.toLowerCase());
		GameLog.log('指示当前的操作系统egret.Capabilities.os：', egret.Capabilities.os);
		GameLog.log('指示当前的运行类型egret.Capabilities.runtimeType：', egret.Capabilities.runtimeType);
		GameLog.log('视频是否正在播放Video.instance().paused：', Video.instance().paused + " ，播放路径Video.instance().src：" + Video.instance().src);
		GameLog.log('赵小野数据App.data.game2Center.DataCenter：', App.data.game2Center.DataCenter);
		GameLog.log('房东数据App.data.gameFangDongCenter：', App.data.gameFangDongCenter);
		GameLog.log('用户数据App.global.userInfo：', App.global.userInfo);
	}
}