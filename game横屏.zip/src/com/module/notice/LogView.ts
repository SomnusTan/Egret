class LogView extends h5_engine.GSprite {

    private WIDTH: number = 500;
    private HEIGHT: number = 600;

    private _txt: egret.TextField;

    private _btn: h5_engine.GSprite;

    private _isShow: boolean;
    /**信息数量 */
    private _count: number;
    /**信息上限 */
    private MAX_COUNT: number = 100;

    private _logList: string[];

    private _group: eui.Group;

    private _scroller: eui.Scroller;


    public constructor() {
        super();
        this.init();
    }

    public init(): void {
        this._count = 0;
        this._logList = [];

        this.graphics.beginFill(0, 0.5);
        this.graphics.drawRect(0, 0, this.WIDTH, this.HEIGHT);
        this.graphics.endFill();

        this._txt = new egret.TextField();
        this._txt.width = this.WIDTH;
        this._txt.height = this.HEIGHT;
        this._txt.size = 20;
        this._group = new eui.Group();
        this._group.addChild(this._txt);
        this.addChild(this._group);

        this._scroller = new eui.Scroller();
        this._scroller.skinName="skins.ScrollerSkin";
        this._scroller.width = this.WIDTH;
        this._scroller.height = this.HEIGHT;
        this._scroller.viewport = this._group;
        this.addChild(this._scroller);

        this._isShow = false;

        this._btn = new h5_engine.GSprite()
        this.addChild(this._btn);
        this._btn.graphics.beginFill(0x0000ff, 0.7);
        this._btn.graphics.drawRect(0, 0, 40, 100);
        this._btn.graphics.endFill();
        this._btn.x = this.WIDTH;
        this._btn.y = this.HEIGHT - this._btn.height >> 1;
        this._btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onHideOrShow, this);
        this._btn.touchEnabled = true;

        this.y = Config.SCREEN_HEIGHT - this.HEIGHT >> 1;

        this.onHideOrShow();
    }

    private onHideOrShow(): void {
        if (this.parent) {
            if (this._isShow) {
                this.x = -this.WIDTH;
            }
            else {
                this.x = 0;
            }
            this._isShow = !this._isShow;
        }
    }

    public addLog(str: string): void {
        if (this._count < this.MAX_COUNT) {
            this._txt.appendText(str + "\n");
            this._logList.push(str);
            this._count++;
        }
        else {
            this._logList.shift();
            this._logList.push(str);
            this._count = this.MAX_COUNT;
            this._txt.text = this._logList.join("\n");
        }
        this._group.scrollV = this._txt.maxScrollV;
    }
}