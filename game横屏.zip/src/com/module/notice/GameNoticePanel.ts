/**
 * 公告面板
 */
class GameNoticePanel extends WindowView3 {

    private _view: GameNoticeViewUI;

    public constructor() {
        super(510, 420, "公告");
    }

    protected init(): void {
        super.init();
        this._view = new GameNoticeViewUI();
        this.viewSp.addChild(this._view);
    }

    public dispose(): void {
        super.dispose();
        if (this._view) {
            this._view.dispose();
            this._view = null;
        }
    }

    public show(data?: any): void {
        super.show(data);
        this._view.txtNotice.text = data.notice;
        if (this._view.txtNotice.height > 500) {
            this._view.scrollBar.height = 500;
            this._view.height = this._view.txtNotice.y + 500 + 90;
            this.setWH(510, 500 + 90);
        }
        else {
            this._view.scrollBar.height = this._view.txtNotice.height;
            this._view.height = this._view.txtNotice.y + this._view.txtNotice.height + 90;
            this.setWH(510, this._view.height);
        }
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClose, this, this._view.btnOK);
    }

    public hide(): void {
        super.hide();

    }
}
