class MousePosMessageView extends h5_engine.GSprite {
	public constructor() {
		super();
		App.dispatcher.addEventListener(EventType.STGAE_RESIZE, this.setPos, this);
	}

	private setPos(event: Event = null): void {
		this.x = Config.SCREEN_WIDTH - this.width >> 1;
		this.y = Config.SCREEN_HEIGHT - this.height >> 1;
	}

	public showMousePosMessage(str: string, color: number, mouseX: number = 0, mouseY: number = 0): void {
		if (this._isLoading)
			return;
		this._isLoading = true;

		let textFiled: h5_engine.GTextField = new h5_engine.GTextField();
		textFiled.htmlText = str;
		textFiled.textColor = color;
		textFiled.size = 20;
		textFiled.textAlign = egret.HorizontalAlign.CENTER;
		textFiled.verticalAlign = egret.VerticalAlign.MIDDLE;
		textFiled.x = (this.width - textFiled.textWidth) / 2;

		this.addChild(textFiled);
		if (!App.layer.messageLayer.contains(this))
			App.layer.messageLayer.addChild(this); //直接显示
		let changeY: number;
		if (mouseX) {
			this.x = mouseX //- (this.width >> 1);
			this.y = mouseY - 20;
		} else {
			this.setPos();
		}
		changeY = this.y - MousePosMessageView.UPHEIGHT

		egret.Tween.get(this).to({ y: changeY},MousePosMessageView.TIME).call(this.moveOver,this,[textFiled]);
	}

	private moveOver(textFiled: h5_engine.GTextField): void {
		if (textFiled && textFiled.parent) {
			textFiled.parent.removeChild(textFiled);
		}
		if (this && this.parent) {
			this._isLoading = false;
			if (this._parent.contains(this)) {
				this._parent.removeChild(this);
			}
			Notice.setMousePosMessagePool(this);
			this.setPos();
		}
	}


	private _parent: egret.DisplayObjectContainer;
	private _isLoading: boolean; //只出现一条信息
	private _pChild: egret.DisplayObjectContainer;
	private static TIME: number = 2500; //向上飘的时间
	private static UPHEIGHT: number = 150; //向上飘的高度
}