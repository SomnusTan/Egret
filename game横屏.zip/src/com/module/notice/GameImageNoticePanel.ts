class GameImageNoticePanel extends WindowView {

    private _view: eui.Image;

    public constructor() {
        super(520, 820, true);

    }

    protected init(): void {
        super.init();
        this._view = new eui.Image();
        this.viewSp.addChild(this._view);
        this._view.y = -60;
        this._view.x = 8;
        // this._view.scaleX = 0.7;
        // this._view.scaleY = 0.7; 
    }

    public show(data?: any): void {
        super.show(data);
        this._windowView.imgBg0.visible = false;
        this.topTitle = data.title ? data.title : "公告";
        this._view.source = data.notice;
        this._view.touchEnabled = true;
        this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closePanel, this, this._view);
    }

    public hide(): void {
        super.hide();
    }

    // public get width(): number {
    //     return Config.MAIN_WIDTH * 0.8;
    // }
    // public get height(): number {
    //     return Config.MAIN_HEIGHT * 0.8;
    // }
}