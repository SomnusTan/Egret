
/**
 * 系统提示广播(位置在中上部)
 */
class MiddleMessageView extends h5_engine.GSprite {

	public constructor() {
		super();
	}

	/**
		 * @param str
		 * @param color
		 */
	public showMiddleMessage(str: string, color: number): void {
		if (!App.layer.messageLayer.contains(this)) {
			App.layer.messageLayer.addChild(this); //直接显示
			App.dispatcher.addEventListener(EventType.STGAE_RESIZE, this.setPos, this);
		}
		this._msgAry.push(str);
		this._colorAry.push(color);
		App.timer.doTimeOnce(this, MiddleMessageView.DELAYTIME, this.addLabelItem);
	}

	private addLabelItem(): void {
		if (this._count < MiddleMessageView.TOTALNUM) {
			let str: string = this._msgAry[this._showIndex];
			if (str) {
				let msgContainer: h5_engine.GDisplayObjectContainer = this.getGDisplayObjectContainer();
				msgContainer.alpha = 1;

				let bg: eui.Image = this.getImage();
				bg.name = "image";
				bg.alpha = 1;
				bg.source = "notice_json.notice_bg2_png";
				bg.height = 22;

				let textField: h5_engine.GTextField = this.getBaseTextField();
				textField.name = "label";
				textField.htmlText = str;
				textField.size = 16;
				textField.textColor = this._colorAry[this._showIndex];
				textField.textAlign = egret.HorizontalAlign.CENTER;
				textField.verticalAlign = egret.VerticalAlign.MIDDLE;
				bg.width = textField.textWidth + 80;
				textField.x = bg.width - textField.textWidth >> 1;
				textField.y = bg.height - 16 >> 1;

				msgContainer.addChild(bg);
				msgContainer.addChild(textField);
				this.addChild(msgContainer);
				msgContainer.anchorOffsetX = bg.width / 2;
				msgContainer.anchorOffsetY = bg.height / 2;
				msgContainer.x = bg.width / 2;
				msgContainer.y = bg.height / 2;

				this._imageAry.push(bg);
				this._textFieldAry.push(textField);
				this._msgContainerAry.push(msgContainer);

				// this.setPos();
				this.x = (Config.SCREEN_WIDTH - bg.width) / 2;
				this.y = 0.4 * Config.SCREEN_HEIGHT;

				++this._showIndex;
				++this._count;

				this.refreshPos();
				egret.Tween.get(msgContainer).to({scaleX: 2, scaleY: 2},100).call(this.scale2Time,this,[msgContainer]);
			}
		}
	}

	private scale2Time(msgContainer: h5_engine.GDisplayObjectContainer): void //0.5秒后恢复到正常字体
	{
		egret.Tween.get(msgContainer).wait(500).to({
			x: (this.width - msgContainer.width) / 2, y: this._count * MiddleMessageView.H, scaleX: 1, scaleY: 1
		},100).call(this.showTime,this,[msgContainer]);
	}

	private showTime(msgContainer: h5_engine.GDisplayObjectContainer): void //正常显示4秒后
	{
		this.refreshPos();
		App.timer.doTimeOnce(this, MiddleMessageView.DELAYTIME, this.addLabelItem);
		let id: any = App.timer.doTimeOnce(this, 4000, this.scale1Time, [msgContainer], false);
		this._clearIdAry.push(id);
	}

	private scale1Time(msgContainer: h5_engine.GDisplayObjectContainer): void //文字1秒内渐弱至消失
	{
		App.timer.clearTimer(this, this._clearIdAry.shift());
		egret.Tween.get(msgContainer).to({ alpha: 0.01},1000).call(this.removeImage,this,[msgContainer]);
	}

	private removeImage(msgContainer: h5_engine.GDisplayObjectContainer): void {
		let img: eui.Image = msgContainer.getChildByName("image") as eui.Image;
		if (img && img.parent) {
			img.parent.removeChild(img);
		}
		img = null;
		let label: h5_engine.GTextField = msgContainer.getChildByName("label") as h5_engine.GTextField;
		if (label && label.parent) {
			label.parent.removeChild(label);
		}
		label = null;
		this.removeLabelChild(msgContainer);
		this.refreshPos();
		if (this._count < MiddleMessageView.TOTALNUM && this._count > 0) {
			App.timer.doTimeOnce(this, MiddleMessageView.DELAYTIME, this.addLabelItem);
		}
		if (this._count == 0) {
			this._imageAry = [];
			this._textFieldAry = [];
			this._msgAry = [];
			this._colorAry = [];
			this._showIndex = 0;
			if (App.layer.messageLayer.contains(this)) {
				App.layer.messageLayer.removeChild(this);
				App.dispatcher.removeEventListener(EventType.STGAE_RESIZE, this.setPos, this);
			}
		}
	}

	private removeLabelChild(msgContainer: h5_engine.GDisplayObjectContainer): void {
		if (msgContainer && msgContainer.parent) {
			msgContainer.parent.removeChild(msgContainer);
			this._msgContainerPool.push(msgContainer);
			msgContainer = null;
			this._msgContainerAry.shift();
			--this._count;
		} else { //正常情况不会走这里，走了说明有错误
			this._textFieldAry = [];
			this._msgContainerAry = this._imageAry = this._msgAry = this._colorAry = [];
			this._count = this._showIndex = 0;
			if (App.layer.messageLayer.contains(this)) {
				App.dispatcher.removeEventListener(EventType.STGAE_RESIZE, this.setPos, this);
				App.layer.messageLayer.removeChild(this);
			}
		}
	}

	private getGDisplayObjectContainer(): h5_engine.GDisplayObjectContainer {
		if (this._msgContainerPool.length > 0) {
			return this._msgContainerPool.pop();
		}
		return new h5_engine.GDisplayObjectContainer();
	}

	/**
	 * 来新的消息要重新刷新位置
	 */
	private refreshPos(): void {
		for (let i: number = 0; i < this._msgContainerAry.length; i++) {
			let e: h5_engine.GDisplayObjectContainer = this._msgContainerAry[i] as h5_engine.GDisplayObjectContainer;
			egret.Tween.get(e).to({ y: i * MiddleMessageView.H},300);
		}
	}

	private getBaseTextField(): h5_engine.GTextField {
		if (this._labelPool.length > 0) {
			return this._labelPool.pop();
		}
		return new h5_engine.GTextField();
	}

	private getImage(): eui.Image {
		if (this._imagePool.length > 0) {
			return this._imagePool.pop();
		}
		return new eui.Image();
	}

	private setPos(event: Event = null): void {
		this.x = (Config.SCREEN_WIDTH - this.width) / 2;
		this.y = Config.SCREEN_HEIGHT * 0.18;
	}

	private _msgAry: Array<any> = [];
	private _colorAry: Array<any> = [];
	private static DELAYTIME: number = 100;
	private _count: number = 0; //计数
	private static TOTALNUM: number = 4;
	private _showIndex: number = 0;
	private _textFieldAry: Array<h5_engine.GTextField> = [];
	private _imageAry: Array<eui.Image> = [];
	private _labelPool: Array<h5_engine.GTextField> = [];
	private _imagePool: Array<eui.Image> = [];
	private static H: number = 20;
	private _msgContainerPool: Array<h5_engine.GDisplayObjectContainer> = [];
	private _msgContainerAry: Array<h5_engine.GDisplayObjectContainer> = [];
	private _clearIdAry: Array<any> = [];
}