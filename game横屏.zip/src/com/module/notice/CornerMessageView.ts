class CornerMessageView extends egret.DisplayObjectContainer {
	public constructor(removeFun: FunctionVO) {
		super();

		this._textFieldAry = [];
		this._labelHeightAry = [];
		this._removeFun = removeFun;
		App.dispatcher.addEventListener(EventType.STGAE_RESIZE, this.setPos, this);
		this.setPos();
		this.touchEnabled = this.touchChildren = false;
	}

	/**
	 * 销毁
	 */
	public dispose(): void {
		this.removeAll();
		if (this._labelPool) {
			for (var i: number = 0; i < this._labelPool.length; i++) {
				if (this._labelPool[i]) {
					if (this._labelPool[i].parent) {
						this._labelPool[i].parent.removeChild(this._labelPool[i]);
					}
					this._labelPool[i] = null;
				}
			}
			this._labelPool = null;
		}
		App.dispatcher.removeEventListener(EventType.STGAE_RESIZE, this.setPos, this);
	}

	public showCornerMessage(): void {
		while (Notice.cornerAry.length > 0) {
			var str: string = Notice.cornerAry.shift();
			this.addLabelItem(str);
		}
	}

	private addLabelItem(str: string): void {
		if (!str) { return };
		var label: h5_engine.GTextField = this.getBaseTextField();
		label.alpha = 1;
		label.textColor = Notice.CORNER_COLOR;
		label.size = 19;
		label.htmlText = str;
		// label.filters = [new egret.GlowFilter(0x212121, 1, 2, 2, 5, 1)];
		label.stroke = 1;
		label.strokeColor = 0x212121;
		label.multiline = true;
		label.wordWrap = true;
		label.y = this.height - label.textHeight;
		label.height = label.numLines * 28;
		this.addChild(label);
		++this._count;
		this._textFieldAry.push(label);
		this._labelHeightAry.push(label.height);
		this.refreshPos();

		// label.x = -label.textWidth;
		egret.Tween.get(label).wait(2000).to({ x: -label.textWidth},500,egret.Ease.cubicOut).call(this.removeLabelChild,this,[label]);
	}

	private removeLabelChild(label: h5_engine.GTextField): void {
		if (this._labelPool == null) {
			this._labelPool = new Array<h5_engine.GTextField>();
		}
		if (label && label.parent) {
			this._labelPool.push(label);
			if (label.parent) {
				label.parent.removeChild(label);
			} else {
				label.text = "";
				label.dispose();
			}
			if (this._textFieldAry) this._textFieldAry.shift();
			if (this._labelHeightAry) this._labelHeightAry.shift();
			--this._count;
		} else {
			if (this._removeFun != null) {
				this._removeFun.exec();
				this._removeFun = null;
			}
			this._count = 0;
			// logDebug("removeLabelChild()::label.parent = null");
		}
		if (this._count == 0) {
			if (this._removeFun != null) {
				this._removeFun.exec();
				this._removeFun = null;
			}
		}
	}

	/**
	 * 清空，把所有文本移除，所有计时停止,回到初始化
	 */
	private removeAll(): void {
		for (var i: number = 0; i < this._textFieldAry.length; i++) {
			var label: h5_engine.GTextField = this._textFieldAry[i];
			if (label) {
				if (label.parent) {
					label.parent.removeChild(label);
				}
				label.text = "";
				label.dispose();
				label = null;
			}
		}
		this._count = 0;
		this._textFieldAry = [];
		this._labelHeightAry = [];
		this._msgAry = [];
		// App.timer.clearTimer(this, this.showCornerMessage);
	}

	private setPos(): void {
		// this.x = Config.SCREEN_WIDTH - this.width;
		// this.y = Config.SCREEN_HEIGHT - this.height;
		// this.y = Config.SCREEN_HEIGHT * 0.63;
	}

	/**
	 * 来新的消息要重新刷新位置
	 */
	private refreshPos(): void {
		for (var i: number = 0; i < this._textFieldAry.length; i++) {
			var label: h5_engine.GTextField = this._textFieldAry[i] as h5_engine.GTextField;
			var allHeight: number = 0;
			for (var j: number = i; j < this._labelHeightAry.length; j++) {
				allHeight += this._labelHeightAry[j];
			}
			if (label) {
				egret.Tween.get(label).to({ y: this.height - allHeight},100,egret.Ease.cubicOut);
			}
		}
	}

	public get height(): number {
		return 820;
	}

	private getBaseTextField(): h5_engine.GTextField {
		if (this._labelPool == null) {
			this._labelPool = new Array<h5_engine.GTextField>();
		}
		if (this._labelPool.length > 0) {
			return this._labelPool.pop();
		}
		return new h5_engine.GTextField();
	}

	private _begin: boolean = true;
	private _removeFun: FunctionVO;
	private _count: number = 0; //计数
	private _msgAry: Array<any> = [];
	private _textFieldAry: Array<h5_engine.GTextField>;
	private _labelHeightAry: number[];
	public static TOTALNUM: number = 7;
	// private DELAYTIME: number = 100; //数量较少时，用这个时间，较慢
	// private DELAYTIME2: number = 80; //数量较多时，用这个时间，较快
	private _labelPool: Array<h5_engine.GTextField>;

}