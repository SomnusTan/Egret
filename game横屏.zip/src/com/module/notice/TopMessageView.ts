
/**
 * 屏幕上方居中显示的系统消息
 */
class TopMessageView extends h5_engine.GSprite {

	public constructor() {
		super();

		if (this._bg == null) {
			this._bg = new eui.Image("notice_json.notice_bg1_png");
			this._bg.height = this.height;
			this.addChild(this._bg);
		}

		if (this._sh == null) {
			this._sh = this.createShap();
			this.addChild(this._sh);
		}

		this.mask = this._sh;
		App.dispatcher.addEventListener(EventType.STGAE_RESIZE, this.setPos, this);
		if (!App.layer.messageLayer.contains(this))
			App.layer.messageLayer.addChild(this);
	}

	/**
		 * 系统公告广播(位置在中间顶部)
		 * @param content
		 * @param color
		 */
	public showTopMessage(content: string, color: number): void {
		if (this._bg) {
			this._bg.visible = true;
		}
		this.setPos();
		this._msgAry.push(content);
		this._colorAry.push(color);
		App.timer.doTimeOnce(this, TopMessageView.DELAYTIME, this.addLabelItem);
	}

	private addLabelItem(): void {
		let str: string = this._msgAry[this._showIndex];
		if (str != null) {
			let label: h5_engine.GTextField = this.getGTextField();
			label.alpha = 1;
			// _defaultFormat.color = _colorAry[_showIndex] == null ? Notice.TOP_COLOR : _colorAry[_showIndex];
			// label.autoSize = TextFieldAutoSize.CENTER;
			// label.defaultTextFormat = _defaultFormat;
			// label.htmlText = str;
			// label.filters = [new GlowFilter(0x370000, 1, 2, 2, 5, 1)];

			label.textFlow = HtmlUtil.getHtmlStr(str);
			label.textColor = Notice.TOP_COLOR;
			label.size = 16;
			label.textAlign = egret.HorizontalAlign.CENTER;
			label.verticalAlign = egret.VerticalAlign.MIDDLE;

			label.y = this.height - label.height >> 1;
			if (this._preLabel == null)
				label.x = this.width;
			else
				label.x = this._preLabel.x + this._preLabel.width < this.width ? this.width : this._preLabel.x + this._preLabel.width + 20;
			this._preLabel = label;
			this.addChild(label);
			++this._count;
			++this._showIndex;
			this._textFieldAry.push(label);
			this.showTime(label);
		}
	}

	private getGTextField():h5_engine.GTextField{
		if(this._textFieldPool.length>0){
			return this._textFieldPool.pop();
		}
		return new h5_engine.GTextField();
	}

	private showTime(label: h5_engine.GTextField): void {
		App.timer.doTimeOnce(this, TopMessageView.DELAYTIME, this.addLabelItem);
		let id: any = App.timer.doTimeLoop(this, TopMessageView.FRAME, this.moveTo, [label], false);
		this._clearIdAry.push(id);
	}

	private moveTo(txt: h5_engine.GTextField): void {
		txt.x -= this.width / Math.floor(1000 / TopMessageView.FRAME * TopMessageView.TIME);
		if (txt.x <= -txt.width) {
			App.timer.clearTimer(this, this._clearIdAry.shift());
			egret.Tween.get(txt).to({alpha:0.01},100).call(this.removeLabel,this,[txt]);
		} else if (txt.x < this.width - txt.width) {
			this.addLabelItem();
		}
	}

	private removeLabel(textField: h5_engine.GTextField): void {
		if (textField && textField.parent) {
			textField.parent.removeChild(textField);
			this._textFieldPool.push(textField);
			textField = null;
			this._textFieldAry.shift();
			--this._count;
		} else { //正常情况不会走这里，走了说明有错误
			for (let i: number = 0; i < this._textFieldAry.length; i++) {
				textField = this._textFieldAry[i];
				if (textField && textField.parent) {
					textField.parent.removeChild(textField);
					this._textFieldPool.push(textField);
					textField = null;
					--this._count;
				}
			}
			this._textFieldAry = this._msgAry = this._colorAry = [];
			this._count = this._showIndex = 0;
			return;
		}
		if (this._count > 0) {
			App.timer.doTimeOnce(this, TopMessageView.DELAYTIME, this.addLabelItem);
		}
		if (this._count == 0) {
			this._msgAry = [];
			this._colorAry = [];
			this._showIndex = 0;
			this._preLabel = null;
			if (this._bg) {
				this._bg.visible = false;
			}
			//				if(Application.stageLayer.messageLayer.contains(this))
			//					Application.stageLayer.messageLayer.removeChild(this);
		}
	}

	protected setPos(event: Event = null): void {
		this.y = 200;
		this.x = Config.SCREEN_WIDTH - this.width >> 1;
	}

	private createShap(): egret.Shape {
		let sh: egret.Shape = new egret.Shape();
		sh.graphics.clear();
		sh.graphics.beginFill(0);
		sh.graphics.drawRect(0, 0, this.width, this.height);
		sh.graphics.endFill();
		return sh;
	}

	public get width(): number {
		return 640;
	}

	public get height(): number {
		return 30;
	}

	private _bg: eui.Image;
	private _sh: egret.Shape;
	private _msgAry: Array<any> = [];
	private _colorAry: Array<any> = [];
	private static DELAYTIME: number = 100;
	private _showIndex: number = 0;
	private _preLabel: h5_engine.GTextField;
	private _count: number = 0;
	private _textFieldAry: Array<h5_engine.GTextField> = [];
	private _clearIdAry: Array<any> = [];
	private static FRAME: number = 20; // 毫秒
	private static TIME: number = 6; //总共需要这个时间完成滚动消息
	private _textFieldPool: Array<h5_engine.GTextField> = [];

}