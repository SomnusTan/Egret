
class BottomMessageView extends h5_engine.GSprite {
	public constructor() {
		super();
		App.stage.addEventListener(egret.Event.RESIZE, this.setPos, this);
		this.setPos();
		this.touchEnabled = this.touchChildren = false;
	}

	private setPos(): void {
		if (App.layer.rotation == 0) {
			this.x = Config.SCREEN_WIDTH >> 1;
			this.y = (Config.SCREEN_HEIGHT >> 1) + (Config.isLandscape ? 0 : 30);
		}
		else {
			this.x = Config.SCREEN_HEIGHT >> 1;
			this.y = Config.SCREEN_WIDTH >> 1 + (Config.isLandscape ? 30 : 0);
		}
	}

	public show(str: string, color: number = Notice.BOTTOM_COLOR, playSound: boolean = true): void {
		if (str == undefined || str == "undefined")
			return;
		this._msgArr.push(str);
		this._colorArr.push(color);
		this._soundArr.push(playSound);
		App.timer.doTimeOnce(this, BottomMessageView.DELAYTIME, this.addItem);
		this.addItem();
	}

	private addItem(): void {
		let str: string = this._msgArr[this._showIndex];
		if (str) {
			var color: number = this._colorArr[this._showIndex];
			if (this._count >= BottomMessageView.TOTALNUM) {
				this.removeItem(this._msgContainerArr[0]);
			}
			let msgContainer: h5_engine.GDisplayObjectContainer = this.getMsgContainer();
			let textField: h5_engine.GTextField = msgContainer.getChildByName("textField") as h5_engine.GTextField;
			textField.htmlText = str;
			textField.textColor = color;

			let bgShape: h5_engine.GShape = msgContainer.getChildByName("bgShape") as h5_engine.GShape;
			bgShape.graphics.clear();
			bgShape.graphics.beginFill(0x232323, 0.9);
			bgShape.graphics.drawRoundRect(0, 0, textField.textWidth + 20, textField.textHeight + 10, 40);
			bgShape.graphics.endFill();

			textField.x = bgShape.width - textField.textWidth >> 1;
			textField.y = bgShape.height - textField.textHeight >> 1;
			msgContainer.alpha = 1;
			msgContainer.x = -bgShape.width >> 1;
			msgContainer.y = this._count * BottomMessageView.MSG_H;
			msgContainer.addChild(bgShape);
			msgContainer.addChild(textField);
			this.addChild(msgContainer);
			this._msgContainerArr.push(msgContainer);
			this._showIndex++;
			this._count++;
			this.refreshPos();
			if (this._soundArr[this._showIndex])
				App.sound.playSoundSwitchClient(EnumSoundId.NOTICE);
			egret.Tween.get(msgContainer).wait(4000).to({ alpha: 0.01 }, 1000).call(this.removeItem, this, [msgContainer]);
		}
	}

	private removeItem(msgContainer: h5_engine.GDisplayObjectContainer): void {
		if (msgContainer && msgContainer.parent) {
			this.removeChild(msgContainer);
			if (this._msgContainerPool.indexOf(msgContainer) == -1) {
				this._msgContainerPool.push(msgContainer);
			}
			this._msgContainerArr.shift();
			this._count--;
			this.refreshPos();
			egret.Tween.removeTweens(msgContainer);
		} else {
			this.clearData();
		}

		if (this._count <= 0) {
			this.clearData();
		} else {
		}
	}

	private clearData(): void {
		this._msgArr = [];
		this._colorArr = [];
		this._soundArr = [];
		this._msgContainerArr = [];
		this._showIndex = 0;
		// if (App.layer.messageLayer.contains(this)) 
		// {
		// 	//移除舞台尺寸change事件
		// 	App.layer.messageLayer.removeChild(this);
		// }
	}

	private refreshPos(): void {
		for (let i = 0; i < this._msgContainerArr.length; i++) {
			let e: h5_engine.GDisplayObjectContainer = this._msgContainerArr[i];
			if (e) {
				egret.Tween.get(e).to({ y: i * BottomMessageView.MSG_H }, 100).wait(0.05 * i);
			}
		}
	}


	private getMsgContainer(): h5_engine.GDisplayObjectContainer {
		if (this._msgContainerPool.length > 0) {
			return this._msgContainerPool.pop();
		}
		let sp: h5_engine.GDisplayObjectContainer = new h5_engine.GDisplayObjectContainer();
		let bgShape: h5_engine.GShape = new h5_engine.GShape();
		bgShape.name = "bgShape";
		sp.addChild(bgShape);

		let textField: h5_engine.GTextField = new h5_engine.GTextField();
		textField.size = 28;
		textField.textAlign = egret.HorizontalAlign.CENTER;
		textField.verticalAlign = egret.VerticalAlign.MIDDLE;
		textField.name = "textField";
		textField.fontFamily = "fzyc";
		sp.addChild(textField);
		return sp;
	}

	//信息
	private _msgArr: Array<any> = [];
	private _colorArr: Array<any> = [];
	private _soundArr: Array<boolean> = [];

	private _showIndex: number = 0;
	private _count: number = 0;

	private static TOTALNUM: number = 1;
	private static DELAYTIME: number = 300;
	private static MSG_H: number = 50;
	private static MSG_W: number = 50;

	//ui
	private _msgContainerArr: Array<any> = [];

	//对象池
	private _msgContainerPool: Array<h5_engine.GDisplayObjectContainer> = [];

}