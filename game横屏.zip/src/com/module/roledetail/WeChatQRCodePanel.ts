class WeChatQRCodePanel extends BasePanel {
	private _view: WeChatQRCodeUI;
	private _qrView: QRCodeView;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new WeChatQRCodeUI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closePanel, this, this._view.btn_close);
		this.createQRCodeView(data);
		this._view.imgPayType.source = data.payType == EnumPayType.PAY_WECHAT ? "choosepay_title_wx_png" : "choosepay_title_zfb_png";
		if (data.price) {
			this._view.txt_money.text = data.price + "";
		} else {
			this._view.txt_money.text = "---";
		}
	}

	private createQRCodeView(data: any): void {
		if (!this._qrView) {
			this._qrView = new QRCodeView();
			this._view.addChild(this._qrView);
		}
		var url:string = Config.isRelease ? data.code : "http://www.dmgame.com";
		this._qrView.show(url, "logo_qrcode_png");
		this._qrView.x = this.width - this._qrView.width >> 1;
		this._qrView.y = 165;
	}

	public dispose(): void {
		if (this._qrView) {
			this._qrView.dispose();
			this._qrView = undefined;
		}
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	public get width(): number {
		return 658;
	}

	public get height(): number {
		return 480;
	}

}