class ChaoZhiZuHePanel extends BasePanel {
	private _view: ChaoZhiZuHeUI;

	private _uid: number;
	private _orderId: string;//请求支付的订单id
	private _waitTimes: number;//请求支付的等待时间，超过5分钟关闭面板
	private _needSendBuy: boolean;//请求是否支付成功

	private _tempWin: Window;
	private _data: any;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new ChaoZhiZuHeUI();
		this.addChild(this._view);
	}

	public show(data?: any): void {
		super.show(data);
		this._data = data;
		this._uid = data.id;
		this._view.bg.source = data.image;
		//content: "[{"type": 1, "number": 1}, {"type": 101, "number": 1000}, {"type": 120 "number": 1}, {"type": 121, "number": 1}]"
		// depict: "解锁《纯情房东俏房客》全部内容及追加的外传内容+赵小野版本钻石1000、微信秒回特权、工作恋爱一键完成无冷却特权"
		// id: 1
		// image: "http://192.168.0.121/act_bg2.png.jpg"
		// rebate_money: 69
		// start_time: 0
		// stop_time: 1546271999
		// title: "纯情房东俏房客"
		this._dispatcher.addEventListener(EventType.SHOP_IS_SHOP, this.onCheckShop, this);
		this._dispatcher.addEventListener(EventType.BUY_SUCCESS, this.onBuySuccess, this);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnBuy);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onQuitClick, this, this._view.btn_quit);

		this._view.rectBg.alpha = GameManager.isPlaying ? 1 : 0.5;

		if (DeviceUtil.IsWeb && DeviceUtil.isMobile && (Config.soEasy == false && H5_360_Sdk.getInstance().config360 == null) &&
			(DeviceUtil.isWeiBoBrowser || DeviceUtil.isWeiXinBrowser || DeviceUtil.isQQInBrowser || DeviceUtil.isSogouBrowser)) {
			Notice.showBottomCenterMessage("因内嵌浏览器无法弹出支付窗口,请使用\n谷歌浏览器支付体验");
		}

		this.showActPrice();
	}

	public hide(): void {
		super.hide();
		this.clearTimer();
		App.timer.clearTimer(this, this.onActTimer);
		App.timer.clearTimer(this, this.sendGetEndOrder);
		this._data = null;
		this._tempWin = null;
	}

	private onQuitClick(e: egret.TouchEvent): void {
		// if (GameManager.isPlaying) {
		// 	GameManager.exitGame();
		// 	App.global.guide.changeGuideTo_stateN(EnumGuideType.DETAIL_READ);
		// }
		// if (!GameManager.isPlaying && !PanelManager.isShowing(PanelRegister.HEROINES_DETAIL)) {
		// 	PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, App.data.gameHallCenter.getHeroniesData(this._uid));
		// }
		this.closePanel();
	}

	private onClick(e: egret.TouchEvent): void {
		// 查询服务端版本数据
		// if (DeviceUtil.IsWeb) {
		// 	if (Config.soEasy || Config.isLocalApp || H5_360_Sdk.getInstance().config360) {
		// 		ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_ZUHE, this._uid, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayOtherBack, this));
		// 	} else {
		// 		Alert.choosePay({ price: this._data.rebate_money, closeHandler: new FunctionVO(this.onChooseBack, this) });
		// 		// if (Config.skipVideo) {
		// 		// } else {
		// 		// 	this.onChooseBack({ payType: EnumPayType.PAY_ALIPAY });
		// 		// }
		// 	}
		// }
		// else {
		// 	if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
		// 		App.nativeBridge.sendU8PayNew(EnumPayType.BUY_ZUHE, {
		// 			productId: this._uid,
		// 			buyNum: 1,
		// 			price: this._data.rebate_money,
		// 			productName: this._data.title,
		// 			productDesc: "解锁《" + this._data.title + "》后续内容",
		// 			ratio: "",
		// 			serverID: "",
		// 			serverName: this._data.title
		// 		});
		// 	} else if (DeviceUtil.IsIos && DeviceUtil.IsNative) {
		// 		App.nativeBridge.sendIOSPayNew(EnumPayType.BUY_ZUHE, this._uid);
		// 	}
		// }
		Alert.show(StringUtil.substitute(EnumAlertContent.BUY_CHAO_ZHI_GIFT, this._data.balance_money, this._data.title), "确定|取消",
			new FunctionVO(this.onSureBuy, this));
	}

	private onSureBuy(data: any): void {
		if (data.type == Alert.OK) {
			if (App.global.userInfo.xdCoin >= this._data.balance_money)
				ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_ZUHE, this._uid, EnumPayType.BUY_TYPE_COIN, new FunctionVO(this.onBuyBack, this));
			else
				PanelOpenManager.openPanel(EnumPanelID.GAME_CHARGE, { type: 0, minCoin: this._data.balance_money, successClose: true });
		}
	}

	private onBuyBack(response: any): void {
		if (ResponseUtil.checkResponseData(response) && response.data.type == "balance") {
			Notice.showBottomCenterMessage(`购买${response.data.name}成功`);
			App.global.userInfo.xdCoin = response.data.balance;
			App.dispatcher.dispatchEvent(EventType.UPDATE_COIN);
			App.data.gameHallCenter.updateHeroniesProps(this._uid, { is_shop: true });
			this.closePanel();
			App.dispatcher.dispatchEvent(EventType.DETAIL_BUY_CZZH);
		}
		else if (response.code == 234) {
			PanelOpenManager.openPanel(EnumPanelID.GAME_CHARGE, { type: 0, minCoin: this._data.balance_money, successClose: true });
		}
	}

    /**
     *  {payType:支付类型 1：微信，2：支付宝}
     */
	private onChooseBack(data: any): void {
		if (Config.isRelease || Config.skipVideo) {
			if (data.payType == EnumPayType.PAY_WECHAT && DeviceUtil.isMobile) { //手机端微信支付
				var url: string = WebParams.ip + ProtocolHttpUrl.shop_please_pay + "?channel=wechat&type=" + EnumPayType.BUY_ZUHE + "&good_id=" + this._uid + "&setting=" + DeviceUtil.currentSetting +
					"&channel_id=" + App.global.userInfo.channelId + "&Authorization=" + App.global.userInfo.skey + "&AuthorizationID=" + App.global.userInfo.uid;
				this._tempWin = window.open(url, "_blank");
				App.timer.doTimeOnce(this, 3000, this.sendGetEndOrder);
			} else if (data.payType == EnumPayType.PAY_ALIPAY || (!DeviceUtil.isMobile && data.payType == EnumPayType.PAY_WECHAT)) { //支付宝 || 微信web
				if (data.payType == EnumPayType.PAY_ALIPAY)
					this._tempWin = WebParams.openWindow(WebParams.defaultURL);
				ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_ZUHE, this._uid, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayBack1, this, data.payType), data.payType);
			}
		} else {
			ProtocolCommon.instance().send_shop_please_pay(EnumPayType.BUY_ZUHE, this._uid, EnumPayType.BUY_TYPE_CASH, new FunctionVO(this.onHttpShopPayBack, this), data.payType);
		}
	}

	private sendGetEndOrder(): void {
		App.timer.clearTimer(this, this.sendGetEndOrder);
		ProtocolCommon.sendBack(ProtocolHttpUrlGame2.shop_end_order, { good_id: this._uid, type: EnumPayType.BUY_ZUHE }, new FunctionVO(this.checkOrder, this));
	}

	private checkOrder(data): void {
		if (data.code == 200) {
			this._orderId = data.data;
			this.clearTimer();
			App.timer.doTimeLoop(this, 3000, this.checkBuySuccess);
		}
	}

	/** 
	 * 请求跳转支付宝页面，并且循环检测是否支付完成
     * type:支付类型 1：微信，2：支付宝
	 */
	private onHttpShopPayBack1(data: any, type: number): void {
		if (data.code == 200) {
			this._orderId = data.data.order_id;
			this._waitTimes = 0;
			this._needSendBuy = true;
			if (type == EnumPayType.PAY_WECHAT) {
				data.data.payType = type;
				PanelOpenManager.openPanel(EnumPanelID.WECHAT_QRCODE, data.data);
			} else if (type == EnumPayType.PAY_ALIPAY) {
				ProtocolCommon.instance().send_alipay_switch(data.data.code, this._tempWin);
			}
			this.clearTimer();
			App.timer.doTimeLoop(this, 3000, this.checkBuySuccess);
		}
	}

	/** 检测是否支付完成*/
	private checkBuySuccess(): void {
		this._waitTimes += 3;
		if (this._waitTimes >= 300) {
			this.clearTimer();
			Notice.showBottomCenterMessage("支付失败");
			return;
		}
		if (this._needSendBuy) {
			this._needSendBuy = false;
			ProtocolCommon.sendBack(ProtocolHttpUrl.shop_is_shop, { order_id: this._orderId }, new FunctionVO(this.onShopBack, this));
		}
	}

	private onCheckShop(): void {
		this._waitTimes = 0;
		this._needSendBuy = true;
		this.clearTimer();
		this.checkBuySuccess();
		App.timer.doTimeLoop(this, 3000, this.checkBuySuccess);
	}

	/** 支付完成返回*/
	private onShopBack(data: any): void {
		if (data.code == 200) {
			if (data.data.type) {//data.data == true时，成功
				this.clearTimer();
				this.onHttpShopPayBack(data);
			} else {
				this._needSendBuy = true;
			}
		}
	}

	private clearTimer(): void {
		App.timer.clearTimer(this, this.checkBuySuccess);
	}

    /**
     * 购买成功
     */
	private onBuySuccess(id: number, data: any): void {
		if (id == this._uid) {
			this.onHttpShopPayBack(data);
		}
	}

	/** 支付完成返回*/
	private onHttpShopPayBack(data: any): void {
		if (data.code == 200) {
			PanelOpenManager.removePanel(EnumPanelID.WECHAT_QRCODE);
			this.closePanel();
			PanelOpenManager.removePanel(EnumPanelID.GAME_FANG_DONG_BUY);
			App.data.gameHallCenter.updateHeroniesProps(this._uid, { is_shop: true });
			var hd: HeroinesData = App.data.gameHallCenter.getHeroniesData(this._uid);
			Notice.showBottomCenterMessage("购买超值组合礼包成功");
			if (!App.global.forceToPhoneBind()) {
				App.dispatcher.dispatchEvent(GameEvent.GAME_UNLOCK_SUCCESS, this._uid);
			}
			App.dispatcher.dispatchEvent(EventType.DETAIL_BUY_CZZH);
			//window['closeWebView']();
		}
	}

	/**渠道支付返回 */
	private onHttpShopPayOtherBack(data: any): void {
		if (data.code == 200) {
			this._orderId = data.data.order_id;
			if (Config.soEasy) {
				let payinfojson = {
					check: data.data.code, feeid: data.data.order_id, fee: String(Number(data.data.price) * 100), feename: data.data.productName,
					extradata: data.data.order_id, serverid: "1", servername: data.data.ServerName
				}
				GameLog.log('------------请求支付房东----------------payinfojson--,', payinfojson);
				ZmSdk.getInstance().pay(payinfojson, function (data) {
					GameLog.log('------------请求支付房东---------payBack:data,', data);
					if (data.retcode === "0") {
						App.dispatcher.dispatchEvent(EventType.SHOP_IS_SHOP);
					} else if (data.retcode === "1") { //购买失败处理
					} else if (data.retcode === "2") { //初购取消
					} else if (data.retcode === "3") { // 跳转到了支付界面或渠道不支持
					}
				});
			} else if (H5_360_Sdk.getInstance().config360) {
				H5_360_Sdk.getInstance().pay360Param = data.data.code;
				H5_360_Sdk.getInstance().order_id = data.data.order_id;
				H5_360_Sdk.getInstance().paySdk();
				App.dispatcher.dispatchEvent(EventType.SHOP_IS_SHOP);
				GameLog.log("360支付订单号：", this._orderId);
			}
			else if (Config.isLocalApp) {
				GameLog.log('请求后端调steam支付:' + this._orderId);
			}
		}
	}

	private showActPrice(): void {
		if (this._data.rebate_money) {
			this._view.txtPrice.text = this._data.balance_money;
			if (this._data.stop_time > 0) {
				this._view.txtTime.visible = true;
				App.timer.serverTimeEnd(this, this.onActTimer, this._data.stop_time);
			} else {
				this._view.txtTime.visible = false;
			}
		}
	}

	private onActTimer(data: ServerTimeData): void {
		if (data.spuleTime > 0) {
			this._view.txtTime.text = "活动时间剩余 " + StringUtil.formatLeftTimeDHM(data.spuleTime);
		} else {
			App.timer.clearTimer(this, this.onActTimer);
		}
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}

}