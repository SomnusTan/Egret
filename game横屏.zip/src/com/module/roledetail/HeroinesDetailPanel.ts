class HeroinesDetailPanel extends BasePanel {
	private _view: HeroinesDetailUI;
	private _heroniesData: HeroinesData;
	private _groupNewX: number;
	private _groupHuiyiX: number;
	private _groupDuquX: number;

	private _startEffect: GMovieClip;
	private _czzhBtn: ChaoZhiZuHeButton;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new HeroinesDetailUI();
		this.addChild(this._view);
		this._groupNewX = this._view.groupNew.x;
		this._groupHuiyiX = this._view.groupHuiyi.x;
		this._groupDuquX = this._view.groupDuqu.x;

		this._startEffect = new GMovieClip();
		this._startEffect.init("startgame_json", "startgame_png", "startgame");
		this._startEffect.x = this._view.groupNew.x;
		this._startEffect.y = this._view.groupNew.y;
		this._startEffect.play(-1);
	}

	public show(data?: any): void {
		super.show(data);
		Config.hasEnterGame = true;
		if (App.sound.isBgmPlaying == false) {
			var isPlay: string = App.global.storage.getItem(EnumStorageType.HALL_MUSIC_SETTING);
			if (isPlay == "0") {
				App.sound.isCloseBgm = true;
			} else {
				App.sound.isCloseBgm = false;
				App.sound.playBgm(ResPathUtil.getBgmPath(EnumSoundId.BGM), 2000, false, true);
			}
		}
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBack, this, this._view.btnBack);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickGroup, this, this._view.btnOtherStory);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickGroup, this, this._view.groupNew);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickGroup, this, this._view.groupDuqu);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickGroup, this, this._view.groupHuiyi);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onImgShezhi, this, this._view.img_shezhi);
		this._dispatcher.addEventListener(VideoEvent.REPLAYVIDEO, this.onReplayVideo, this);
		this._dispatcher.addEventListener(EventType.DETAIL_BUY_CZZH, this.onBuyCzzhSuccess, this);

		this.resetChildrenTouch();
		this.bindEffect(this._view.groupNew, EnumTouchEffect.ADD_SCALE);

		this._heroniesData = data;
		if (this._heroniesData.getNewMemory == 3) {//解锁了新的结局后，回到详情界面需要提示
			if (Config.isLocalApp == false)
				Notice.showBottomCenterMessage("获得了心动碎片x 5（可在心动女生中兑换额外剧情）");
			App.data.gameHallCenter.updateHeroniesProps(this._heroniesData.id, { getNewMemory: 0 });
		}

		ProtocolCommon.instance().send_heroinesDetail(this._heroniesData.id, new FunctionVO(this.onHttpBack, this));
		this._view.groupHuiyi.visible = false;
		this._view.groupDuqu.visible = false;
		this._view.btnOtherStory.visible = false;
		this._view.btnBack.visible = !Config.isLocalApp;
		this._view.boxSet.visible = Config.isLocalApp;
		if (Config.isLocalApp)
			this._view.boxStory.x = 444;

		// this.onReplayVideo();
		// this._view.txtHeroniesName.textFlow = HtmlUtil.getHtmlStr(this._heroniesData.title + "    <font size=26>" + this._heroniesData.name + "</font>");
		this._view.txtHeroniesName.text = this._heroniesData.title;
		this._view.txtDesc.text = this._heroniesData.depict;
		this._view.groupNew.x = Config.MAIN_WIDTH + this._view.groupNew.anchorOffsetX;
		egret.Tween.get(this._view.groupNew).to({ x: this._groupNewX }, 300, egret.Ease.backInOut).call(this.tweenBack, this);
	}

	private tweenBack(): void {
		this._startEffect.play();
		this._view.addChild(this._startEffect);
	}

	private onImgShezhi(e: egret.TouchEvent): void {
		egret.Tween.pauseTweens(this._view.img_shezhi);
		this._view.img_shezhi.rotation = 19;
		egret.Tween.get(this._view.img_shezhi).to({ rotation: 619 }, 1000, egret.Ease.sineOut);
		PanelOpenManager.openPanel(EnumPanelID.GAMEHALL_SETTING);
	}

	private onReplayVideo(): void {//这里可能更新壁纸，从本地数据中取
		Video.instance().init(this._heroniesData.videoUrl, true, true, null, Video.BOTTOM, null, Config.isLandscape);
	}

	/**
	 * "id": "女主ID",
	 * "money": "关卡金额",
	 * 	"label": "女主标签",
	 *	"is_shop": "是否已经购买",
	 *	"is_toll": "当前关卡是否需要收费",
	 *	"record_type": "记录状态 0:没有记录, 1:有记录, 2:已完结",
	 *	"is_new_collect": 是否有新的收藏 True False
	 */
	private onHttpBack(data: any): void {
		if (!this._heroniesData) return;
		if (data.data.label) {
			var arr: string[] = data.data.label;
			var txt: string = "";
			for (var i: number = 0, len: number = arr.length; i < len; i++) {
				txt += arr[i];
				if (i < arr.length - 1) {
					txt += " | ";
				}
			}
			this._view.txtHeroniesLabel.text = txt;
		}
		if (data.data.dlc_list) {
			var dlcData: HeroinesDlcData;
			this._heroniesData.dlcList = [];
			for (i = 0, len = data.data.dlc_list.length; i < len; i++) {
				dlcData = new HeroinesDlcData();
				dlcData.parse(this._heroniesData.id, data.data.dlc_list[i]);
				this._heroniesData.dlcList.push(dlcData);
			}
			this._view.btnOtherStory.visible = len > 0;
			if (this._view.btnOtherStory.visible) {
				RedDisplay.setRedByDisPlayer(this._view.btnOtherStory.parent, data.data.unlock_dlc_list == 1, 2, this._view.btnOtherStory.x + this._view.btnOtherStory.width - 13, this._view.btnOtherStory.y + 8);
			}
		}

		// 需要播放的视频路径
		this._heroniesData.videoUrl = data.data.video;
		this.onReplayVideo();
		// 提取女主金额
		this._heroniesData.money = data.data.money;
		// 下一关卡是否需要收费
		this._heroniesData.is_toll = data.data.is_toll;
		// 当前是否已经购买了该女主
		this._heroniesData.is_shop = data.data.is_shop;
		this._heroniesData.is_new_collect = data.data.is_new_collect;
		this._heroniesData.gift_package = data.data.gift_package;
		if (this._heroniesData.gift_package) {
			this.addCzzhBtn();
		} else {
			this.removeCzzhBtn();
		}

		// 当前是否有记录,1有记录，2已通关
		var record: number = data.data.record_type;
		this._heroniesData.record_type = record;
		var hasRecord: boolean = record > 0;
		this._view.txtStory.text = record == 1 ? "继续陪伴" : (record == 2 ? "新的故事" : "邂逅她");
		this._view.groupDuqu.visible = hasRecord;
		this._view.groupHuiyi.visible = hasRecord;
		if (hasRecord) {
			this._view.groupDuqu.x = Config.MAIN_WIDTH;
			egret.Tween.get(this._view.groupDuqu).wait(100).to({ x: this._groupDuquX }, 300, egret.Ease.backInOut).call(() => {
				App.global.guide.showView(this._view.btnDuqu, EnumGuideType.DETAIL_READ, this.panelName);
				egret.Tween.removeTweens(this._view.groupDuqu);
			}, this);
			this._view.groupHuiyi.x = Config.MAIN_WIDTH;
			egret.Tween.get(this._view.groupHuiyi).wait(300).to({ x: this._groupHuiyiX }, 300, egret.Ease.backInOut).call(() => {
				if (this._heroniesData && this._heroniesData.is_new_collect) {
					App.global.guide.showView(this._view.btnHuiyi, EnumGuideType.DETAIL_MEMORY, this.panelName);
				}
				egret.Tween.removeTweens(this._view.groupHuiyi);
			}, this);
		}

		// 判断是否已经购买了女主
		if (!this._heroniesData.is_shop) {
			if (this._heroniesData.is_toll) {// 未购买女主,判断下一关是否需要收费
				this._view.txtStory.text = "继续陪伴";// 下一章要收费
			}
		}
		App.data.gameHallCenter.setHeroniesData(this._heroniesData);
		this.showHuiyiRed();
		// App.global.forceToPhoneBind();

	}

	private showHuiyiRed(): void {
		RedDisplay.setRedByDisPlayer(this._view.groupHuiyi, this._heroniesData.is_new_collect, 1, 150);
	}

	private onClickGroup(e: egret.TouchEvent): void {
		switch (e.currentTarget) {
			case this._view.groupNew://新的故事
				// App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
				// if (!this._heroniesData.is_shop && this._heroniesData.is_toll) {// 未购买女主,判断下一关是否需要收费
				// 	var obj: any = { id: this._heroniesData.id, money: this._heroniesData.money, title: this._heroniesData.title };
				// 	if (this._heroniesData.id == EnumGameID.FANG_DONG)
				// 		PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_BUY, obj);
				// 	else
				// 		PanelOpenManager.openPanel(EnumPanelID.HERONIES_BUY, obj);
				// 	this._dispatcher.addEventListener(GameEvent.GAME_UNLOCK_SUCCESS, this.onUnlockSuccess, this);
				// } else {
				// }
				//需求改变，详情界面不展示购买面板，直接进入AVG逻辑
				App.sound.playSoundSwitchClient(EnumSoundId.HEART);
				App.sound.needSkip = true;
				ProtocolCommon.instance().send_heroine_version(this._heroniesData.id, EnumGameID.NO_DLC, this._heroniesData.record_type == 1 ? 0 : 7);
				if (this._heroniesData.record_type == 2) {//改变引导状态
					App.global.guide.changeGuideTo_stateN(EnumGuideType.PRESS_JUMPREAD);
				}
				this.touchChildren = false;
				App.timer.doTimeOnce(this, 5000, this.resetChildrenTouch);
				break;
			case this._view.groupDuqu://读取
				PanelOpenManager.openPanel(EnumPanelID.RECORD, { uid: this._heroniesData.id, type: EnumRecordType.READ, panelName: this.panelName });
				this.closePanel();
				break;
			case this._view.groupHuiyi://回忆
				RedDisplay.setRedImage(this._view.groupHuiyi);
				PanelOpenManager.openPanel(EnumPanelID.MEMORY, this._heroniesData);
				this.closePanel();
				break;
			case this._view.btnOtherStory://他的故事
				PanelOpenManager.openPanel(EnumPanelID.OTHER_STORY, this._heroniesData);
				break;
		}
	}

	private resetChildrenTouch(): void {
		this.touchChildren = true;
	}

	/**
	 * 购买成功
	 */
	private onUnlockSuccess(uid: number): void {
		var hData: HeroinesData = App.data.gameHallCenter.getHeroniesData(uid);
		ProtocolCommon.instance().send_heroine_version(uid, EnumGameID.NO_DLC, hData.record_type == 1 ? 0 : 7);
	}

	private onBack(e: egret.TouchEvent): void {
		App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
		if (Config.isLandscape) {
			App.setOrientation(egret.OrientationMode.LANDSCAPE);
		}
		PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
		PanelOpenManager.removePanel(EnumPanelID.HEROINES_DETAIL);
	}

	private addCzzhBtn(): void {
		if (!this._czzhBtn) {
			this._czzhBtn = new ChaoZhiZuHeButton(this._heroniesData.gift_package);
			this._czzhBtn.x = 100;
			this._czzhBtn.y = 850;
			this._view.addChild(this._czzhBtn);
		}
	}

	private onBuyCzzhSuccess(): void {
		this.removeCzzhBtn();
	}

	private removeCzzhBtn(): void {
		if (this._czzhBtn) {
			this._czzhBtn.dispose();
			this._czzhBtn = null;
		}
	}

	public hide(): void {
		super.hide();
		if (this._startEffect) {
			this._startEffect.stop();
			this._startEffect.remove();
		}
		App.timer.clearTimer(this, this.resetChildrenTouch);
		RedDisplay.setRedImage(this._view.btnOtherStory.parent);
		RedDisplay.setRedImage(this._view.groupHuiyi);
		Video.instance().dispose(true);
		this.removeCzzhBtn();
		this._heroniesData = undefined;
		App.global.guide.removeExistGuide();
	}

	public dispose(): void {
		if (this._startEffect) {
			this._startEffect.dispose();
			this._startEffect = undefined;
		}
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}

	/**
     * 是否需要发送数据
     */
    public get needSendUMeng(): boolean {
        return true;
    }

}