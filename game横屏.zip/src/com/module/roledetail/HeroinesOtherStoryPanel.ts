class HeroinesOtherStoryPanel extends WindowView {

	private _view: HeroinesOtherStoryUI;

	private _heroinesData: HeroinesData;

	private _index: number;

	public constructor() {
		super(589, 810, true);
	}

	protected initView(): void {
		super.initView();
		this._view = new HeroinesOtherStoryUI();
		this.viewSp.addChild(this._view);
		this._view.x = 7;
		this._view.y = -102;
	}

	public show(data?: any): void {
		super.show(data);
		this._heroinesData = data;
		if (this._heroinesData) {
			this._index = 0;
			var dlcData: HeroinesDlcData = this._heroinesData.dlcList[this._index];
			this.topTitle = dlcData.title;
			this._view.txtDetail.text = dlcData.depict;
			this._view.imgBg.source = "other_story_" + dlcData.heroinesId + "_" + dlcData.dlcId + "_png";
			this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onStart, this, this._view.btnStart);
		}
	}


	private onStart(e: egret.TouchEvent): void {
		var dlcData: HeroinesDlcData = this._heroinesData.dlcList[this._index];
		ProtocolCommon.instance().send_heroine_version(this._heroinesData.id, dlcData.dlcId, 1);
	}
}