class ChaoZhiZuHeButton extends egret.Sprite {
	// 初始动画
	private _dragonbonesFactory: dragonBones.EgretFactory;
	// 定义爆破骨骼动画
	private _bubbleEffect: dragonBones.EgretArmatureDisplay;

	private _data: any;

	public constructor(data?: any) {
		super();
		this._data = data;
		var dragonbonesData = RES.getRes("chaozhizuhe_ske_json");
		if (!dragonbonesData) {
			App.res.loadGroup([EnumResGroupName.CHAOZHIZUHE], new FunctionVO(this.onLoadComplete, this));
		} else {
			this.onLoadComplete();
		}
	}

	public setData(value: any): void {
		this._data = value;
		this.play();
	}

	private onLoadComplete(): void {
		this.touchEnabled = true;
		this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
		this._dragonbonesFactory = new dragonBones.EgretFactory();
		// 加载龙骨动画资源
		var dragonbonesData = RES.getRes("chaozhizuhe_ske_json");
		var textureData1 = RES.getRes("chaozhizuhe_tex_json");
		var texture1 = RES.getRes("chaozhizuhe_tex_png");
		//往龙骨工厂里添加资源
		this._dragonbonesFactory.parseDragonBonesData(dragonbonesData);
		this._dragonbonesFactory.parseTextureAtlasData(textureData1, texture1);
		// 构建男孩骨架显示对象
		this._bubbleEffect = this._dragonbonesFactory.buildArmatureDisplay("Armature");
		this.addChild(this._bubbleEffect);
		this.play();
	}

	/**
	 * effectType 0:超值组合 1:整包购买
	 */
	private play(): void {
		if (this._bubbleEffect && this._data) {
			if (this._data.hasOwnProperty("effectType") == false || this._data.effectType == 0)
				this._bubbleEffect.animation.play("chaozhizuhe");
			else
				this._bubbleEffect.animation.play("zhengbaogomai");
		}
	}

	private onClick(e: egret.TouchEvent): void {
		e.stopPropagation();
		if (this._data.panelID) {
			PanelOpenManager.openPanel(this._data.panelID, this._data);
		}
		else {
			PanelOpenManager.openPanel(EnumPanelID.CHAOZHIZUHE, this._data);
		}
	}

	public dispose(): void {
		this._data = null;
		this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
		if (this._bubbleEffect) {
			this._bubbleEffect.animation.stop();
			if (this._bubbleEffect.parent)
				this._bubbleEffect.parent.removeChild(this._bubbleEffect);
			this._bubbleEffect.dispose();
			this._bubbleEffect = null;
		}
		if (this._dragonbonesFactory) {
			this._dragonbonesFactory.clear(true);
			this._dragonbonesFactory = null;
		}
		if (this.parent) {
			this.parent.removeChild(this);
		}
	}

}