class HeroniesSettingPanel extends WindowView {
	private _view: HeroniesSettingUI;
	/**女主ID */
	private _heronieId: number;
	private _posx1: number;//三个端点的位置
	private _posx2: number;
	private _posx3: number;
	private _normalColor: number;
	private _selectColor: number;
	private _needShowName: string;
	/**角色ID */
	private _uid: number

	public constructor() {
		super(450, 496);
	}

	protected initView(): void {
		this._view = new HeroniesSettingUI();
		this._view.y = 75;
		this.viewSp.addChild(this._view);
		this.rightTitle = "设置";

		this._posx1 = 0;
		this._posx2 = 147;
		this._posx3 = 293;

		this._normalColor = 0x666666;
		this._selectColor = 0xFF83BB;
	}

	protected initSkinType(): void {
		this._skinType = EnumWindowType.TYPE_2;
	}

	public show(data?: any): void {
		super.show(data);
		this._uid = App.global.userInfo.uid;
		this._heronieId = data.id;
		this._needShowName = data.panelName;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_bgm);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_effect);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_rolesound);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_autoplay);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btn_sure);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onDragSlider, this, this._view.imgSlide);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onDragOverSlider, this, this._view.imgSlide);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onReleaseOut, this, this._view.imgSlide);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onDragSlider, this, this._view.imgSlideBg);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_END, this.onDragOverSlider, this, this._view.imgSlideBg);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onReleaseOut, this, this._view.imgSlideBg);

		var bgm: string = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_BGM + this._uid + "_" + this._heronieId);
		var effect: string = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_EFFECT + this._uid + "_" + this._heronieId);
		var rolesound: string = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_ROLESOUND + this._uid + "_" + this._heronieId);
		this._view.btn_bgm.selected = !bgm ? true : false;
		this._view.btn_effect.selected = !effect ? true : false;
		this._view.btn_rolesound.selected = !rolesound ? true : false;
		this._view.btn_autoplay.selected = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_AUTOPLAY + this._uid + "_" + this._heronieId) ? true : false;
		var speed: string = App.global.storage.getItem(EnumStorageType.HERONIES_SETTING_WORDSPEED + this._uid + "_" + this._heronieId);

		this._view.imgSlide.x = speed == "1" ? 0 : (speed == "3" ? this._posx3 : this._posx2);
		this._view.txtSpeed1.textColor = this._view.txtSpeed2.textColor = this._view.txtSpeed3.textColor = this._normalColor;
		if (speed) {
			this._view["txtSpeed" + speed].textColor = this._selectColor;
		} else {
			this._view.txtSpeed2.textColor = this._selectColor;
		}
	}

	public hide(): void {
		super.hide();
		if (this._needShowName && Config.hasEnterGame) {
			PanelManager.openPanel(this._needShowName);
		}
		this._needShowName = null;
	}

	private onDragSlider(e: egret.TouchEvent): void {
		App.stage.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onMoveSlider, this);
		this.onMoveSlider(e);
	}

	private onReleaseOut(e: egret.TouchEvent): void {
		this.onDragOverSlider(e);
	}

	private onMoveSlider(e: egret.TouchEvent): void {
		var localx: number = this._view.imgSlide.parent.globalToLocal(e.stageX, 0).x - this._view.imgSlide.width * 0.5;
		let posx: number = localx < 0 ? 0 : (localx > this._posx3 ? this._posx3 : localx);
		this._view.imgSlide.x = posx;
	}

	private onDragOverSlider(e: egret.TouchEvent): void {
		App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
		let s0: number = Math.abs(this._view.imgSlide.x - this._posx1);
		let s1: number = Math.abs(this._view.imgSlide.x - this._posx2);
		let s2: number = Math.abs(this._view.imgSlide.x - this._posx3);
		var min: number = Math.min(s0, s1, s2);
		this._view.imgSlide.x = min == s0 ? 0 : (min == s1 ? this._posx2 : this._posx3);
		var speed: string = min == s0 ? "1" : (min == s1 ? "2" : "3");
		this._view.txtSpeed1.textColor = this._view.txtSpeed2.textColor = this._view.txtSpeed3.textColor = this._normalColor;
		this._view["txtSpeed" + speed].textColor = this._selectColor;
		App.global.storage.setItem(EnumStorageType.HERONIES_SETTING_WORDSPEED + this._uid + "_" + this._heronieId, speed);
		App.stage.removeEventListener(egret.TouchEvent.TOUCH_MOVE, this.onMoveSlider, this);
		if (App.data.gameFangDongCenter.gameId)
			App.data.gameFangDongCenter.updateSetting();
	}

	private onClick(e: egret.TouchEvent): void {
		switch (e.currentTarget) {
			case this._view.btn_bgm:
				App.global.storage.setItem(EnumStorageType.HERONIES_SETTING_BGM + this._uid + "_" + this._heronieId, !this._view.btn_bgm.selected ? "1" : "");
				if (!this._view.btn_bgm.selected) {
					App.sound.isCloseBgm = true;
				} else {
					App.sound.isCloseBgm = false;
				}
				break;
			case this._view.btn_effect:
				App.global.storage.setItem(EnumStorageType.HERONIES_SETTING_EFFECT + this._uid + "_" + this._heronieId, !this._view.btn_effect.selected ? "1" : "");
				App.sound.isCloseSound = !this._view.btn_effect.selected;
				break;
			case this._view.btn_rolesound:
				App.global.storage.setItem(EnumStorageType.HERONIES_SETTING_ROLESOUND + this._uid + "_" + this._heronieId, !this._view.btn_rolesound.selected ? "1" : "");
				App.sound.isCloseVoice = !this._view.btn_rolesound.selected;
				break;
			case this._view.btn_autoplay:
				App.global.storage.setItem(EnumStorageType.HERONIES_SETTING_AUTOPLAY + this._uid + "_" + this._heronieId, this._view.btn_autoplay.selected ? "1" : "");
				if (App.data.gameFangDongCenter.gameId)
					App.data.gameFangDongCenter.updateSetting();
				break;
			case this._view.btn_sure:
				PanelOpenManager.removePanel(EnumPanelID.HERONIES_SETTING);
				break;
		}
	}

	public dispose(): void {
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		super.dispose();
	}
}