class LoadingResView extends BasePanel {
	private _view: LoadingResUI;

	private _scrollRect: egret.Rectangle;
	private _data: any;
	private _showFalseProNum: number = 0;

	private _boyOffsetX: number = 30;
	// 初始骨骼动画
	private _dragonbonesFactory: dragonBones.EgretFactory;
	// 定义男孩骨骼动画
	private _boy_armature: dragonBones.EgretArmatureDisplay;
	// 定义女孩骨骼动画
	private _girl_armature: dragonBones.EgretArmatureDisplay;

	private _listenEffect: ListenEffect;

	public static LOAD_LOCAL_PROGRESS: string = "LoadingResView.LOAD_LOCAL_PROGRESS";
	public static LOAD_LOCAL_SUCCESS: string = "LoadingResView.LOAD_LOCAL_SUCCESS";

	private _loadList: string[];

	private _length: number;

	private _currentGroupName: string;

	private _progress: number;
	/**正加载中 */
	private _isLoading: boolean;

	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new LoadingResUI();
		this.addChild(this._view);
		// 加载龙骨动画资源
		var dragonbonesData = RES.getRes("jindutiao2_ske_json");
		var textureData1 = RES.getRes("jindutiao2_tex_json");
		var texture1 = RES.getRes("jindutiao2_tex_png");
		// 创建龙骨工厂
		this._dragonbonesFactory = new dragonBones.EgretFactory;
		//往龙骨工厂里添加资源
		this._dragonbonesFactory.parseDragonBonesData(dragonbonesData);
		this._dragonbonesFactory.parseTextureAtlasData(textureData1, texture1);
		// 构建男孩骨架显示对象
		this._boy_armature = this._dragonbonesFactory.buildArmatureDisplay("armatureName");
		// 构建女孩显示对象
		this._girl_armature = this._dragonbonesFactory.buildArmatureDisplay("armatureName");
		// 把男孩女孩添加到舞台
		this.addChild(this._boy_armature);
		this.addChild(this._girl_armature);
		this._boyOffsetX = 30;
		// 设置男孩初始位置
		this._boy_armature.x = this._boyOffsetX;
		this._boy_armature.y = 1147;
		// 设置女孩初始位置
		this._girl_armature.x = 670;
		this._girl_armature.y = 1147;

		this._scrollRect = new egret.Rectangle();
		this._scrollRect.height = 50;
		this._isLoading = false;
	}

	public show(data?: any): void {
		super.show(data);
		if (this._isLoading) {
			return;
		}
		App.sound.closeBgm(true, true);
		this._data = data;
		if (this._listenEffect == null) {
			this._listenEffect = new ListenEffect();
		}
		this.addChild(this._listenEffect);
		this._listenEffect.x = Config.MAIN_WIDTH >> 1;
		this._listenEffect.y = 580;
		this._listenEffect.play();

		// 播放男孩及女孩动画
		this._boy_armature.animation.gotoAndPlayByFrame("nanpao", 1, 0);
		this._girl_armature.animation.gotoAndPlayByFrame("nvhai", 1, 0);

		this._progress = 0;
		this.updateProgress("资源加载中", 0);
		this.loadResource();
		this._isLoading = true;
		// this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this, this._view)
	}

	// private onTouch(e: egret.TouchEvent): void {
	// 	PanelManager.removeAllPanel();
	// 	GameManager.exitGame();
	// 	Video.instance().dispose();
	// 	PanelOpenManager.openPanel(EnumPanelID.GAME_HALL);
	// }

	public hide(): void {
		super.hide();
		this._loadList = null;
		this._boy_armature.animation.stop();
		this._girl_armature.animation.stop();
		if (this._listenEffect) {
			this._listenEffect.stop();
		}
		this._isLoading = false;
	}

	private loadResource(): void {
		App.data.gameResourceCenter.disposeFreeChapter(this._data.chapter);
		this._loadList = App.data.gameResourceCenter.getChapterGroupName(this._data.chapter);
		this._length = this._loadList.length;
		this.loadNextGroup(null);
	}

	private loadNextGroup(groupName: string): void {
		if (GameManager.isPlaying == false)
			return;
		var index: number = 0;
		if (groupName) {
			GameLog.log("加载完资源组:" + groupName + "(" + App.res.isGroupLoaded(this._currentGroupName) + ")");
			if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
				App.nativeBridge.log("加载完资源组:" + groupName + "(" + App.res.isGroupLoaded(this._currentGroupName) + ")");
			}
			index = this._loadList.indexOf(groupName);
			index++;
		}
		// if (this.isShowing == false) {
		// 	return;
		// }
		if (index < this._length) {
			this._currentGroupName = this._loadList[index];
			if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
				App.nativeBridge.log("加载资源组:" + this._currentGroupName);
			}
			App.res.setMaxLoadingThread(this._currentGroupName.indexOf(App.data.gameResourceCenter.SOUND_SUFFIX) != -1 ? 1 : App.res.DEFAULT_LOAD_THREAD);
			App.res.loadGroup([this._currentGroupName], new FunctionVO(this.loadNextGroup, this), new FunctionVO(this.onResourceProgress, this));
		}
		else {
			App.res.setMaxLoadingThread(App.res.DEFAULT_LOAD_THREAD);
			this.onLoadAllComplete(groupName);
		}
	}

	private startGame(): void {
		// App.nativeBridge.log("start " + App.data.gameHallCenter.getHeroniesData(this._data.heroine_id).name + " game");
		PanelOpenManager.removePanel(EnumPanelID.LOADING_RESVIEW);
		if (GameManager.isPlaying)
			App.dispatcher.dispatchEvent(this._data.completeEvent);
	}

	private onResourceProgress(event: RES.ResourceEvent): void {
		if (Config.isRelease == false) {
			// GameLog.log("资源已加载:", event.resItem.name + "[" + event.itemsLoaded + "/" + event.itemsTotal + "]");
			GameLog.log(`资源已加载:${event.groupName} [${event.resItem.name}:${event.itemsLoaded}/${event.itemsTotal}]`);
		}
		else if (DeviceUtil.IsAndroid && DeviceUtil.IsNative) {
			App.nativeBridge.log(`资源已加载:${event.groupName} [${event.resItem.name}:${event.itemsLoaded}/${event.itemsTotal}]`);
		}
		var index: number = this._loadList.indexOf(event.groupName) + 1;
		this.updateProgress("", (index - 1) / this._length + event.itemsLoaded / event.itemsTotal / this._length);
	}

	private onLoadAllComplete(groupName: string): void {
		// 修改播放女生亲吻
		this._boy_armature.animation.gotoAndPlayByFrame("nanzhanli", 1, 1);
		this._boy_armature.armature.proxy.addDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onBoyComplete, this);
	}

	private onBoyComplete(e: dragonBones.EgretEvent): void {
		this._boy_armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onBoyComplete, this);
		this._girl_armature.animation.gotoAndPlayByFrame("nvhaiwendao", 1, 1);
		this._girl_armature.armature.proxy.addDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onGirlComplete, this);
	}

	private onGirlComplete(e: dragonBones.EgretEvent): void {
		this._girl_armature.armature.proxy.removeDBEventListener(dragonBones.EgretEvent.COMPLETE, this.onBoyComplete, this);
		App.data.gameResourceCenter.setLoadedResourceChapter(this._data.chapter);
		// 加载完毕跳转到AVG
		this.startGame();
	}

	private onLoadError(event: RES.ResourceEvent): void {
		console.warn("Url:" + event.resItem.url + " has failed to load");
		App.nativeBridge.log("load " + event.resItem.url + " failed");
	}

	private updateProgress(str: string, progress: number): void {
		if (this._progress < progress)
			this._progress = progress;
		this._scrollRect.width = 669 * this._progress;
		this._view.imgProgress.scrollRect = this._scrollRect;
		if (this._progress <= 1 / 3)
			str = "正在偷瞄女孩";
		else if (this._progress <= 2 / 3)
			str = "正在整理形象";
		else
			str = "正在翻看恋爱秘籍";
		this._view.txtLabel.text = str + " " + Math.floor(this._progress * 100) + "%";
		// GameLog.log("加载到:" + this._view.txtLabel.text);
		// 提取男生位置
		var boyPosition: number = this._boyOffsetX + this._scrollRect.width;
		// 判断男生位置是否小于 550
		if (boyPosition <= 540) {
			this._boy_armature.x = boyPosition;
		}
		else if (this._boy_armature.x != 540) {
			this._boy_armature.x = 540;
		}
	}

	public dispose(): void {
		// 停止男孩女孩骨骼动画
		if (this._boy_armature) {
			this._boy_armature.animation.stop();
			if (this._boy_armature.parent)
				this._boy_armature.parent.removeChild(this._boy_armature);
			this._boy_armature.dispose();
			this._boy_armature = null;
		}
		if (this._girl_armature) {
			this._girl_armature.animation.stop();
			if (this._girl_armature.parent)
				this._girl_armature.parent.removeChild(this._girl_armature);
			this._girl_armature.dispose();
			this._girl_armature = null;
		}
		if (this._listenEffect) {
			this._listenEffect.dispose();
			this._listenEffect = null;
		}

		this._data = null;
		this._view.imgProgress.scrollRect = null;
		this._scrollRect = null;
		if (this._view) {
			this._view.dispose();
			this._view = undefined;
		}
		if (this._dragonbonesFactory) {
			this._dragonbonesFactory.clear(true);
			this._dragonbonesFactory = null;
		}
		super.dispose();
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}

	/**
     * 是否需要发送数据
     */
    public get needSendUMeng(): boolean {
        return true;
    }

}