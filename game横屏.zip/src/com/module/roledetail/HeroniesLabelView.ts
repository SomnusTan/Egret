class HeroniesLabelView  extends BaseUI{
	public txtSign:eui.Label;

	public constructor() {
		super("HeroniesLabelSkin");
	}

	public show(txt?: string): void {
		this.txtSign.text = txt;
	}
}