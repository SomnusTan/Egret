class RecordPanel extends BasePanel {
	private _view: RecordUI;

	private _scrollPanel: eui.Scroller;
	private _itemGroup: eui.Group;

	private _itemArr: RecordItem[];

	/** 0：存档，1：读档 */
	private _type: number;
	private _uid: number;
	private _panelName: string;
	public constructor() {
		super();
	}

	protected init(): void {
		this._view = new RecordUI();
		this.addChild(this._view);

		this._itemGroup = new eui.Group();
		this._scrollPanel = new eui.Scroller();
		this._scrollPanel.skinName="skins.ScrollerSkin"
		this._scrollPanel.scrollPolicyH = eui.ScrollPolicy.OFF;
		this._scrollPanel.width = this._view.groupItem.width;
		this._scrollPanel.height = this._view.groupItem.height;
		this._view.groupItem.addChild(this._scrollPanel);
		this._itemArr = [];
		var item: RecordItem;
		for (var i: number = 0; i < 6; i++) {
			item = new RecordItem(i);
			item.x = 9 + i % 2 * 351;
			item.y = Math.floor(i / 2) * 606;
			this._itemGroup.addChild(item);
			this._itemArr.push(item);
		}
	}

	public show(data?: any): void {
		super.show(data);
		this._uid = data.uid;
		this._type = data.type;
		this._panelName = data.hasOwnProperty("panelName") ? data.panelName : "";

		this._view.btnReplay.visible = this._type == EnumRecordType.READ;

		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnBack);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnReplay);
		this._dispatcher.addEventListener(RecordEvent.RECORD_LIST, this.onRecordList, this);
		ProtocolCommon.instance().send_heroine_archive_list(this._uid);
		this._scrollPanel.viewport = this._itemGroup;
		if (this._scrollPanel.viewport) {
			this._scrollPanel.viewport.scrollV = 0;//每次都是显示第一个
		}
	}

	private onRecordList(data: any): void {
		// GameLog.log('onRecordList::', data);
		this.clearItems();
		var list: any[] = data.data;
		for (var i: number = 0; i < this._itemArr.length; i++) {
			this._itemArr[i].show(this._uid, this._type, list[i]);
		}
		ScrollerCenter.hideVerticalScrollBar(this._scrollPanel);
	}

	private onClick(e: egret.TouchEvent): void {
		switch (e.currentTarget) {
			case this._view.btnBack:
				App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
				this.closePanel();
				if (this._panelName == PanelRegister.ENDING) {
					return;
				}
				if (GameManager.isPlaying) {
					PanelOpenManager.openPanel(EnumPanelID.GAME_FANG_DONG_MENU);
				}
				if (this._panelName) {
					let data: any;
					if (this._panelName == PanelRegister.HEROINES_DETAIL) {
						data = App.data.gameHallCenter.getHeroniesData(this._uid);
					}
					PanelManager.openPanel(this._panelName, data);
				}
				break;
			case this._view.btnReplay:
				App.sound.playSoundSwitchClient(EnumSoundId.BUBBLE);
				Alert.show(EnumAlertContent.RESTART_AVG_KOUYA, "确定|取消", new FunctionVO(this.onCloseHandler, this));
				break;
		}
	}

	private onCloseHandler(data: any): void {
		if (data.type == Alert.OK) {
			this.closePanel();
			PanelOpenManager.removePanel(EnumPanelID.ENDING);
			if (GameManager.isPlaying == false) {//在游戏外
				ProtocolCommon.instance().send_heroine_version(this._uid, EnumGameID.NO_DLC, 7);
			} else {
				GameManager.startGame(this._uid, EnumGameID.NO_DLC, { id: this._uid, saveId: 7, isInGame: true });
			}
			//改变引导状态
			App.global.guide.changeGuideTo_stateN(EnumGuideType.PRESS_JUMPREAD);
		}
	}

	private clearItems(): void {
		for (var i: number = 0; i < this._itemArr.length; i++) {
			this._itemArr[i].hide();
		}
	}

	public hide(): void {
		super.hide();
		this.clearItems();
		App.dispatcher.dispatchEvent(VideoEvent.REPLAYVIDEO);
	}

	public dispose(): void {
		super.dispose();
		for (var i: number = 0; i < this._itemArr.length; i++) {
			if (this._itemArr[i]) {
				this._itemArr[i].dispose();
				this._itemArr[i] = undefined;
			}
		}
		this._itemArr = undefined;
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}
}