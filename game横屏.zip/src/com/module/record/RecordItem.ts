class RecordItem extends BaseUI {
	public imgBg: eui.Image;
	public txtNull: eui.Label;
	public imgNocontent: eui.Image;
	public imgRecord: eui.Image;
	public imgMask: eui.Rect;
	public imgText: eui.Image;
	public txtDesc: eui.Label;

	/** 存档id：6：分叉点自动存，1-5：手动存*/
	public scheduleId: number;
	private _uid: number;
	private _type: number;
	private _dispatcher: DispatcherRegister;
	private _hasRecord: boolean;

	public constructor(index: number) {
		super("RecordItemSkin");

		this.scheduleId = index;
		if (this.scheduleId == 0) {
			this.scheduleId = 6;
			this.imgBg.filters = FilterUtil.FILTER_DARK;
			// this.filters = FilterUtil.FILTER_GRAY;
		} else {
			this.imgBg.filters = null;
			// this.filters = null;
		}

		// var canOperate: boolean = index > 0;
		// this.touchEnabled = canOperate;
		// this.touchChildren = canOperate;

		this._dispatcher = new DispatcherRegister();
		this.txtDesc.text = "";
	}
	/**
	 * @param uid  女主id
	 * @param type 0存档，1读档
	 * @param data 数据
	 */
	public show(uid: number, type: number, data: any): void {
		// GameLog.log('RecordItem :: ' + this.scheduleId, data);
		this.imgMask.graphics.clear();
		this.imgMask.graphics.beginFill(0);
		this.imgMask.graphics.drawRoundRect(0, 0, this.imgMask.width, this.imgMask.height, 20, 20);
		this.imgMask.graphics.endFill();
		this._uid = uid;
		this._type = type;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this);
		this.imgRecord.mask = this.imgMask;
		this._dispatcher.addEventListener(egret.Event.COMPLETE, this.onLoadComplete, this, this.imgRecord);

		if (data.thumbnail) {
			this._hasRecord = true;
			this.imgRecord.source = data.thumbnail;
			this.txtNull.visible = false;
			this.imgNocontent.visible = false;
			if (this.scheduleId == 6) { //系统自动存档位置
				this.txtDesc.text = StringUtil.format(new Date(data.time * 1000), "M月D日 h时m分") + "(自动存档)";
			} else {
				this.txtDesc.text = StringUtil.format(new Date(data.time * 1000), "M月D日 h时m分");
			}
			this.imgText.visible = true;
		} else {
			this._hasRecord = false;
			this.imgRecord.source = undefined;
			this.txtNull.visible = true;
			this.imgNocontent.visible = true;
			if (this.scheduleId == 6) { //系统自动存档位置
				this.imgText.visible = true;
				this.txtDesc.text = "系统自动存档";
			} else {
				this.imgText.visible = false;
				this.txtDesc.text = "";
			}
		}
	}

	private onLoadComplete(e: egret.Event): void {
		this.imgRecord.scaleY = this.imgRecord.width / this.imgRecord.texture.textureWidth;
	}

	private onClick(e: egret.TouchEvent): void {
		if (this._hasRecord == false && this._type == EnumRecordType.READ) return;
		if (this._type == EnumRecordType.SAVE && this.scheduleId == 6) return;
		if (this._type == EnumRecordType.SAVE) {
			if (this._hasRecord) {
				App.sound.playSoundSwitchClient(EnumSoundId.BUBBLE);
				Alert.show(EnumAlertContent.SAVE_RECORD, "确定覆盖|取消覆盖", new FunctionVO(this.onCloseHandler, this));
			} else {
				App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
				ProtocolCommon.instance().send_chat_save_schedule(this._uid, this.scheduleId, new FunctionVO(this.onSaveSuccess, this));
			}
		} else {
			if (this._hasRecord) {
				App.sound.playSoundSwitchClient(EnumSoundId.BUBBLE);
				Alert.show(EnumAlertContent.READ_RECORD, "确定读取|取消读取", new FunctionVO(this.onCloseHandler1, this));
			}
		}
	}
	/** 存 */
	private onCloseHandler(data: any): void {
		if (data.type == Alert.OK) {
			ProtocolCommon.instance().send_chat_save_schedule(this._uid, this.scheduleId, new FunctionVO(this.onSaveSuccess, this));
		}
	}
	/** 读 */
	private onCloseHandler1(data: any): void {
		if (data.type == Alert.OK) {
			PanelOpenManager.removePanel(EnumPanelID.ENDING);
			if (GameManager.isPlaying == false) {//在游戏外
				ProtocolCommon.instance().send_heroine_version(this._uid, EnumGameID.NO_DLC, this.scheduleId);
			} else {
				PanelOpenManager.removePanel(EnumPanelID.RECORD);
				GameManager.startGame(this._uid, EnumGameID.NO_DLC, { id: this._uid, saveId: this.scheduleId, isInGame: true });
				// ProtocolFangDong.instance().send_chat_init(this._uid, this.scheduleId);
			}
		}
	}
	private onSaveSuccess(data: any): void {
		if (ResponseUtil.checkResponseData(data)) {
			// GameLog.log('保存进度成功');
			ProtocolCommon.instance().send_heroine_archive_list(this._uid);
		}
	}

	public hide(): void {
		this._dispatcher.removeAllListeners();
		if (this.imgRecord.source) {
			RES.destroyRes(this.imgRecord.source.toString());
			this.imgRecord.source = undefined;
		}
		this.txtDesc.text = "";
	}

	public dispose(): void {
		this._dispatcher = undefined;
		super.dispose();
	}
}