/**
 * 通用弹框面板基类
 */
class WindowView extends BasePanel {
	protected _windowView: WindowViewUI;
	protected _skinType: number;

	public constructor(w: number, h: number, force: boolean = false) {
		super();
		this.setWH(w, h, force);
		this.touchEnabled = false;
	}

	protected init(): void {
		this._windowView = new WindowViewUI();
		this.addChild(this._windowView);

		this.initView();
		// this.initSkinType();
		// this.changePanelSkin();
	}
	/** 子类重写此方法添加面板内容 */
	protected initView(): void {
	}
	/** 皮肤类型-EnumWindowType常量 */
	protected initSkinType(): void {
		this._skinType = EnumWindowType.TYPE_1;
	}
	/** 
	 * 切换面板背景皮肤
	 */
	protected changePanelSkin(): void {
		// this._windowView.imghead_1.visible = this._skinType == EnumWindowType.TYPE_1;
		// if (this._skinType == EnumWindowType.TYPE_0) {
		// 	this._windowView.imghead.source = "";
		// 	this._windowView.imgfoot.source = "";
		// } else {
		// 	this._windowView.imghead.source = "window_json.window_head_" + this._skinType;
		// 	this._windowView.imgfoot.source = "window_json.window_foot_" + this._skinType;
		// }
	}
	/** 右侧文本标题 */
	protected set rightTitle(value: string) {
		this._windowView.groupCenterTitle.visible = false;
		this._windowView.groupTopTitle.visible = false;
		if (value) {
			this._windowView.groupRightTitle.visible = true;
			this._windowView.txtRightTitle.text = value;
		} else {
			this._windowView.groupRightTitle.visible = false;
			this._windowView.txtRightTitle.text = "";
		}
	}
	/** 中间文本标题 */
	protected set centerTitle(value: string) {
		this._windowView.groupRightTitle.visible = false;
		this._windowView.groupTopTitle.visible = false;
		if (value) {
			this._windowView.groupCenterTitle.visible = true;
			this._windowView.txtCenterTitle.text = value;
		} else {
			this._windowView.groupCenterTitle.visible = false;
			this._windowView.txtCenterTitle.text = "";
		}
	}
	/** 顶部文本标题 */
	protected set topTitle(value: string) {
		this._windowView.groupRightTitle.visible = false;
		this._windowView.groupCenterTitle.visible = false;
		if (value) {
			this._windowView.groupTopTitle.visible = true;
			this._windowView.txtTopTitle.text = value;
		} else {
			this._windowView.groupTopTitle.visible = false;
			this._windowView.txtTopTitle.text = "";
		}
	}

	protected onClose(e?: egret.TouchEvent): void {
		PanelManager.removePanelByName(this.panelName);
	}

	public show(data?: any): void {
		super.show(data);
	}

	public dispose(): void {
		if (this._windowView) {
			this._windowView.dispose();
			this._windowView = undefined;
		}
		this.removeChildren();
		super.dispose();
	}
	/** 内容的宽高 */
	public setWH(w: number, h: number, force: boolean = false): void {
		if (force) {
			this._windowView.width = w + 8;
			this._windowView.imgBg.width = w + 8;
			this._windowView.imgBg0.width = w + 8;
		}
		this._windowView.height = h + 140;
		this._windowView.imgBg.height = h + 140;
		this._windowView.imgBg0.height = h + 140;
		this.resize();
	}
	/***定位 */
	public resize(): void {
	}

	public get width(): number {
		return this._windowView.width;
	}
	public get height(): number {
		return this._windowView.height;
	}

	/** 界面容器 */
	public get viewSp(): eui.Group {
		return this._windowView.groupView;
	}
}