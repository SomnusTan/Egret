class WindowView3 extends BasePanel {

    protected _windowView: WindowView3UI;

    public constructor(w: number, h: number, title: string) {
        super();
        this.setWH(w, h);
        this.setTitle(title);
    }

    protected init(): void {
        super.init();
        this._windowView = new WindowView3UI();
        this.addChild(this._windowView);
    }

    public dispose(): void {
        if (this._windowView) {
            this._windowView.dispose();
            this._windowView = undefined;
        }
        this.removeChildren();
        super.dispose();
    }

    public show(data?: any): void {
        super.show(data);

    }

    public hide(): void {
        super.hide();

    }

    protected onClose(e?: egret.TouchEvent): void {
        PanelManager.removePanelByName(this.panelName);
    }

    /**
     * 设置标题
     */
    public setTitle(title: string): void {
        this._windowView.txtTitle.text = title;
    }

    /** 内容的宽高 */
    public setWH(w: number, h: number): void {
        this._windowView.width = w + 44;
        this._windowView.height = h + 104;
        this.resize();
    }

    /***定位 */
    public resize(): void {

    }

    public get width(): number {
        return this._windowView.width;
    }
    public get height(): number {
        return this._windowView.height;
    }

    /** 界面容器 */
    public get viewSp(): eui.Group {
        return this._windowView.container;
    }
}