class WindowView2 extends BasePanel {
	protected _windowView: WindowView2UI;

	public constructor(w: number, h: number) {
		super();
		this.setWH(w, h);
		this.touchEnabled = false;
	}

	protected init(): void {
		this._windowView = new WindowView2UI();
		this.addChild(this._windowView);

		this.initView();
	}
	/** 子类重写此方法添加面板内容 */
	protected initView(): void {
	}

	protected onClose(e: egret.TouchEvent): void {
		PanelManager.removePanelByName(this.panelName);
	}

	public show(data?: any): void {
		super.show(data);
	}

	public dispose(): void {
		super.dispose();
		if (this._windowView) {
			this._windowView.dispose();
			this._windowView = undefined;
		}
		this.removeChildren();
	}
	/** 内容的宽高 */
	public setWH(w: number, h: number): void {
		this._windowView.width = w + 60;
		this._windowView.height = h + 60;
		this.resize();
	}
	/***定位 */
	public resize(): void {
	}

	public get width(): number {
		return this._windowView.width;
	}
	public get height(): number {
		return this._windowView.height;
	}

	/** 界面容器 */
	public get viewSp(): eui.Group {
		return this._windowView.groupView;
	}
}