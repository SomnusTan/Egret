class MemoryPanel extends BasePanel {
	private _view: MemoryViewUI;

	private _memoryItems: MemoryItem[];

	private _scrollPanel: eui.Scroller;
	private _group: eui.Group;
	// private _bg: h5_engine.GSprite;
	private _lastIndex: number;
	private _curBmp: egret.Bitmap;
	private _titleTxtArr: string[];
	private _heroniesData: HeroinesData;

	private static _memoryPool: MemoryItem[] = [];
	private _endNullImg: eui.Image;//没有回忆的图片展示

	public constructor() {
		super();
	}

	public static getMemoryItem(): MemoryItem {
		if (this._memoryPool.length > 0) {
			return this._memoryPool.pop();
		}
		return new MemoryItem();
	}

	protected init(): void {
		this._view = new MemoryViewUI();
		this.addChild(this._view);
		this._view.viewStack.height = Config.MAIN_HEIGHT - 260;

		this._titleTxtArr = ["动态壁纸", "回忆视频", "心跳结局"];

		this._group = new eui.Group();
		this._scrollPanel = new eui.Scroller();
		this._scrollPanel.skinName="skins.ScrollerSkin"
		this._scrollPanel.scrollPolicyH = eui.ScrollPolicy.OFF;
		this._scrollPanel.width = this._view.viewStack.width;
		this._scrollPanel.height = this._view.viewStack.height;
		// this._bg = new h5_engine.GSprite();
		// this._bg.graphics.beginFill(0xFFFFFF, 1);
		// this._bg.graphics.drawRect(0, 0, 720, Config.SCREEN_HEIGHT);
		// this._bg.graphics.endFill();
		// this._view.addChildAt(this._bg, 0);

		this._memoryItems = [];
	}

	public show(data?: any): void {
		super.show(data);
		this._heroniesData = data;
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnBack);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnBizhi);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnShipin);
		this._dispatcher.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this, this._view.btnJieju);
		this._lastIndex = -1;
		this._view.txtNew.visible = false;
		this.setViewStackData(0);
	}

	private onClick(e: egret.TouchEvent): void {
		switch (e.currentTarget) {
			case this._view.btnBack:
				App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
				PanelOpenManager.removePanel(EnumPanelID.MEMORY);
				PanelOpenManager.openPanel(EnumPanelID.HEROINES_DETAIL, this._heroniesData);
				break;
			case this._view.btnBizhi:
				this.setViewStackData(0);
				break;
			case this._view.btnShipin:
				this.setViewStackData(1);
				break;
			case this._view.btnJieju:
				this.setViewStackData(2);
				break;
		}
	}

	private setViewStackData(index: number): void {
		if (this._lastIndex == index) return;
		ProtocolCommon.instance().send_user_favorite_list(index + 1, this._heroniesData.id, 1, new FunctionVO(this.onListBack, this, index));
	}

	private onListBack(data: any, index: number): void {
		this._view.viewStack.selectedIndex = index;
		this._view.txtTitle.text = this._titleTxtArr[index];
		if (this._lastIndex != -1) {
			this.onBmpOver();
			var lastGroup: eui.Group = this._view.viewStack.getChildAt(this._lastIndex) as eui.Group;
			var texture: egret.Texture = BitmapDataUtil.createTextureByClass(lastGroup);
			this._curBmp = new egret.Bitmap(texture);
		}
		this.clearMemoryItems();
		if (data.data.hasOwnProperty("obtained") && data.data.hasOwnProperty("total")) {
			this._view.txtNumber.text = "（" + data.data.obtained + "/" + data.data.total + "）";
		} else {
			this._view.txtNumber.text = " ";
		}
		App.nativeBridge.log("设置的进度值是:" + this._view.txtNumber.text);
		var child: eui.Group = this._view.viewStack.getChildAt(index) as eui.Group;
		var showArr: any[] = data.data.data;
		var item: MemoryItem;
		var hasNewVideo: boolean = false;
		if (!showArr || showArr.length == 0) {//没有数据的时候
			if (this._endNullImg == undefined) {
				this._endNullImg = new eui.Image(ResPathUtil.getCommonImageRes("memory_end_null"));
				this._endNullImg.x = 106;
				this._endNullImg.y = 252;
			}
			this._endNullImg.visible = true;
			child.addChild(this._endNullImg);
			// item = MemoryPanel.getMemoryItem();
			// item.collectType = index + 1;
			// item.uid = this._heroniesData.id;
			// item.x = 106;
			// item.y = 252;
			// item.showBg(ResPathUtil.getCommonImageRes("memory_end_null"));
			// child.addChild(item);
			// this._memoryItems.push(item);
		} else {
			if (this._endNullImg)
				this._endNullImg.visible = false;
			for (var i: number = 0; i < showArr.length; i++) {
				item = MemoryPanel.getMemoryItem();
				item.collectType = index + 1;
				item.uid = this._heroniesData.id;
				item.x = 9 + i % 2 * 351;
				item.y = Math.floor(i / 2) * 366;
				item.showNetImg(showArr[i]);
				this._group.addChild(item);
				this._memoryItems.push(item);
				if (showArr[i].is_new == 1 && showArr[i].is_dlc) {
					hasNewVideo = true;
				}
			}
			this._view.txtNew.visible = hasNewVideo;
			this._scrollPanel.viewport = this._group;
			if (this._scrollPanel.viewport) {
				this._scrollPanel.viewport.scrollV = 0;//每次都是显示第一个
			}
			child.addChild(this._scrollPanel);
			ScrollerCenter.hideVerticalScrollBar(this._scrollPanel);
		}

		(this._view.btnChange.getChildAt(0) as eui.Image).source = "memory_json.memory_btn" + index + "_png";
		this._view.btnChange.x = index == 0 ? this._view.btnBizhi.x : (index == 1 ? this._view.btnShipin.x : this._view.btnJieju.x);
		// this._view.btnBizhi.filters = index == 0 ? null : FilterUtil.FILTER_GRAY;
		// this._view.btnShipin.filters = index == 1 ? null : FilterUtil.FILTER_GRAY;
		// this._view.btnJieju.filters = index == 2 ? null : FilterUtil.FILTER_GRAY;

		if (this._curBmp) {
			this._curBmp.y = this._view.viewStack.y;
			this._view.addChild(this._curBmp);
			// GameLog.log('this._lastIndex : ' + this._lastIndex, "index : " + index);
			var bmpTox: number = index > this._lastIndex ? -720 : 720;
			this._view.viewStack.x = index > this._lastIndex ? 720 : -720;
			egret.Tween.get(this._curBmp).to({ x: bmpTox }, 300).call(this.onBmpOver, this);
			egret.Tween.get(this._view.viewStack).to({ x: 0 }, 300);
		}
		this._lastIndex = index;
	}

	/** 缓动结束 */
	private onBmpOver(): void {
		this.removeBmp();
	}
	/** 移除临时资源 */
	private removeBmp(): void {
		if (this._curBmp) {
			egret.Tween.removeTweens(this._curBmp);
			egret.Tween.removeTweens(this._view.viewStack);
			if (this._curBmp.parent) {
				this._curBmp.parent.removeChild(this._curBmp);
			}
			if (this._curBmp.texture) {
				this._curBmp.texture.dispose();
				this._curBmp.texture = undefined;
			}
		}
		this._curBmp = undefined;
	}

	private clearMemoryItems(): void {
		for (var i: number = 0; i < this._memoryItems.length; i++) {
			this._memoryItems[i].remove();
			MemoryPanel._memoryPool.push(this._memoryItems[i]);
		}
		this._memoryItems = [];
	}

	public hide(): void {
		super.hide();
		this.clearMemoryItems();
		App.dispatcher.dispatchEvent(VideoEvent.REPLAYVIDEO);
		ProtocolCommon.instance().send_user_close_favorite(this._heroniesData.id);
	}

	public dispose(): void {
		super.dispose();
		this._scrollPanel.removeChildren();
		this._scrollPanel = undefined;
		if (this._endNullImg) {
			if (this._endNullImg.parent) {
				this._endNullImg.parent.removeChild(this._endNullImg);
			}
			this._endNullImg = undefined;
		}
		if (this._memoryItems) {
			for (var i: number = 0; i < this._memoryItems.length; i++) {
				if (this._memoryItems[i]) {
					this._memoryItems[i].dispose();
					this._memoryItems[i] = null;
				}
			}
		}
		this._memoryItems = undefined;
		this.removeBmp();
		this._group = undefined;
		// if (this._bg) {
		// 	if (this._bg.parent) {
		// 		this._bg.parent.removeChild(this._bg);
		// 	}
		// 	this._bg = undefined;
		// }
		this._titleTxtArr = undefined;
	}

	public get width(): number {
		return Config.MAIN_WIDTH;
	}

	public get height(): number {
		return Config.MAIN_HEIGHT;
	}
}