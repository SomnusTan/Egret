class MemoryItem extends BaseUI {
	public groupBg: eui.Group;
	public imgShow: eui.Image;
	public imgMask: eui.Rect;
	public imgText: eui.Image;
	public txtTitle: eui.Label;
	public groupUse: eui.Group;
	public imgSign: eui.Image;
	public imgPlay: eui.Image;

	/** 1动态壁纸2回忆视频3心跳结局 */
	public collectType: number;
	public uid: number;//女主id
	private _collectId: number;//收藏id
	private _isWallPaper: boolean;

	public constructor() {
		super("MemoryVideoSkin");
	}

	// public showBg(skin: string): void {
	// 	this.groupBg.visible = false;
	// 	this.groupUse.visible = false;
	// 	this.imgText.visible = false;
	// 	this.txtTitle.visible = false;
	// 	this.imgPlay.visible = false;
	// 	this.imgShow.source = skin;
	// }

	/**{"id": "收藏ID",
	 * "time": "时间戳",
	 * "type": "收藏列表: 1:对白, 2:电话, 3:微信, 4:视频, 5:条件分歧节点",
	 * "title": "收藏标题", 
	 * "is_wallpaper": "正在使用的壁纸", 
	 * "is_new 1:最新 0：无",
	 * "collect_image": "收藏展示图URL", }
	 */
	public showNetImg(data: any): void {
		this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
		App.dispatcher.addEventListener(MemoryEvent.CHANGE_BIZHI, this.onChangeBizhi, this);
		if (this.collectType == EnumVideoType.DONGTAI_BIZHI) {
			this.imgPlay.visible = false;
		} else if (this.collectType == EnumVideoType.XINTIAO_JIEJU && data.type == 1) {
			this.imgPlay.visible = false;
		} else {
			this.imgPlay.visible = true;
		}

		if (this.collectType == EnumVideoType.XIN_DONG1_VIDEO && data.is_walfare == 1) {
			this.imgText.source = "memory_json.memory_titlebg1_png";
			this.txtTitle.strokeColor = 0XF82680;
		} else {
			this.imgText.source = "common_v1_rail_png";
			this.txtTitle.strokeColor = 0x6073FF;
		}
		this._collectId = data.id;
		var url: string = data.collect_image;
		var title: string = data.title;
		this._isWallPaper = data.is_wallpaper;
		this.groupUse.visible = this._isWallPaper || Number(data.is_new) == 1 || data.is_dlc;
		if (this.groupUse.visible) {
			if (data.is_dlc) {
				this.imgSign.source = "memory_json.memory_welfare_png";
			}
			else {
				this.imgSign.source = this._isWallPaper ? "memory_json.memory_using_png" : "memory_json.memory_new_png";
			}
		}
		this.groupBg.visible = true;
		this.imgText.visible = true;
		this.txtTitle.visible = true;
		this.txtTitle.text = title;
		// GameLog.log("MemoryItem::showNetImg() --  " + RES.getRes(url), this._data);
		this.imgMask.graphics.clear();
		this.imgMask.graphics.beginFill(0);
		this.imgMask.graphics.drawRoundRect(0, 0, this.imgMask.width, this.imgMask.height, 20, 20);
		this.imgMask.graphics.endFill();
		this.imgShow.mask = this.imgMask;
		this.imgShow.source = url.indexOf("/.") != -1 ? "" : url;
	}

	private onChangeBizhi(collectId: number) {
		this.groupUse.visible = this._collectId == collectId;
		this._isWallPaper = this.groupUse.visible;
		if (this._isWallPaper) {
			this.imgSign.source = "memory_json.memory_using_png";
		}
		// this.txtSign.text = "使用中";
	}

	private onClick(e: egret.TouchEvent): void {
		if (this.collectType != EnumVideoType.HUIYI_SHIPIN) {//壁纸和结局查看时播放按键音
			App.sound.playSoundSwitchClient(EnumSoundId.CLICK);
		}
		if (this.groupUse.visible && this.imgSign.source != "memory_json.memory_welfare_png") {//最新解锁标识去掉
			// this.txtSign.text = this._isWallPaper ? "使用中" : "";
			this.imgSign.source = this._isWallPaper ? "memory_json.memory_using_png" : "";
			this.groupUse.visible = this._isWallPaper;
		}
		ProtocolCommon.instance().send_user_collect_info(this.collectType, this.uid, this._collectId, new FunctionVO(this.onVideoPlay, this));
	}

	private onVideoPlay(data: any): void {
		//如果都是视频的话。心跳结局特殊处理，有只展示一张图片的情况
		var url: string = data.data.url;
		GameLog.log('data.data.url :: == ' + url);
		if (data.data.type == 4 || this.collectType != EnumVideoType.XINTIAO_JIEJU) {//动态壁纸+回忆视频+（心跳结局中类型4）的才是播放视频
			var completeHandler: FunctionVO = null;
			var muted: boolean = this.collectType == EnumVideoType.DONGTAI_BIZHI ? true : false;
			var loop: boolean = this.collectType == EnumVideoType.DONGTAI_BIZHI ? true : false;
			if (!loop) {
				completeHandler = new FunctionVO(this.onPlayEnd, this);
			}
			Video.instance().init(url, muted, loop, completeHandler, Video.TOP, null, Config.isLandscape);
			PanelOpenManager.openPanel(EnumPanelID.VIDEO_BUTTON, {
				type: this.collectType, uid: this.uid, collectId: this._collectId,
				using: this._isWallPaper
			});
		} else if (this.collectType == EnumVideoType.XINTIAO_JIEJU && data.data.type == 1) {
			PanelOpenManager.openPanel(EnumPanelID.FULL_SCREEN_IMAGE, { url: url });
		} else {
		}
	}

	private onPlayEnd(): void {
		Video.instance().dispose();
	}

	public remove(): void {
		super.remove();
		if (this.imgShow.source) {
			RES.destroyRes(this.imgShow.source.toString());
			this.imgShow.source = undefined;
		}
		this.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
		App.dispatcher.removeEventListener(MemoryEvent.CHANGE_BIZHI, this.onChangeBizhi, this);
	}
}