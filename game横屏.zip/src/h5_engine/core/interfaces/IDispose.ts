interface IDispose
{
	isDispose:boolean;
	dispose():void;
}