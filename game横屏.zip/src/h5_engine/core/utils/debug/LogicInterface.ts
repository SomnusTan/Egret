module h5_engine {
	export class LogicInterface {
		public constructor() {
		}
		public static instance:h5_engine.LogicInterface;
		public log(... args):void {
		}

		public logError(... args):void {
		}

		public logInfo(... args):void {
		}

		public logDebug(... args):void {
		}

		public logWarn(... args):void {
		}

		public logStack(... args):void {
		}

		public logXingneng(... args):void {
		}
	}
}