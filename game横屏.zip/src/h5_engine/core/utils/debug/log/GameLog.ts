class GameLog {
	public constructor() {
	}

	public static isTraceLog: boolean = false;

	public static RED: string = "color:red";

	public static GREEN: string = "color:green";

	public static YELLOW: string = "color:yellow";

	public static BLUE: string = "color:blue";


	/***
	 * 代码耗时测试
	 * des:
	 * by: guwanyuan(顾万圆)
	 * 2016-2-27 上午3:19:17
	 ***/
	public static codeTimeCal(str: string, fuc: Function, thisAny: any, ...args): any {
		var t: number = egret.getTimer();
		var ret: any = fuc.apply(null, args);
		var t2: number = egret.getTimer() - t;
		if (GameLog.isTraceLog) {
			console.log(str, "代码耗时", t2);
		}
		if (h5_engine.LogicInterface.instance) {
			h5_engine.LogicInterface.instance.logInfo(str, "代码耗时", t2);
		}
		return ret;
	}

	/**
	 * 打印一些调试信息
	 */
	public static log(...args): void {
		if (GameLog.isTraceLog) {
			if (args.length > 1 && typeof args[args.length - 1] == "string" && args[args.length - 1].indexOf("color:") == 0) {
				console.log("%c" + args.slice(0, args.length - 1).join(" "), args[args.length - 1]);
			}
			else
				console.log.apply(this, [">>>> [log]: "].concat(args));
		}
		if (h5_engine.LogicInterface.instance) {
			h5_engine.LogicInterface.instance.log.apply(this, args);
		}
	}

	public static logDebug(...args): void {
		if (GameLog.isTraceLog) {
			console.debug.apply(this, [">>>> [debug]: "].concat(args));
		}
		if (h5_engine.LogicInterface.instance) {
			h5_engine.LogicInterface.instance.logDebug.apply(this, args);
		}
	}

	public static logWarn(...args): void {
		if (GameLog.isTraceLog) {
			console.warn.apply(this, [">>>> [warn]: "].concat(args));
		}
		if (h5_engine.LogicInterface.instance) {
			h5_engine.LogicInterface.instance.logWarn.apply(this, args);
		}
	}

	/***
	 * 打印一些查看信息
	 * des:
	 * by: guwanyuan(顾万圆)
	 * 2016-2-27 上午3:31:38
	 ***/
	public static logInfo(...args): void {
		if (GameLog.isTraceLog) {
			console.info.apply(this, [">>>> [info]: "].concat(args));
		}
		if (h5_engine.LogicInterface.instance) {
			h5_engine.LogicInterface.instance.logInfo.apply(this, args);
		}
	}

	public static logErrorStack(error: any, str: string): void {
		// if(GameLog.isTraceLog) {
		// 	console.error(">>>> [error]: ", error.message, str);
		// 	// console.error(error.stack);
		// }
		try {
			throw new Error(error);
		} catch (e) {
			var stack: string = e.stack;
			if (h5_engine.LogicInterface.instance) {
				h5_engine.LogicInterface.instance.logError(error, stack);
			}
			if (GameLog.isTraceLog) {
				console.error(">>>> [error]: ", stack);
			}
		}
	}

	/**
	 * 打印错误信息
	 */
	public static logError(...args): string {
		var strErr: string = args.join(" ");
		if (GameLog.isTraceLog) {
			console.error(">>>> [error]: ", strErr);
		}
		try {
			throw new Error(strErr);
		} catch (e) {
			var stack: string = e.stack;
			if (h5_engine.LogicInterface.instance) {
				h5_engine.LogicInterface.instance.logError(strErr, stack);
			}
			if (GameLog.isTraceLog) {
				console.error(">>>> [error]: ", stack);
			}
			return stack;
		}
	}

}