class ByteUtils {
	public constructor() {
	}

	/**
	 * 判断 
	 * @param key
	 * @param sign
	 * @return 
	 * 
	 */		
	public static hasKey(key:number, sign:number):boolean{
		return (key & sign) > 0;
	}
}