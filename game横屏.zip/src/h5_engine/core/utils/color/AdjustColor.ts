module h5_engine {
	export class AdjustColor extends Dispose {
		private static s_arrayOfDeltaIndex:Array<number> = [
//      0     1     2     3     4     5     6     7     8     9                                        
			/*0*/0, 0.01, 0.02, 0.04, 0.05, 0.06, 0.07, 0.08, 0.1, 0.11,
				/*1*/0.12, 0.14, 0.15, 0.16, 0.17, 0.18, 0.20, 0.21, 0.22, 0.24,
					/*2*/0.25, 0.27, 0.28, 0.30, 0.32, 0.34, 0.36, 0.38, 0.40, 0.42,
				 /*3*/0.44, 0.46, 0.48, 0.5, 0.53, 0.56, 0.59, 0.62, 0.65, 0.68,
				 /*4*/0.71, 0.74, 0.77, 0.80, 0.83, 0.86, 0.89, 0.92, 0.95, 0.98,
				 /*5*/1.0, 1.06, 1.12, 1.18, 1.24, 1.30, 1.36, 1.42, 1.48, 1.54,
				 /*6*/1.60, 1.66, 1.72, 1.78, 1.84, 1.90, 1.96, 2.0, 2.12, 2.25,
				 /*7*/2.37, 2.50, 2.62, 2.75, 2.87, 3.0, 3.2, 3.4, 3.6, 3.8,
				 /*8*/4.0, 4.3, 4.7, 4.9, 5.0, 5.5, 6.0, 6.5, 6.8, 7.0,
				 /*9*/7.3, 7.5, 7.8, 8.0, 8.4, 8.7, 9.0, 9.4, 9.6, 9.8,
				 /*10*/10.0];

		private m_brightnessMatrix:ColorMatrix;
		private m_contrastMatrix:ColorMatrix;
		private m_saturationMatrix:ColorMatrix;
		private m_hueMatrix:ColorMatrix;
		private m_finalMatrix:ColorMatrix;

		/**
		 * The AdjustColor class defines various color properties to support the ColorMatrixFilter.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 * @see flash.filters.ColorMatrixFilter
		 */
		public constructor() {
			super();
		}


		/**
		 * 亮度
		 * Sets the brightness of the AdjustColor filter. The range of valid values is <code>-100</code> to <code>100</code>.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public set brightness(value:number) {
			if(this.m_brightnessMatrix == null) {
				this.m_brightnessMatrix = new ColorMatrix();
			}

			if(value != 0) {
				// brightness does not need to be denormalized
				this.m_brightnessMatrix.SetBrightnessMatrix(value);
			}
		}


		/**
		 * 对比度
		 * Sets the contrast of the AdjustColor filter. The range of valid values is <code>-100</code> to <code>100</code>.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public set contrast(value:number) {
			// denormalized contrast value
			var deNormVal:number = value;
			if(value == 0) {
				deNormVal = 127;
			} else if(value > 0) {
				deNormVal = AdjustColor.s_arrayOfDeltaIndex[(value >> 0)] * 127 + 127;
			} else {
				deNormVal = (value / 100 * 127) + 127;
			}

			if(this.m_contrastMatrix == null) {
				this.m_contrastMatrix = new ColorMatrix();
			}
			this.m_contrastMatrix.SetContrastMatrix(deNormVal);
		}


		/**
		 * 饱和度
		 * Sets the saturation of the AdjustColor filter. The range of valid values is <code>-100</code> to <code>100</code>.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public set saturation(value:number) {
			// denormalized saturation value
			var deNormVal:number = value;
			if(value == 0) {
				deNormVal = 1;
			} else if(value > 0) {
				deNormVal = 1.0 + (3 * value / 100); // max value is 4
			} else {
				deNormVal = value / 100 + 1;
			}

			if(this.m_saturationMatrix == null) {
				this.m_saturationMatrix = new ColorMatrix();
			}
			this.m_saturationMatrix.SetSaturationMatrix(deNormVal);
		}


		/**
		 * 色相
		 * Sets the hue of the AdjustColor filter. The range of valid values is <code>-180</code> to <code>180</code>.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public set hue(value:number) {
			// hue value does not need to be denormalized
			if(this.m_hueMatrix == null) {
				this.m_hueMatrix = new ColorMatrix();
			}

			if(value != 0) {
				// Convert to radian
				this.m_hueMatrix.SetHueMatrix(value * Math.PI / 180.0);
			}
		}


		/**
		 * Verifies if all four AdjustColor properties are set.
		 * @return A Boolean value that is <code>true</code> if all four AdjustColor properties have been set, <code>false</code> otherwise.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public AllValuesAreSet():boolean {
			return ((this.m_brightnessMatrix != null) && (this.m_contrastMatrix  != null) && 
						(this.m_saturationMatrix != null) && (this.m_hueMatrix != null));
		}


		/**
		 * Returns the flat array of values for all four properties.
		 * @return An array of 20 numerical values representing all four AdjustColor properties
		 * to use with the <code>flash.filters.ColorMatrixFilter</code> class.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 * @see flash.filters.ColorMatrixFilter
			  */
		public CalculateFinalFlatArray():Array<any> {
			if(this.CalculateFinalMatrix()) {
				return this.m_finalMatrix.GetFlatArray();
			}

			return null;
		}

		private CalculateFinalMatrix():Boolean {
			if(!this.AllValuesAreSet())
				return false;

			this.m_finalMatrix = new ColorMatrix();
			this.m_finalMatrix.Multiply(this.m_brightnessMatrix);
			this.m_finalMatrix.Multiply(this.m_contrastMatrix);
			this.m_finalMatrix.Multiply(this.m_saturationMatrix);
			this.m_finalMatrix.Multiply(this.m_hueMatrix);

			return true;
		}
	}
}