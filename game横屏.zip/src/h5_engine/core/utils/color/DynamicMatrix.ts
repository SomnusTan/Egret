module h5_engine {
	export class DynamicMatrix extends Dispose {
		/**
		 * Specifies that a matrix is prepended for concatenation.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public static MATRIX_ORDER_PREPEND:number = 0;


		/**
		 * Specifies that a matrix is appended for concatenation.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public static MATRIX_ORDER_APPEND:number = 1;

		/**
		* @private
		*/
		protected m_width:number = 0;
		/**
		* @private
		*/
		protected m_height:number = 0;
		/**
		* @private
		*/
		protected m_matrix:Array<any>;


		/**
		 * Constructs a matrix with the given number of rows and columns.
		 * @param width number of columns.
		 * @param height number of rows.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public constructor(width:number, height:number) {
			super();
			this.Create(width, height);
		}


		/**
		* @private
		*/
		protected Create(width:number, height:number):void {
			if(width > 0 && height > 0) {
				this.m_width = width;
				this.m_height = height;

				this.m_matrix = new Array(height);
				for(var i:number = 0; i < height; i++) {
					this.m_matrix[i] = new Array(width);
					for(var j:number = 0; j < height; j++) {
						this.m_matrix[i][j] = 0;
					}
				}
			}
		}


		/**
		* @private
		*/
		protected Destroy():void {
			this.m_matrix = null;
		}


		/**
		 * Returns the number of columns in the current matrix.
		 * @return The number of columns.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 * @see #GetHeight
		*/
		public GetWidth():number {
			return this.m_width;
		}


		/**
		 * Returns the number of rows in the current matrix.
		 * @return The number of rows.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public GetHeight():number {
			return this.m_height;
		}


		/**
		 * Returns the value at the specified zero-based row and column in the current matrix.
		 * @param row The row containing the value you want.
		 * @param col The column containing the value you want.
		 * @return number The value at the specified row and column location.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public GetValue(row:number, col:number):number {
			var value:number = 0;
			if(row >= 0 && row < this.m_height && col >= 0 && col <= this.m_width) {
				value = this.m_matrix[row][col];
			}
			return value;
		}


		/**
		 * Sets the value at a specified zero-based row and column in the current matrix.
		 * @param row The row containing the value you want to set.
		 * @param col The column containing the value you want to set.
		 * @param value The number to insert into the matrix.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public SetValue(row:number, col:number, value:number):void {
			if(row >= 0 && row < this.m_height && col >= 0 && col <= this.m_width) {
				this.m_matrix[row][col] = value;
			}
		}


		/**
		 * Sets the current matrix to an identity matrix.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 * @see flash.geom.Matrix#identity()
		*/
		public LoadIdentity():void {
			if(this.m_matrix) {
				for(var i:number = 0; i < this.m_height; i++) {
					for(var j:number = 0; j < this.m_width; j++) {
						if(i == j) {
							this.m_matrix[i][j] = 1;
						} else {
							this.m_matrix[i][j] = 0;
						}
					}
				}
			}
		}


		/**
		 * Sets all values in the current matrix to zero.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public LoadZeros():void {
			if(this.m_matrix) {
				for(var i:number = 0; i < this.m_height; i++) {
					for(var j:number = 0; j < this.m_width; j++) {
						this.m_matrix[i][j] = 0;
					}
				}
			}
		}


		/**
		 * Multiplies the current matrix with a specified matrix; and either
		 * appends or prepends the specified matrix. Use the
		 * second parameter of the <code>DynamicMatrix.Multiply()</code> method to
		 * append or prepend the specified matrix.
		 * @param inMatrix The matrix to add to the current matrix.
		 * @param order Specifies whether to append or prepend the matrix from the
		 * <code>inMatrix</code> parameter; either <code>MATRIX_ORDER_APPEND</code>
		 * or <code>MATRIX_ORDER_PREPEND</code>.
		 * @return  A boolean value indicating whether the multiplication succeeded (<code>true</code>) or
		 * failed (<code>false</code>). The value is <code>false</code> if either the current matrix or
		 * specified matrix (the <code>inMatrix</code> parameter) is null, or if the order is to append and the
		 * current matrix's width is not the same as the supplied matrix's height; or if the order is to prepend
		 * and the current matrix's height is not equal to the supplied matrix's width.
		 *
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 * @see #MATRIX_ORDER_PREPEND
		 * @see #MATRIX_ORDER_APPEND
		*/
		public Multiply(inMatrix:DynamicMatrix, order:number = DynamicMatrix.MATRIX_ORDER_PREPEND):boolean {
			if(!this.m_matrix || !inMatrix)
				return false;

			var inHeight:number = inMatrix.GetHeight();
			var inWidth:number = inMatrix.GetWidth();

			if(order == DynamicMatrix.MATRIX_ORDER_APPEND) {
				//inMatrix on the left
				if(this.m_width != inHeight)
					return false;

				var result:DynamicMatrix = new DynamicMatrix(inWidth, this.m_height);
				for(var i:number = 0; i < this.m_height; i++) {
					for(var j:number = 0; j < inWidth; j++) {
						var total:number = 0;
						for(var k:number = 0, m:number = 0; k < Math.max(this.m_height, inHeight) && m < Math.max(this.m_width, inWidth); k++, m++) {
							total = total + (inMatrix.GetValue(k, j) * this.m_matrix[i][m]);
						}

						result.SetValue(i, j, total);
					}
				}

				// destroy self and recreate with a new dimension
				this.Destroy();
				this.Create(inWidth, this.m_height);

				// assign result back to self
				for(i = 0; i < inHeight; i++) {
					for(j = 0; j < this.m_width; j++) {
						this.m_matrix[i][j] = result.GetValue(i, j);
					}
				}
			}

			else {
				// inMatrix on the right
				if(this.m_height != inWidth)
					return false;

				result = new DynamicMatrix(this.m_width, inHeight);
				for(i = 0; i < inHeight; i++) {
					for(j = 0; j < this.m_width; j++) {
						total = 0;
						for(k = 0, m = 0; k < Math.max(inHeight, this.m_height) && m < Math.max(inWidth, this.m_width); k++, m++) {
							total = total + (this.m_matrix[k][j] * inMatrix.GetValue(i, m));
						}
						result.SetValue(i, j, total);
					}
				}

				// destroy self and recreate with a new dimension
				this.Destroy();
				this.Create(this.m_width, inHeight);

				// assign result back to self
				for(i = 0; i < inHeight; i++) {
					for(j = 0; j < this.m_width; j++) {
						this.m_matrix[i][j] = result.GetValue(i, j);
					}
				}
			}

			return true;
		}



		// Multiply matrix with a value
		/**
		 * Multiplies a number with each item in the matrix and stores the results in
		 * the current matrix.
		 * @param value A number to multiply by each item in the matrix.
		 * @return A boolean value indicating whether the multiplication succeeded (<code>true</code>)
		 * or failed (<code>false</code>).
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public MultiplyNumber(value:number):boolean {
			

			if(!this.m_matrix)
				return false;

			for(var i:number = 0; i < this.m_height; i++) {
				for(var j:number = 0; j < this.m_width; j++) {
					var total:number = 0;
					total = this.m_matrix[i][j] * value;
					this.m_matrix[i][j] = total;
				}
			}

			return true;
		}



		// Add two matrices
		/**
		 * Adds the current matrix with a specified matrix. The
		 * current matrix becomes the result of the addition (in other
		 * words the <code>DynamicMatrix.Add()</code> method does
		 * not create a new matrix to contain the result).
		 * @param inMatrix The matrix to add to the current matrix.
		 * @return A boolean value indicating whether the addition succeeded (<code>true</code>)
		 * or failed (<code>false</code>). If the dimensions of the matrices are not
		 * the same, <code>DynamicMatrix.Add()</code> returns <code>false</code>.
		 * @playerversion Flash 9
		 * @playerversion AIR 1.0
		 * @productversion Flash CS3
		 * @langversion 3.0
		 */
		public Add(inMatrix:DynamicMatrix):boolean {
			

			if(!this.m_matrix || !inMatrix)
				return false;

			var inHeight:number = inMatrix.GetHeight();
			var inWidth:number = inMatrix.GetWidth();

			if(this.m_width != inWidth || this.m_height != inHeight)
				return false;

			for(var i:number = 0; i < this.m_height; i++) {
				for(var j:number = 0; j < this.m_width; j++) {
					var total:number = 0;
					total = this.m_matrix[i][j] + inMatrix.GetValue(i, j);
					this.m_matrix[i][j] = total;
				}
			}

			return true;
		}
	}
}