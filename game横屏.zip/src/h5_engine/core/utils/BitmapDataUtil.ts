class BitmapDataUtil {
	public constructor() {
	}

	public static createColorTexture(color: number, wth: number, hth: number, alpha: number = 1): egret.Texture {
		var texture: egret.RenderTexture = new egret.RenderTexture();
		var shape: h5_engine.GShape = new h5_engine.GShape();
		shape.graphics.beginFill(color, alpha);
		shape.graphics.drawRect(0, 0, wth, hth);
		shape.graphics.endFill();
		texture.drawToTexture(shape);
		return texture;
	}

	public static createTextureByClass(cls: any, rect?: egret.Rectangle): egret.Texture {
		var texture: egret.RenderTexture = new egret.RenderTexture();
		texture.drawToTexture(cls, rect);
		return texture;
	}
}