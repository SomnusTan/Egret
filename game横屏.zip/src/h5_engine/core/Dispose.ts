class Dispose extends egret.HashObject implements IDispose{
	public constructor() {
		super();
	}

	public get isDispose():boolean {
		return this._isDispose;
	}

	protected resetDispose():void
	{
		this._isDispose = false;
	}

	public dispose():void{
		this._isDispose = true;
	}

	private _isDispose:boolean = false;
}
