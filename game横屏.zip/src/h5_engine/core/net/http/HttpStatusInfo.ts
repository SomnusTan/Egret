class HttpStatusInfo 
{
	/***十、 状态码定义（status code definitions）
	 * 1. 信息1XX——
	 *    100继续
	 *    101转换协议
	 * 
	 * 2. 成功2XX——
	 *    200请求成功
	 *    201创建
	 *    202接受
	 *    203非权威信息
	 *    204无内容
	 *    205重置内容
	 *    206局部内容
	 * 
	 * 3. 重新定向3XX——
	 *    300多样选择
	 *    301永久移动
	 *    302创立
	 *    303观察别的部分
	 *    304只读
	 *    306(没有用的)
	 *    307临时重发
	 * 
	 * 4. 客户错误4xx——
	 *    400坏请求
	 *    401未授权的
	 *    402必需的支付
	 *    403禁用
	 *    404没有找到
	 *    405不被允许的方法
	 *    406不接受
	 *    407代理服务器认证所必需
	 *    408请求超时
	 *    409冲突
	 *    410停止
	 *    411必需的长度
	 *    412预处理失败
	 *    413请求实体太大
	 *    414请求的URI过长
	 *    415不被支持的媒体类型
	 *    416请求范围不满足
	 *    417期望失败
	 * 
	 * 5. 服务器错误5xx——
	 *    500服务器内部错误
	 *    501不能实现
	 *    502坏网关
	 *    503难以获得的服务
	 *    504网关超时
	 *    505 HTTP版本不支持
	 * **/
	public constructor() 
	{
	}

	public static getMessage(status:number):string 
	{
		if(!this.messageDict) 
		{
			this.initMessageDict();
		}
		let msg:string = this.messageDict.get(status);
		return msg;
	}

	private static initMessageDict():void 
	{
		this.messageDict = new HashMap();
		this.registerMessgae(100, "继续");
		this.registerMessgae(101, "转换协议");
		this.registerMessgae(200, "请求成功");
		this.registerMessgae(201, "创建");
		this.registerMessgae(202, "接受");
		this.registerMessgae(203, "非权威信息");
		this.registerMessgae(204, "无内容");
		this.registerMessgae(205, "重置内容");
		this.registerMessgae(206, "局部内容");
		this.registerMessgae(300, "多样选择");
		this.registerMessgae(301, "永久移动");
		this.registerMessgae(302, "创立");
		this.registerMessgae(303, "观察别的部分");
		this.registerMessgae(304, "只读");
		this.registerMessgae(306, "(没有用的)");
		this.registerMessgae(307, "临时重发");
		this.registerMessgae(400, "坏请求");
		this.registerMessgae(401, "未授权的");
		this.registerMessgae(402, "必需的支付");
		this.registerMessgae(403, "禁用");
		this.registerMessgae(404, "没有找到");
		this.registerMessgae(405, "不被允许的方法");
		this.registerMessgae(406, "不接受");
		this.registerMessgae(407, "代理服务器认证所必需");
		this.registerMessgae(408, "请求超时");
		this.registerMessgae(409, "冲突");
		this.registerMessgae(410, "停止");
		this.registerMessgae(411, "必需的长度");
		this.registerMessgae(412, "预处理失败");
		this.registerMessgae(413, "请求实体太大");
		this.registerMessgae(414, "请求的URI过长");
		this.registerMessgae(415, "不被支持的媒体类型");
		this.registerMessgae(416, "请求范围不满足");
		this.registerMessgae(417, "期望失败");
		this.registerMessgae(500, "服务器内部错误");
		this.registerMessgae(501, "不能实现");
		this.registerMessgae(502, "坏网关");
		this.registerMessgae(503, "难以获得的服务");
		this.registerMessgae(504, "网关超时");
		this.registerMessgae(505, "HTTP版本不支持");
	}

	private static  registerMessgae(status:number, msg:string):void 
	{
		this.messageDict.put(status,msg);
	}

	private static messageDict:HashMap;
}