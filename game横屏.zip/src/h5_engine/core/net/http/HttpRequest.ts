class HttpRequest extends egret.HashObject {
	public constructor() {
		super();
	}

	/**
	 * 发送请求
	 * url  请求地址
	 * data 请求数据
	 * responseType 指定接收已下载数据的类型 默认Text
	 * method 发送数据方式，值为“Get”或“Post”，默认为 “Post”方式。
	 * headers 给指定的HTTP请求头赋值 默认"Content-Type", "application/x-www-form-urlencoded" 
	 */
	public send(url: string, data: any = null, responseType: string = egret.HttpResponseType.TEXT, method: string = egret.HttpMethod.POST,
		headers: string[] = ["Content-Type", "application/x-www-form-urlencoded"]): void {
		this._url = url;
		this._data = data;
		this.responseType = responseType;
		this.httpMethod = method;
		this.httpHeader = headers;
		this._request = new egret.HttpRequest();
		this._request.addEventListener(egret.Event.COMPLETE, this.onRequestComplete, this);
		this._request.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onRequestIOError, this);
		this._request.addEventListener(egret.ProgressEvent.PROGRESS, this.onRequestProgress, this);
		this._request.addEventListener(egret.HTTPStatusEvent.HTTP_STATUS, this.onRequestHttpStatus, this);
		this._request.responseType = this.responseType;
		this._request.open((this._baseURL ? this._baseURL : WebParams.ip) + this.url, this.httpMethod);
		// 允许cookie跨域
		this._request.withCredentials = true;
		this._request.setRequestHeader(this.httpHeader[0], this.httpHeader[1]);
		this._requestStartTime = egret.getTimer();
		if (this.httpMethod == egret.HttpMethod.GET) {
			this._request.send();
			return;
		}
		this._request.send(data);
		GameLog.log("############ POST ##############");
		GameLog.log((this._baseURL ? this._baseURL : WebParams.ip) + this._url);
		if (DeviceUtil.IsNative)
			App.nativeBridge.log("request:" + (this._baseURL ? this._baseURL : WebParams.ip) + this._url + "[" + JSON.stringify(data) + "]");
		GameLog.log("发送数据data:", data);
		App.layer.showLoading();
		if (this.needTimeOut && Config.isDebug == false)
			App.timer.doTimeOnce(this, 5000, this.onTimeOut);
	}
	/**
	 * 请求数据返回
	 */
	private onRequestComplete(evt: egret.Event): void {
		let request: egret.HttpRequest = <egret.HttpRequest>evt.currentTarget;
		this._response = request.response;
		if (!request.response) {
			PanelOpenManager.openPanel(EnumPanelID.RETRY_CONNECT, {
				url: this._url, data: this._data, callBack: this._httpRequestCompFunc, notice: this._noticeError, baseURL: this._baseURL, needAddToken: this.needAddToken
			}, false);
		} else {
			if (this._httpRequestCompFunc) {
				var data: any = JSON.parse(request.response);
				GameLog.log("########## RESPONSE ############");
				GameLog.log("数据返回data(" + (egret.getTimer() - this._requestStartTime) + "ms):", data);
				if (DeviceUtil.IsNative)
					App.nativeBridge.log("response:" + (this._baseURL ? this._baseURL : WebParams.ip) + this._url + "[" + JSON.stringify(this._response) + "]");
				// 判断是否200
				if (ResponseUtil.checkResponseData(data, true) == false && this._noticeError) {
					Notice.showBottomCenterMessage(data.data ? data.data : data.info);
				}
				if (this._httpRequestCompFunc.param && this._httpRequestCompFunc.param.length > 0)
					this._httpRequestCompFunc.param = [data].concat(this._httpRequestCompFunc.param);
				else
					this._httpRequestCompFunc.param = [data];
				this._httpRequestCompFunc.exec();
			}
			if (PanelManager.isShowing(PanelRegister.RETRY_CONNECT))
				PanelOpenManager.removePanel(EnumPanelID.RETRY_CONNECT);
		}
		this.destroy();
		// GameLog.logError("HttpRequset Complete：post data：", request.response);
	}

	/**
	 * 网络超时
	 */
	private onTimeOut(): void {
		if (this._request)
			this._request.abort();
		PanelOpenManager.openPanel(EnumPanelID.RETRY_CONNECT, {
			url: this._url, data: this._data, callBack: this._httpRequestCompFunc, notice: this._noticeError, baseURL: this._baseURL, needAddToken: this.needAddToken
		}, false);
		this.destroy();
		GameLog.log('网络超时');
	}

	/**
	 * 网络错误
	 */
	private onRequestIOError(evt: egret.IOErrorEvent): void {
		// Notice.showBottomCenterMessage("网络连接中断，请检查移动网络或WIFI设置");
		PanelOpenManager.openPanel(EnumPanelID.RETRY_CONNECT, {
			url: this._url, data: this._data, callBack: this._httpRequestCompFunc, notice: this._noticeError, baseURL: this._baseURL, needAddToken: this.needAddToken
		}, false);
		this.destroy();
		let request: egret.HttpRequest = <egret.HttpRequest>evt.currentTarget;
		GameLog.logError(request.response);
	}

	private onRequestProgress(evt: egret.ProgressEvent): void {
		// GameLog.log("HttpRequest Progress：" + evt.bytesLoaded + "/" + evt.bytesTotal);
	}

	private onRequestHttpStatus(evt: egret.HTTPStatusEvent): void {
		this.destroy();
		GameLog.logError("HttpStatus code：" + evt.status + "msg：" + HttpStatusInfo.getMessage(evt.status));
	}

	public set responseType(value: string) {
		this._responseType = value;
	}

	public get responseType(): string {
		return this._responseType;
	}

	public set httpHeader(value: string[]) {
		this._httpHeader = value;
	}

	public get httpHeader(): string[] {
		return this._httpHeader;
	}

	public set httpMethod(value: string) {
		this._httpMethod = value;
	}

	public get httpMethod(): string {
		return this._httpMethod;
	}

	public set requestCompleteFun(value: FunctionVO) {
		this._httpRequestCompFunc = value;
	}

	public get requestCompleteFun(): FunctionVO {
		return this._httpRequestCompFunc;
	}

	public get url(): string {
		return this._url;
	}

	public set noticeError(value: boolean) {
		this._noticeError = value;
	}

	/**
	 * 请求返回的数据
	 */
	public get response(): any {
		return this._response;
	}

	public get httpRequest(): egret.HttpRequest {
		return this._request;
	}

	public set baseURL(value: string) {
		this._baseURL = value;
	}

	/**
	 * 回收
	 */
	public destroy(): void {
		App.layer.hideLoading();
		App.timer.clearTimer(this, this.onTimeOut);
		if (this._request) {
			this._request.removeEventListener(egret.Event.COMPLETE, this.onRequestComplete, this);
			this._request.removeEventListener(egret.IOErrorEvent.IO_ERROR, this.onRequestIOError, this);
			this._request.removeEventListener(egret.ProgressEvent.PROGRESS, this.onRequestProgress, this);
			this._request.removeEventListener(egret.HTTPStatusEvent.HTTP_STATUS, this.onRequestHttpStatus, this);
		}
		this._response = null;
		this._data = null;
		this._request = null;
		this._url = null;
		this._httpHeader = null;
		this._httpRequestCompFunc = null;
	}

	private _httpRequestCompFunc: FunctionVO;
	private _responseType: string = egret.HttpResponseType.TEXT;
	private _httpHeader: string[] = ["Content-Type", "application/x-www-form-urlencoded"];
	private _httpMethod: string = egret.HttpMethod.POST;
	/**请求路径 */
	private _url: string;
	/**请求发送的数据 */
	private _data: any;
	/**返回反数据 */
	private _response: any;
	/**请求配置 */
	private _request: egret.HttpRequest;
	/**是否弹错误提示 */
	private _noticeError: boolean = true;

	private _requestStartTime: number;

	private _baseURL: string;
	/**请求是否加TOKEN */
	public needAddToken: boolean;
	/**是否超时判断 */
	public needTimeOut: boolean;
}