/**
 * 对象池
 */
class ObjectPool {

	private _cls: any = undefined;
	private _pool: any[] = undefined;
	private _poolDict: HashMap = undefined;
	private _numCount: number = 0;
	private _checkDuplicate: boolean = true;

	public constructor(cls: any, checkDuplicate: boolean = true) {
		this._pool = [];
		this._cls = cls;
		this._checkDuplicate = checkDuplicate;
		if (this._checkDuplicate) {
			this._poolDict = new HashMap();
		}
	}

	get numCount(): number {
		return this._numCount;
	}

	public getObject(): any {
		var eft: any = undefined;
		if (this._pool.length > 0) {
			eft = this._pool.pop();
			if (this._checkDuplicate) {
				this._poolDict.del(eft);
			}
		}
		else {
			eft = new this._cls();
			this._numCount++;
		}
		return eft;
	}

	public push(data: any): void {
		if (data == null)
			return;
		if (this._checkDuplicate) {
			if (!this._poolDict.has(data)) {
				this._pool.push(data);
				this._poolDict.put(data, data);
			}
			else {
				GameLog.logDebug("有重复的对象入池");
			}
		}
		else {
			this._pool.push(data);
		}
	}

	public pushArr(datas: any[]): void {
		let i: number = 0, len: number = datas.length;
		for (i = 0; i < len; i++) {
			this.push(datas[i]);
		}
	}

	public static getPool(className: string): ObjectPool {
		if (this.POOL_HASH.has(className) == false) {
			var cls: any = egret.getDefinitionByName(className);
			this.POOL_HASH.put(className, new ObjectPool(cls));
		}
		return this.POOL_HASH.get(className);
	}

	/**
	 * 获取实例对象
	 */
	public static getObject(className: string): any {
		return this.getPool(className).getObject();
	}

	/**
	 * 回收实例对象
	 */
	public static recoveryObject(cls: any, obj: any): void {
		this.getPool(cls).push(obj);
	}

	private static POOL_HASH: HashMap = new HashMap();
}