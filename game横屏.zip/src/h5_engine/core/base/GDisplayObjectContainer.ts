module h5_engine {
	export class GDisplayObjectContainer extends egret.DisplayObjectContainer implements IDispose
	{
		private _isDispose:boolean = false;
		public constructor() 
		{
			super();
		}

		public get isDispose():boolean 
		{
			return this._isDispose;
		}
		
		public dispose():void{
			this._isDispose = true;
		}

		public remove():void
		{
			if(this.parent)
				this.parent.removeChild(this);
		}
	}
}