module h5_engine {
	export class GSprite extends egret.Sprite implements IDispose{
		public constructor() {
			super();
		}

		public get isDispose():boolean {
			return this._isDispose;
		}

		public dispose():void{
			this.remove();
			this._isDispose = true;
		}

		public remove():void{
			if(this.parent)
				this.parent.removeChild(this);
		}

		private _isDispose:boolean = false;
	}
}