module h5_engine {
	export class GTextField extends egret.TextField implements IDispose{
		public constructor() {
			super();
			this.touchEnabled = false;
		}

		public set htmlText(value:string){
			this.textFlow = HtmlUtil.getHtmlStr(value);
		}

		public get htmlText():string {
			if(this._htmlText){
				return this._htmlText;
			}
			return this.text;
		}

		public get isDispose():boolean {
			return this._isDispose;
		}

		public dispose():void{
			this._isDispose = true;
		}

		private _isDispose:boolean = false;
		private _htmlText:string;
	}
}