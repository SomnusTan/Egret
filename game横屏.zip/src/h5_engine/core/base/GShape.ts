module h5_engine {
	export class GShape extends egret.Shape implements IDispose{
		public constructor() {
			super();
		}

		public get isDispose():boolean {
			return this._isDispose;
		}
		
		public dispose():void	{
			this._isDispose = true;
		}

		public remove():void
		{
			if(this.parent)
				this.parent.removeChild(this);
		}

		private _isDispose:boolean = false;
	}
}