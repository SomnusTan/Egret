class GMovieClip extends egret.MovieClip implements IDispose
{

    public isDispose:boolean=false;

    public constructor() {
		super();
	}

    public init(jsonURL:string,textureURL:string,clipName:string):void
    {   
        let data = RES.getRes(jsonURL);
		let texture = RES.getRes(textureURL);
		let mcDataFactory:egret.MovieClipDataFactory = new egret.MovieClipDataFactory(data, texture);
	    this.movieClipData = mcDataFactory.generateMovieClipData(clipName);
    }

    public remove():void
    {
        if(this.parent)
            this.parent.removeChild(this);
    }

    public dispose():void
    {
        this.stop();
        this.remove();
        this.movieClipData=null;
        this.isDispose =true;
    }
}