module h5_engine
{
	export class GDisplayObject extends egret.DisplayObject implements IDispose
	{
		public constructor() 
		{
			super();
		}
		public get isDispose():boolean {
			return this._isDispose;
		}

		public dispose():void{
			this._isDispose = true;
		}

		private _isDispose:boolean = false;
	}
}