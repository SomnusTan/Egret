module h5_engine {
	export class GBitmap extends egret.Bitmap implements IDispose{
		public constructor(value?: egret.Texture) {
			super(value);
		}

		public get isDispose():boolean {
			return this._isDispose;
		}
		
		public dispose():void	{
			this._isDispose = true;
		}

		private _isDispose:boolean = false;
	}
}