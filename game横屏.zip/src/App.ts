/**
 * 应用总管理
 */
class App {
    private static _instance;

    public static layer: MainLayer;

    public static stage: egret.Stage;
    /**客户端自定义的数据管理中心 */
    public static data: ClientDataManager;
    /**全局管理类 */
    public static global: GlobalManager;
    /**时间控制器管理*/
    public static timer: TimeCenter;
    /**声音播放器管理*/
    public static sound: MusicManager;
    /**全局事件管理*/
    public static dispatcher: EventManager;
    /**全局tip管理 */
    public static res: ResManager = new ResManager();
    /**日志管理器 */
    public static log: LogManager;
    /**原生对接 */
    public static nativeBridge: NativeBridge;

    public constructor() {
    }

    public static init(stage: egret.Stage): void {
        App.stage = stage;
        App.nativeBridge = new NativeBridge();
        App.nativeBridge.init();
        App.dispatcher = new EventManager();
        App.timer = new TimeCenter(App.stage);
        App.data = new ClientDataManager();
        App.log = new LogManager();
        App.layer = new MainLayer();
        App.sound = new MusicManager();
        App.global = new GlobalManager();
        App.stage.addChild(App.layer);
        ServerTime.setServerTime(new Date().getTime());
        PanelRegister.init();
        GameManager.init();
        App.timer.doTimeLoop(this, 30000, this.onUpateTime);

        // 避免 在pc上按住鼠标移动，鼠标就会变成针型样式
        // Config.isMobile = egret.Capabilities.isMobile;
        // if (!Config.isMobile) {
        //     // let cavans: any = document.getElementsByTagName("CANVAS")[0];
        //     // cavans.style.cursor = "default";
        //     App.stage.scaleMode = egret.StageScaleMode.SHOW_ALL;
        // } else {
        //     // App.stage.scaleMode = egret.StageScaleMode.FIXED_WIDTH;
        // }
        egret.lifecycle.onPause = () => {
            if ((DeviceUtil.IsWeb && DeviceUtil.isMobile) || DeviceUtil.IsNative) {
                egret.ticker.pause();
                if (GameManager.isPlaying && GameManager.lasetGameId == EnumGameID.GAME2)
                    App.data.game2Center.SoundManager.stopBGM();
                else
                    App.sound.closeBgm(false, false);
                if (Video.instance().src && Video.instance().paused == false) {
                    Video.instance().pause();
                    Video.instance().resumeContine = true;
                }
            }
        }
        egret.lifecycle.onResume = () => {
            if ((DeviceUtil.IsWeb && DeviceUtil.isMobile) || DeviceUtil.IsNative) {
                egret.ticker.resume();
                if (GameManager.isPlaying && GameManager.lasetGameId == EnumGameID.GAME2)
                    App.data.game2Center.SoundManager.playBGM(SoundManager.bgm);
                else {
                    App.sound.playBgm(App.sound.currentBackBgms);
                }
                if (Video.instance().src && Video.instance().resumeContine) {
                    Video.instance().play();
                }
            }
        }
    }

    public static setOrientation(orientation: string): void {
        if (Config.orientation != orientation) {
            Config.orientation = orientation;
            if (DeviceUtil.IsWeb) {
                if (Config.isLocalApp) {
                    this.stage.orientation = orientation;
                    if (orientation == egret.OrientationMode.AUTO) {
                        App.stage.setContentSize(Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
                        window["ipcRenderer"].send("changeAuto");
                    }
                    else {
                        App.stage.setContentSize(Config.MAIN_HEIGHT, Config.MAIN_WIDTH);
                        window["ipcRenderer"].send("changeLandscape");
                    }
                }
                else {
                    if (DeviceUtil.isMobile == false) {
                        if (orientation == egret.OrientationMode.AUTO)
                            App.stage.setContentSize(Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
                        else
                            App.stage.setContentSize(Config.MAIN_HEIGHT, Config.MAIN_WIDTH);
                    }
                    else {
                        this.stage.orientation = orientation;
                        if (orientation == egret.OrientationMode.PORTRAIT)
                            App.stage.setContentSize(Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
                        else
                            App.stage.setContentSize(Config.MAIN_HEIGHT, Config.MAIN_WIDTH);
                    }
                }
            }
            else {
                if (Config.isLandscape == false) {
                    if (orientation == egret.OrientationMode.AUTO) {
                        App.nativeBridge.setOrientation("false");
                        App.stage.setContentSize(Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
                    }
                    else {
                        App.nativeBridge.setOrientation("true");
                        App.stage.setContentSize(Config.MAIN_HEIGHT, Config.MAIN_WIDTH);
                    }
                }
                else {
                    if (orientation == egret.OrientationMode.AUTO) {
                        App.nativeBridge.setOrientation("false");
                        App.stage.setContentSize(Config.MAIN_WIDTH, Config.MAIN_HEIGHT);
                    }
                    else {
                        App.nativeBridge.setOrientation("true");
                        App.stage.setContentSize(Config.MAIN_HEIGHT, Config.MAIN_WIDTH);
                    }
                }
            }
        }
    }

    /**
     * 资源检测释放
     */
    public static onUpateTime(): void {
        App.sound.addvanceTime();
        PanelManager.checkHidePanelDispose();
    }

}
